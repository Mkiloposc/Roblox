local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.AdminConfig)
local v_u_37 = {
	["Rewrite"] = function(p3) -- name: Rewrite
		-- upvalues: (copy) v_u_2
		local v4, v5 = string.match(p3, "^%s*([%w_%-]+)%s+(.-)%s*$")
		if v4 and (v5 and v5 ~= "") then
			local v6 = string.lower(v4)
			for _, v7 in v_u_2.RawTextCommands do
				if v7 ~= v6 then
					continue
				end
				v8 = true
			end
			local v8 = false
			if v8 then
				if string.match(v5, "^\"[^\"]*\"$") ~= nil and true or string.match(v5, "^\'[^\']*\'$") ~= nil then
					return p3
				end
				local v9 = string.gsub(v5, "\\", "\\92")
				return ("%* \"%*\""):format(v4, (string.gsub(v9, "\"", "\\34")))
			end
		end
		return p3
	end,
	["QuoteUnitNumbers"] = function(p10, p11) -- name: QuoteUnitNumbers
		local v12 = #p10
		local v13 = 1
		local v14 = {}
		local v15 = 0
		while v13 <= v12 do
			local v16 = string.sub(p10, v13, v13)
			if v16 == "\"" or v16 == "\'" then
				local v17 = string.find(p10, v16, v13 + 1, true) or v12
				local v18 = string.sub(p10, v13, v17)
				table.insert(v14, v18)
				v13 = v17 + 1
			else
				local v19
				if v13 > 1 then
					local v20 = v13 - 1
					local v21 = v13 - 1
					v19 = string.sub(p10, v20, v21)
				else
					v19 = " "
				end
				if string.match(v16, "%d") and string.match(v19, "[%s%(%[{,=]") then
					local v22 = string.match(p10, "^[%w%._]+", v13)
					local v23 = v13 + #v22 - 1
					local v24 = string.gsub(v22, "_", "")
					if tonumber(v24) == nil then
						local v25 = ("\"%*\""):format(v22)
						table.insert(v14, v25)
						if p11 then
							if v23 <= p11 then
								v15 = v15 + 2
							elseif v13 <= p11 then
								v15 = v15 + 1
							end
						end
					else
						table.insert(v14, v22)
					end
					v13 = v23 + 1
				else
					table.insert(v14, v16)
					v13 = v13 + 1
				end
			end
		end
		local v26 = table.concat(v14)
		if p11 then
			return v26, p11 + v15
		else
			return v26, nil
		end
	end,
	["Install"] = function(p27) -- name: Install
		-- upvalues: (copy) v_u_37
		local v_u_28 = p27.execute
		function p27.execute(p29, ...)
			-- upvalues: (ref) v_u_37, (copy) v_u_28
			local v30 = v_u_37.Rewrite(p29)
			if v30 == p29 then
				v30 = v_u_37.QuoteUnitNumbers(p29)
			end
			return v_u_28(v30, ...)
		end
		local v_u_31 = p27.analyze
		function p27.analyze(p32, p33, ...)
			-- upvalues: (ref) v_u_37, (copy) v_u_31
			local v34 = v_u_37.Rewrite(p32)
			if v34 ~= p32 then
				return v_u_31(v34, #v34, ...)
			end
			local v35, v36 = v_u_37.QuoteUnitNumbers(p32, p33)
			return v_u_31(v35, v36 or p33, ...)
		end
	end
}
return v_u_37
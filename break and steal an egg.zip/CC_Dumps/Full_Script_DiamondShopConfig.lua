local v1 = require(script.Parent.RideEggConfig)
local v2 = Enum.EasingDirection.Out
local v3 = Enum.EasingDirection.In
local v4 = Enum.EasingDirection.InOut
local v5 = {
	["GuiName"] = "DiamondShop",
	["ShopName"] = "GemShop",
	["ScrollName"] = "Shop"
}
local v6 = {
	["ButtonsName"] = "Buttons",
	["Default"] = "Eggs",
	["Pages"] = nil,
	["UnselectedBrightness"] = 0.55,
	["Shortcuts"] = nil,
	["ColorTween"] = nil,
	["OutWaveDuration"] = 0.3,
	["OutWaveWeightX"] = 1,
	["OutWaveWeightY"] = 1.5,
	["OutTween"] = nil,
	["OutScaleTween"] = nil,
	["OutScale"] = 0.75,
	["OutRotationRange"] = nil,
	["InStartAt"] = 0.5
}
local v7 = {
	["Eggs"] = {
		["Scroll"] = "Shop",
		["Sections"] = nil,
		["Sections"] = { "Mounted", "EggsSplitter_1" }
	},
	["Gems"] = {
		["Scroll"] = "Shop",
		["Sections"] = nil,
		["Sections"] = { "GemsSplitter_3", "GemsPacks" }
	},
	["PlotSkins"] = {
		["Scroll"] = "Plots"
	}
}
v6.Pages = v7
v6.Shortcuts = {
	{
		["Path"] = nil,
		["Tab"] = "Gems",
		["Path"] = { "TopBar", "CurrencyBar", "More" }
	}
}
v6.ColorTween = {
	["Duration"] = 0.15,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quad,
	["Direction"] = v2
}
v6.OutTween = {
	["Duration"] = 0.22,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quad,
	["Direction"] = v3
}
v6.OutScaleTween = {
	["Duration"] = 0.22,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Back,
	["Direction"] = v3
}
v6.OutRotationRange = {
	["Min"] = 6,
	["Max"] = 12
}
v5.Tabs = v6
v5.PreviewFolderName = "CrateDisplay"
v5.BuyListName = "PurchaseButtonsList"
v5.CrateImageName = "EggDisplay"
v5.SunburstName = "Sunburst"
v5.CrateNameLabel = "EggName"
v5.PreviewNames = {
	"EggDisplay",
	"Sunburst",
	"Content Preview",
	"EggName"
}
v5.ExtraPreviewNames = { "Crate Name" }
v5.OpenRotation = -8
v5.OpenRotateTween = {
	["Duration"] = 0.15,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quart,
	["Direction"] = v2
}
v5.OpenFadeTween = {
	["Duration"] = 0.15,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quart,
	["Direction"] = v2
}
v5.TopBarName = "TopBar"
v5.DecorationNames = {
	"Studs",
	"Shine",
	"InnerShine",
	"Background",
	"DiamondRain"
}
v5.ContentDelay = 0.125
v5.WaveDuration = 0.5
v5.WaveWeightX = 1
v5.WaveWeightY = 1
v5.WaveChildGap = 0.04
v5.PopFromScale = 0.6
v5.PopRotationRange = {
	["Min"] = 4,
	["Max"] = 9
}
v5.PopScaleTween = {
	["Duration"] = 0.3,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Back,
	["Direction"] = v2
}
v5.PopRotateTween = {
	["Duration"] = 0.3,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quart,
	["Direction"] = v4
}
v5.PopFadeTween = {
	["Duration"] = 0.15,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quad,
	["Direction"] = v2
}
v5.CardFromScale = 0.55
v5.CardRotationRange = {
	["Min"] = 0,
	["Max"] = 0
}
v5.ElementFromScale = 0.5
v5.ElementRotationRange = {
	["Min"] = 0,
	["Max"] = 20
}
v5.CardScaleTween = {
	["Duration"] = 0.3,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Back,
	["Direction"] = v2
}
v5.CardRotateTween = {
	["Duration"] = 0.3,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quart,
	["Direction"] = v4
}
v5.InteractAfter = 0.1
v5.SunburstSpeed = 30
v5.BobPeriod = 2.8
v5.BobAmplitude = 0.03
v5.HoverScale = 1.07
v5.HoverInTween = {
	["Duration"] = 0.3,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quart,
	["Direction"] = v2
}
v5.HoverOutTween = {
	["Duration"] = 0.3,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quart,
	["Direction"] = v2
}
v5.PressScale = 0.9
v5.PressTween = {
	["Duration"] = 0.12,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quart,
	["Direction"] = v2
}
v5.ReleaseTween = {
	["Duration"] = 0.4,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Back,
	["Direction"] = v2
}
v5.SpotlightEnabled = false
v5.DimTransparency = 0.85
v5.DimFadeSpeed = 12
v5.DimThickness = 4000
v5.SpotlightPadding = 6
v5.SpotlightCornerPx = 14
v5.SpotlightSmoothTime = 0.05
v5.SpotlightGrace = 0.12
v5.PreviewSpin = {
	["CrateDisplay"] = 40,
	["Sunburst"] = 120,
	["List"] = -25,
	["Crate Name"] = 25,
	["Content Preview"] = 0
}
v5.PreviewSpinDefault = 20
v5.HideTween = {
	["Duration"] = 0.32,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Back,
	["Direction"] = v3
}
v5.SpinHideTween = {
	["Duration"] = 0.32,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quart,
	["Direction"] = v4
}
v5.SpinShowTween = {
	["Duration"] = 0.6,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quart,
	["Direction"] = v4
}
v5.ButtonsInAt = 0.65
v5.ButtonFromScale = 0.3
v5.ButtonPopTween = {
	["Duration"] = 0.4,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Back,
	["Direction"] = v2
}
v5.ButtonPopRotation = 5
v5.ButtonRotateTween = {
	["Duration"] = 0.5,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quart,
	["Direction"] = v4
}
v5.ButtonFadeTween = {
	["Duration"] = 0.2,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quad,
	["Direction"] = v2
}
v5.ButtonStagger = 0.09
v5.ButtonsOutTween = {
	["Duration"] = 0.2,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Back,
	["Direction"] = v3
}
v5.ButtonsOutScale = 0.2
v5.ButtonFadeOutTween = {
	["Duration"] = 0.16,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Quad,
	["Direction"] = v3
}
v5.PreviewInDelay = 0.12
v5.ShowTween = {
	["Duration"] = 0.9,
	["Style"] = nil,
	["Direction"] = nil,
	["Style"] = Enum.EasingStyle.Elastic,
	["Direction"] = v2
}
v5.ShowOvershoot = 0.6
v5.DiamondRain = {
	["Sections"] = nil,
	["Name"] = "DiamondRain",
	["Image"] = "rbxassetid://99253762015679",
	["Color"] = nil,
	["Count"] = 14,
	["ZIndex"] = -1,
	["SizeMin"] = 0.07,
	["SizeMax"] = 0.2,
	["FallTimeFar"] = 5,
	["FallTimeNear"] = 2.4,
	["FarTransparency"] = 0.7,
	["NearTransparency"] = 0.2,
	["Sway"] = 0.04,
	["Spin"] = 60,
	["Sections"] = { "Mounted" },
	["Color"] = Color3.new(1, 1, 1)
}
local v8 = {
	["Enabled"] = true,
	["Name"] = "EggSparkles",
	["Image"] = "rbxassetid://12386386944",
	["Count"] = 5,
	["Spread"] = 1.25,
	["SizeMin"] = 0.12,
	["SizeMax"] = 0.26,
	["Color"] = nil,
	["BarThickness"] = 0.16,
	["GlowSize"] = 0.35,
	["GlowTransparency"] = 0.35,
	["ZIndex"] = 3,
	["PopInTween"] = nil,
	["PopOutTween"] = nil,
	["Spin"] = 90,
	["DelayMin"] = 0.2,
	["DelayMax"] = 1.4,
	["Color"] = Color3.new(1, 1, 1),
	["PopInTween"] = {
		["Duration"] = 0.25,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quad,
		["Direction"] = v2
	},
	["PopOutTween"] = {
		["Duration"] = 0.4,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quad,
		["Direction"] = v3
	}
}
v5.Sparkles = v8
v5.BuyButtons = {
	["InnerLighten"] = 0.35,
	["PoorColor"] = nil,
	["PoorInnerColor"] = nil,
	["PoorColor"] = ColorSequence.new(Color3.fromRGB(160, 160, 160), Color3.fromRGB(255, 255, 255)),
	["PoorInnerColor"] = Color3.fromRGB(255, 255, 255)
}
v5.Plots = {
	["ScrollName"] = "Plots",
	["IconName"] = "Icon",
	["SunburstName"] = "Sunburst",
	["TitleName"] = "Title",
	["BuyListName"] = "PurchaseButtonsList",
	["BuyName"] = "Buy",
	["EquippedText"] = "Equipped",
	["EquipText"] = "Equip",
	["EquippedColor"] = nil,
	["EquipColor"] = nil,
	["Cooldown"] = 0.3,
	["EquippedColor"] = ColorSequence.new(Color3.fromRGB(0, 105, 255), Color3.fromRGB(60, 185, 255)),
	["EquipColor"] = ColorSequence.new(Color3.fromRGB(21, 212, 17), Color3.fromRGB(99, 255, 26))
}
local v9 = {
	["ContainerName"] = "GemsPacks",
	["TitleName"] = "Title",
	["IconName"] = "Icon",
	["BurstImage"] = "rbxassetid://99253762015679",
	["SunrayName"] = "Sunray",
	["PurchaseName"] = "Purchase",
	["GiftName"] = "Gift",
	["TargetIconName"] = "CurrencyIcon",
	["Cooldown"] = 0.4,
	["CountPerTenfold"] = 6,
	["CountMin"] = 8,
	["CountMax"] = 24,
	["GemSize"] = 1.1,
	["ExplodeTween"] = {
		["Duration"] = 0.6,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quart,
		["Direction"] = v2
	},
	["ExplodeScaleTween"] = {
		["Duration"] = 0.45,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Back,
		["Direction"] = v2
	},
	["ExplodeDistance"] = {
		["Min"] = 0.12,
		["Max"] = 0.45
	},
	["ExplodeCurve"] = 0.35,
	["ExplodeSpin"] = 90,
	["DriftDistance"] = 0.25,
	["HoldTime"] = 0.15,
	["Stagger"] = 0.05,
	["FlyTween"] = {
		["Duration"] = 0.5,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quad,
		["Direction"] = v3
	},
	["FlyCurve"] = 0.3,
	["EndSize"] = 0.55,
	["NeonColor"] = Color3.new(1, 1, 1),
	["NeonTransparency"] = 0,
	["NeonScale"] = 1.35,
	["NeonTween"] = {
		["Duration"] = 0.35,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quart,
		["Direction"] = v2
	},
	["TallyFormat"] = "+%s",
	["TallyColor"] = Color3.fromRGB(30, 230, 60),
	["TallyWidth"] = 1,
	["TallyHeight"] = 0.7,
	["TallyGap"] = 0.15,
	["TallyPopScale"] = 1.3,
	["TallyPopTween"] = {
		["Duration"] = 0.2,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Back,
		["Direction"] = v2
	},
	["TallyLinger"] = 0.8,
	["TallyFadeTween"] = {
		["Duration"] = 0.3,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quad,
		["Direction"] = v2
	},
	["ArriveSound"] = "Pop1",
	["ArriveSoundFolder"] = "rransCustomSFX",
	["ArrivePitchStart"] = 1,
	["ArrivePitchStep"] = 0.05,
	["ArrivePitchMax"] = 1.6
}
v5.GemPacks = v9
v5.PurchaseHoldTime = 0.25
v5.Eggs = {
	["AssetsPath"] = { "Assets", "DiamondShop" },
	["TemplatesFolder"] = "Eggs",
	["Template"] = "2: LockedEgg",
	["VfxFolder"] = { "VFX", "EggHatch" },
	["VfxAttachments"] = { "EggHatchingVfx", "EggOpen" },
	["ImpactEffectName"] = "EggImpact",
	["BreakBurstEffects"] = { "Sparkles" },
	["OpenEffectName"] = "EggOpen",
	["CloseShop"] = false,
	["CloseDelay"] = 0.15,
	["SpawnDelay"] = 0.3,
	["Stagger"] = 0.15,
	["EggHeight"] = 7,
	["Radius"] = 9,
	["Spacing"] = 1.3,
	["Clearance"] = 1.1,
	["MaxRings"] = 12,
	["MaxStepUp"] = 2,
	["MaxStepDown"] = 6,
	["OriginRise"] = 0.5,
	["ArcHeight"] = 4,
	["FlightTime"] = 0.55,
	["FlightStyle"] = Enum.EasingStyle.Quart,
	["FlightDirection"] = Enum.EasingDirection.In,
	["Flips"] = 1,
	["FlyScale"] = 1,
	["TrailColor"] = Color3.new(1, 1, 1),
	["TrailWidth"] = 0.6,
	["TrailLifetime"] = 0.3,
	["TrailTransparency"] = 0.1,
	["TrailBrightness"] = 3,
	["LandLean"] = 22,
	["ShakeFrequency"] = 2.2,
	["ShakeDamping"] = 5,
	["ShakeTime"] = 1,
	["SitTime"] = 0.6,
	["Surges"] = 3,
	["SurgeFirstGap"] = 0.8,
	["SurgeSpeedup"] = 0.8,
	["SurgeRandomMin"] = 0.75,
	["SurgeRandomMax"] = 1.25,
	["SurgeShakeStart"] = 6,
	["SurgeShakeEnd"] = 16,
	["SurgeShakeFrequency"] = 9,
	["SurgeShakeDamping"] = 10,
	["SurgeShakeNudge"] = 0.05,
	["SurgeSquishTime"] = 0.25,
	["SurgeSizeDownStart"] = 0.06,
	["SurgeSizeDownEnd"] = 0.16,
	["SurgeSquishStart"] = 0.08,
	["SurgeSquishEnd"] = 0.2,
	["SurgeRingScale"] = 1.7,
	["TapGhostColor"] = Color3.new(1, 1, 1),
	["TapGhostTransparency"] = 0.25,
	["TapGhostScale"] = 1.5,
	["TapGhostTime"] = 0.35,
	["SpinStart"] = 2,
	["SpinMax"] = 28,
	["HighlightColor"] = Color3.new(1, 1, 1),
	["FinalFillTime"] = 0.2,
	["FinalFillStyle"] = Enum.EasingStyle.Quart,
	["FinalFillDirection"] = Enum.EasingDirection.Out,
	["OutlineColor"] = Color3.new(0, 0, 0),
	["OutlineTransparency"] = 0,
	["RingColor"] = Color3.new(1, 1, 1),
	["RingThickness"] = 4,
	["RingTime"] = 0.4,
	["LandRingScale"] = 2.4,
	["HatchRingScale"] = 3.2,
	["SparkleTexture"] = "rbxasset://textures/particles/sparkles_main.dds",
	["SparkleColors"] = {
		Color3.fromRGB(255, 80, 80),
		Color3.fromRGB(255, 200, 60),
		Color3.fromRGB(90, 255, 120),
		Color3.fromRGB(80, 180, 255),
		Color3.fromRGB(200, 100, 255)
	},
	["SparklesPerColor"] = 6,
	["SparkleSize"] = 0.22,
	["SparkleSpeed"] = {
		["Min"] = 3,
		["Max"] = 6
	},
	["SparkleDrag"] = 5,
	["SparkleLife"] = {
		["Min"] = 0.45,
		["Max"] = 0.8
	},
	["FlareSize"] = 1.4,
	["FlareLife"] = 0.25,
	["SurgeSound"] = nil,
	["SurgeSoundFolder"] = "rransCustomSFX",
	["SurgePitchStart"] = 1,
	["SurgePitchStep"] = 0.2,
	["RollSound"] = nil,
	["RollSoundFolder"] = "rransCustomSFX",
	["RollStartInterval"] = 0.1,
	["RollEndInterval"] = 0.011,
	["RollMaxVoices"] = 24,
	["RollCurve"] = 2,
	["RollPitchStart"] = 1,
	["RollPitchEnd"] = 1.3,
	["RollVolumeStart"] = 0.6,
	["RollVolumeEnd"] = 1.3,
	["FinaleSound"] = nil,
	["FinaleSoundFolder"] = "rransCustomSFX",
	["HatchSounds"] = { "Bell Chime 2", "Block Explode", "Reveal" },
	["HatchSoundFolder"] = "rransCustomSFX",
	["ScreenFlashTransparency"] = 0.55,
	["ScreenFlashTime"] = 0.45,
	["SquishTime"] = 0.12,
	["SquishFlatten"] = 0.3,
	["SquishWiden"] = 0.2,
	["StretchTime"] = 0.14,
	["StretchTall"] = 0.22,
	["StretchThin"] = 0.12,
	["VanishTime"] = 0.18,
	["PopSound"] = nil,
	["PopSoundFolder"] = "rransCustomSFX",
	["PitchStart"] = 1,
	["PitchStep"] = 0.06,
	["PitchMax"] = 1.8,
	["MaxEggs"] = 60
}
local v10 = {
	["Stagger"] = 0.12,
	["StartSize"] = 1.6,
	["PopTween"] = {
		["Duration"] = 0.28,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Back,
		["Direction"] = v2
	},
	["PopHold"] = 0.22,
	["PopRise"] = 0.6,
	["PopSide"] = 0.5,
	["PopTilt"] = 12,
	["FlightTween"] = {
		["Duration"] = 0.55,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quad,
		["Direction"] = v3
	},
	["CurveLift"] = 1.2,
	["CurveSide"] = 1.5,
	["EndSize"] = 0.75,
	["CounterWidth"] = 1.3,
	["CounterHeight"] = 0.5,
	["CounterAbove"] = 0.95,
	["CounterRotation"] = 0,
	["CounterPopScale"] = 1.45,
	["CounterPopTween"] = {
		["Duration"] = 0.22,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Back,
		["Direction"] = v2
	},
	["BurstScale"] = 1.7,
	["BurstTween"] = {
		["Duration"] = 0.35,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quart,
		["Direction"] = v2
	},
	["ShakeSteps"] = 5,
	["ShakeStepTime"] = 0.035,
	["ShakeDistance"] = 0.12,
	["ShakeTilt"] = 14,
	["CounterLinger"] = 0.8,
	["CounterFadeTween"] = {
		["Duration"] = 0.3,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quad,
		["Direction"] = v2
	},
	["LandSound"] = "Click Pop",
	["LandSoundFolder"] = "rransCustomSFX",
	["PitchStart"] = 1,
	["PitchStep"] = 0.06,
	["PitchMax"] = 1.8,
	["SlotSize"] = 60,
	["SlotGap"] = 5,
	["SmallSlotSize"] = 48,
	["SmallScreenHeight"] = 500,
	["BottomOffset"] = 5
}
v5.Fly = v10
v5.Inventory = {
	["Enabled"] = false,
	["ToolNameFormat"] = "%s x%d",
	["ShowIcon"] = false
}
v5.PurchaseSounds = {
	["Folder"] = "rransCustomSFX",
	["Names"] = nil,
	["Names"] = { "Collect Item", "Bell Chime 2", "Bubble Ding" }
}
local v11 = {
	["Color"] = nil,
	["FillTransparency"] = 0.2,
	["StrokeThickness"] = 3,
	["EndThickness"] = 1,
	["ExpandScale"] = 1.45,
	["GrowTween"] = nil,
	["FadeTween"] = nil,
	["Color"] = Color3.new(1, 1, 1),
	["GrowTween"] = {
		["Duration"] = 0.35,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quart,
		["Direction"] = v2
	},
	["FadeTween"] = {
		["Duration"] = 0.25,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quad,
		["Direction"] = v2
	}
}
v5.Burst = v11
v5.Confetti = {
	["Count"] = 40,
	["MaxPieces"] = 160,
	["Speed"] = nil,
	["Spread"] = 70,
	["Drag"] = 3,
	["Gravity"] = 20,
	["Spin"] = 540,
	["FlipRate"] = nil,
	["Life"] = nil,
	["FadeFrom"] = 0.65,
	["PieceWidth"] = 0.2,
	["PieceHeight"] = 0.34,
	["DotSize"] = 0.18,
	["DotChance"] = 0.3,
	["SpawnArea"] = nil,
	["Saturation"] = 0.75,
	["Brightness"] = 1,
	["Speed"] = {
		["Min"] = 7,
		["Max"] = 16
	},
	["FlipRate"] = {
		["Min"] = 6,
		["Max"] = 12
	},
	["Life"] = {
		["Min"] = 0.9,
		["Max"] = 1.5
	},
	["SpawnArea"] = Vector2.new(3, 0.6)
}
v5.DenyColor = Color3.fromRGB(255, 70, 70)
v5.DenyFlashTime = 0.5
v5.DenyShakeAngle = 6
v5.DenyShakeTime = 0.05
v5.ContentPreviewName = "Content Preview"
v5.Carousel = {
	["VisibleCount"] = 5,
	["SlotFill"] = 0.82,
	["Speed"] = 0.4,
	["EdgeScale"] = 0.8,
	["CardOffset"] = 0.35
}
v5.Rarities = {
	["Common"] = Color3.fromRGB(200, 200, 200),
	["Uncommon"] = Color3.fromRGB(90, 220, 90),
	["Rare"] = Color3.fromRGB(70, 160, 255),
	["Epic"] = Color3.fromRGB(180, 90, 255),
	["Legendary"] = Color3.fromRGB(255, 190, 40),
	["Mythic"] = Color3.fromRGB(255, 70, 90),
	["Secret"] = Color3.fromRGB(255, 255, 255)
}
local v12 = {
	{
		["Name"] = "Helper 1",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 10,
		["Power"] = 1.05,
		["Rarity"] = "Common"
	},
	{
		["Name"] = "Helper 2",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 10,
		["Power"] = 1.1,
		["Rarity"] = "Common"
	},
	{
		["Name"] = "Helper 3",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 10,
		["Power"] = 1.15,
		["Rarity"] = "Common"
	},
	{
		["Name"] = "Helper 4",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 9,
		["Power"] = 1.2,
		["Rarity"] = "Common"
	},
	{
		["Name"] = "Helper 5",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 9,
		["Power"] = 1.25,
		["Rarity"] = "Common"
	},
	{
		["Name"] = "Helper 6",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 8,
		["Power"] = 1.3,
		["Rarity"] = "Common"
	},
	{
		["Name"] = "Helper 7",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 8,
		["Power"] = 1.4,
		["Rarity"] = "Uncommon"
	},
	{
		["Name"] = "Helper 8",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 7,
		["Power"] = 1.5,
		["Rarity"] = "Uncommon"
	},
	{
		["Name"] = "Helper 9",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 6,
		["Power"] = 1.6,
		["Rarity"] = "Uncommon"
	},
	{
		["Name"] = "Helper 10",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 5,
		["Power"] = 1.75,
		["Rarity"] = "Uncommon"
	},
	{
		["Name"] = "Helper 11",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 4,
		["Power"] = 2,
		["Rarity"] = "Rare"
	},
	{
		["Name"] = "Helper 12",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 3.5,
		["Power"] = 2.25,
		["Rarity"] = "Rare"
	},
	{
		["Name"] = "Helper 13",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 3,
		["Power"] = 2.5,
		["Rarity"] = "Rare"
	},
	{
		["Name"] = "Helper 14",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 2.5,
		["Power"] = 3,
		["Rarity"] = "Rare"
	},
	{
		["Name"] = "Helper 15",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 2,
		["Power"] = 3.5,
		["Rarity"] = "Epic"
	},
	{
		["Name"] = "Helper 16",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 1.5,
		["Power"] = 4,
		["Rarity"] = "Epic"
	},
	{
		["Name"] = "Helper 17",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 1,
		["Power"] = 5,
		["Rarity"] = "Epic"
	},
	{
		["Name"] = "Helper 18",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 0.4,
		["Power"] = 7.5,
		["Rarity"] = "Legendary"
	},
	{
		["Name"] = "Helper 19",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 0.09,
		["Power"] = 12,
		["Rarity"] = "Mythic"
	},
	{
		["Name"] = "Helper 20",
		["Image"] = "rbxassetid://79739705736509",
		["Chance"] = 0.01,
		["Power"] = 25,
		["Rarity"] = "Secret"
	}
}
v5.Crates = {
	["Mounted"] = {
		["Name"] = "Mounted Egg",
		["Price"] = 1000,
		["Egg"] = "RideEgg"
	},
	["1"] = {
		["Name"] = "Basic Crate",
		["Price"] = 50
	},
	["2"] = {
		["Name"] = "Rare Crate",
		["Price"] = 250
	},
	["3"] = {
		["Name"] = "Epic Crate",
		["Price"] = 1000
	}
}
v5.Contents = {
	["Default"] = v12,
	["Mounted"] = v1.ContentsFor("Mounted"),
	["1"] = v12,
	["2"] = v12,
	["3"] = v12
}
return v5
local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.DiamondShopConfig)
local v_u_3 = {}
local v_u_4 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_15(p5) -- name: lookOf
	-- upvalues: (copy) v_u_4
	local v6 = v_u_4[p5]
	if v6 then
		return v6
	end
	local v7 = {}
	for _, v8 in p5:GetDescendants() do
		if not v8:IsA("UIGradient") or (not v8.Parent or v8.Parent ~= p5 and (not v8.Parent:IsA("UIStroke") or v8.Parent.Parent ~= p5)) then
			continue
		end
		table.insert(v7, v8)
	end
	local v9 = p5:FindFirstChildOfClass("UIGradient")
	local v10 = p5:FindFirstChild("Inner")
	local v11 = {
		["gradients"] = v7
	}
	local v12
	if v9 then
		v12 = v9.Color
	else
		v12 = nil
	end
	v11.authoredColor = v12
	local v13
	if v10 and v10:IsA("UIStroke") then
		v13 = v10
	else
		v13 = nil
	end
	v11.inner = v13
	local v14
	if v10 and v10:IsA("UIStroke") then
		v14 = v10.Color
	else
		v14 = nil
	end
	v11.authoredInner = v14
	v_u_4[p5] = v11
	return v11
end
function v_u_3.Lighter(p16) -- name: Lighter
	-- upvalues: (copy) v_u_2
	local v17 = p16.Keypoints[1].Value
	for _, v18 in p16.Keypoints do
		local v19 = v18.Value
		if v19.R + v19.G + v19.B <= v17.R + v17.G + v17.B then
			continue
		end
		v17 = v19
	end
	return v17:Lerp(Color3.new(1, 1, 1), v_u_2.BuyButtons.InnerLighten)
end
function v_u_3.Paint(p20, p21, p22) -- name: Paint
	-- upvalues: (copy) v_u_15, (copy) v_u_3
	local v23 = v_u_15(p20)
	local v24 = p21 or v23.authoredColor
	if v24 then
		for _, v25 in v23.gradients do
			v25.Color = v24
		end
	end
	if v23.inner then
		if p22 then
			v23.inner.Color = p22
			return
		end
		if p21 then
			v23.inner.Color = v_u_3.Lighter(p21)
			return
		end
		if v23.authoredInner then
			v23.inner.Color = v23.authoredInner
		end
	end
end
function v_u_3.Poor(p26) -- name: Poor
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v27 = v_u_2.BuyButtons
	v_u_3.Paint(p26, v27.PoorColor, v27.PoorInnerColor)
end
return v_u_3
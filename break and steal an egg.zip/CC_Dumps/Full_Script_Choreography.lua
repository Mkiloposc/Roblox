local v_u_1 = {}
local v_u_2 = nil
local v_u_3 = nil
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
v_u_1.staticActors = {}
v_u_1.panel = nil
v_u_1.impactDelay = nil
local v_u_11 = v_u_1.staticActors
local v_u_12 = {}
v_u_1.entranceList = v_u_12
local function v_u_15(p13) -- name: add
	-- upvalues: (copy) v_u_11
	if p13 then
		local v14 = v_u_11
		table.insert(v14, p13)
	end
	return p13
end
local function v_u_73(p16) -- name: defineAll
	-- upvalues: (ref) v_u_2, (copy) v_u_11, (copy) v_u_1, (ref) v_u_5, (ref) v_u_3, (copy) v_u_15
	local v17 = p16.Actors
	local v18 = p16.Idle
	local v19 = p16.main
	local v20 = v17.makeActor(v19)
	local v21 = v_u_2.PANEL_FROM_Y
	local v22 = v_u_2.PANEL_FROM_SCALE
	v20.pX = 0
	v20.pY = v21
	v20.pR = 0
	v20.pS = v22
	v20.pA = 1
	local v23 = v_u_2.PANEL_AT
	local v24 = v_u_2.PANEL_IN[1]
	local v25 = v_u_2.PANEL_IN[2]
	v20.inAt = v23
	v20.inF = v24
	v20.inD = v25
	local v26 = v_u_2.PANEL_OUT_AT
	local v27 = v_u_2.PANEL_OUT[1]
	local v28 = v_u_2.PANEL_OUT[2]
	v20.outAt = v26
	v20.outF = v27
	v20.outD = v28
	local v29 = v_u_2.PANEL_ALPHA_IN
	local v30 = v_u_2.PANEL_ALPHA_OUT
	v20.aInF = v29
	v20.aOutF = v30
	v20.outKick = v_u_2.PANEL_OUT_KICK
	local v31 = v_u_2.PANEL_OUT_Y
	local v32 = v_u_2.PANEL_OUT_SCALE
	v20.qY = v31
	v20.qS = v32
	v20.entrance = true
	v20.fades = true
	if v20 then
		local v33 = v_u_11
		table.insert(v33, v20)
	end
	v_u_1.panel = v20
	v17.panel = v20
	local v34 = p16.decor
	table.sort(v34, function(p35, p36)
		local v37 = p35.Position.X.Scale - 0.5
		local v38 = math.abs(v37)
		local v39 = p36.Position.X.Scale - 0.5
		local v40 = math.abs(v39)
		if p35.Name == p36.Name then
			return p35.Position.X.Scale < p36.Position.X.Scale
		else
			return v40 < v38
		end
	end)
	local v41 = {}
	local v42 = 0
	for _, v43 in ipairs(v34) do
		if not v41[v43.Name] then
			v41[v43.Name] = v42
			v42 = v42 + 1
		end
		local v44 = v43.Position.X.Scale < 0.5 and -1 or 1
		local v45 = v_u_5(v43, {
			["park"] = nil,
			["inAt"] = nil,
			["inSpring"] = nil,
			["outAt"] = nil,
			["outSpring"] = nil,
			["alphaIn"] = 8,
			["park"] = {
				-v44 * 0.02,
				0.05,
				-v44 * v_u_2.DECOR_PARK_ROT,
				0,
				1
			},
			["inAt"] = v_u_2.DECOR_AT + v41[v43.Name] * v_u_2.DECOR_STEP,
			["inSpring"] = v_u_2.DECOR_IN,
			["outAt"] = v_u_2.DECOR_OUT_AT,
			["outSpring"] = v_u_2.RIG_OUT
		})
		if v45 then
			local v46 = v_u_11
			table.insert(v46, v45)
		end
		if v43.Name == "BlackHole" then
			continue
		end
		v18.setBob(v45, v_u_3:NextNumber(v_u_2.DECOR_BOB[1], v_u_2.DECOR_BOB[2]), v_u_2.DECOR_BOB_Y, v_u_2.DECOR_BOB_R * v44, v_u_3:NextNumber(0, 6.283185307179586))
	end
	local v47 = v_u_5(p16.Header, {
		["park"] = {
			0,
			-0.04,
			0,
			1,
			1
		},
		["inAt"] = v_u_2.HEADER_AT,
		["inSpring"] = v_u_2.CONTENT_IN,
		["outAt"] = v_u_2.CONTENT_OUT_AT,
		["outSpring"] = v_u_2.CONTENT_OUT
	})
	if v47 then
		local v48 = v_u_11
		table.insert(v48, v47)
	end
	if p16.Title then
		local v49 = v_u_5(p16.Title, {
			["park"] = nil,
			["inAt"] = nil,
			["inSpring"] = nil,
			["outAt"] = nil,
			["outSpring"] = nil,
			["alphaIn"] = 8,
			["park"] = {
				0,
				-0.04,
				-8,
				v_u_2.TITLE_FROM_SCALE,
				1
			},
			["inAt"] = v_u_2.TITLE_AT,
			["inSpring"] = v_u_2.TITLE_IN,
			["outAt"] = v_u_2.TITLE_OUT_AT,
			["outSpring"] = v_u_2.CONTENT_OUT
		})
		if v49 then
			local v50 = v_u_11
			table.insert(v50, v49)
		end
		v_u_1.impactDelay = v_u_2.TITLE_AT + v_u_2.IMPACT_AFTER
	end
	table.sort(p16.inputs, function(p51, p52)
		return p51.Position.X.Scale < p52.Position.X.Scale
	end)
	for v53, v54 in ipairs(p16.inputs) do
		local v55 = v_u_5(v54, {
			["park"] = {
				0,
				0.08,
				(v53 - 2) * 6,
				0.5,
				1
			},
			["inAt"] = v_u_2.INPUT_AT + (v53 - 1) * v_u_2.INPUT_STEP,
			["inSpring"] = v_u_2.INPUT_IN,
			["outAt"] = v_u_2.CONTENT_OUT_AT + (#p16.inputs - v53) * 0.015,
			["outSpring"] = v_u_2.CONTENT_OUT
		})
		if not v55 then
			continue
		end
		local v56 = v_u_11
		table.insert(v56, v55)
	end
	for v57, v58 in ipairs(p16.bars) do
		local v59 = v_u_5(v58, {
			["park"] = {
				0,
				0.04,
				0,
				0.6,
				1
			},
			["inAt"] = v_u_2.BARS_AT + (v57 - 1) * 0.03,
			["inSpring"] = v_u_2.CONTENT_IN,
			["outAt"] = v_u_2.CONTENT_OUT_AT,
			["outSpring"] = v_u_2.CONTENT_OUT
		})
		if not v59 then
			continue
		end
		local v60 = v_u_11
		table.insert(v60, v59)
	end
	local v61 = v_u_5(p16.EnergyBall, {
		["park"] = nil,
		["inAt"] = nil,
		["inSpring"] = nil,
		["outAt"] = nil,
		["outSpring"] = nil,
		["alphaIn"] = 8,
		["park"] = {
			0,
			0,
			0,
			0,
			1
		},
		["inAt"] = v_u_2.OUTPUT_AT - 0.04,
		["inSpring"] = v_u_2.DECOR_IN,
		["outAt"] = v_u_2.CONTENT_OUT_AT,
		["outSpring"] = v_u_2.RIG_OUT
	})
	if v61 then
		local v62 = v_u_11
		table.insert(v62, v61)
	end
	local v63 = v_u_5(p16.Output, {
		["park"] = {
			0,
			0.03,
			10,
			0.3,
			1
		},
		["inAt"] = v_u_2.OUTPUT_AT,
		["inSpring"] = v_u_2.TITLE_IN,
		["outAt"] = v_u_2.CONTENT_OUT_AT,
		["outSpring"] = v_u_2.CONTENT_OUT
	})
	if v63 then
		local v64 = v_u_11
		table.insert(v64, v63)
	end
	local v65 = v_u_5(p16.Sacrifice, {
		["park"] = {
			0,
			0.02,
			0,
			0.5,
			1
		},
		["inAt"] = v_u_2.SACRIFICE_AT,
		["inSpring"] = v_u_2.BUY_IN,
		["outAt"] = v_u_2.CLOSE_OUT_AT,
		["outSpring"] = v_u_2.CONTENT_OUT
	})
	if v65 then
		local v66 = v_u_11
		table.insert(v66, v65)
	end
	local v67 = v_u_5(p16.Chances, {
		["park"] = {
			-0.06,
			0,
			0,
			0.94,
			1
		},
		["inAt"] = v_u_2.CHANCES_AT,
		["inSpring"] = v_u_2.CONTENT_IN,
		["outAt"] = v_u_2.CONTENT_OUT_AT,
		["outSpring"] = v_u_2.CONTENT_OUT
	})
	if v67 then
		local v68 = v_u_11
		table.insert(v68, v67)
	end
	local v69 = v_u_5(p16.ChancesTitle, {
		["park"] = nil,
		["inAt"] = nil,
		["inSpring"] = nil,
		["outAt"] = nil,
		["outSpring"] = nil,
		["alphaIn"] = 8,
		["park"] = {
			0,
			-0.02,
			6,
			1.5,
			1
		},
		["inAt"] = v_u_2.CHANCES_TITLE_AT,
		["inSpring"] = v_u_2.TITLE_IN,
		["outAt"] = v_u_2.TITLE_OUT_AT,
		["outSpring"] = v_u_2.CONTENT_OUT
	})
	if v69 then
		local v70 = v_u_11
		table.insert(v70, v69)
	end
	local v71 = v_u_5(p16.CloseButton, {
		["park"] = {
			0,
			0,
			-120,
			0,
			1
		},
		["inAt"] = v_u_2.CLOSE_AT,
		["inSpring"] = v_u_2.CONTENT_IN,
		["outAt"] = v_u_2.CLOSE_OUT_AT,
		["outSpring"] = v_u_2.CONTENT_OUT
	})
	if v71 then
		local v72 = v_u_11
		table.insert(v72, v71)
	end
	v18.defineTagged(p16, v_u_15, v_u_5)
end
function v_u_1.prepareOpen(p74) -- name: prepareOpen
	-- upvalues: (copy) v_u_12, (copy) v_u_1, (ref) v_u_4, (ref) v_u_9, (copy) v_u_11, (ref) v_u_8, (ref) v_u_6, (ref) v_u_10, (ref) v_u_7, (ref) v_u_2
	table.clear(v_u_12)
	v_u_1.panel.screen = v_u_4.AbsoluteSize
	v_u_9.collect()
	for _, v75 in ipairs(v_u_11) do
		if not v_u_8(v75.inst) then
			continue
		end
		v_u_6(v75)
		local v76 = v_u_12
		table.insert(v76, v75)
	end
	for _, v77 in ipairs(v_u_10) do
		v_u_6(v77)
		local v78 = v_u_12
		table.insert(v78, v77)
	end
	for _, v79 in ipairs(v_u_12) do
		v_u_7(v79)
		v79.pend = 1
		v79.pendAt = p74 + v79.inAt * v_u_2.TIME_SCALE
	end
end
function v_u_1.reopen(p80) -- name: reopen
	-- upvalues: (copy) v_u_12, (ref) v_u_2
	for _, v81 in ipairs(v_u_12) do
		v81.pend = 1
		v81.pendAt = p80 + v81.inAt * v_u_2.TIME_SCALE * v_u_2.REOPEN_DELAY
	end
end
function v_u_1.queueClose(p82) -- name: queueClose
	-- upvalues: (copy) v_u_11, (ref) v_u_8, (ref) v_u_6, (copy) v_u_12, (ref) v_u_2
	for _, v83 in ipairs(v_u_11) do
		if v83.session or not v_u_8(v83.inst) then
			continue
		end
		v_u_6(v83)
		v83.session = true
		local v84 = v_u_12
		table.insert(v84, v83)
	end
	for _, v85 in ipairs(v_u_12) do
		v85.pend = 2
		v85.pendAt = p82 + v85.outAt * v_u_2.TIME_SCALE
	end
end
function v_u_1.clearOpen() -- name: clearOpen
	-- upvalues: (copy) v_u_12, (ref) v_u_10
	table.clear(v_u_12)
	table.clear(v_u_10)
end
function v_u_1.dropActor(p86) -- name: dropActor
	-- upvalues: (copy) v_u_12, (ref) v_u_9
	local v87 = table.find(v_u_12, p86)
	if v87 then
		table.remove(v_u_12, v87)
	end
	v_u_9.forgetActor(p86)
end
function v_u_1.clear() -- name: clear
	-- upvalues: (copy) v_u_12, (copy) v_u_11, (ref) v_u_9
	table.clear(v_u_12)
	table.clear(v_u_11)
	v_u_9.clear()
end
function v_u_1.init(p88) -- name: init
	-- upvalues: (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (copy) v_u_73
	local v89 = p88.T
	local v90 = p88.rng
	local v91 = p88.gui
	v_u_2 = v89
	v_u_3 = v90
	v_u_4 = v91
	local v92 = p88.Actors.define
	local v93 = p88.Actors.refresh
	local v94 = p88.Actors.park
	v_u_5 = v92
	v_u_6 = v93
	v_u_7 = v94
	v_u_8 = p88.Actors.chainVisible
	v_u_9 = p88.Rows
	v_u_10 = v_u_9.openItems
	v_u_73(p88)
end
return v_u_1
return {
	["ShowPlayableAttributionMapper"] = {
		["UnplayableOtherReason"] = true,
		["Playable"] = true,
		["GuestProhibited"] = true,
		["GameUnapproved"] = false,
		["IncorrectConfiguration"] = false,
		["UniverseRootPlaceIsPrivate"] = false,
		["InsufficientPermissionFriendsOnly"] = true,
		["InsufficientPermissionGroupOnly"] = true,
		["DeviceRestricted"] = true,
		["UnderReview"] = true,
		["PurchaseRequired"] = true,
		["AccountRestricted"] = true,
		["TemporarilyUnavailable"] = true,
		["ComplianceBlocked"] = true,
		["ContextualPlayabilityAgeRecommendationParentalControls"] = true,
		["ContextualPlayabilityRegionalAvailability"] = true,
		["ContextualPlayabilityRegionalCompliance"] = true,
		["ContextualPlayabilityUnverifiedSeventeenPlusUser"] = true
	}
}
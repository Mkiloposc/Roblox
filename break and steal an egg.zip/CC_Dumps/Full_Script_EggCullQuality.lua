local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v3 = game:GetService("RunService")
local v4 = game:GetService("UserInputService")
local v5 = require(v2.Shared.EggConfig)
local v_u_6 = require(v2.Shared.ZoneHitboxLookup)
local v_u_7 = {}
local v_u_8 = v5.AdaptiveCull
local v_u_9 = v_u_8.Tiers
local v_u_10 = #v_u_9
local v_u_11 = 1
local v_u_12 = v_u_9[1].DistanceScale
local v_u_13 = v_u_9[1].HideDelayScale
function v_u_7.GetTier() -- name: GetTier
	-- upvalues: (ref) v_u_11
	return v_u_11
end
function v_u_7.Distance(p14) -- name: Distance
	-- upvalues: (ref) v_u_12
	return p14 * v_u_12
end
function v_u_7.HideDelay(p15) -- name: HideDelay
	-- upvalues: (ref) v_u_13
	return p15 * v_u_13
end
local v_u_16 = nil
function v_u_7.EggZone(p17) -- name: eggZone
	-- upvalues: (copy) v_u_6
	local v18 = p17:GetAttribute("ZoneIndex")
	if typeof(v18) == "number" then
		return v18
	else
		return v_u_6.GetZoneIndexAt(p17.Position)
	end
end
function v_u_7.IsHomeZoneEgg(p19) -- name: IsHomeZoneEgg
	-- upvalues: (ref) v_u_16, (copy) v_u_6
	local v20
	if v_u_16 == nil then
		v20 = false
	else
		local v21 = p19:GetAttribute("ZoneIndex")
		if typeof(v21) ~= "number" then
			v21 = v_u_6.GetZoneIndexAt(p19.Position)
		end
		v20 = v21 == v_u_16
	end
	return v20
end
function v_u_7.EggDistance(p22, p23) -- name: EggDistance
	-- upvalues: (ref) v_u_12, (copy) v_u_7
	if v_u_12 == 1 or v_u_7.IsHomeZoneEgg(p23) then
		return p22
	else
		return p22 * v_u_12
	end
end
function v_u_7.EggHideDelay(p24, p25) -- name: EggHideDelay
	-- upvalues: (ref) v_u_13, (copy) v_u_7
	if v_u_13 == 1 or v_u_7.IsHomeZoneEgg(p25) then
		return p24
	else
		return p24 * v_u_13
	end
end
local function v_u_34(p26, p27) -- name: setTier
	-- upvalues: (copy) v_u_10, (ref) v_u_11, (ref) v_u_12, (copy) v_u_9, (ref) v_u_13, (copy) v_u_1, (copy) v_u_8
	local v28 = v_u_10
	local v29 = math.clamp(p26, 1, v28)
	if v29 ~= v_u_11 then
		v_u_11 = v29
		v_u_12 = v_u_9[v29].DistanceScale
		v_u_13 = v_u_9[v29].HideDelayScale
		local v30 = v_u_1.LocalPlayer
		if v30 then
			v30:SetAttribute("EggCullTier", v29)
		end
		if v_u_8.Debug then
			local v31 = print
			local v32 = v_u_10
			local v33 = p27 + 0.5
			v31((("[EggCullQuality] tier %*/%* at %* fps (distance x%*)"):format(v29, v32, math.floor(v33), v_u_12)))
		end
	end
end
if v_u_8.Enabled and v_u_10 > 1 then
	local v_u_35 = v_u_1.LocalPlayer
	if v_u_35 then
		v_u_35:SetAttribute("EggCullTier", v_u_11)
	end
	local v_u_36 = 0.016666666666666666
	local v_u_37 = os.clock() + v_u_8.WarmupSeconds
	local v_u_38 = nil
	local v_u_39 = nil
	local v_u_40 = v_u_8.RecoverHold
	local v_u_41 = (-1 / 0)
	local v_u_42 = false
	local v_u_43 = true
	local v_u_44 = 0
	v3.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_44, (copy) v_u_35, (ref) v_u_16, (copy) v_u_6
		local v45 = os.clock()
		if v45 >= v_u_44 then
			v_u_44 = v45 + 0.25
			local v46 = v_u_35
			if v46 then
				v46 = v_u_35.Character
			end
			if v46 then
				v46 = v46:FindFirstChild("HumanoidRootPart")
			end
			if v46 and v46:IsA("BasePart") then
				v_u_16 = v_u_6.GetZoneIndexAt(v46.Position)
			end
		end
	end)
	v4.WindowFocusReleased:Connect(function()
		-- upvalues: (ref) v_u_43
		v_u_43 = false
	end)
	v4.WindowFocused:Connect(function()
		-- upvalues: (ref) v_u_43, (ref) v_u_37, (copy) v_u_8, (ref) v_u_38, (ref) v_u_39
		v_u_43 = true
		local v47 = v_u_37
		local v48 = os.clock() + v_u_8.SmoothTime * 2
		v_u_37 = math.max(v47, v48)
		v_u_38 = nil
		v_u_39 = nil
	end)
	v3.RenderStepped:Connect(function(p49)
		-- upvalues: (ref) v_u_43, (copy) v_u_8, (ref) v_u_36, (ref) v_u_37, (ref) v_u_42, (ref) v_u_41, (ref) v_u_40, (ref) v_u_39, (ref) v_u_11, (copy) v_u_10, (ref) v_u_38, (copy) v_u_34
		if v_u_43 then
			local v50 = v_u_8.MaxFrameTime
			local v51 = math.min(p49, v50)
			local v52 = -p49 / v_u_8.SmoothTime
			local v53 = 1 - math.exp(v52)
			v_u_36 = v_u_36 + (v51 - v_u_36) * v53
			local v54 = os.clock()
			if v54 >= v_u_37 then
				local v55 = 1 / v_u_36
				if v_u_42 and v54 - v_u_41 > v_u_8.RelapseWindow then
					v_u_42 = false
					v_u_40 = v_u_8.RecoverHold
				end
				if v55 < v_u_8.LowFps then
					v_u_39 = nil
					if v_u_10 <= v_u_11 then
						v_u_38 = nil
						return
					end
					if not v_u_38 then
						v_u_38 = v54
						return
					end
					if v54 - v_u_38 >= v_u_8.DowngradeHold then
						v_u_38 = nil
						if v_u_42 and v54 - v_u_41 <= v_u_8.RelapseWindow then
							local v56 = v_u_40 * 2
							local v57 = v_u_8.RecoverHoldMax
							v_u_40 = math.min(v56, v57)
						end
						v_u_42 = false
						v_u_34(v_u_11 + 1, v55)
						return
					end
				elseif v_u_8.HighFps < v55 then
					v_u_38 = nil
					if v_u_11 <= 1 then
						v_u_39 = nil
						return
					end
					if not v_u_39 then
						v_u_39 = v54
						return
					end
					if v_u_40 <= v54 - v_u_39 then
						v_u_39 = nil
						v_u_41 = v54
						v_u_42 = true
						v_u_34(v_u_11 - 1, v55)
						return
					end
				else
					v_u_38 = nil
					v_u_39 = nil
				end
			end
		else
			return
		end
	end)
end
return v_u_7
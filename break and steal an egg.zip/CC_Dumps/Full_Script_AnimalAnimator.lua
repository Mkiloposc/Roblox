local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v_u_1.Shared.EggRewards)
local v_u_3 = require(v_u_1.Shared.KeyframeRegistrar)
local v_u_4 = require(v_u_1.Shared.WaitFor)
local v_u_5 = {}
v_u_5.__index = v_u_5
local v_u_6 = { "AnimalsAnim1", "AnimalsAnim2", "RBX_ANIMSAVES" }
v_u_5.UsePublishedFallback = false
v_u_5.AnimationIds = {}
local v_u_7 = {
	["Bird"] = "rbxassetid://93597131728442",
	["Wild"] = "rbxassetid://95953778768459",
	["Fish"] = "rbxassetid://81933091997852",
	["Octopus"] = "rbxassetid://110744481730263",
	["Nautilus"] = "rbxassetid://125284578355081",
	["Snake"] = "rbxassetid://81761997293533",
	["Biped"] = "rbxassetid://93231461556916"
}
v_u_5.CLIP_KEYWORDS = {
	["Walk"] = { "walk", "swim", "run" },
	["Idle"] = { "idle" }
}
local v_u_8 = v_u_5.CLIP_KEYWORDS
local v_u_9 = {}
local v_u_10 = {}
local v_u_11 = {}
local v_u_12 = {
	0.5,
	1,
	2,
	4,
	8
}
local v_u_13 = #v_u_12 + 1
local function v_u_25(p_u_14) -- name: registerSequence
	-- upvalues: (copy) v_u_3, (copy) v_u_9, (copy) v_u_13, (copy) v_u_10, (copy) v_u_11, (copy) v_u_12
	if v_u_3.IsBlocked() then
		return nil
	end
	local v15 = v_u_9[p_u_14]
	local v16, v17
	if v15 == nil then
		v16 = nil
		v17 = true
	elseif v15.Hash then
		v16 = v15.Hash
		v17 = false
	elseif v_u_13 <= v15.Failures then
		v16 = nil
		v17 = false
	else
		v16 = nil
		if os.clock() >= v15.NextAt then
			v17 = true
		else
			v17 = false
		end
	end
	if v16 then
		return v16
	end
	if not v17 then
		return nil
	end
	local v18 = os.clock() + 8
	if v_u_10[p_u_14] and os.clock() < v18 then
		task.wait()
		local v19 = v_u_9[p_u_14]
		local v20, v21
		if v19 == nil then
			v20 = nil
			v21 = true
		elseif v19.Hash then
			v20 = v19.Hash
			v21 = false
		elseif v_u_13 <= v19.Failures then
			v20 = nil
			v21 = false
		else
			v20 = nil
			if os.clock() >= v19.NextAt then
				v21 = true
			else
				v21 = false
			end
		end
		if v20 then
			return v20
		end
		if v21 then
			continue
		end
		return nil
	end
	v_u_10[p_u_14] = true
	if p_u_14:IsA("KeyframeSequence") then
		pcall(function()
			-- upvalues: (copy) p_u_14
			p_u_14.Loop = true
		end)
	end
	local v22 = v_u_3.Register(p_u_14)
	v_u_10[p_u_14] = nil
	if v22 ~= nil then
		if not v_u_11[p_u_14] then
			v_u_11[p_u_14] = true
			p_u_14.Destroying:Once(function()
				-- upvalues: (ref) v_u_9, (copy) p_u_14, (ref) v_u_10, (ref) v_u_11
				v_u_9[p_u_14] = nil
				v_u_10[p_u_14] = nil
				v_u_11[p_u_14] = nil
			end)
		end
		v_u_9[p_u_14] = {
			["Hash"] = nil,
			["Failures"] = 0,
			["NextAt"] = 0,
			["Hash"] = v22
		}
		return v22
	end
	if v_u_3.IsBlocked() then
		return nil
	end
	local v23 = v_u_9[p_u_14]
	local v24 = (v23 and v23.Failures or 0) + 1
	if not v_u_11[p_u_14] then
		v_u_11[p_u_14] = true
		p_u_14.Destroying:Once(function()
			-- upvalues: (ref) v_u_9, (copy) p_u_14, (ref) v_u_10, (ref) v_u_11
			v_u_9[p_u_14] = nil
			v_u_10[p_u_14] = nil
			v_u_11[p_u_14] = nil
		end)
	end
	v_u_9[p_u_14] = {
		["Hash"] = nil,
		["Failures"] = nil,
		["NextAt"] = nil,
		["Failures"] = v24,
		["NextAt"] = os.clock() + (v_u_12[v24] or v_u_12[#v_u_12])
	}
	return nil
end
local v_u_26 = {
	0.25,
	0.5,
	1,
	2,
	4,
	8,
	16
}
local v_u_27 = {}
local function v_u_31(p28) -- name: resolveAnimator
	local v29 = p28:FindFirstChildOfClass("AnimationController") or p28:FindFirstChildOfClass("Humanoid")
	if v29 == nil then
		v29 = Instance.new("AnimationController")
		v29.Parent = p28
	end
	local v30 = v29:FindFirstChildOfClass("Animator")
	if v30 == nil then
		v30 = Instance.new("Animator")
		v30.Parent = v29
	end
	return v30
end
local function v_u_37(p32, p33) -- name: findSequence
	-- upvalues: (copy) v_u_8
	local v34 = v_u_8[p33]
	if v34 == nil then
		return nil
	end
	for _, v35 in ipairs(v34) do
		for _, v36 in ipairs(p32:GetChildren()) do
			if not (v36:IsA("KeyframeSequence") and string.find(v36.Name:lower(), v35, 1, true)) then
				continue
			end
			return v36
		end
	end
	return nil
end
local function v_u_44(p38, p39) -- name: findAnimationInstance
	-- upvalues: (copy) v_u_8
	if p38 == nil then
		return nil
	end
	local v40 = p38:FindFirstChild(p39)
	if v40 and (v40:IsA("Animation") and v40.AnimationId ~= "") then
		return v40
	end
	local v41 = v_u_8[p39]
	if v41 == nil then
		return nil
	end
	for _, v42 in ipairs(v41) do
		for _, v43 in ipairs(p38:GetChildren()) do
			if not v43:IsA("Animation") or (v43.AnimationId == "" or not string.find(v43.Name:lower(), v42, 1, true)) then
				continue
			end
			return v43
		end
	end
	return nil
end
local function v_u_71(p45, p46, p47, p48) -- name: resolveAnimSets
	-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_2
	local v49 = {}
	local v50 = {}
	if p45 then
		p45 = p45.AnimSet
	end
	if type(p45) ~= "string" or p45 == "" then
		p45 = nil
	end
	if p45 then
		for _, v51 in v_u_6 do
			local v52 = v_u_1:FindFirstChild(v51)
			if v52 then
				v52 = v52:FindFirstChild(p45)
			end
			if not v52 or v50[v52] then
				continue
			end
			local v53
			if v52 then
				for _, v54 in v52:GetChildren() do
					if not v54:IsA("KeyframeSequence") then
						continue
					end
					v53 = true
				end
				v53 = false
			else
				v53 = false
			end
			if not v53 then
				continue
			end
			v50[v52] = true
			table.insert(v49, v52)
		end
	end
	if p46 then
		p46 = p46:FindFirstChild("AnimSaves")
	end
	if p46 and not v50[p46] then
		local v55
		if p46 then
			for _, v56 in p46:GetChildren() do
				if not v56:IsA("KeyframeSequence") then
					continue
				end
				v55 = true
			end
			v55 = false
		else
			v55 = false
		end
		if v55 then
			v50[p46] = true
			table.insert(v49, p46)
		end
	end
	local v57 = v_u_2.FindAnimalTemplate(p47)
	if v57 then
		v57 = v57:FindFirstChild("AnimSaves")
	end
	if v57 and not v50[v57] then
		local v58
		if v57 then
			for _, v59 in v57:GetChildren() do
				if not v59:IsA("KeyframeSequence") then
					continue
				end
				v58 = true
			end
			v58 = false
		else
			v58 = false
		end
		if v58 then
			v50[v57] = true
			table.insert(v49, v57)
		end
	end
	for _, v60 in v_u_6 do
		local v61 = v_u_1:FindFirstChild(v60)
		if v61 == nil then
			continue
		end
		if p47 then
			local v62 = v61:FindFirstChild(p47)
			if v62 and not v50[v62] then
				local v63
				if v62 then
					for _, v64 in v62:GetChildren() do
						if not v64:IsA("KeyframeSequence") then
							continue
						end
						v63 = true
					end
					v63 = false
				else
					v63 = false
				end
				if v63 then
					v50[v62] = true
					table.insert(v49, v62)
				end
			end
		end
		if not p48 then
			continue
		end
		local v65 = v61:FindFirstChild(p48.Name)
		if v65 and not v50[v65] then
			local v66
			if v65 then
				for _, v67 in v65:GetChildren() do
					if not v67:IsA("KeyframeSequence") then
						continue
					end
					v66 = true
				end
				v66 = false
			else
				v66 = false
			end
			if v66 then
				v50[v65] = true
				table.insert(v49, v65)
			end
		end
		local v68 = v61:FindFirstChild(p48.Name .. "_Rig")
		if not v68 or v50[v68] then
			continue
		end
		local v69
		if v68 then
			for _, v70 in v68:GetChildren() do
				if not v70:IsA("KeyframeSequence") then
					continue
				end
				v69 = true
			end
			v69 = false
		else
			v69 = false
		end
		if not v69 then
			continue
		end
		v50[v68] = true
		table.insert(v49, v68)
	end
	return v49
end
function v_u_5.ResolveMesh(p72) -- name: ResolveMesh
	local v73 = -1
	local v74 = nil
	for _, v75 in ipairs(p72:GetDescendants()) do
		if not (v75:IsA("MeshPart") or v75:IsA("BasePart")) then
			continue
		end
		local v76 = v75.Size
		local v77 = v76.X * v76.Y * v76.Z
		if v73 >= v77 then
			continue
		end
		v74 = v75
		v73 = v77
	end
	return v74
end
function v_u_5.new(p78, p79, p80) -- name: new
	-- upvalues: (copy) v_u_5, (copy) v_u_31, (copy) v_u_4
	local v81 = v_u_5
	local v_u_82 = setmetatable({}, v81)
	v_u_82._model = p78
	v_u_82._config = p79 or {}
	v_u_82._mesh = p80 or v_u_5.ResolveMesh(p78)
	v_u_82._animator = v_u_31(p78)
	v_u_82._tracks = {}
	v_u_82._current = nil
	v_u_82._generation = 0
	v_u_82._repairAttempt = 0
	v_u_82._restartAt = {}
	if v_u_82._animator == nil then
		return v_u_82
	end
	v_u_82:_loadTracks()
	v_u_82._boneArrivals = 0
	v_u_82._boneWatch = p78.DescendantAdded:Connect(function(p83)
		-- upvalues: (copy) v_u_82, (ref) v_u_4
		if p83:IsA("Bone") then
			local v84 = v_u_82
			v84._boneArrivals = v84._boneArrivals + 1
			if not v_u_82._reloadPending then
				v_u_82._reloadPending = true
				task.spawn(function()
					-- upvalues: (ref) v_u_4, (ref) v_u_82
					v_u_4.Stable(function()
						-- upvalues: (ref) v_u_82
						return v_u_82._boneArrivals
					end, 3, 1)
					v_u_82._reloadPending = nil
					if not v_u_82._destroyed and v_u_82._model.Parent then
						v_u_82:_reload()
					end
				end)
			end
		else
			return
		end
	end)
	return v_u_82
end
function v_u_5._reload(p85) -- name: _reload
	local v86 = p85._current
	p85._generation = p85._generation + 1
	local v87 = p85._tracks
	p85._tracks = {}
	p85._current = nil
	p85._currentTrack = nil
	p85._lastRate = nil
	for _, v88 in pairs(v87) do
		v88:Stop(0)
		v88:Destroy()
	end
	p85._repairAttempt = 0
	p85:_loadTracks()
	if not p85._destroyed then
		if v86 == "Idle" then
			p85:PlayIdle()
		end
	end
end
local function v_u_95(p89) -- name: resolveFallbackId
	-- upvalues: (copy) v_u_7
	for _, v90 in p89 do
		for _, v91 in ipairs(v90:GetChildren()) do
			local v92 = v91.Name:lower()
			for v93, v94 in pairs(v_u_7) do
				if not string.find(v92, v93:lower(), 1, true) then
					continue
				end
				return v94
			end
		end
	end
	return "rbxassetid://139927001766889"
end
function v_u_5._resolveAnimationId(p96, p97, p98) -- name: _resolveAnimationId
	-- upvalues: (copy) v_u_44, (copy) v_u_2, (copy) v_u_5, (copy) v_u_37, (copy) v_u_25, (copy) v_u_3, (copy) v_u_27, (copy) v_u_95
	local v99 = v_u_44(p96._model:FindFirstChild("Animations"), p97)
	if v99 == nil then
		local v100 = p96._animalName
		local v101 = v_u_2.FindAnimalTemplate(v100)
		local v102 = v_u_44
		if v101 then
			v101 = v101:FindFirstChild("Animations")
		end
		v99 = v102(v101, p97)
	end
	if v99 then
		return v99.AnimationId
	else
		local v103 = p96._config.Animations
		if v103 then
			v103 = p96._config.Animations[p97]
		end
		if type(v103) == "string" and v103 ~= "" then
			return v103
		else
			local v104 = p96._animalName
			if v104 then
				v104 = v_u_5.AnimationIds[p96._animalName]
			end
			if v104 then
				v104 = v104[p97]
			end
			if type(v104) == "string" and v104 ~= "" then
				return v104
			else
				local v105 = false
				for _, v106 in p98 do
					local v107 = v_u_37(v106, p97)
					if v107 == nil then
						continue
					end
					local v108 = v_u_25(v107)
					if v108 ~= nil then
						return v108
					end
					v105 = true
				end
				if v105 and not v_u_3.IsBlocked() then
					local v109 = ("%*_reg_%*"):format(p96._model.Name, p97)
					local v110 = ("[AnimalAnimator] %*: could not register a \"%*\" sequence (will retry)"):format(p96._model.Name, p97)
					if not v_u_27[v109] then
						v_u_27[v109] = true
						warn(v110)
					end
				end
				if v_u_5.UsePublishedFallback then
					return v_u_95(p98)
				else
					return nil
				end
			end
		end
	end
end
function v_u_5._missingClips(p111) -- name: _missingClips
	-- upvalues: (copy) v_u_8
	local v112 = {}
	for v113 in pairs(v_u_8) do
		if p111._tracks[v113] ~= nil then
			continue
		end
		table.insert(v112, v113)
	end
	return v112
end
function v_u_5._loadTracks(p_u_114) -- name: _loadTracks
	-- upvalues: (copy) v_u_71, (copy) v_u_27
	local v115 = p_u_114._model:GetAttribute("AnimalName") or p_u_114._model.Name
	p_u_114._animalName = v115
	local v116 = p_u_114._generation
	local v117 = v_u_71(p_u_114._config, p_u_114._model, v115, p_u_114._mesh)
	for _, v118 in p_u_114:_missingClips() do
		local v119 = p_u_114:_resolveAnimationId(v118, v117)
		if p_u_114._destroyed or p_u_114._generation ~= v116 then
			return
		end
		if v119 == nil or p_u_114._tracks[v118] ~= nil then
			continue
		end
		local v_u_120 = Instance.new("Animation")
		v_u_120.Name = v118
		v_u_120.AnimationId = v119
		local v121, v122 = pcall(function()
			-- upvalues: (copy) p_u_114, (copy) v_u_120
			return p_u_114._animator:LoadAnimation(v_u_120)
		end)
		if v121 and v122 then
			if p_u_114._destroyed or p_u_114._generation ~= v116 then
				v122:Destroy()
				return
			end
			p_u_114._tracks[v118] = v122
			p_u_114:_watchTrack(v118, v122)
			if p_u_114._current ~= v118 then
				continue
			end
			p_u_114:_assert(v118)
		else
			local v123 = ("%*_load_%*"):format(p_u_114._model.Name, v118)
			local v124 = ("[AnimalAnimator] %*: failed to load \"%*\""):format(p_u_114._model.Name, v118)
			if v_u_27[v123] then
				continue
			end
			v_u_27[v123] = true
			warn(v124)
		end
	end
	if p_u_114._generation == v116 and #p_u_114:_missingClips() > 0 then
		p_u_114:_scheduleRepair()
	end
end
function v_u_5._scheduleRepair(p_u_125) -- name: _scheduleRepair
	-- upvalues: (copy) v_u_3, (copy) v_u_5, (copy) v_u_26
	if p_u_125._destroyed or p_u_125._repairPending then
		return
	else
		local v126 = p_u_125._repairAttempt + 1
		if v126 <= 10 or (not v_u_3.IsBlocked() or v_u_5.UsePublishedFallback) then
			local v127 = v_u_26[v126] or v_u_26[#v_u_26]
			p_u_125._repairAttempt = v126
			p_u_125._repairPending = true
			task.delay(v127, function()
				-- upvalues: (copy) p_u_125
				p_u_125._repairPending = nil
				if not p_u_125._destroyed and #p_u_125:_missingClips() ~= 0 then
					if p_u_125._model.Parent == nil then
						p_u_125._unparentedRepairs = (p_u_125._unparentedRepairs or 0) + 1
						if p_u_125._unparentedRepairs >= 2 then
							return
						end
					else
						p_u_125._unparentedRepairs = 0
					end
					p_u_125:_loadTracks()
				end
			end)
		end
	end
end
function v_u_5._watchData(p_u_128, p_u_129, p_u_130) -- name: _watchData
	-- upvalues: (copy) v_u_4
	if p_u_130.Length <= 0 then
		task.spawn(function()
			-- upvalues: (ref) v_u_4, (copy) p_u_128, (copy) p_u_130, (copy) p_u_129
			v_u_4.Until(function()
				-- upvalues: (ref) p_u_128, (ref) p_u_130
				return p_u_128._destroyed or p_u_130.Length > 0
			end, 10)
			if not p_u_128._destroyed and p_u_128._tracks[p_u_129] == p_u_130 then
				p_u_130.Looped = true
				if p_u_128._current == p_u_129 then
					p_u_128:_assert(p_u_129)
				end
			end
		end)
	end
end
function v_u_5._watchTrack(p_u_131, p_u_132, p_u_133) -- name: _watchTrack
	p_u_131:_watchData(p_u_132, p_u_133)
	p_u_133.Stopped:Connect(function()
		-- upvalues: (copy) p_u_131, (copy) p_u_132, (copy) p_u_133
		if p_u_131._destroyed or (p_u_131._current ~= p_u_132 or p_u_131._tracks[p_u_132] ~= p_u_133) then
			return
		else
			local v134 = os.clock()
			local v135 = (p_u_131._restartAt[p_u_132] or 0) - v134
			local v136 = math.max(v135, 0)
			p_u_131._restartAt[p_u_132] = v134 + v136 + 0.5
			if v136 <= 0 then
				p_u_131:_assert(p_u_132)
			else
				task.delay(v136, function()
					-- upvalues: (ref) p_u_131, (ref) p_u_132, (ref) p_u_133
					if p_u_131._tracks[p_u_132] == p_u_133 then
						p_u_131:_assert(p_u_132)
					end
				end)
			end
		end
	end)
end
function v_u_5._assert(p137, p138) -- name: _assert
	if p137._destroyed or p137._current ~= p138 then
		return
	else
		local v139 = p137._tracks[p138]
		if v139 == nil or p137._model.Parent == nil then
			return
		else
			if not v139.Looped then
				v139.Looped = true
			end
			if not v139.IsPlaying then
				v139:Play(0.2)
				p137._currentTrack = v139
				p137._lastRate = nil
				p137._verifyAt = os.clock() + 0.25
			end
		end
	end
end
function v_u_5._switchTo(p140, p141) -- name: _switchTo
	local v142 = p140._tracks[p141]
	p140:_stopCurrent()
	p140._current = p141
	if v142 == nil then
		return false
	end
	v142.Looped = true
	v142:AdjustSpeed(1)
	v142:Play(0.2)
	p140._currentTrack = v142
	p140._lastRate = 1
	p140._verifyAt = os.clock() + 0.25
	return true
end
function v_u_5.PlayRun(p143, p144) -- name: PlayRun
	local v145 = p143._tracks.Walk
	if v145 == nil then
		p143:PlayIdle()
		return
	end
	local v146 = p144 / (p143._config.AnimationBaseWalkSpeed or 7)
	local v147 = math.max(v146, 0.01)
	if p143._current ~= "Walk" then
		if p143:_switchTo("Walk") then
			v145:AdjustSpeed(v147)
			p143._lastRate = v147
		end
		return
	end
	local v148
	if p143._lastRate == nil then
		v145:AdjustSpeed(v147)
		p143._lastRate = v147
		v148 = os.clock()
		if (p143._verifyAt or 0) <= v148 then
			p143._verifyAt = v148 + 0.25
			if not v145.IsPlaying then
				p143:_assert("Walk")
				v145:AdjustSpeed(v147)
				p143._lastRate = v147
			end
		end
		return
	else
		local v149 = v147 - p143._lastRate
		if math.abs(v149) > 0.02 then
			v145:AdjustSpeed(v147)
			p143._lastRate = v147
			v148 = os.clock()
			if (p143._verifyAt or 0) <= v148 then
				p143._verifyAt = v148 + 0.25
				if not v145.IsPlaying then
					p143:_assert("Walk")
					v145:AdjustSpeed(v147)
					p143._lastRate = v147
				end
			end
		else
			v148 = os.clock()
			if (p143._verifyAt or 0) <= v148 then
				p143._verifyAt = v148 + 0.25
				if not v145.IsPlaying then
					p143:_assert("Walk")
					v145:AdjustSpeed(v147)
					p143._lastRate = v147
				end
			end
		end
	end
end
function v_u_5.PlayIdle(p150) -- name: PlayIdle
	if p150._current == "Idle" then
		p150:_assert("Idle")
	else
		p150:_switchTo("Idle")
	end
end
function v_u_5.Stop(p151) -- name: Stop
	p151:_stopCurrent()
	p151._current = nil
end
function v_u_5._stopCurrent(p152) -- name: _stopCurrent
	if p152._currentTrack then
		p152._currentTrack:Stop(0.2)
	end
	p152._current = nil
	p152._currentTrack = nil
	p152._lastRate = nil
end
function v_u_5.Destroy(p153) -- name: Destroy
	p153._destroyed = true
	p153._generation = p153._generation + 1
	if p153._boneWatch then
		p153._boneWatch:Disconnect()
		p153._boneWatch = nil
	end
	for _, v154 in pairs(p153._tracks) do
		v154:Stop(0)
		v154:Destroy()
	end
	p153._tracks = {}
	p153._current = nil
	p153._currentTrack = nil
end
return v_u_5
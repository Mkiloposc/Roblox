local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = require(v1.Shared.CameraFovConfig)
local v4 = {}
local v_u_5 = nil
local v_u_6 = {}
local v_u_7 = false
local v_u_8 = 0
local v_u_9 = nil
local v_u_10 = false
local function v_u_24() -- name: onFovChanged
	-- upvalues: (ref) v_u_7, (copy) v_u_6, (ref) v_u_8, (copy) v_u_3, (copy) v_u_2, (ref) v_u_5
	if not v_u_7 and next(v_u_6) == nil then
		v_u_8 = v_u_8 + 1
		local v_u_11 = v_u_8
		task.delay(v_u_3.StrayResetDelay, function()
			-- upvalues: (copy) v_u_11, (ref) v_u_8, (ref) v_u_6, (ref) v_u_2, (ref) v_u_5, (ref) v_u_3, (ref) v_u_7
			if v_u_11 == v_u_8 and next(v_u_6) == nil then
				local v12 = v_u_2.CurrentCamera
				if v12 ~= nil then
					local v13 = v12.FieldOfView
					if v_u_5 == nil then
						local v14 = v_u_2.CurrentCamera
						local v15
						if v14 == nil then
							v15 = v_u_3.DefaultFov
						else
							v15 = v14.FieldOfView
						end
						v_u_5 = v15
					end
					local v16 = v13 - v_u_5
					if math.abs(v16) > 0.01 then
						local v17 = v_u_2.CurrentCamera
						if v17 == nil then
							return
						end
						v_u_7 = true
						if v_u_5 == nil then
							local v18 = v_u_2.CurrentCamera
							local v19
							if v18 == nil then
								v19 = v_u_3.DefaultFov
							else
								v19 = v18.FieldOfView
							end
							v_u_5 = v19
						end
						local v20 = v_u_5
						for _, v21 in v_u_6 do
							v20 = v20 + v21
						end
						local v22 = v_u_3.MinFov
						local v23 = v_u_3.MaxFov
						v17.FieldOfView = math.clamp(v20, v22, v23)
						v_u_7 = false
					end
				end
			end
		end)
	end
end
local function v_u_33() -- name: watchCamera
	-- upvalues: (ref) v_u_9, (copy) v_u_2, (copy) v_u_24, (ref) v_u_7, (ref) v_u_5, (copy) v_u_3, (copy) v_u_6
	if v_u_9 ~= nil then
		v_u_9:Disconnect()
		v_u_9 = nil
	end
	local v25 = v_u_2.CurrentCamera
	if v25 == nil then
		return
	else
		v_u_9 = v25:GetPropertyChangedSignal("FieldOfView"):Connect(v_u_24)
		local v26 = v_u_2.CurrentCamera
		if v26 ~= nil then
			v_u_7 = true
			if v_u_5 == nil then
				local v27 = v_u_2.CurrentCamera
				local v28
				if v27 == nil then
					v28 = v_u_3.DefaultFov
				else
					v28 = v27.FieldOfView
				end
				v_u_5 = v28
			end
			local v29 = v_u_5
			for _, v30 in v_u_6 do
				v29 = v29 + v30
			end
			local v31 = v_u_3.MinFov
			local v32 = v_u_3.MaxFov
			v26.FieldOfView = math.clamp(v29, v31, v32)
			v_u_7 = false
		end
	end
end
function v4.Set(p34, p35) -- name: Set
	-- upvalues: (ref) v_u_5, (copy) v_u_2, (copy) v_u_3, (copy) v_u_6, (ref) v_u_8, (ref) v_u_7
	if v_u_5 == nil then
		local v36 = v_u_2.CurrentCamera
		local v37
		if v36 == nil then
			v37 = v_u_3.DefaultFov
		else
			v37 = v36.FieldOfView
		end
		v_u_5 = v37
	end
	if math.abs(p35) < 0.001 then
		v_u_6[p34] = nil
	else
		v_u_6[p34] = p35
	end
	v_u_8 = v_u_8 + 1
	local v38 = v_u_2.CurrentCamera
	if v38 ~= nil then
		v_u_7 = true
		if v_u_5 == nil then
			local v39 = v_u_2.CurrentCamera
			local v40
			if v39 == nil then
				v40 = v_u_3.DefaultFov
			else
				v40 = v39.FieldOfView
			end
			v_u_5 = v40
		end
		local v41 = v_u_5
		for _, v42 in v_u_6 do
			v41 = v41 + v42
		end
		local v43 = v_u_3.MinFov
		local v44 = v_u_3.MaxFov
		v38.FieldOfView = math.clamp(v41, v43, v44)
		v_u_7 = false
	end
end
function v4.Clear(p45) -- name: Clear
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (ref) v_u_7, (ref) v_u_5, (copy) v_u_3
	if v_u_6[p45] == nil then
		return
	else
		v_u_6[p45] = nil
		local v46 = v_u_2.CurrentCamera
		if v46 ~= nil then
			v_u_7 = true
			if v_u_5 == nil then
				local v47 = v_u_2.CurrentCamera
				local v48
				if v47 == nil then
					v48 = v_u_3.DefaultFov
				else
					v48 = v47.FieldOfView
				end
				v_u_5 = v48
			end
			local v49 = v_u_5
			for _, v50 in v_u_6 do
				v49 = v49 + v50
			end
			local v51 = v_u_3.MinFov
			local v52 = v_u_3.MaxFov
			v46.FieldOfView = math.clamp(v49, v51, v52)
			v_u_7 = false
		end
	end
end
function v4.Reset() -- name: Reset
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (ref) v_u_7, (ref) v_u_5, (copy) v_u_3
	table.clear(v_u_6)
	local v53 = v_u_2.CurrentCamera
	if v53 ~= nil then
		v_u_7 = true
		if v_u_5 == nil then
			local v54 = v_u_2.CurrentCamera
			local v55
			if v54 == nil then
				v55 = v_u_3.DefaultFov
			else
				v55 = v54.FieldOfView
			end
			v_u_5 = v55
		end
		local v56 = v_u_5
		for _, v57 in v_u_6 do
			v56 = v56 + v57
		end
		local v58 = v_u_3.MinFov
		local v59 = v_u_3.MaxFov
		v53.FieldOfView = math.clamp(v56, v58, v59)
		v_u_7 = false
	end
end
function v4.GetOriginal() -- name: GetOriginal
	-- upvalues: (ref) v_u_5, (copy) v_u_2, (copy) v_u_3
	if v_u_5 == nil then
		local v60 = v_u_2.CurrentCamera
		local v61
		if v60 == nil then
			v61 = v_u_3.DefaultFov
		else
			v61 = v60.FieldOfView
		end
		v_u_5 = v61
	end
	return v_u_5
end
function v4.Start() -- name: Start
	-- upvalues: (ref) v_u_10, (ref) v_u_5, (copy) v_u_2, (copy) v_u_3, (ref) v_u_9, (copy) v_u_24, (ref) v_u_7, (copy) v_u_6, (copy) v_u_33
	if not v_u_10 then
		v_u_10 = true
		if v_u_5 == nil then
			local v62 = v_u_2.CurrentCamera
			local v63
			if v62 == nil then
				v63 = v_u_3.DefaultFov
			else
				v63 = v62.FieldOfView
			end
			v_u_5 = v63
		end
		if v_u_9 ~= nil then
			v_u_9:Disconnect()
			v_u_9 = nil
		end
		local v64 = v_u_2.CurrentCamera
		if v64 ~= nil then
			v_u_9 = v64:GetPropertyChangedSignal("FieldOfView"):Connect(v_u_24)
			local v65 = v_u_2.CurrentCamera
			if v65 ~= nil then
				v_u_7 = true
				if v_u_5 == nil then
					local v66 = v_u_2.CurrentCamera
					local v67
					if v66 == nil then
						v67 = v_u_3.DefaultFov
					else
						v67 = v66.FieldOfView
					end
					v_u_5 = v67
				end
				local v68 = v_u_5
				for _, v69 in v_u_6 do
					v68 = v68 + v69
				end
				local v70 = v_u_3.MinFov
				local v71 = v_u_3.MaxFov
				v65.FieldOfView = math.clamp(v68, v70, v71)
				v_u_7 = false
			end
		end
		v_u_2:GetPropertyChangedSignal("CurrentCamera"):Connect(v_u_33)
	end
end
return v4
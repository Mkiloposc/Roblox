local v_u_1 = {}
local v_u_2 = {
	["live"] = 0
}
v_u_1.state = v_u_2
local v_u_3 = nil
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = -1
local v_u_10 = -1
local v_u_11 = 0
local v_u_12 = false
function v_u_1.play(p13) -- name: play
	-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_9, (ref) v_u_10, (copy) v_u_2
	if v_u_5 and v_u_6 then
		v_u_9 = -p13
		v_u_10 = -1
		v_u_2.live = 1
	end
end
function v_u_1.step(p14) -- name: step
	-- upvalues: (ref) v_u_9, (ref) v_u_8, (ref) v_u_7, (copy) v_u_1, (ref) v_u_10, (ref) v_u_5, (ref) v_u_11, (ref) v_u_4, (ref) v_u_3, (ref) v_u_6
	v_u_9 = v_u_9 + p14
	if v_u_9 < 0 then
		return
	else
		local v15 = v_u_9 * v_u_8
		local v16 = math.floor(v15) + 1
		if v_u_7 < v16 then
			v_u_1.hideAll()
		else
			if v_u_10 == -1 then
				v_u_5.Rotation = v_u_11 + v_u_4:NextNumber(-v_u_3.BURST_ROT, v_u_3.BURST_ROT)
				v_u_5.ImageRectOffset = v_u_6[1]
				v_u_5.Visible = true
			end
			if v16 ~= v_u_10 then
				v_u_10 = v16
				v_u_5.ImageRectOffset = v_u_6[v16]
			end
		end
	end
end
function v_u_1.hideAll() -- name: hideAll
	-- upvalues: (copy) v_u_2, (ref) v_u_9, (ref) v_u_5, (ref) v_u_10, (ref) v_u_12, (ref) v_u_11, (ref) v_u_6
	if v_u_2.live ~= 0 then
		v_u_2.live = 0
		v_u_9 = -1
		if v_u_5 and v_u_10 ~= -1 then
			v_u_5.Visible = v_u_12
			v_u_5.Rotation = v_u_11
			v_u_5.ImageRectOffset = v_u_6[1]
		end
		v_u_10 = -1
	end
end
function v_u_1.init(p17) -- name: init
	-- upvalues: (ref) v_u_3, (ref) v_u_4, (copy) v_u_2, (ref) v_u_9, (ref) v_u_10, (ref) v_u_6, (ref) v_u_5, (ref) v_u_11, (ref) v_u_12, (ref) v_u_8, (ref) v_u_7
	local v18 = p17.T
	local v19 = p17.rng
	v_u_3 = v18
	v_u_4 = v19
	v_u_2.live = 0
	v_u_9 = -1
	v_u_10 = -1
	v_u_6 = nil
	v_u_5 = p17.OpeningBurst
	if not v_u_5 then
		return
	end
	p17.Actors.noFade[v_u_5] = true
	local v20 = v_u_5.Rotation
	local v21 = v_u_5.Visible
	v_u_11 = v20
	v_u_12 = v21
	local v22 = v_u_5:GetAttribute("Cells")
	v_u_8 = v_u_5:GetAttribute("FPS")
	local v23 = v_u_5.ImageRectSize
	if typeof(v22) == "Vector2" then
		local v24 = v_u_8
		if type(v24) == "number" and (v_u_8 > 0 and v23.X > 0) then
			v_u_6 = p17.Sprites.offsetsFor(v22, v23, false)
			local v25 = v_u_5:GetAttribute("Frames")
			local v26
			if type(v25) == "number" and v25 >= 1 then
				local v27 = math.floor(v25)
				local v28 = #v_u_6
				v26 = math.min(v27, v28)
				if v26 then
					v_u_7 = v26
				else
					v26 = #v_u_6
					v_u_7 = v26
				end
			else
				v26 = #v_u_6
				v_u_7 = v26
				return
			end
		else
			v_u_5 = nil
			return
		end
	else
		v_u_5 = nil
		return
	end
end
return v_u_1
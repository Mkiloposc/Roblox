local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v_u_1.Shared.AnimalWalkerTemplate)
local v_u_3 = require(v_u_1.Shared.CollisionGroups)
local v_u_4 = require(v_u_1.Shared.ModelScaler)
local v_u_5 = {
	["WALKER_NAME"] = "R6"
}
local v_u_6 = {
	["BodyHitbox"] = true,
	["MouthPoint"] = true
}
local v_u_7 = { "BodyHitbox", "BodyCenter" }
local function v_u_12(p8, p9) -- name: ensureWeld
	for _, v10 in ipairs(p9:GetChildren()) do
		if not v10:IsA("WeldConstraint") or (v10.Part0 ~= p8 or v10.Part1 ~= p9) and (v10.Part0 ~= p9 or v10.Part1 ~= p8) then
			continue
		end
		return
	end
	local v11 = Instance.new("WeldConstraint")
	v11.Name = "WalkerWeld"
	v11.Part0 = p8
	v11.Part1 = p9
	v11.Parent = p9
end
function v_u_5.Hide(p13) -- name: Hide
	for _, v14 in ipairs(p13:GetDescendants()) do
		if v14:IsA("BasePart") then
			v14.Transparency = 1
		else
			if not (v14:IsA("Decal") or v14:IsA("Texture")) then
				continue
			end
			v14.Transparency = 1
		end
	end
end
function v_u_5.Find(p15) -- name: Find
	for _, v16 in ipairs(p15:GetChildren()) do
		if not v16:IsA("Model") then
			continue
		end
		local v17 = v16:FindFirstChildOfClass("Humanoid")
		local v18 = v16:FindFirstChild("HumanoidRootPart")
		if v17 == nil or (v18 == nil or not v18:IsA("BasePart")) then
			continue
		end
		return v16
	end
	return nil
end
function v_u_5.ResolveHitPart(p19, p20, p21) -- name: ResolveHitPart
	-- upvalues: (copy) v_u_7
	for _, v22 in ipairs(v_u_7) do
		local v23 = p19:FindFirstChild(v22)
		if v23 == nil or (not v23:IsA("BasePart") or p20 ~= nil and v23:IsDescendantOf(p20)) then
			continue
		end
		return v23
	end
	local v24 = -1
	local v25 = nil
	for _, v26 in ipairs(p19:GetDescendants()) do
		if not v26:IsA("BasePart") or p20 ~= nil and v26:IsDescendantOf(p20) then
			continue
		end
		local v27 = v26.Size
		local v28 = v27.X * v27.Y * v27.Z
		if v24 >= v28 then
			continue
		end
		v25 = v26
		v24 = v28
	end
	return v25 or p21
end
function v_u_5.HitDistanceXZ(p29, p30) -- name: HitDistanceXZ
	local v31 = p29.CFrame:PointToObjectSpace(p30)
	local v32 = p29.Size * 0.5
	local v33 = v31.X
	local v34 = math.abs(v33) - v32.X
	local v35 = math.max(v34, 0)
	local v36 = v31.Z
	local v37 = math.abs(v36) - v32.Z
	local v38 = math.max(v37, 0)
	local v39 = v35 * v35 + v38 * v38
	return math.sqrt(v39)
end
local v_u_40 = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_5.Build(p41, p_u_42) -- name: Build
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_12, (copy) v_u_40
	local v43 = p_u_42:FindFirstChildOfClass("Humanoid")
	local v_u_44 = p_u_42:FindFirstChild("HumanoidRootPart")
	local v45 = p_u_42:GetFullName() .. " has no Humanoid"
	assert(v43, v45)
	local v46
	if v_u_44 then
		v46 = v_u_44:IsA("BasePart")
	else
		v46 = v_u_44
	end
	local v47 = p_u_42:GetFullName() .. " has no HumanoidRootPart"
	assert(v46, v47)
	for _, v_u_48 in ipairs(p_u_42:GetDescendants()) do
		if v_u_48:IsA("BasePart") then
			v_u_48.Anchored = false
			v_u_48.Transparency = 1
			v_u_48.CanQuery = false
			v_u_48.CanTouch = false
			local function v49()
				-- upvalues: (copy) v_u_48, (ref) v_u_3
				v_u_48.CollisionGroup = v_u_3.Animals
			end
			pcall(v49)
		else
			if not (v_u_48:IsA("Decal") or v_u_48:IsA("Texture")) then
				continue
			end
			v_u_48.Transparency = 1
		end
	end
	p_u_42.PrimaryPart = v_u_44
	local v50 = {}
	local v51 = {}
	for _, v52 in ipairs(p41:GetDescendants()) do
		if v52:IsDescendantOf(p_u_42) or not v52:IsA("BasePart") then
			continue
		end
		if v52.Name == "HumanoidRootPart" then
			table.insert(v51, v52)
		else
			table.insert(v50, v52)
		end
	end
	for _, v53 in ipairs(v51) do
		v53:Destroy()
	end
	for _, v_u_54 in ipairs(v50) do
		v_u_54.Anchored = false
		v_u_54.CanCollide = false
		v_u_54.Massless = true
		v_u_54.CanQuery = v_u_6[v_u_54.Name] == true
		v_u_54.CanTouch = false
		local function v55()
			-- upvalues: (copy) v_u_54, (ref) v_u_3
			v_u_54.CollisionGroup = v_u_3.Animals
		end
		pcall(v55)
		v_u_12(v_u_44, v_u_54)
	end
	local v56 = v_u_40[p41]
	if v56 then
		v_u_40[p41] = nil
		for _, v57 in v56 do
			v57:Disconnect()
		end
	end
	local v_u_58 = {}
	v_u_40[p41] = v_u_58
	local v59 = p41.DescendantAdded
	local function v62(p_u_60)
		-- upvalues: (copy) p_u_42, (ref) v_u_3, (ref) v_u_12, (copy) v_u_44
		if p_u_60:IsA("BasePart") and not p_u_60:IsDescendantOf(p_u_42) then
			p_u_60.CanCollide = false
			p_u_60.Massless = true
			local function v61()
				-- upvalues: (copy) p_u_60, (ref) v_u_3
				p_u_60.CollisionGroup = v_u_3.Animals
			end
			pcall(v61)
			v_u_12(v_u_44, p_u_60)
		end
	end
	table.insert(v_u_58, v59:Connect(v62))
	local v63 = p41.Destroying
	table.insert(v_u_58, v63:Once(function()
		-- upvalues: (copy) v_u_58
		for _, v64 in v_u_58 do
			v64:Disconnect()
		end
	end))
	p41.PrimaryPart = v_u_44
	p41:SetAttribute("RigMode", "Walker")
	v43.AutoRotate = true
	v43.PlatformStand = false
	v43.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
	v43.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
	v43:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
	v43:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false)
	v43:SetStateEnabled(Enum.HumanoidStateType.PlatformStanding, false)
	return v43, v_u_44
end
local v_u_65 = {
	["HumanoidRootPart"] = true,
	["BodyHitbox"] = true,
	["BodyCenter"] = true,
	["MouthPoint"] = true,
	["BillboardAnchor"] = true,
	["FloorPoint"] = true
}
function v_u_5.ResolveBodyMesh(p66, p67) -- name: ResolveBodyMesh
	-- upvalues: (copy) v_u_65
	local v68 = -1
	local v69 = nil
	for _, v70 in ipairs(p66:GetDescendants()) do
		if not v70:IsA("BasePart") or (v_u_65[v70.Name] or p67 ~= nil and v70:IsDescendantOf(p67)) then
			continue
		end
		local v71 = v70.Size
		local v72 = v71.X * v71.Y * v71.Z
		if v68 >= v72 then
			continue
		end
		v69 = v70
		v68 = v72
	end
	return v69
end
function v_u_5.ResolveFeetY(p73, p74, p75) -- name: ResolveFeetY
	-- upvalues: (copy) v_u_65
	local v76 = (1 / 0)
	for _, v77 in ipairs(p73:GetDescendants()) do
		if not v77:IsA("BasePart") or (v_u_65[v77.Name] or (v77.Transparency >= 1 or p74 ~= nil and v77:IsDescendantOf(p74))) then
			continue
		end
		local v78 = v77.CFrame
		local v79 = v77.Size * 0.5
		local v80 = v78.RightVector.Y
		local v81 = math.abs(v80) * v79.X
		local v82 = v78.UpVector.Y
		local v83 = v81 + math.abs(v82) * v79.Y
		local v84 = v78.LookVector.Y
		local v85 = v83 + math.abs(v84) * v79.Z
		local v86 = v77.Position.Y - v85
		v76 = math.min(v76, v86)
	end
	if v76 == (1 / 0) then
		return p75.Position.Y - p75.Size.Y * 0.5
	else
		return v76
	end
end
function v_u_5.ResolveTemplate(p87) -- name: ResolveTemplate
	-- upvalues: (copy) v_u_1, (copy) v_u_5, (copy) v_u_2
	local v88 = v_u_1:FindFirstChild("Templates")
	if v88 ~= nil then
		local v89 = v88:FindFirstChild("WalkerRig")
		if v89 ~= nil and v89:IsA("Model") then
			return v89
		end
	end
	for _, v90 in ipairs(p87:GetChildren()) do
		if not v90:IsA("Model") then
			continue
		end
		local v91 = v_u_5.Find(v90)
		if v91 == nil then
			continue
		end
		return v91
	end
	return v_u_2.Create()
end
function v_u_5.Stamp(p92, p93, p94) -- name: Stamp
	-- upvalues: (copy) v_u_5, (copy) v_u_4
	local v95 = p94 or {}
	local v_u_96 = v_u_5.ResolveBodyMesh(p92, nil)
	if v_u_96 == nil then
		return nil
	end
	local v_u_97 = p93:Clone()
	v_u_97.Name = v_u_5.WALKER_NAME
	local v98 = v_u_97:FindFirstChild("HumanoidRootPart")
	if v98 == nil or not v98:IsA("BasePart") then
		v_u_97:Destroy()
		return nil
	end
	v_u_97.PrimaryPart = v98
	if v95.ScaleToAnimal then
		local _, v_u_99 = v_u_97:GetBoundingBox()
		if v_u_99.Y > 0 then
			local function v103()
				-- upvalues: (ref) v_u_4, (copy) v_u_97, (copy) v_u_96, (copy) v_u_99
				local v100 = v_u_4.ScaleBy
				local v101 = v_u_97
				local v102 = v_u_96.Size.Y / v_u_99.Y
				v100(v101, (math.max(v102, 0.05)))
			end
			pcall(v103)
		end
	end
	local v104, v105 = v_u_97:GetBoundingBox()
	local v106 = v98.Position.Y - (v104.Position.Y - v105.Y * 0.5)
	local v107 = v_u_5.ResolveFeetY(p92, v_u_97, v_u_96)
	local v108 = v_u_96.CFrame.LookVector
	local v109 = v108.X
	local v110 = v108.Z
	local v111 = Vector3.new(v109, 0, v110)
	local v112
	if v111.Magnitude > 0.0001 then
		v112 = CFrame.lookAt(Vector3.new(0, 0, 0), v111.Unit)
	else
		v112 = CFrame.identity
	end
	if v95.YawOffset then
		local v113 = CFrame.Angles
		local v114 = v95.YawOffset
		v112 = v112 * v113(0, math.rad(v114), 0)
	end
	v_u_97:SetPrimaryPartCFrame(CFrame.new(v_u_96.Position.X, v107 + v106, v_u_96.Position.Z) * v112)
	v98.Anchored = true
	v_u_5.Hide(v_u_97)
	v_u_97.Parent = p92
	return v_u_97
end
return v_u_5
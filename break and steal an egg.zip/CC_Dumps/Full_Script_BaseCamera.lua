local v1 = game:GetService("Players")
local v_u_2 = game:GetService("VRService")
local v_u_3 = game:GetService("GuiService")
local v_u_4 = UserSettings():GetService("UserGameSettings")
local v5 = require(script.Parent.Parent:WaitForChild("CommonUtils"))
local v_u_6 = v5.get("ConnectionUtil")
v5.get("FlagUtil")
local v_u_7 = require(script.Parent:WaitForChild("CameraUtils"))
local v_u_8 = require(script.Parent:WaitForChild("ZoomController"))
local v_u_9 = require(script.Parent:WaitForChild("CameraToggleStateController"))
local v_u_10 = require(script.Parent:WaitForChild("CameraInput"))
local v_u_11 = require(script.Parent:WaitForChild("CameraUI"))
local v_u_12 = script.Parent.Parent:WaitForChild("InputContexts"):WaitForChild("CameraContext"):WaitForChild("CameraGamepadZoomAction")
local v_u_13 = v1.LocalPlayer
local v_u_14 = {}
v_u_14.__index = v_u_14
function v_u_14.new() -- name: new
	-- upvalues: (copy) v_u_14, (copy) v_u_6, (copy) v_u_13, (copy) v_u_12, (copy) v_u_4
	local v15 = v_u_14
	local v_u_16 = setmetatable({}, v15)
	v_u_16._connections = v_u_6.new()
	v_u_16.gamepadZoomLevels = { 0, 10, 20 }
	v_u_16.FIRST_PERSON_DISTANCE_THRESHOLD = 1
	v_u_16.cameraType = nil
	v_u_16.cameraMovementMode = nil
	v_u_16.lastCameraTransform = nil
	v_u_16.lastUserPanCamera = tick()
	v_u_16.humanoidRootPart = nil
	v_u_16.humanoidCache = {}
	v_u_16.lastSubject = nil
	v_u_16.lastSubjectPosition = Vector3.new(0, 5, 0)
	v_u_16.lastSubjectCFrame = CFrame.new(v_u_16.lastSubjectPosition)
	local v17 = v_u_13.CameraMinZoomDistance
	local v18 = v_u_13.CameraMaxZoomDistance
	v_u_16.currentSubjectDistance = math.clamp(12.5, v17, v18)
	v_u_16.inFirstPerson = false
	v_u_16.inMouseLockedMode = false
	v_u_16.resetCameraAngle = true
	v_u_16.enabled = false
	v_u_16.cameraChangedConn = nil
	v_u_16.shouldUseVRRotation = false
	v_u_16.VRRotationIntensityAvailable = false
	v_u_16.lastVRRotationIntensityCheckTime = 0
	v_u_16.lastVRRotationTime = 0
	v_u_16.vrRotateKeyCooldown = {}
	v_u_16.cameraTranslationConstraints = Vector3.new(1, 1, 1)
	v_u_16.humanoidJumpOrigin = nil
	v_u_16.trackingHumanoid = nil
	v_u_16.cameraFrozen = false
	v_u_16.subjectStateChangedConn = nil
	v_u_16.gamepadZoomPressConnection = v_u_12.Pressed:Connect(function()
		-- upvalues: (copy) v_u_16
		v_u_16:GamepadZoomPress()
	end)
	v_u_16.mouseLockOffset = Vector3.new(0, 0, 0)
	v_u_4:SetCameraYInvertVisible()
	v_u_4:SetGamepadCameraSensitivityVisible()
	return v_u_16
end
function v_u_14.GetModuleName(_) -- name: GetModuleName
	return "BaseCamera"
end
function v_u_14._setUpConfigurations(p_u_19) -- name: _setUpConfigurations
	-- upvalues: (copy) v_u_13, (copy) v_u_3, (copy) v_u_12
	p_u_19._connections:trackConnection("CHARACTER_ADDED", v_u_13.CharacterAdded:Connect(function(p20)
		-- upvalues: (copy) p_u_19
		p_u_19:OnCharacterAdded(p20)
	end))
	p_u_19.humanoidRootPart = nil
	p_u_19._connections:trackConnection("CAMERA_MODE_CHANGED", v_u_13:GetPropertyChangedSignal("CameraMode"):Connect(function()
		-- upvalues: (copy) p_u_19
		p_u_19:OnPlayerCameraPropertyChange()
	end))
	p_u_19._connections:trackConnection("CAMERA_MIN_DISTANCE_CHANGED", v_u_13:GetPropertyChangedSignal("CameraMinZoomDistance"):Connect(function()
		-- upvalues: (copy) p_u_19
		p_u_19:OnPlayerCameraPropertyChange()
	end))
	p_u_19._connections:trackConnection("CAMERA_MAX_DISTANCE_CHANGED", v_u_13:GetPropertyChangedSignal("CameraMaxZoomDistance"):Connect(function()
		-- upvalues: (copy) p_u_19
		p_u_19:OnPlayerCameraPropertyChange()
	end))
	p_u_19._connections:trackConnection("SELECTION_MODE_CHANGED", v_u_3:GetPropertyChangedSignal("SelectedObject"):Connect(function()
		-- upvalues: (ref) v_u_12, (ref) v_u_3
		v_u_12.Enabled = not v_u_3.SelectedObject
	end))
	p_u_19:OnPlayerCameraPropertyChange()
end
function v_u_14.OnCharacterAdded(p21, _) -- name: OnCharacterAdded
	p21.resetCameraAngle = p21.resetCameraAngle or p21:GetEnabled()
	p21.humanoidRootPart = nil
end
function v_u_14.GetHumanoidRootPart(p22) -- name: GetHumanoidRootPart
	-- upvalues: (copy) v_u_13
	local v23 = (not p22.humanoidRootPart and v_u_13.Character and true or false) and v_u_13.Character:FindFirstChildOfClass("Humanoid")
	if v23 then
		p22.humanoidRootPart = v23.RootPart
	end
	return p22.humanoidRootPart
end
function v_u_14.GetSubjectCFrame(p24) -- name: GetSubjectCFrame
	local v25 = p24.lastSubjectCFrame
	local v26 = workspace.CurrentCamera
	if v26 then
		v26 = v26.CameraSubject
	end
	if not v26 then
		return v25
	end
	if v26:IsA("Humanoid") then
		local v27 = v26:GetState() == Enum.HumanoidStateType.Dead
		local v28 = v26.CameraOffset
		if p24:GetIsMouseLocked() then
			v28 = Vector3.new()
		end
		local v29 = v26.RootPart
		if v27 and (v26.Parent and v26.Parent:IsA("Model")) then
			v29 = v26.Parent:FindFirstChild("Head") or v29
		end
		if v29 and v29:IsA("BasePart") then
			local v30
			if v26.RigType == Enum.HumanoidRigType.R15 then
				if v26.AutomaticScalingEnabled then
					v30 = Vector3.new(0, 1.5, 0)
					local v31 = v26.RootPart
					if v29 == v31 then
						local v32 = (v31.Size.Y - 2) / 2
						v30 = v30 + Vector3.new(0, v32, 0)
					end
				else
					v30 = Vector3.new(0, 2, 0)
				end
			else
				v30 = Vector3.new(0, 1.5, 0)
			end
			v25 = v29.CFrame * CFrame.new((v27 and Vector3.new(0, 0, 0) or v30) + v28)
		end
	elseif v26:IsA("BasePart") then
		v25 = v26.CFrame
	elseif v26:IsA("Model") then
		if v26.PrimaryPart then
			v25 = v26:GetPrimaryPartCFrame()
		else
			v25 = CFrame.new()
		end
	end
	if v25 then
		p24.lastSubjectCFrame = v25
	end
	return v25
end
function v_u_14.GetSubjectVelocity(_) -- name: GetSubjectVelocity
	local v33 = workspace.CurrentCamera
	if v33 then
		v33 = v33.CameraSubject
	end
	if not v33 then
		return Vector3.new(0, 0, 0)
	end
	if v33:IsA("BasePart") then
		return v33.Velocity
	end
	if v33:IsA("Humanoid") then
		local v34 = v33.RootPart
		if v34 then
			return v34.Velocity
		end
	else
		local v35 = v33:IsA("Model") and v33.PrimaryPart
		if v35 then
			return v35.Velocity
		end
	end
	return Vector3.new(0, 0, 0)
end
function v_u_14.GetSubjectRotVelocity(_) -- name: GetSubjectRotVelocity
	local v36 = workspace.CurrentCamera
	if v36 then
		v36 = v36.CameraSubject
	end
	if not v36 then
		return Vector3.new(0, 0, 0)
	end
	if v36:IsA("BasePart") then
		return v36.RotVelocity
	end
	if v36:IsA("Humanoid") then
		local v37 = v36.RootPart
		if v37 then
			return v37.RotVelocity
		end
	else
		local v38 = v36:IsA("Model") and v36.PrimaryPart
		if v38 then
			return v38.RotVelocity
		end
	end
	return Vector3.new(0, 0, 0)
end
function v_u_14.StepZoom(p39, p40) -- name: StepZoom
	-- upvalues: (copy) v_u_10, (copy) v_u_8
	local v41 = p39.currentSubjectDistance
	local v42 = v_u_10.getZoomDelta(p40)
	if math.abs(v42) > 0 then
		local v43
		if v42 > 0 then
			local v44 = v41 + v42 * (v41 * 0.5 + 1)
			local v45 = p39.FIRST_PERSON_DISTANCE_THRESHOLD
			v43 = math.max(v44, v45)
		else
			local v46 = (v41 + v42) / (1 - v42 * 0.5)
			v43 = math.max(v46, 0.5)
		end
		p39:SetCameraToSubjectDistance(v43 < p39.FIRST_PERSON_DISTANCE_THRESHOLD and 0.5 or v43)
	end
	return v_u_8.GetZoomRadius()
end
function v_u_14.GetSubjectPosition(p47) -- name: GetSubjectPosition
	local v48 = p47.lastSubjectPosition
	local v49 = game.Workspace.CurrentCamera
	if v49 then
		v49 = v49.CameraSubject
	end
	if not v49 then
		return nil
	end
	if v49:IsA("Humanoid") then
		local v50 = v49:GetState() == Enum.HumanoidStateType.Dead
		local v51 = v49.CameraOffset
		if p47:GetIsMouseLocked() then
			v51 = Vector3.new()
		end
		local v52 = v49.RootPart
		if v50 and (v49.Parent and v49.Parent:IsA("Model")) then
			v52 = v49.Parent:FindFirstChild("Head") or v52
		end
		if v52 and v52:IsA("BasePart") then
			local v53
			if v49.RigType == Enum.HumanoidRigType.R15 then
				if v49.AutomaticScalingEnabled then
					v53 = Vector3.new(0, 1.5, 0)
					if v52 == v49.RootPart then
						local v54 = v49.RootPart.Size.Y / 2 - 1
						v53 = v53 + Vector3.new(0, v54, 0)
					end
				else
					v53 = Vector3.new(0, 2, 0)
				end
			else
				v53 = Vector3.new(0, 1.5, 0)
			end
			v48 = v52.CFrame.Position + v52.CFrame:vectorToWorldSpace((v50 and Vector3.new(0, 0, 0) or v53) + v51)
		end
	elseif v49:IsA("VehicleSeat") then
		v48 = v49.CFrame.Position + v49.CFrame:vectorToWorldSpace(Vector3.new(0, 5, 0))
	elseif v49:IsA("SkateboardPlatform") then
		v48 = v49.CFrame.Position + Vector3.new(0, 5, 0)
	elseif v49:IsA("BasePart") then
		v48 = v49.CFrame.Position
	elseif v49:IsA("Model") then
		if v49.PrimaryPart then
			v48 = v49:GetPrimaryPartCFrame().Position
		else
			v48 = v49:GetModelCFrame().Position
		end
	end
	p47.lastSubject = v49
	p47.lastSubjectPosition = v48
	return v48
end
function v_u_14.OnCurrentCameraChanged(p_u_55) -- name: OnCurrentCameraChanged
	if p_u_55.cameraSubjectChangedConn then
		p_u_55.cameraSubjectChangedConn:Disconnect()
		p_u_55.cameraSubjectChangedConn = nil
	end
	local v56 = game.Workspace.CurrentCamera
	if v56 then
		p_u_55.cameraSubjectChangedConn = v56:GetPropertyChangedSignal("CameraSubject"):Connect(function()
			-- upvalues: (copy) p_u_55
			p_u_55:OnNewCameraSubject()
		end)
		p_u_55:OnNewCameraSubject()
	end
end
function v_u_14.OnPlayerCameraPropertyChange(p57) -- name: OnPlayerCameraPropertyChange
	p57:SetCameraToSubjectDistance(p57.currentSubjectDistance)
end
function v_u_14.InputTranslationToCameraAngleChange(_, p58, p59) -- name: InputTranslationToCameraAngleChange
	return p58 * p59
end
function v_u_14.GamepadZoomPress(p60) -- name: GamepadZoomPress
	-- upvalues: (copy) v_u_13
	local v61 = p60:GetCameraToSubjectDistance()
	local v62 = v_u_13.CameraMaxZoomDistance
	for v63 = #p60.gamepadZoomLevels, 1, -1 do
		local v64 = p60.gamepadZoomLevels[v63]
		if v62 < v64 then
			continue
		end
		if v64 < v_u_13.CameraMinZoomDistance then
			v64 = v_u_13.CameraMinZoomDistance
			if v62 == v64 then
				break
			end
		end
		if v64 + (v62 - v64) / 2 < v61 then
			p60:SetCameraToSubjectDistance(v64)
			return
		end
		v62 = v64
	end
	p60:SetCameraToSubjectDistance(p60.gamepadZoomLevels[#p60.gamepadZoomLevels])
end
function v_u_14.Enable(p65, p66) -- name: Enable
	if p65.enabled ~= p66 then
		p65.enabled = p66
		p65:OnEnabledChanged()
	end
end
function v_u_14.OnEnabledChanged(p_u_67) -- name: OnEnabledChanged
	-- upvalues: (copy) v_u_10, (copy) v_u_12, (copy) v_u_13
	if p_u_67.enabled then
		p_u_67:_setUpConfigurations()
		v_u_10.setInputEnabled(true)
		v_u_12.Enabled = true
		if v_u_13.CameraMode == Enum.CameraMode.LockFirstPerson then
			p_u_67.currentSubjectDistance = 0.5
			if not p_u_67.inFirstPerson then
				p_u_67:EnterFirstPerson()
			end
		end
		if p_u_67.cameraChangedConn then
			p_u_67.cameraChangedConn:Disconnect()
			p_u_67.cameraChangedConn = nil
		end
		p_u_67.cameraChangedConn = workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(function()
			-- upvalues: (copy) p_u_67
			p_u_67:OnCurrentCameraChanged()
		end)
		p_u_67:OnCurrentCameraChanged()
	else
		p_u_67._connections:disconnectAll()
		v_u_10.setInputEnabled(false)
		v_u_12.Enabled = false
		p_u_67:Cleanup()
	end
end
function v_u_14.GetEnabled(p68) -- name: GetEnabled
	return p68.enabled
end
function v_u_14.Cleanup(p69) -- name: Cleanup
	-- upvalues: (copy) v_u_7
	if p69.subjectStateChangedConn then
		p69.subjectStateChangedConn:Disconnect()
		p69.subjectStateChangedConn = nil
	end
	if p69.cameraChangedConn then
		p69.cameraChangedConn:Disconnect()
		p69.cameraChangedConn = nil
	end
	p69.lastCameraTransform = nil
	p69.lastSubjectCFrame = nil
	v_u_7.restoreMouseBehavior()
end
function v_u_14.UpdateMouseBehavior(p70) -- name: UpdateMouseBehavior
	-- upvalues: (copy) v_u_4, (copy) v_u_11, (copy) v_u_10, (copy) v_u_9, (copy) v_u_7
	local v71 = v_u_4.ComputerMovementMode == Enum.ComputerMovementMode.ClickToMove
	if p70.isCameraToggle and v71 == false then
		v_u_11.setCameraModeToastEnabled(true)
		v_u_10.enableCameraToggleInput()
		v_u_9(p70.inFirstPerson)
		return
	else
		v_u_11.setCameraModeToastEnabled(false)
		v_u_10.disableCameraToggleInput()
		if p70.inFirstPerson or p70.inMouseLockedMode then
			v_u_7.setRotationTypeOverride(Enum.RotationType.CameraRelative)
			v_u_7.setMouseBehaviorOverride(Enum.MouseBehavior.LockCenter)
			return
		else
			v_u_7.restoreRotationType()
			if v_u_10.getPanActivated() then
				v_u_7.setMouseBehaviorOverride(Enum.MouseBehavior.LockCurrentPosition)
			else
				v_u_7.restoreMouseBehavior()
			end
		end
	end
end
function v_u_14.UpdateForDistancePropertyChange(p72) -- name: UpdateForDistancePropertyChange
	p72:SetCameraToSubjectDistance(p72.currentSubjectDistance)
end
function v_u_14.SetCameraToSubjectDistance(p73, p74) -- name: SetCameraToSubjectDistance
	-- upvalues: (copy) v_u_13, (copy) v_u_8
	local v75 = p73.currentSubjectDistance
	if v_u_13.CameraMode == Enum.CameraMode.LockFirstPerson then
		p73.currentSubjectDistance = 0.5
		if not p73.inFirstPerson then
			p73:EnterFirstPerson()
		end
	else
		local v76 = v_u_13.CameraMinZoomDistance
		local v77 = v_u_13.CameraMaxZoomDistance
		local v78 = math.clamp(p74, v76, v77)
		if v78 < 1 then
			p73.currentSubjectDistance = 0.5
			if not p73.inFirstPerson then
				p73:EnterFirstPerson()
			end
		else
			p73.currentSubjectDistance = v78
			if p73.inFirstPerson then
				p73:LeaveFirstPerson()
			end
		end
	end
	local v79 = v_u_8.SetZoomParameters
	local v80 = p73.currentSubjectDistance
	local v81 = p74 - v75
	v79(v80, (math.sign(v81)))
	return p73.currentSubjectDistance
end
function v_u_14.SetCameraType(p82, p83) -- name: SetCameraType
	p82.cameraType = p83
end
function v_u_14.GetCameraType(p84) -- name: GetCameraType
	return p84.cameraType
end
function v_u_14.SetCameraMovementMode(p85, p86) -- name: SetCameraMovementMode
	p85.cameraMovementMode = p86
end
function v_u_14.GetCameraMovementMode(p87) -- name: GetCameraMovementMode
	return p87.cameraMovementMode
end
function v_u_14.SetIsMouseLocked(p88, p89) -- name: SetIsMouseLocked
	p88.inMouseLockedMode = p89
end
function v_u_14.GetIsMouseLocked(p90) -- name: GetIsMouseLocked
	return p90.inMouseLockedMode
end
function v_u_14.SetMouseLockOffset(p91, p92) -- name: SetMouseLockOffset
	p91.mouseLockOffset = p92
end
function v_u_14.GetMouseLockOffset(p93) -- name: GetMouseLockOffset
	return p93.mouseLockOffset
end
function v_u_14.InFirstPerson(p94) -- name: InFirstPerson
	return p94.inFirstPerson
end
function v_u_14.EnterFirstPerson(p95) -- name: EnterFirstPerson
	p95.inFirstPerson = true
	p95:UpdateMouseBehavior()
end
function v_u_14.LeaveFirstPerson(p96) -- name: LeaveFirstPerson
	p96.inFirstPerson = false
	p96:UpdateMouseBehavior()
end
function v_u_14.GetCameraToSubjectDistance(p97) -- name: GetCameraToSubjectDistance
	return p97.currentSubjectDistance
end
function v_u_14.GetMeasuredDistanceToFocus(_) -- name: GetMeasuredDistanceToFocus
	local v98 = game.Workspace.CurrentCamera
	if v98 then
		return (v98.CoordinateFrame.Position - v98.Focus.Position).magnitude
	else
		return nil
	end
end
function v_u_14.GetCameraLookVector(_) -- name: GetCameraLookVector
	return game.Workspace.CurrentCamera and game.Workspace.CurrentCamera.CFrame.LookVector or Vector3.new(0, 0, 1)
end
function v_u_14.CalculateNewLookCFrameFromArg(p99, p100, p101) -- name: CalculateNewLookCFrameFromArg
	local v102 = p100 or p99:GetCameraLookVector()
	local v103 = v102.Y
	local v104 = math.asin(v103)
	local v105 = p101.Y
	local v106 = v104 + -1.3962634015954636
	local v107 = v104 + 1.3962634015954636
	local v108 = math.clamp(v105, v106, v107)
	local v109 = Vector2.new(p101.X, v108)
	local v110 = CFrame.new(Vector3.new(0, 0, 0), v102)
	return CFrame.Angles(0, -v109.X, 0) * v110 * CFrame.Angles(-v109.Y, 0, 0)
end
function v_u_14.CalculateNewLookVectorFromArg(p111, p112, p113) -- name: CalculateNewLookVectorFromArg
	return p111:CalculateNewLookCFrameFromArg(p112, p113).LookVector
end
function v_u_14.CalculateNewLookVectorVRFromArg(p114, p115) -- name: CalculateNewLookVectorVRFromArg
	local v116 = ((p114:GetSubjectPosition() - game.Workspace.CurrentCamera.CFrame.Position) * Vector3.new(1, 0, 1)).unit
	local v117 = Vector2.new(p115.X, 0)
	local v118 = CFrame.new(Vector3.new(0, 0, 0), v116)
	return ((CFrame.Angles(0, -v117.X, 0) * v118 * CFrame.Angles(-v117.Y, 0, 0)).LookVector * Vector3.new(1, 0, 1)).unit
end
function v_u_14.GetHumanoid(p119) -- name: GetHumanoid
	-- upvalues: (copy) v_u_13
	local v120 = v_u_13
	if v120 then
		v120 = v_u_13.Character
	end
	if not v120 then
		return nil
	end
	local v121 = p119.humanoidCache[v_u_13]
	if v121 and v121.Parent == v120 then
		return v121
	end
	p119.humanoidCache[v_u_13] = nil
	local v122 = v120:FindFirstChildOfClass("Humanoid")
	if v122 then
		p119.humanoidCache[v_u_13] = v122
	end
	return v122
end
function v_u_14.OnNewCameraSubject(p123) -- name: OnNewCameraSubject
	if p123.subjectStateChangedConn then
		p123.subjectStateChangedConn:Disconnect()
		p123.subjectStateChangedConn = nil
	end
end
function v_u_14.IsInFirstPerson(p124) -- name: IsInFirstPerson
	return p124.inFirstPerson
end
function v_u_14.Update(_, _) -- name: Update
	error("BaseCamera:Update() This is a virtual function that should never be getting called.", 2)
end
function v_u_14.GetCameraHeight(p125) -- name: GetCameraHeight
	-- upvalues: (copy) v_u_2
	return (not v_u_2.VREnabled or p125.inFirstPerson) and 0 or 0.25881904510252074 * p125.currentSubjectDistance
end
return v_u_14
local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Shared.AnimalEggsConfig)
local v_u_4 = require(v2.Shared.AnimalRenders)
local v_u_5 = require(v2.Shared.AnimalViewport)
local v_u_6 = require(v2.Shared.BackpackSellConfig)
local v_u_7 = require(v2.Shared.BackpackUiConfig)
local v_u_8 = require(script.Parent.BackpackHover)
local v_u_9 = require(v2.Shared.BatConfig)
local v_u_10 = require(v2.Shared.BatToolQuery)
local v_u_11 = require(v2.Shared.EggRewards)
local v_u_12 = require(v2.Shared.FloatingIconConfig)
local v_u_13 = require(script.Parent.FloatingIconFX)
local v_u_14 = require(v2.Shared.MergeConfig)
local v_u_15 = require(v2.Shared.PickaxeConfig)
local v_u_16 = require(v2.Shared.RarityGradientFX)
local v_u_17 = require(v2.Shared.ViewportLighting)
local v_u_18 = require(v2.Shared.WeightTag)
local v_u_61 = {
	["Collect"] = function(p19, p20) -- name: Collect
		local v21 = p20:FindFirstChild("InfoList")
		local v22 = {
			["Root"] = nil,
			["Button"] = nil,
			["Image"] = nil,
			["Viewport"] = nil,
			["Name"] = nil,
			["Weight"] = nil,
			["Number"] = nil,
			["SellSelected"] = nil,
			["SellX"] = nil,
			["SellShrunk"] = false,
			["Equipped"] = nil,
			["SwapMark"] = nil,
			["ViewportTool"] = nil,
			["ViewportModel"] = nil,
			["Authored"] = nil,
			["Root"] = p19,
			["Button"] = p20
		}
		local v23
		if p20 then
			v23 = p20:FindFirstChild("ImageDisplay")
		else
			v23 = p20
		end
		if not (v23 and v23:IsA("ImageLabel")) then
			v23 = nil
		end
		v22.Image = v23
		local v24
		if p20 then
			v24 = p20:FindFirstChild("ViewportDisplay")
		else
			v24 = p20
		end
		if not (v24 and v24:IsA("ViewportFrame")) then
			v24 = nil
		end
		v22.Viewport = v24
		local v25
		if v21 then
			v25 = v21:FindFirstChild("Name")
		else
			v25 = v21
		end
		if not (v25 and v25:IsA("TextLabel")) then
			v25 = nil
		end
		v22.Name = v25
		if v21 then
			v21 = v21:FindFirstChild("Weight")
		end
		if not (v21 and v21:IsA("TextLabel")) then
			v21 = nil
		end
		v22.Weight = v21
		if p20 then
			p20 = p20:FindFirstChild("Number")
		end
		if not (p20 and p20:IsA("TextLabel")) then
			p20 = nil
		end
		v22.Number = p20
		local v26
		if p19 then
			v26 = p19:FindFirstChild("SellSelected")
		else
			v26 = p19
		end
		if not (v26 and v26:IsA("GuiObject")) then
			v26 = nil
		end
		v22.SellSelected = v26
		if p19 then
			p19 = p19:FindFirstChild("X")
		end
		if not (p19 and p19:IsA("GuiObject")) then
			p19 = nil
		end
		v22.SellX = p19
		v22.Authored = {}
		for _, v27 in { v22.Name, v22.Weight } do
			if not v27 then
				continue
			end
			local v28 = {}
			for _, v29 in v27:GetChildren() do
				if not v29:IsA("UIStroke") then
					continue
				end
				v28[v29] = v29.Color
			end
			v22.Authored[v27] = {
				["Text"] = v27.TextColor3,
				["Strokes"] = v28
			}
		end
		return v22
	end,
	["AttachImageFX"] = function(p30) -- name: AttachImageFX
		-- upvalues: (copy) v_u_13, (copy) v_u_12
		local v31 = p30.Image
		if v31 and v31:FindFirstChild("Inner") then
			v_u_13.Attach(v31, v_u_12.Styles.AnimalTile, p30.Button)
		end
	end,
	["Pulse"] = function(p32) -- name: Pulse
		-- upvalues: (copy) v_u_13
		if p32.Image then
			v_u_13.Pulse(p32.Image)
		end
	end,
	["ResetCopy"] = function(p33, p34) -- name: ResetCopy
		-- upvalues: (copy) v_u_13
		local v35 = p33.Image
		local v36
		if v35 then
			v36 = p34:FindFirstChild(v35.Name)
		else
			v36 = v35
		end
		if v35 and (v36 and v36:IsA("GuiObject")) then
			v_u_13.ResetCopy(v35, v36)
		end
	end,
	["AdoptSellOverlay"] = function(p37, p38) -- name: AdoptSellOverlay
		if not p37.SellSelected then
			local v39
			if p38 then
				v39 = p38:FindFirstChild("SellSelected")
			else
				v39 = p38
			end
			if not (v39 and v39:IsA("GuiObject")) then
				v39 = nil
			end
			if v39 then
				local v40 = v39:Clone()
				v40.Visible = false
				v40.Parent = p37.Button
				p37.SellSelected = v40
			end
		end
		if not p37.SellX then
			if p38 then
				p38 = p38:FindFirstChild("X")
			end
			if not (p38 and p38:IsA("GuiObject")) then
				p38 = nil
			end
			if p38 then
				local v41 = p38:Clone()
				v41.Visible = false
				v41.Parent = p37.Button
				p37.SellX = v41
			end
		end
	end,
	["AdoptStrokes"] = function(p42, p43, p44) -- name: AdoptStrokes
		-- upvalues: (copy) v_u_7
		local v45 = p42.Button:FindFirstChild(v_u_7.SelectedStrokeName)
		if not (v45 and v45:IsA("UIStroke")) then
			v45 = nil
		end
		local v46 = v45 or (p44 or p43)
		if v46 then
			if not v45 then
				if p44 then
					v45 = p44:Clone()
					v45.Name = v_u_7.SelectedStrokeName
					v45.Parent = p42.Button
				else
					v45 = v46:Clone()
					v45.Name = "Equipped"
					v45.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
					v45.Parent = p42.Button
				end
			end
			v45.Enabled = false
			p42.Equipped = v45
			local v47 = v46:Clone()
			v47.Name = "SwapMark"
			v47.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
			v47.Thickness = v46.Thickness * v_u_7.SwapMarkThicknessMult
			v47.Enabled = false
			v47.Parent = p42.Button
			p42.SwapMark = v47
		end
	end,
	["SetEquipped"] = function(p48, p49) -- name: SetEquipped
		if p48.Equipped then
			p48.Equipped.Enabled = p49
		end
	end,
	["SetSwapMark"] = function(p50, p51) -- name: SetSwapMark
		if p50.SwapMark then
			p50.SwapMark.Enabled = p51
		end
	end,
	["SetSellSelected"] = function(p52, p53) -- name: SetSellSelected
		-- upvalues: (copy) v_u_6, (copy) v_u_8
		if p52.SellSelected then
			p52.SellSelected.Visible = p53
		end
		if p52.SellX then
			p52.SellX.Visible = p53
		end
		if p52.SellShrunk ~= p53 then
			p52.SellShrunk = p53
			local v54 = not p53 and 1 or v_u_6.SelectedScale
			v_u_8.SetShrink(p52.Button, v54, v_u_6.SelectedTweenInfo)
		end
	end,
	["IsEgg"] = function(p55) -- name: IsEgg
		-- upvalues: (copy) v_u_1, (copy) v_u_14
		return v_u_1:HasTag(p55, v_u_14.EggToolTag)
	end,
	["IsPet"] = function(p56) -- name: IsPet
		-- upvalues: (copy) v_u_1
		return v_u_1:HasTag(p56, "AnimalTool")
	end,
	["IsLocked"] = function(p57) -- name: IsLocked
		-- upvalues: (copy) v_u_61, (copy) v_u_15, (copy) v_u_10
		if v_u_61.IsPet(p57) or v_u_61.IsEgg(p57) then
			return false
		else
			return p57.Name == v_u_15.ToolName and true or v_u_10.IsBatWeapon(p57)
		end
	end,
	["DisplayName"] = function(p58) -- name: DisplayName
		-- upvalues: (copy) v_u_10, (copy) v_u_9
		local v59 = p58:GetAttribute("PickaxeName")
		if typeof(v59) == "string" and v59 ~= "" then
			return v59
		end
		if v_u_10.IsBatWeapon(p58) then
			local v60 = p58:GetAttribute(v_u_9.NameAttribute)
			if typeof(v60) == "string" and v60 ~= "" then
				return v60
			end
		end
		return p58.Name
	end
}
local function v_u_67(p62) -- name: searchText
	-- upvalues: (copy) v_u_11, (copy) v_u_61
	local v63 = string.gsub(p62.ToolTip, "<[^>]*>", "")
	local v64 = p62:GetAttribute("Rarity")
	if typeof(v64) ~= "string" then
		local v65 = p62:GetAttribute("AnimalName")
		if typeof(v65) == "string" then
			v64 = v_u_11.RarityOf(v65)
		else
			v64 = nil
		end
	end
	local v66 = p62:GetAttribute("Mutation")
	return string.lower(table.concat({
		v_u_61.DisplayName(p62),
		v63,
		typeof(v64) ~= "string" and "" or v64,
		typeof(v66) ~= "string" and "" or v66
	}, " "))
end
function v_u_61.SearchHits(p68, p69) -- name: SearchHits
	-- upvalues: (copy) v_u_67
	local v70 = v_u_67(p68)
	local v71 = 0
	for _, v72 in p69 do
		if not string.find(v70, v72, 1, true) then
			continue
		end
		v71 = v71 + 1
	end
	return v71
end
local function v_u_74(p73) -- name: isRenderJunk
	return p73:IsA("LuaSourceContainer") or (p73:IsA("Sound") or p73:IsA("ParticleEmitter") or (p73:IsA("Trail") or p73:IsA("Beam")) or (p73:IsA("Light") or p73:IsA("Fire") or (p73:IsA("Smoke") or p73:IsA("Sparkles"))))
end
local function v_u_83(p75) -- name: buildToolModel
	-- upvalues: (copy) v_u_74, (copy) v_u_3, (copy) v_u_5
	local v76 = Instance.new("Model")
	v76.Name = "SlotModel"
	for _, v77 in p75:GetChildren() do
		if v77:IsA("BasePart") then
			if v77.Transparency >= 1 then
				continue
			end
		elseif not (v77:IsA("Model") or v77:IsA("Folder")) then
			continue
		end
		local v78 = v77.Clone
		local v79, v80 = pcall(v78, v77)
		if not (v79 and v80) then
			continue
		end
		v80.Parent = v76
	end
	for _, v81 in v76:GetDescendants() do
		if not v_u_74(v81) then
			continue
		end
		v81:Destroy()
	end
	if not v76:FindFirstChildWhichIsA("BasePart", true) then
		v76:Destroy()
		return nil
	end
	local v82 = v76:FindFirstChild(v_u_3.FrameAttachmentName, true)
	if v82 and v82:IsA("Attachment") then
		v76.WorldPivot = v82.WorldCFrame
	end
	v_u_5.PrepareModel(v76)
	return v76
end
local function v_u_95(p84, p85) -- name: frameCamera
	-- upvalues: (copy) v_u_7
	local v86 = p84:FindFirstChild("SlotCamera")
	if not (v86 and v86:IsA("Camera")) then
		v86 = Instance.new("Camera")
		v86.Name = "SlotCamera"
		v86.Parent = p84
	end
	local v87, v88 = p85:GetBoundingBox()
	local v89 = v_u_7.ViewportFov
	local v90 = v88.Magnitude / 2
	local v91 = v89 / 2
	local v92 = math.rad(v91)
	local v93 = v90 / math.sin(v92)
	local v94 = v87:VectorToWorldSpace(v_u_7.ViewportDirection.Unit)
	v86.FieldOfView = v89
	v86.CFrame = CFrame.lookAt(v87.Position + v94 * v93, v87.Position)
	p84.CurrentCamera = v86
end
local function v_u_100(p96, p97) -- name: renderViewport
	-- upvalues: (copy) v_u_83, (copy) v_u_95, (copy) v_u_17
	local v98 = p96.Viewport
	if not v98 then
		return false
	end
	if p96.ViewportTool == p97 and (p96.ViewportModel and p96.ViewportModel.Parent == v98) then
		v98.Visible = true
		return true
	end
	if p96.ViewportModel then
		p96.ViewportModel:Destroy()
	end
	p96.ViewportModel = nil
	p96.ViewportTool = nil
	if p96.Viewport then
		p96.Viewport.Visible = false
	end
	local v99 = v_u_83(p97)
	if not v99 then
		return false
	end
	v99.Parent = v98
	v_u_95(v98, v99)
	v_u_17.Apply(v98)
	v98.Visible = true
	p96.ViewportTool = p97
	p96.ViewportModel = v99
	return true
end
function v_u_61.ImageFor(p101) -- name: ImageFor
	-- upvalues: (copy) v_u_61, (copy) v_u_4
	local v102 = p101.TextureId
	if v102 ~= "" or not v_u_61.IsEgg(p101) then
		if v102 == "" and (v_u_61.IsPet(p101) and not v_u_61.IsEgg(p101)) then
			local v103 = p101:GetAttribute("AnimalName")
			local v104 = p101:GetAttribute("Variant")
			local v105 = v_u_4.GetImage
			if typeof(v103) ~= "string" then
				v103 = nil
			end
			if typeof(v104) ~= "string" then
				v104 = nil
			end
			v102 = v105(v103, v104)
		end
		return v102
	end
	local v106 = p101:GetAttribute("AnimalName")
	local v107 = v_u_4.GetEggImage
	if typeof(v106) ~= "string" then
		v106 = nil
	end
	return v107(v106)
end
local function v_u_113(p108, p109) -- name: renderImage
	-- upvalues: (copy) v_u_61, (copy) v_u_100
	local v110 = p108.Image
	local v111 = v_u_61.ImageFor(p109)
	if v111 == "" or not v110 then
		if v110 then
			v110.Image = ""
			v110.Visible = false
		end
		v_u_100(p108, p109)
	else
		v110.ScaleType = Enum.ScaleType.Fit
		v110.Image = v111
		for _, v112 in v110:GetDescendants() do
			if not v112:IsA("ImageLabel") then
				continue
			end
			v112.ScaleType = Enum.ScaleType.Fit
			v112.Image = v111
		end
		v110.Visible = true
		if p108.ViewportModel then
			p108.ViewportModel:Destroy()
		end
		p108.ViewportModel = nil
		p108.ViewportTool = nil
		if p108.Viewport then
			p108.Viewport.Visible = false
		end
	end
end
local function v_u_117(p114) -- name: rarityOf
	-- upvalues: (copy) v_u_61, (copy) v_u_11
	if v_u_61.IsPet(p114) or v_u_61.IsEgg(p114) then
		local v115 = p114:GetAttribute("Rarity")
		if typeof(v115) ~= "string" then
			local v116 = p114:GetAttribute("AnimalName")
			if typeof(v116) == "string" then
				v115 = v_u_11.RarityOf(v116)
			else
				v115 = nil
			end
		end
		if typeof(v115) == "string" then
			return v115
		else
			return nil
		end
	else
		return nil
	end
end
v_u_61.RarityOf = v_u_117
local function v_u_124(p118, p119) -- name: unpaint
	-- upvalues: (copy) v_u_16
	for _, v120 in p119:GetChildren() do
		if not v120:IsA("UIGradient") then
			continue
		end
		v_u_16.Detach(v120)
		v120:Destroy()
	end
	local v121 = p118.Authored[p119]
	if v121 then
		p119.TextColor3 = v121.Text
		for v122, v123 in v121.Strokes do
			v122.Color = v123
		end
	end
end
local function v_u_129(p125, p126) -- name: paintLabels
	-- upvalues: (copy) v_u_117, (copy) v_u_124, (copy) v_u_16
	local v127
	if p126 then
		v127 = v_u_117(p126)
	else
		v127 = nil
	end
	for _, v128 in { p125.Name, p125.Weight } do
		if not v128 then
			continue
		end
		v_u_124(p125, v128)
		if not v127 then
			continue
		end
		v_u_16.ApplyToLabel(v128, v127)
	end
end
function v_u_61.RenderEntry(p130, p131, p132, p133) -- name: RenderEntry
	-- upvalues: (copy) v_u_124, (copy) v_u_16
	local v134 = p130.Image
	if v134 then
		v134.ScaleType = Enum.ScaleType.Fit
		v134.Image = p132
		for _, v135 in v134:GetDescendants() do
			if not v135:IsA("ImageLabel") then
				continue
			end
			v135.ScaleType = Enum.ScaleType.Fit
			v135.Image = p132
		end
		v134.Visible = true
	end
	if p130.ViewportModel then
		p130.ViewportModel:Destroy()
	end
	p130.ViewportModel = nil
	p130.ViewportTool = nil
	if p130.Viewport then
		p130.Viewport.Visible = false
	end
	if p130.Name then
		p130.Name.Text = p131
	end
	if p130.Weight then
		p130.Weight.Text = ""
		p130.Weight.Visible = false
	end
	for _, v136 in { p130.Name, p130.Weight } do
		if not v136 then
			continue
		end
		v_u_124(p130, v136)
		if not p133 then
			continue
		end
		v_u_16.ApplyToLabel(v136, p133)
	end
end
function v_u_61.Render(p137, p138) -- name: Render
	-- upvalues: (copy) v_u_124, (copy) v_u_61, (copy) v_u_7, (copy) v_u_18, (copy) v_u_129, (copy) v_u_113
	if p138 then
		local v139 = p138:GetAttribute("WeightKg")
		local v140 = typeof(v139) == "number"
		if p137.Name then
			local v141 = v_u_61.DisplayName(p138)
			if not p137.Weight and v140 then
				v141 = string.format(v_u_7.NameWeightFormat, v141, v_u_18.FormatKg(v139))
			end
			p137.Name.Text = v141
		end
		local v142 = p137.Weight
		if v142 then
			if v140 then
				v142.Text = string.format(v_u_7.WeightFormat, v_u_18.FormatKg(v139))
				v142.Visible = true
			else
				v142.Text = ""
				v142.Visible = false
			end
		end
		v_u_129(p137, p138)
		v_u_113(p137, p138)
	else
		if p137.Image then
			p137.Image.Image = ""
			p137.Image.Visible = false
		end
		if p137.ViewportModel then
			p137.ViewportModel:Destroy()
		end
		p137.ViewportModel = nil
		p137.ViewportTool = nil
		if p137.Viewport then
			p137.Viewport.Visible = false
		end
		if p137.Name then
			p137.Name.Text = ""
		end
		if p137.Weight then
			p137.Weight.Text = ""
			p137.Weight.Visible = false
		end
		for _, v143 in { p137.Name, p137.Weight } do
			if not v143 then
				continue
			end
			v_u_124(p137, v143)
		end
	end
end
return v_u_61
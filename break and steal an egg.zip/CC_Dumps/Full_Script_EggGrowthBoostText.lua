local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.EggGrowthClock)
local v_u_3 = require(v1.Shared.PotionConfig)
local v_u_10 = {
	["MultiplierFor"] = function(p4) -- name: MultiplierFor
		-- upvalues: (copy) v_u_2
		return v_u_2.RateOf(p4)
	end,
	["Suffix"] = function(p5) -- name: Suffix
		-- upvalues: (copy) v_u_3
		return p5 <= 1 and "" or (" <font color=\"%*\">(%*x)</font>"):format(v_u_3.HoverMultiplierColor, (string.format("%g", p5)))
	end,
	["Decorate"] = function(p6, p7, p8) -- name: Decorate
		-- upvalues: (copy) v_u_10
		local v9 = v_u_10.Suffix(v_u_10.MultiplierFor(p7))
		if v9 ~= "" and not p6.RichText then
			p6.RichText = true
		end
		return p8 .. v9
	end
}
return v_u_10
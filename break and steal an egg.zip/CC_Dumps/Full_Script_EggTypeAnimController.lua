local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(v2.Shared.AnimationAssets)
local v_u_6 = require(v2.Shared.EggTypeConfig)
local v_u_7 = require(v2.Shared.MergeConfig)
local v_u_8 = require(script.Parent.Parent.Modules.EggCullQuality)
local v9 = {}
local v_u_10 = {}
local function v_u_16(p11) -- name: inRange
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_6
	local v12 = p11.Anchor
	local v13 = v_u_4.CurrentCamera
	if v12 and (v12.Parent and v13) then
		local v14 = v12.Position - v13.CFrame.Position
		local v15 = v14.Magnitude
		if v_u_8.Distance(v_u_6.AnimMaxDistance) < v15 then
			return false
		else
			return v15 < 20 and true or v14:Dot(v13.CFrame.LookVector) > -0.3 * v15
		end
	else
		return true
	end
end
local function v_u_31(p17) -- name: refresh
	-- upvalues: (copy) v_u_10, (copy) v_u_6, (copy) v_u_4, (copy) v_u_5, (copy) v_u_16
	local v18 = v_u_10[p17]
	if v18 then
		local v19 = v_u_6.Get(p17:GetAttribute(v_u_6.Attribute))
		if v19 and (v19.IdleAnimationId and p17:IsDescendantOf(v_u_4)) then
			if v18.Track then
				return
			else
				local v_u_20 = p17:FindFirstChildWhichIsA("Animator", true)
				if v_u_20 then
					local v21 = p17:GetAttribute("AttachmentCount")
					if typeof(v21) == "number" then
						local v22 = 0
						for _, v23 in p17:GetDescendants() do
							if not v23:IsA("Attachment") then
								continue
							end
							v22 = v22 + 1
						end
						if v22 < v21 then
							return
						end
					end
					local v_u_24 = v_u_5.Get(v19.IdleAnimationId, (("%* Idle"):format(v19.DisplayName)))
					local v25, v26 = pcall(function()
						-- upvalues: (copy) v_u_20, (copy) v_u_24
						return v_u_20:LoadAnimation(v_u_24)
					end)
					if v25 and v26 then
						v26.Looped = true
						v26.Priority = Enum.AnimationPriority.Idle
						v18.Track = v26
						v18.Playing = false
						local v27
						if p17:IsA("Model") and p17.PrimaryPart then
							v27 = p17.PrimaryPart
						else
							v27 = p17:FindFirstChildWhichIsA("BasePart", true)
						end
						v18.Anchor = v27
						local v28 = v18.Track
						if v28 then
							local v29 = v_u_16(v18)
							if v29 and not v18.Playing then
								v18.Playing = true
								v28:Play(0.2)
							elseif not v29 and v18.Playing then
								v18.Playing = false
								v28:Stop(0.3)
							end
						else
							return
						end
					else
						warn((("[EggTypeAnimController] couldn\'t load %* idle: %*"):format(v19.DisplayName, v26)))
						return
					end
				else
					return
				end
			end
		else
			local v30 = v18.Track
			if v30 then
				v18.Track = nil
				v18.Playing = false
				v30:Stop(0.2)
				v30:Destroy()
			end
			return
		end
	else
		return
	end
end
local function v_u_36(p32) -- name: unwatch
	-- upvalues: (copy) v_u_10
	local v33 = v_u_10[p32]
	if v33 then
		v_u_10[p32] = nil
		local v34 = v33.Track
		if v34 then
			v33.Track = nil
			v33.Playing = false
			v34:Stop(0.2)
			v34:Destroy()
		end
		for _, v35 in v33.Connections do
			v35:Disconnect()
		end
	end
end
local function v_u_55(p_u_37) -- name: watch
	-- upvalues: (copy) v_u_10, (copy) v_u_31, (copy) v_u_6
	if not v_u_10[p_u_37] then
		local v38 = {
			["Track"] = nil,
			["Playing"] = false,
			["Anchor"] = nil,
			["Connections"] = nil,
			["Connections"] = {}
		}
		v_u_10[p_u_37] = v38
		local function v39() -- name: again
			-- upvalues: (ref) v_u_31, (copy) p_u_37
			v_u_31(p_u_37)
		end
		local v40 = v38.Connections
		local v41 = p_u_37.AncestryChanged
		table.insert(v40, v41:Connect(v39))
		local v42 = v38.Connections
		local v43 = p_u_37:GetAttributeChangedSignal(v_u_6.Attribute)
		table.insert(v42, v43:Connect(v39))
		local v44 = v38.Connections
		local v45 = p_u_37.DescendantAdded
		local function v47(p46)
			-- upvalues: (ref) v_u_31, (copy) p_u_37
			if p46:IsA("Animator") or p46:IsA("Attachment") then
				v_u_31(p_u_37)
			end
		end
		table.insert(v44, v45:Connect(v47))
		local v48 = v38.Connections
		local v49 = p_u_37.Destroying
		local function v54()
			-- upvalues: (copy) p_u_37, (ref) v_u_10
			local v50 = p_u_37
			local v51 = v_u_10[v50]
			if v51 then
				v_u_10[v50] = nil
				local v52 = v51.Track
				if v52 then
					v51.Track = nil
					v51.Playing = false
					v52:Stop(0.2)
					v52:Destroy()
				end
				for _, v53 in v51.Connections do
					v53:Disconnect()
				end
			end
		end
		table.insert(v48, v49:Connect(v54))
		v_u_31(p_u_37)
	end
end
function v9.Continue(p56, p57) -- name: Continue
	-- upvalues: (copy) v_u_10, (copy) v_u_55
	local v58 = v_u_10[p56]
	if v58 then
		v58 = v58.Track
	end
	local v59
	if v58 then
		v59 = v58.TimePosition
	else
		v59 = nil
	end
	v_u_55(p57)
	local v60 = v_u_10[p57]
	if v60 and (v60.Track and v59) then
		if not v60.Playing then
			v60.Playing = true
			v60.Track:Play(0)
		end
		v60.Track.TimePosition = v59
	end
end
function v9.Start() -- name: Start
	-- upvalues: (copy) v_u_7, (copy) v_u_1, (copy) v_u_55, (copy) v_u_36, (copy) v_u_3, (copy) v_u_6, (copy) v_u_10, (copy) v_u_16
	for _, v61 in { v_u_7.EggToolTag, v_u_7.PlacedEggTag } do
		for _, v62 in v_u_1:GetTagged(v61) do
			v_u_55(v62)
		end
		v_u_1:GetInstanceAddedSignal(v61):Connect(v_u_55)
		v_u_1:GetInstanceRemovedSignal(v61):Connect(v_u_36)
	end
	local v_u_63 = 0
	v_u_3.Heartbeat:Connect(function(p64)
		-- upvalues: (ref) v_u_63, (ref) v_u_6, (ref) v_u_10, (ref) v_u_16
		v_u_63 = v_u_63 + p64
		if v_u_63 >= v_u_6.AnimCheckInterval then
			v_u_63 = 0
			for _, v65 in v_u_10 do
				local v66 = v65.Track
				if not v66 then
					continue
				end
				local v67 = v_u_16(v65)
				if v67 and not v65.Playing then
					v65.Playing = true
					v66:Play(0.2)
				else
					if v67 or not v65.Playing then
						continue
					end
					v65.Playing = false
					v66:Stop(0.3)
				end
			end
		end
	end)
end
return v9
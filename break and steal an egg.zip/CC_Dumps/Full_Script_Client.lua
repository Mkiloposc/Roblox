local v1 = game:GetService("Players")
local v_u_2 = require(script.Parent.console)
require(script.Parent.Parent.roblox_packages.language)
local v_u_3 = require(script.Parent.net)
local v_u_4 = require(script.Parent.state)
require(script.Parent.types)
local v_u_5 = require(script.Parent.user)
local v_u_6 = v1.LocalPlayer
local v_u_7 = 0
return {
	["create_local_user"] = function(p8) -- name: create_local_user
		-- upvalues: (copy) v_u_5, (copy) v_u_6, (copy) v_u_4
		v_u_4.local_user = v_u_5.create_user({
			["name"] = p8.name,
			["player"] = v_u_6
		})
	end,
	["update_user_roles"] = function(p9) -- name: update_user_roles
		-- upvalues: (copy) v_u_4
		local v10 = v_u_4.users[p9.id]
		assert(v10, "local user does not exist")
		v10.roles = p9.roles
	end,
	["update_role_permissions"] = function(p11) -- name: update_role_permissions
		-- upvalues: (copy) v_u_4
		v_u_4.roles[p11.name] = p11.permissions
	end,
	["register_command"] = function(p_u_12) -- name: register_command
		-- upvalues: (copy) v_u_2, (ref) v_u_7, (copy) v_u_4, (copy) v_u_3
		local v_u_13 = {
			["kind"] = "overload",
			["overloads"] = nil,
			["overloads"] = p_u_12.overloads
		}
		for _, v14 in v_u_13.overloads do
			for v15, v16 in v14.arguments do
				if v16.kind == "literal" then
					continue
				end
				local v17 = v_u_2.get_type(v16.unique_identifier)
				if not v17 then
					warn("unregistered type", v17)
					return
				end
				local v18 = table.clone(v17.analysis)
				v18.name = v16.name
				v18.description = v16.description
				v18.optional = v16.optional
				v18.type = v16.type
				if v18.kind == "argument" then
					v18.vararg = v16.vararg
				end
				v14.arguments[v15] = v18
			end
		end
		v_u_2.register_command(p_u_12.name, {
			["description"] = p_u_12.description,
			["permissions"] = p_u_12.permissions,
			["arguments"] = function()
				-- upvalues: (copy) v_u_13
				return v_u_13
			end,
			["callback"] = function(...) -- name: callback
				-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_3, (copy) p_u_12
				local v19 = coroutine.running()
				v_u_7 = v_u_7 + 1
				v_u_4.continuations[v_u_7] = v19
				v_u_3.client.invoke_command(v_u_7, p_u_12.name, { ... })
				local v20 = coroutine.yield()
				if v20.status == "ok" then
					local v21 = v20.results
					return unpack(v21)
				end
				error("something went wrong on the server")
			end
		})
	end,
	["receive_server_results"] = function(p22) -- name: receive_server_results
		-- upvalues: (copy) v_u_4
		local v23 = v_u_4.continuations[p22.invoke_id]
		if v23 then
			v_u_4.continuations[p22.invoke_id] = nil
			task.spawn(v23, p22)
		end
	end,
	["log"] = function(p24) -- name: log
		-- upvalues: (copy) v_u_2
		v_u_2.console.output(p24)
	end
}
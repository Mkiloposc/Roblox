local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(script.Parent.MutationConfig)
local v_u_3 = require(script.Parent.ZoneAnimalsConfig)
local v4 = script.Parent.Parent:WaitForChild("Rarities", 10)
local v_u_5 = {
	["PoolFolderName"] = "Animals",
	["PoolVariants"] = nil,
	["DefaultPoolVariant"] = "Normal",
	["PoolVariantCashMult"] = nil,
	["PoolVariantHatchChance"] = nil,
	["TargetHeight"] = 4,
	["MaxVisualSizeMult"] = 10,
	["MaxMergedSizeMult"] = 13,
	["SoftVisualSizeMult"] = 1.5,
	["MinVisualSizeMult"] = 0.4,
	["PickupSpawnDelay"] = 0,
	["PickupLifetime"] = 45,
	["OneShotLifetimeFraction"] = 1,
	["OneShotLifetimeMin"] = 10,
	["PickupDespawnPop"] = nil,
	["HatchSequence"] = nil,
	["Luck"] = nil,
	["Weight"] = nil,
	["ZoneEggs"] = nil,
	["Pool"] = nil,
	["DisplayNames"] = nil,
	["RarityColors"] = nil,
	["RarityGradients"] = nil,
	["RarityGradientRotations"] = nil,
	["AnimatedRarityGradients"] = nil,
	["PoolVariants"] = { "Normal", "Gold", "Diamond" },
	["PoolVariantCashMult"] = {
		["Gold"] = 2,
		["Diamond"] = 4
	},
	["PoolVariantHatchChance"] = {
		["Gold"] = 0.01,
		["Diamond"] = 0.0025
	},
	["PickupDespawnPop"] = {
		["PopScale"] = 1.2,
		["PopTime"] = 0.12,
		["ShrinkTime"] = 0.25,
		["CleanupDelay"] = 0.6
	},
	["HatchSequence"] = {
		["SpinIntroDuration"] = 1,
		["ShakePreDuration"] = 1.75,
		["ShakeTiltMagnitude"] = 8,
		["ShakeTiltRate"] = 6,
		["Grow"] = nil,
		["ScreenShakeDistance"] = 60,
		["ScreenShakeDurationBuffer"] = 2,
		["OpenSoundRange"] = 80,
		["ExplodeDuration"] = 1,
		["ExplodeUpscaleSize"] = 3,
		["PetLookDuration"] = 2.5,
		["PetFloatRate"] = 0.5,
		["PetFloatHeight"] = 0,
		["Grow"] = {
			["Duration"] = 4,
			["MinVisualMult"] = 1.75,
			["ShakeRate"] = 60,
			["JitterPerMult"] = 0.5,
			["JitterMax"] = 2,
			["ScreenShakePerMult"] = 0.05,
			["RattleSpeedPerMult"] = 0.35,
			["AuraDelayFrac"] = 0.65,
			["AuraShakeDuration"] = 1,
			["AuraShakeMagnitude"] = 2,
			["Tick"] = nil,
			["Rumble"] = nil,
			["Tick"] = {
				["SoundName"] = "Dark Impact",
				["StartInterval"] = 0.25,
				["EndInterval"] = 0.05,
				["StartPitch"] = 1,
				["EndPitch"] = 2
			},
			["Rumble"] = {
				["SoundName"] = "Egg Rumble",
				["SoundFolder"] = "SFX",
				["Volume"] = 0.15,
				["FadeOutTime"] = 0.25
			}
		}
	},
	["Luck"] = {
		["PoolChances"] = nil,
		["PoolFalloff"] = 2.5,
		["BasePoolBias"] = 1.1,
		["LuckPoolBias"] = 0.5,
		["MaxLuckBias"] = 4,
		["SizePickLuck"] = 1,
		["SizeFloors"] = nil,
		["BracketPickLuck"] = nil,
		["PoolChances"] = {
			[2] = { 99, 1 },
			[3] = { 69, 30, 1 },
			[4] = {
				55,
				30,
				14,
				1
			},
			[5] = {
				50,
				30,
				15,
				4,
				1
			}
		},
		["SizeFloors"] = {
			{
				["Chance"] = 0.2,
				["CutFrac"] = 0.25
			},
			{
				["Chance"] = 0.04,
				["CutFrac"] = 0.5
			},
			{
				["Chance"] = 0.01,
				["CutFrac"] = 0.75
			}
		},
		["BracketPickLuck"] = {
			["TITANIC"] = 2
		}
	},
	["Weight"] = {
		["Normalize"] = {
			["AnchorKg"] = 50,
			["Exponent"] = 1
		},
		["BaseKg"] = {
			["Common"] = 39.8,
			["Uncommon"] = 43.3,
			["Rare"] = 47.3,
			["Epic"] = 42,
			["Legendary"] = 52.3,
			["Mythic"] = 104.4,
			["Divine"] = 100,
			["Cosmic"] = 62.2,
			["Secret"] = 91.9,
			["Celestial"] = 116,
			["Inferno"] = 136.1,
			["Void"] = 165.2,
			["Omega"] = 130.7,
			["Spectral"] = 165.7,
			["Ethereal"] = 170
		},
		["EggBaseKg"] = {
			["Basic Egg"] = 36.2,
			["Forest Egg"] = 36.2,
			["Rock Egg"] = 39.4,
			["Swamp Egg"] = 42.9,
			["Cactus Egg"] = 48.9,
			["Bones Egg"] = 43.2,
			["Scorpion Egg"] = 42.3,
			["Frozen Egg"] = 41.8,
			["Frosty Egg"] = 42.3,
			["Yeti Egg"] = 66.9,
			["Rainbow Egg"] = 40.9,
			["Easter Bunny Egg"] = 40.9,
			["Candy Egg"] = 47.3,
			["Gooey Egg"] = 38.2,
			["Tree Egg"] = 52.4,
			["Lake Egg"] = 60.8,
			["Sea Stones Egg"] = 101.5,
			["Sea Egg"] = 104.5,
			["Water Egg"] = 107.8,
			["Angel Egg"] = 89.4,
			["Fallen Angel Egg"] = 105.3,
			["Volcanic Egg"] = 104.1,
			["Bamboo Egg"] = 44.6,
			["Blossom Egg"] = 45.5,
			["Fortune Egg"] = 47.3,
			["Starry Egg"] = 85.3,
			["Sun Egg"] = 86.3,
			["BlackHole Egg"] = 88.4,
			["Plasma Egg"] = 145,
			["Nebula Egg"] = 149.6,
			["Supernova Egg"] = 155,
			["Skull Egg"] = 145,
			["LockedEgg"] = 149.6,
			["Phantom Egg"] = 155,
			["LunaEgg"] = 145,
			["FairyEgg"] = 147.5,
			["PhoenixEgg"] = 149.6,
			["CrystalEgg"] = 152,
			["RoyalDragonEgg"] = 155
		},
		["AnimalKg"] = {
			["Snail"] = 37.7,
			["Chicken"] = 36,
			["Frog"] = 27.2,
			["Pigeon"] = 36.2,
			["Bunny"] = 40.4,
			["Cat"] = 39.4,
			["Bat"] = 39.1,
			["Binturong"] = 44.8,
			["Badger"] = 41.6,
			["Owl"] = 31.4,
			["Tanuki"] = 41.8,
			["HoneyBadger"] = 41.6,
			["Fossa"] = 42.9,
			["Wolf"] = 48.8,
			["Bear"] = 82.4,
			["Emu"] = 35,
			["Lizard"] = 36,
			["Snake"] = 48.9,
			["Bull"] = 64.9,
			["Cobra"] = 83.6,
			["Aardvark"] = 45,
			["Dingo"] = 40.4,
			["Jackal"] = 39.8,
			["Ostrich"] = 43.2,
			["Llama"] = 50.3,
			["Serval"] = 40.7,
			["Caracal"] = 43.1,
			["SecretaryBird"] = 42.3,
			["Hyena"] = 41.6,
			["Lion"] = 79.2,
			["Maltese"] = 41.8,
			["Goat"] = 47.2,
			["Albatross"] = 32.2,
			["Seal"] = 59.6,
			["Akita"] = 40.5,
			["BichonFrise"] = 32.3,
			["ChowChow"] = 42.3,
			["Blobfish"] = 38.1,
			["Yak"] = 50.6,
			["Polar Bear"] = 82.1,
			["Great Dane"] = 37.9,
			["Whale"] = 94.3,
			["SABER_TOOTHED_TIGER"] = 66.9,
			["Fenrir"] = 49.9,
			["Mamoth"] = 91.6,
			["Seahorse"] = 22.1,
			["Hamster"] = 25.7,
			["Boston Terrier"] = 40.9,
			["GuiennaPig"] = 43.8,
			["Quokka"] = 44.3,
			["English Bulldog"] = 39.9,
			["Koala"] = 36,
			["Cavalier King Charles Spaniel"] = 40.9,
			["GoldenRetriver"] = 53.9,
			["Capybara"] = 43.7,
			["Butterflyfish"] = 40.7,
			["Papillon"] = 43.9,
			["Mandarinfish"] = 47.3,
			["Pony"] = 56.7,
			["Unicorn"] = 58,
			["Muscovy Duck"] = 29.9,
			["pufferfish"] = 36.9,
			["Turtle"] = 38.2,
			["archerfish"] = 39.4,
			["Shoebill"] = 39.9,
			["stingray"] = 40,
			["Crocodile"] = 66.1,
			["wobbegong"] = 48.6,
			["Kappa"] = 52.4,
			["Bunyip"] = 67.1,
			["Cassowary"] = 37.7,
			["Chupacabra"] = 60.8,
			["Lindworm"] = 59.9,
			["MOTHMAN"] = 65.3,
			["TripleCobra"] = 97.6,
			["COCKATRICE"] = 73.1,
			["GRIFFIN"] = 141.2,
			["PEGASUS"] = 101.5,
			["MANTICORE"] = 104.5,
			["WYVERN"] = 201.6,
			["CERBERUS"] = 94.1,
			["HYDRA"] = 123.9,
			["Kitsune"] = 76.7,
			["SPHINX"] = 67.9,
			["KRAKEN"] = 141.6,
			["SIMURGH"] = 89.4,
			["FIREPHOENIX"] = 105.3,
			["LEVIATHAN"] = 92.8,
			["CLASSICDRAGON"] = 252.7,
			["THUNDERBIRD"] = 85.3,
			["QILIN"] = 116.1,
			["ARCHAEOPTERYX"] = 89.6,
			["ARGENTAVIS"] = 87.4,
			["AZHDARCHID"] = 146.9,
			["Amphiptere"] = 148.1,
			["Anglerfish"] = 40.5,
			["Ankylosaurus"] = 99.7,
			["Anteater"] = 48.4,
			["Australian Cattle Dog"] = 40.1,
			["Boxfish"] = 32.5,
			["Brachiosaurus"] = 127.9,
			["CALADRIUS"] = 87.2,
			["CHIREMA"] = 95.8,
			["CoralGoby"] = 34.2,
			["Cow"] = 59.8,
			["Crab"] = 33.5,
			["Cuttlefish"] = 38.3,
			["DIMETRODON"] = 95.1,
			["Dullahan"] = 96.6,
			["DumboOctopus"] = 31.8,
			["Elephant"] = 95.4,
			["FangtoothFish"] = 32.1,
			["GARGOYLE_BAT"] = 77.3,
			["GARUDA"] = 74.4,
			["Gallimimus"] = 116.3,
			["GiantIsopod"] = 28.7,
			["Giraffee"] = 79.7,
			["GoblinShark"] = 38,
			["Goldfish"] = 34.2,
			["Gorilla"] = 78.6,
			["HARPY"] = 86.2,
			["Horse"] = 55.3,
			["Jackalope"] = 45.6,
			["Jellyfish"] = 39,
			["Kangaroo"] = 60.6,
			["Kookaburra"] = 31.6,
			["LeafySeaDragon"] = 45.1,
			["Lionfish"] = 42,
			["MEGALODON"] = 102.5,
			["MICRORAPTOR"] = 125.7,
			["MINOTAUR"] = 56.5,
			["MantisShrimp"] = 37.6,
			["Moorish idol"] = 35.1,
			["Mosasaurus"] = 107.1,
			["Nautilus"] = 29.3,
			["PLESIOSAUR"] = 192.4,
			["PREHISTORIC_DRAGONFLY"] = 51.1,
			["PREHISTORIC_MOTH"] = 44.7,
			["PTERANODON"] = 122.8,
			["PTERODACTYL"] = 158.2,
			["Parrot"] = 40.3,
			["QUETZALCOATLUS"] = 124.5,
			["ROC"] = 85.3,
			["Raiju"] = 42.6,
			["Regal"] = 33,
			["STEGOSAURUS"] = 95.8,
			["STYMPHALIANBIRD"] = 78.3,
			["Shark"] = 68.2,
			["Spinosaurus"] = 125.7,
			["Surgeonfish"] = 40.4,
			["Swordfish"] = 76.6,
			["T-Rex"] = 120.2,
			["Tiger"] = 60.9,
			["Triceratops"] = 104.1,
			["Velicoraptor"] = 136.1,
			["WINGED_IMP"] = 78.9,
			["Wrasse"] = 41.1,
			["YI_QI"] = 67.4,
			["Zebra"] = 61.8,
			["barracuda"] = 33.7,
			["Jax"] = 161.4,
			["Gargoyle"] = 136.2,
			["Mushroom"] = 123.6,
			["Mimic"] = 120.7,
			["Rock Crab"] = 176.9,
			["John The Toad"] = 173.6,
			["Black Widow"] = 191.9,
			["Scarecrow"] = 137.9,
			["Volcano Turtle"] = 192.4,
			["Wizard Owl"] = 130.7,
			["Bug"] = 163.4,
			["CrystalLizard"] = 145,
			["CrystalBeast"] = 145.2,
			["CrystalRaptor"] = 149.8,
			["CrystalDragon"] = 155,
			["Mantis"] = 149.4,
			["AlienJellyfish"] = 162.4,
			["CrystalScorpion"] = 164.4,
			["Behemoth"] = 156.5,
			["CrystalWolf"] = 136.3,
			["CelestialBeast"] = 140.7,
			["CelestialSpirit"] = 123.4,
			["CelestialAxolotl"] = 137.9,
			["CelestialFrog"] = 148.9,
			["CelestialLamb"] = 143.1,
			["CelestialSpiritFox"] = 146.5,
			["CelestialGorilla"] = 150.2,
			["ScarecrowTurkey"] = 136.1,
			["ScarecrowOwl"] = 136.1,
			["CandleCat"] = 136.1,
			["ScarecrowRhino"] = 136.1,
			["CandleWolf"] = 136.1,
			["LanternDeer"] = 136.1,
			["ScarecrowLion"] = 136.1,
			["ScarecrowHorse"] = 136.1,
			["BoneBat"] = 136.1,
			["BoneHydra"] = 136.1,
			["BoneGuineaPig"] = 136.1,
			["BoneRat"] = 136.1,
			["BoneHorse"] = 136.1,
			["BoneLion"] = 136.1,
			["BoneMammoth"] = 136.1,
			["Frankenblob"] = 159.4,
			["VampireCat"] = 159.7,
			["ScareDog"] = 144.4,
			["VampiricBat"] = 136.1,
			["PossessedChameleon"] = 132.1,
			["HauntedMantis"] = 151.9,
			["GhastlyOctopus"] = 165.7,
			["ZombieAxolotl"] = 147.9,
			["PhantomBird"] = 145.4,
			["UndeadCapybara"] = 145,
			["VampirePorcupine"] = 167.8,
			["CursedKangaroo"] = 151.3,
			["HauntedWolf"] = 91.9,
			["HauntedKitsune"] = 91.9,
			["HauntedGriffin"] = 116,
			["HauntedCerberus"] = 116,
			["PenguinKing"] = 136.1,
			["WitchSpider"] = 136.1,
			["cowfish"] = 34.2,
			["hawkfish"] = 37,
			["sailfish"] = 53.3,
			["trumpet"] = 26.3,
			["tuna"] = 39.4
		}
	},
	["ZoneEggs"] = {
		["Zone1"] = {
			["Theme"] = "Forest",
			["Folder"] = "Forest Eggs",
			["Eggs"] = nil,
			["Eggs"] = { "Forest Egg", "Rock Egg", "Swamp Egg" }
		},
		["Zone2"] = {
			["Theme"] = "Desert",
			["Folder"] = "Desert Eggs",
			["Eggs"] = nil,
			["Eggs"] = { "Cactus Egg", "Bones Egg", "Scorpion Egg" }
		},
		["Zone3"] = {
			["Theme"] = "Snowy",
			["Folder"] = "Snowy Eggs",
			["Eggs"] = nil,
			["Eggs"] = { "Frozen Egg", "Frosty Egg", "Yeti Egg" }
		},
		["Zone4"] = {
			["Theme"] = "Candy",
			["Folder"] = "Candy Eggs",
			["Eggs"] = nil,
			["Eggs"] = { "Rainbow Egg", "Easter Bunny Egg", "Candy Egg" }
		},
		["Zone5"] = {
			["Theme"] = "Lake",
			["Folder"] = "Lake Eggs",
			["Eggs"] = nil,
			["Eggs"] = { "Gooey Egg", "Tree Egg", "Lake Egg" }
		},
		["Zone6"] = {
			["Theme"] = "Under Water",
			["Folder"] = "Under Water Eggs",
			["Eggs"] = nil,
			["Eggs"] = { "Sea Stones Egg", "Sea Egg", "Water Egg" }
		},
		["Zone7"] = {
			["Theme"] = "Volcano",
			["Folder"] = "Volcano Eggs",
			["Eggs"] = nil,
			["Eggs"] = { "Angel Egg", "Fallen Angel Egg", "Volcanic Egg" }
		},
		["Zone8"] = {
			["Theme"] = "Blossom",
			["Folder"] = "Blossom Eggs",
			["Eggs"] = nil,
			["Eggs"] = { "Bamboo Egg", "Blossom Egg", "Fortune Egg" }
		},
		["Zone9"] = {
			["Theme"] = "Galaxy",
			["Folder"] = "Galaxy Eggs",
			["Eggs"] = nil,
			["Eggs"] = { "Starry Egg", "Sun Egg", "BlackHole Egg" }
		},
		["Zone10"] = {
			["Theme"] = "Planet X",
			["Folder"] = "Alien Eggs",
			["Eggs"] = nil,
			["Eggs"] = { "Plasma Egg", "Nebula Egg", "Supernova Egg" }
		},
		["Zone11"] = {
			["Theme"] = "Haunted Graveyard",
			["Folder"] = "Zone_11",
			["Eggs"] = nil,
			["Eggs"] = { "Skull Egg", "LockedEgg", "Phantom Egg" }
		},
		["Zone12"] = {
			["Theme"] = "Fairy Castle",
			["Folder"] = "FairyEgg",
			["Eggs"] = nil,
			["Rarities"] = nil,
			["Eggs"] = {
				"LunaEgg",
				"FairyEgg",
				"PhoenixEgg",
				"CrystalEgg",
				"RoyalDragonEgg"
			},
			["Rarities"] = {
				"Void",
				"Void",
				"Omega",
				"Omega",
				"Spectral"
			}
		}
	},
	["Pool"] = {},
	["DisplayNames"] = {
		["GuiennaPig"] = "Guinea Pig",
		["GoldenRetriver"] = "Golden Retriever",
		["Mamoth"] = "Mammoth",
		["Giraffee"] = "Giraffe",
		["Velicoraptor"] = "Velociraptor",
		["FIREPHOENIX"] = "Fire Phoenix",
		["CLASSICDRAGON"] = "Fire Dragon",
		["SABER_TOOTHED_TIGER"] = "Sabertooth",
		["HellCroc"] = "Demon Boar",
		["HellAnky"] = "Demon Boar",
		["HellTrike"] = "Demon Scorpion",
		["HellMegalodon"] = "Hellhound",
		["HellDinoRex"] = "Hellhound",
		["HellTRex"] = "Demon Golem",
		["HellDragon"] = "Demon Dragon",
		["HellHydra"] = "Cerberus",
		["AngelCroc"] = "Angel Boar",
		["AngelAnky"] = "Angel Boar",
		["AngelTrike"] = "Angel Scorpion",
		["AngelMegalodon"] = "Angel Hound",
		["AngelTRex"] = "Angel Golem",
		["AngelDragon"] = "Angel Dragon",
		["AngelHydra"] = "Angel Cerberus"
	},
	["RarityColors"] = {
		["Common"] = Color3.fromRGB(200, 200, 200),
		["Uncommon"] = Color3.fromRGB(88, 214, 96),
		["Rare"] = Color3.fromRGB(64, 140, 255),
		["Epic"] = Color3.fromRGB(170, 84, 255),
		["Legendary"] = Color3.fromRGB(255, 170, 40),
		["Mythic"] = Color3.fromRGB(255, 80, 80),
		["Divine"] = Color3.fromRGB(120, 235, 235),
		["Celestial"] = Color3.fromRGB(255, 223, 110),
		["Cosmic"] = Color3.fromRGB(255, 90, 245),
		["Secret"] = Color3.fromRGB(235, 235, 235),
		["Inferno"] = Color3.fromRGB(235, 30, 30),
		["Void"] = Color3.fromRGB(150, 70, 255),
		["Omega"] = Color3.fromRGB(70, 255, 120),
		["Spectral"] = Color3.fromRGB(110, 235, 255),
		["Ethereal"] = Color3.fromRGB(255, 160, 230)
	}
}
local v6 = {}
local v7 = Color3.fromRGB(200, 200, 200)
local v8
if v4 then
	v8 = v4:FindFirstChild("Common")
else
	v8 = v4
end
if not (v8 and v8:IsA("UIGradient")) then
	v8 = nil
end
local v9
if v8 then
	v9 = v8.Color
else
	v9 = ColorSequence.new(v7)
end
v6.Common = v9
local v10 = Color3.fromRGB(88, 214, 96)
local v11
if v4 then
	v11 = v4:FindFirstChild("Uncommon")
else
	v11 = v4
end
if not (v11 and v11:IsA("UIGradient")) then
	v11 = nil
end
local v12
if v11 then
	v12 = v11.Color
else
	v12 = ColorSequence.new(v10)
end
v6.Uncommon = v12
local v13 = Color3.fromRGB(64, 140, 255)
local v14
if v4 then
	v14 = v4:FindFirstChild("Rare")
else
	v14 = v4
end
if not (v14 and v14:IsA("UIGradient")) then
	v14 = nil
end
local v15
if v14 then
	v15 = v14.Color
else
	v15 = ColorSequence.new(v13)
end
v6.Rare = v15
local v16 = Color3.fromRGB(170, 84, 255)
local v17
if v4 then
	v17 = v4:FindFirstChild("Epic")
else
	v17 = v4
end
if not (v17 and v17:IsA("UIGradient")) then
	v17 = nil
end
local v18
if v17 then
	v18 = v17.Color
else
	v18 = ColorSequence.new(v16)
end
v6.Epic = v18
local v19 = Color3.fromRGB(255, 80, 80)
local v20
if v4 then
	v20 = v4:FindFirstChild("Legendary")
else
	v20 = v4
end
if not (v20 and v20:IsA("UIGradient")) then
	v20 = nil
end
local v21
if v20 then
	v21 = v20.Color
else
	v21 = ColorSequence.new(v19)
end
v6.Legendary = v21
v6.Mythic = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 40, 40)),
	ColorSequenceKeypoint.new(0.16666666666666666, Color3.fromRGB(255, 150, 30)),
	ColorSequenceKeypoint.new(0.3333333333333333, Color3.fromRGB(255, 235, 50)),
	ColorSequenceKeypoint.new(0.5, Color3.fromRGB(60, 230, 80)),
	ColorSequenceKeypoint.new(0.6666666666666666, Color3.fromRGB(40, 160, 255)),
	ColorSequenceKeypoint.new(0.8333333333333334, Color3.fromRGB(160, 70, 255)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 40, 40))
})
local v22 = Color3.fromRGB(235, 235, 235)
local v23
if v4 then
	v23 = v4:FindFirstChild("Secret")
else
	v23 = v4
end
if not (v23 and v23:IsA("UIGradient")) then
	v23 = nil
end
local v24
if v23 then
	v24 = v23.Color
else
	v24 = ColorSequence.new(v22)
end
v6.Secret = v24
v6.Divine = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(10, 20, 120)),
	ColorSequenceKeypoint.new(0.22, Color3.fromRGB(40, 120, 255)),
	ColorSequenceKeypoint.new(0.42, Color3.fromRGB(170, 245, 255)),
	ColorSequenceKeypoint.new(0.62, Color3.fromRGB(90, 100, 255)),
	ColorSequenceKeypoint.new(0.8, Color3.fromRGB(150, 80, 235)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(10, 20, 120))
})
v6.Celestial = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(150, 95, 15)),
	ColorSequenceKeypoint.new(0.35, Color3.fromRGB(235, 170, 40)),
	ColorSequenceKeypoint.new(0.48, Color3.fromRGB(255, 215, 90)),
	ColorSequenceKeypoint.new(0.55, Color3.fromRGB(255, 252, 220)),
	ColorSequenceKeypoint.new(0.62, Color3.fromRGB(255, 215, 90)),
	ColorSequenceKeypoint.new(0.75, Color3.fromRGB(235, 170, 40)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(150, 95, 15))
})
v6.Cosmic = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(25, 5, 60)),
	ColorSequenceKeypoint.new(0.2, Color3.fromRGB(120, 20, 200)),
	ColorSequenceKeypoint.new(0.4, Color3.fromRGB(255, 60, 230)),
	ColorSequenceKeypoint.new(0.55, Color3.fromRGB(255, 170, 250)),
	ColorSequenceKeypoint.new(0.7, Color3.fromRGB(150, 40, 235)),
	ColorSequenceKeypoint.new(0.85, Color3.fromRGB(60, 15, 120)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(25, 5, 60))
})
v6.Inferno = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(200, 25, 25)),
	ColorSequenceKeypoint.new(0.2, Color3.fromRGB(240, 60, 30)),
	ColorSequenceKeypoint.new(0.38, Color3.fromRGB(255, 120, 40)),
	ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 200, 80)),
	ColorSequenceKeypoint.new(0.56, Color3.fromRGB(255, 245, 180)),
	ColorSequenceKeypoint.new(0.62, Color3.fromRGB(255, 200, 80)),
	ColorSequenceKeypoint.new(0.78, Color3.fromRGB(240, 70, 30)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(200, 25, 25))
})
v6.Void = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(12, 0, 30)),
	ColorSequenceKeypoint.new(0.25, Color3.fromRGB(70, 10, 150)),
	ColorSequenceKeypoint.new(0.42, Color3.fromRGB(150, 70, 255)),
	ColorSequenceKeypoint.new(0.5, Color3.fromRGB(230, 210, 255)),
	ColorSequenceKeypoint.new(0.58, Color3.fromRGB(150, 70, 255)),
	ColorSequenceKeypoint.new(0.75, Color3.fromRGB(70, 10, 150)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(12, 0, 30))
})
v6.Omega = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(10, 150, 60)),
	ColorSequenceKeypoint.new(0.22, Color3.fromRGB(40, 230, 90)),
	ColorSequenceKeypoint.new(0.4, Color3.fromRGB(170, 255, 60)),
	ColorSequenceKeypoint.new(0.5, Color3.fromRGB(235, 255, 200)),
	ColorSequenceKeypoint.new(0.6, Color3.fromRGB(170, 255, 60)),
	ColorSequenceKeypoint.new(0.8, Color3.fromRGB(30, 220, 200)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(10, 150, 60))
})
v6.Spectral = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(10, 14, 30)),
	ColorSequenceKeypoint.new(0.18, Color3.fromRGB(40, 70, 120)),
	ColorSequenceKeypoint.new(0.32, Color3.fromRGB(90, 230, 255)),
	ColorSequenceKeypoint.new(0.42, Color3.fromRGB(170, 255, 215)),
	ColorSequenceKeypoint.new(0.48, Color3.fromRGB(255, 255, 255)),
	ColorSequenceKeypoint.new(0.54, Color3.fromRGB(170, 255, 215)),
	ColorSequenceKeypoint.new(0.66, Color3.fromRGB(120, 160, 255)),
	ColorSequenceKeypoint.new(0.8, Color3.fromRGB(70, 50, 140)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(10, 14, 30))
})
v6.Ethereal = ColorSequence.new({
	ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 120, 210)),
	ColorSequenceKeypoint.new(0.2, Color3.fromRGB(200, 140, 255)),
	ColorSequenceKeypoint.new(0.38, Color3.fromRGB(150, 200, 255)),
	ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 255, 255)),
	ColorSequenceKeypoint.new(0.62, Color3.fromRGB(160, 255, 220)),
	ColorSequenceKeypoint.new(0.8, Color3.fromRGB(255, 225, 130)),
	ColorSequenceKeypoint.new(1, Color3.fromRGB(255, 120, 210))
})
v_u_5.RarityGradients = v6
local v25 = {
	["Common"] = nil,
	["Uncommon"] = nil,
	["Rare"] = nil,
	["Epic"] = nil,
	["Legendary"] = nil,
	["Mythic"] = 0,
	["Secret"] = nil,
	["Divine"] = 45,
	["Celestial"] = 0,
	["Cosmic"] = 90,
	["Inferno"] = 135,
	["Void"] = -45,
	["Omega"] = 180,
	["Spectral"] = -135,
	["Ethereal"] = 60
}
v4 = v4
local v26
if v4 then
	v26 = v4:FindFirstChild("Common")
end
if not (v26 and v26:IsA("UIGradient")) then
	v26 = nil
end
v25.Common = not v26 and -90 or v26.Rotation
v4 = v4
local v27
if v4 then
	v27 = v4:FindFirstChild("Uncommon")
end
if not (v27 and v27:IsA("UIGradient")) then
	v27 = nil
end
v25.Uncommon = not v27 and -90 or v27.Rotation
v4 = v4
local v28
if v4 then
	v28 = v4:FindFirstChild("Rare")
end
if not (v28 and v28:IsA("UIGradient")) then
	v28 = nil
end
v25.Rare = not v28 and -90 or v28.Rotation
v4 = v4
local v29
if v4 then
	v29 = v4:FindFirstChild("Epic")
end
if not (v29 and v29:IsA("UIGradient")) then
	v29 = nil
end
v25.Epic = not v29 and -90 or v29.Rotation
v4 = v4
local v30
if v4 then
	v30 = v4:FindFirstChild("Legendary")
else
	v30 = v4
end
if not (v30 and v30:IsA("UIGradient")) then
	v30 = nil
end
v25.Legendary = not v30 and -90 or v30.Rotation
local v31 = v4
if v31 then
	v31 = v4:FindFirstChild("Secret")
end
if not (v31 and v31:IsA("UIGradient")) then
	v31 = nil
end
v25.Secret = not v31 and -90 or v31.Rotation
v_u_5.RarityGradientRotations = v25
v_u_5.AnimatedRarityGradients = {
	["Mythic"] = true,
	["Secret"] = true,
	["Divine"] = true,
	["Celestial"] = true,
	["Cosmic"] = true,
	["Inferno"] = true,
	["Void"] = true,
	["Omega"] = true,
	["Spectral"] = true,
	["Ethereal"] = true
}
local v32 = {}
for v33 = 1, #v_u_3.Zones do
	local v34 = v_u_3.Zones[v33]
	for v35, v36 in v34 do
		local v37 = {
			["Name"] = v36.Name,
			["Rarity"] = v36.Rarity,
			["Cash"] = v36.Cash or 1,
			["Zone"] = v33,
			["Chance"] = v36.Chance,
			["ZoneRank"] = v35,
			["ZoneCount"] = #v34
		}
		table.insert(v32, v37)
	end
end
for _, v38 in v_u_3.Extras do
	local v39 = {
		["Name"] = v38.Name,
		["Rarity"] = v38.Rarity,
		["Cash"] = v38.Cash,
		["IndexHidden"] = v38.IndexHidden,
		["IndexLimited"] = v38.IndexLimited,
		["CashZone"] = v38.CashZone
	}
	table.insert(v32, v39)
end
v_u_5.Pool = v32
function v_u_5.DisplayName(p40) -- name: DisplayName
	-- upvalues: (copy) v_u_5
	return v_u_5.DisplayNames[p40] or p40:gsub("_", " "):gsub("(%l)(%u)", "%1 %2"):gsub("%S+", function(p41)
		local v42 = p41:sub(1, 1):upper()
		local v43 = p41:sub(2)
		if v43 ~= "" and v43 == v43:upper() then
			v43 = v43:lower()
		end
		return v42 .. v43
	end)
end
function v_u_5.GetPoolFolder() -- name: GetPoolFolder
	-- upvalues: (copy) v_u_1, (copy) v_u_5
	return v_u_1:FindFirstChild(v_u_5.PoolFolderName)
end
local function v_u_49(p44, p45) -- name: variantFolderIn
	-- upvalues: (copy) v_u_5
	local v46 = p44:FindFirstChild(p45)
	if v46 and v46:IsA("Folder") then
		return v46
	end
	for _, v47 in p44:GetChildren() do
		if not v47:IsA("Folder") or table.find(v_u_5.PoolVariants, v47.Name) ~= nil then
			continue
		end
		local v48 = v47:FindFirstChild(p45)
		if not (v48 and v48:IsA("Folder")) then
			continue
		end
		return v48
	end
	return nil
end
function v_u_5.GetVariantFolder(p50) -- name: GetVariantFolder
	-- upvalues: (copy) v_u_5, (copy) v_u_49
	local v51 = v_u_5.GetPoolFolder()
	if v51 then
		v51 = v_u_49(v51, p50 or v_u_5.DefaultPoolVariant)
	end
	return v51
end
local function v_u_57(p52, p53) -- name: findTemplateIn
	if not p52 then
		return nil
	end
	local v54 = p52:FindFirstChild(p53)
	if v54 and v54:IsA("Model") then
		return v54
	end
	for _, v55 in p52:GetChildren() do
		if not v55:IsA("Folder") then
			continue
		end
		local v56 = v55:FindFirstChild(p53)
		if not (v56 and v56:IsA("Model")) then
			continue
		end
		return v56
	end
	return nil
end
function v_u_5.FindAnimalTemplate(p58, p59) -- name: FindAnimalTemplate
	-- upvalues: (copy) v_u_5, (copy) v_u_57, (copy) v_u_49
	if typeof(p58) ~= "string" or p58 == "" then
		return nil
	end
	local v60 = v_u_5.GetPoolFolder()
	if not v60 then
		return nil
	end
	local v61 = p59 or v_u_5.DefaultPoolVariant
	local v62 = v_u_57(v_u_49(v60, v61), p58)
	if not v62 then
		v62 = v60:FindFirstChild(p58)
		if not (v62 and v62:IsA("Model")) then
			v62 = nil
		end
	end
	if not v62 and v61 ~= v_u_5.DefaultPoolVariant then
		v62 = v_u_57(v60:FindFirstChild(v_u_5.DefaultPoolVariant), p58)
	end
	if not v62 and p59 == nil then
		for _, v63 in v60:GetChildren() do
			if not v63:IsA("Folder") or table.find(v_u_5.PoolVariants, v63.Name) ~= nil then
				continue
			end
			for _, v64 in v63:GetChildren() do
				if not v64:IsA("Folder") then
					continue
				end
				v62 = v_u_57(v64, p58)
				if not v62 then
					continue
				end
				return v62
			end
		end
	end
	return v62
end
function v_u_5.AnimalTemplates(p65) -- name: AnimalTemplates
	-- upvalues: (copy) v_u_5, (copy) v_u_49
	local v_u_66 = {}
	local v67 = v_u_5.GetPoolFolder()
	if not v67 then
		return v_u_66
	end
	local v_u_68 = {}
	local function v_u_73(p69, p70) -- name: collect
		-- upvalues: (copy) v_u_68, (copy) v_u_66, (copy) v_u_73
		if p69 then
			for _, v71 in p69:GetChildren() do
				if v71:IsA("Model") and not v_u_68[v71.Name] then
					v_u_68[v71.Name] = true
					local v72 = v_u_66
					table.insert(v72, v71)
				else
					if not (p70 and v71:IsA("Folder")) then
						continue
					end
					v_u_73(v71, true)
				end
			end
		end
	end
	v_u_73(v_u_49(v67, p65 or v_u_5.DefaultPoolVariant), true)
	v_u_73(v67)
	return v_u_66
end
function v_u_5.AllAnimalTemplates() -- name: AllAnimalTemplates
	-- upvalues: (copy) v_u_5
	local v_u_74 = {}
	local v75 = v_u_5.GetPoolFolder()
	if not v75 then
		return v_u_74
	end
	local function v_u_79(p76) -- name: collect
		-- upvalues: (copy) v_u_74, (copy) v_u_79
		for _, v77 in p76:GetChildren() do
			if v77:IsA("Model") then
				local v78 = v_u_74
				table.insert(v78, v77)
			else
				if not v77:IsA("Folder") then
					continue
				end
				v_u_79(v77)
			end
		end
	end
	v_u_79(v75)
	return v_u_74
end
local v_u_80 = nil
local function v_u_84(p81) -- name: poolEntry
	-- upvalues: (ref) v_u_80, (copy) v_u_5, (copy) v_u_3
	if not p81 then
		return nil
	end
	if not v_u_80 then
		local v82 = {}
		for _, v83 in v_u_5.Pool do
			v82[v83.Name] = v83
		end
		v_u_80 = v82
	end
	return v_u_80[p81] or v_u_3.Legacy[p81]
end
function v_u_5.CashPerSecond(p85) -- name: CashPerSecond
	-- upvalues: (copy) v_u_84
	local v86 = v_u_84(p85)
	return v86 and v86.Cash or 1
end
function v_u_5.RarityOf(p87) -- name: RarityOf
	-- upvalues: (copy) v_u_84
	local v88 = v_u_84(p87)
	if v88 then
		v88 = v88.Rarity
	end
	return v88
end
function v_u_5.ChanceMultOf(p89) -- name: ChanceMultOf
	-- upvalues: (copy) v_u_84
	local v90 = v_u_84(p89)
	return v90 and v90.ChanceMult or 1
end
function v_u_5.ChanceOf(p91) -- name: ChanceOf
	-- upvalues: (copy) v_u_84
	local v92 = v_u_84(p91)
	if v92 then
		v92 = v92.Chance
	end
	return v92
end
function v_u_5.SoftCapSize(p93) -- name: SoftCapSize
	-- upvalues: (copy) v_u_5
	local v94 = v_u_5.SoftVisualSizeMult
	if p93 <= v94 then
		return p93
	end
	local v95 = v_u_5.MaxVisualSizeMult - v94
	if v95 <= 0 then
		return v94
	end
	local v96 = v_u_5.MaxVisualSizeMult
	local v97 = -(p93 - v94) / v95
	return v96 - v95 * math.exp(v97)
end
function v_u_5.VisualSizeMult(p98) -- name: VisualSizeMult
	return math.max(p98 or 1, 0)
end
v_u_5.ZoneKgMult = {
	[10] = 1.5,
	[11] = 1.5,
	[12] = 1.5
}
function v_u_5.ZoneKgMultFor(p99) -- name: ZoneKgMultFor
	-- upvalues: (copy) v_u_5
	local v100 = v_u_5.ZoneOfEggType(p99)
	return v100 and v_u_5.ZoneKgMult[v100] or 1
end
function v_u_5.EggBaseKgFor(p101, p102, p103) -- name: EggBaseKgFor
	-- upvalues: (copy) v_u_5
	local v104 = v_u_5.Weight
	local v105 = p101 and v104.EggBaseKg[p101] or (p102 and v104.BaseKg[p102] or v104.BaseKg.Common)
	local v106 = p103 and 1 or v_u_5.ZoneKgMultFor(p101)
	local v107 = v_u_5.Weight.Normalize
	if v107 and (v107.Exponent and v107.Exponent ~= 1) then
		v105 = v107.AnchorKg * (v105 / v107.AnchorKg) ^ v107.Exponent
	end
	return v105 * v106
end
local v_u_108 = {}
function v_u_5.AnimalBaseKg(p109) -- name: AnimalBaseKg
	-- upvalues: (copy) v_u_108, (copy) v_u_5, (copy) v_u_84
	local v110 = v_u_108[p109]
	if v110 then
		return v110
	end
	local v111 = v_u_5.Weight
	local v112 = v111.AnimalKg[p109]
	if not v112 then
		v112 = v_u_84(p109)
		if v112 then
			v112 = v111.BaseKg[v112.Rarity]
		end
	end
	local v113 = v112 or v111.BaseKg.Common
	local v114 = v_u_5.Weight.Normalize
	if v114 and (v114.Exponent and v114.Exponent ~= 1) then
		v113 = v114.AnchorKg * (v113 / v114.AnchorKg) ^ v114.Exponent
	end
	v_u_108[p109] = v113
	return v113
end
v_u_5.WeightSizeExponent = 3
function v_u_5.KgForSize(p115, p116) -- name: KgForSize
	-- upvalues: (copy) v_u_5
	return p115 * math.max(p116 or 1, 0) ^ v_u_5.WeightSizeExponent
end
function v_u_5.SizeForKg(p117, p118) -- name: SizeForKg
	-- upvalues: (copy) v_u_5
	return (p117 <= 0 or p118 <= 0) and 1 or (p118 / p117) ^ (1 / v_u_5.WeightSizeExponent)
end
v_u_5.SpeciesSizeSpread = 1.5
function v_u_5.ScaleForWeight(p119, p120, p121, p122, p123) -- name: ScaleForWeight
	-- upvalues: (copy) v_u_5
	local v124
	if p119 and (p120 and p120 > 0) then
		local v125 = v_u_5.SizeForKg(v_u_5.AnimalBaseKg(p119), p120)
		local v126 = p121 or 1
		if v126 > 0 then
			local v127 = v_u_5.SpeciesSizeSpread
			local v128 = v125 / v126
			local v129 = 1 / v127
			v125 = v126 * math.clamp(v128, v129, v127)
		end
		local v130 = v_u_5.MinVisualSizeMult
		v124 = math.max(v125, v130)
	else
		v124 = v_u_5.VisualSizeMult(p121)
	end
	if not p122 then
		local v131
		if p123 then
			local v132 = v_u_5.MaxMergedSizeMult
			v131 = math.min(p123, v132)
		else
			v131 = v_u_5.MaxVisualSizeMult
		end
		v124 = math.min(v124, v131)
	end
	return v124
end
v_u_5.PlacedAspectSpan = 2.5
v_u_5.PlotFitSpecies = {
	["stingray"] = true
}
v_u_5.MaxPlacedFootprintFrac = 1.15
function v_u_5.FitsToPlot(p133) -- name: FitsToPlot
	-- upvalues: (copy) v_u_5
	local v134
	if p133 == nil then
		v134 = false
	else
		v134 = v_u_5.PlotFitSpecies[p133] == true
	end
	return v134
end
function v_u_5.MaxPlacedSpan(p135) -- name: MaxPlacedSpan
	-- upvalues: (copy) v_u_5
	local v136 = p135.X
	local v137 = p135.Z
	local v138 = math.min(v136, v137) * v_u_5.MaxPlacedFootprintFrac
	local v139 = v_u_5.TargetHeight
	return math.max(v138, v139)
end
function v_u_5.PlacedScaleFactor(p140, p141, p142) -- name: PlacedScaleFactor
	-- upvalues: (copy) v_u_5
	if p140.Y <= 0 then
		return 1
	end
	local v143 = p140.X
	local v144 = p140.Z
	local v145 = math.max(v143, v144)
	local v146 = p140.Y
	local v147 = v145 / v_u_5.PlacedAspectSpan
	local v148 = p141 / math.max(v146, v147)
	if p142 and v145 > 0 then
		local v149 = v_u_5.MaxPlacedSpan(p142) / v145
		v148 = math.min(v148, v149)
	end
	return v148
end
v_u_5.CashSizeExponent = 3
v_u_5.CashSizeKnee = 2
v_u_5.CashSizeTailExponent = 1
v_u_5.CashSizeMultMin = 0.2
v_u_5.CashSizeReference = {
	1.38,
	1.48,
	1.55,
	1.65,
	1.7,
	1.73,
	1.79,
	1.81,
	1.81,
	1.81,
	1.81
}
local v_u_150 = nil
function v_u_5.ZoneOfEggType(p151) -- name: ZoneOfEggType
	-- upvalues: (ref) v_u_150, (copy) v_u_5
	if not p151 then
		return nil
	end
	if not v_u_150 then
		local v152 = {}
		for v153, v154 in v_u_5.ZoneEggs do
			local v155 = string.match
			local v156 = tonumber(v155(v153, "%d+"))
			if not v156 then
				continue
			end
			for _, v157 in v154.Eggs do
				v152[v157] = v156
			end
		end
		v_u_150 = v152
	end
	return v_u_150[p151]
end
local v_u_158 = nil
function v_u_5.DisplayRarityOf(p159, p160) -- name: DisplayRarityOf
	-- upvalues: (ref) v_u_158, (copy) v_u_5
	if not v_u_158 then
		local v161 = {}
		for _, v162 in v_u_5.ZoneEggs do
			local v163 = v162.Rarities
			if not v163 then
				continue
			end
			for v164, v165 in v162.Eggs do
				v161[v165] = v163[v164]
			end
		end
		v_u_158 = v161
	end
	if p159 then
		p160 = v_u_158[p159] or p160
	end
	return p160
end
function v_u_5.RosterZoneOf(p166) -- name: RosterZoneOf
	-- upvalues: (copy) v_u_3
	if p166 == nil or v_u_3.Zones[p166] then
		return p166
	end
	local v167 = v_u_3.BorrowedRosters
	if v167 then
		p166 = v167[p166] or p166
	end
	return p166
end
function v_u_5.HomeZoneOf(p168) -- name: HomeZoneOf
	-- upvalues: (copy) v_u_84
	local v169 = v_u_84(p168)
	if v169 then
		v169 = v169.Zone
	end
	return v169
end
function v_u_5.CashZoneOf(p170) -- name: CashZoneOf
	-- upvalues: (copy) v_u_84
	local v171 = v_u_84(p170)
	if v171 then
		v171 = v171.Zone or v171.CashZone
	end
	return v171
end
function v_u_5.ZoneRankOf(p172) -- name: ZoneRankOf
	-- upvalues: (copy) v_u_84
	local v173 = v_u_84(p172)
	if v173 and v173.ZoneRank then
		return v173.ZoneRank, v173.ZoneCount
	else
		return nil, nil
	end
end
function v_u_5.SizeReferenceFor(p174) -- name: SizeReferenceFor
	-- upvalues: (copy) v_u_5
	local v175 = v_u_5.CashZoneOf(p174)
	return v175 and v_u_5.CashSizeReference[v175] or 1
end
v_u_5.CashWeightExponent = {
	1.1,
	1.12,
	1.14,
	1.16,
	1.18,
	1.2,
	1.22,
	1.25,
	1.27,
	1.29,
	1.31
}
v_u_5.CashWeightKnee = 8
v_u_5.CashWeightTailExponent = {
	0.55,
	0.57,
	0.59,
	0.61,
	0.63,
	0.65,
	0.67,
	0.7,
	0.72,
	0.74,
	0.76
}
function v_u_5.CashWeightExponentsFor(p176) -- name: CashWeightExponentsFor
	-- upvalues: (copy) v_u_5
	local v177 = v_u_5.CashZoneOf(p176)
	return v177 and v_u_5.CashWeightExponent[v177] or v_u_5.CashWeightExponent[1], v177 and v_u_5.CashWeightTailExponent[v177] or v_u_5.CashWeightTailExponent[1]
end
v_u_5.CashSpeciesAnchorKg = 50
v_u_5.CashSpeciesWeightExponent = 0.5
v_u_5.CashSpeciesWeightMax = 3
function v_u_5.SpeciesWeightCashMult(p178) -- name: SpeciesWeightCashMult
	-- upvalues: (copy) v_u_5
	if not p178 then
		return 1
	end
	local v179 = v_u_5.AnimalBaseKg(p178)
	if v179 <= 0 then
		return 1
	end
	local v180 = (v179 / v_u_5.CashSpeciesAnchorKg) ^ v_u_5.CashSpeciesWeightExponent
	local v181 = v_u_5.CashSpeciesWeightMax
	return math.clamp(v180, 1, v181)
end
function v_u_5.CashWeightMult(p182, p183) -- name: CashWeightMult
	-- upvalues: (copy) v_u_5
	if not p182 or (not p183 or p183 <= 0) then
		return 1
	end
	local v184 = v_u_5.AnimalBaseKg(p182)
	if v184 <= 0 then
		return 1
	end
	local v185 = v_u_5.SizeReferenceFor(p182)
	local v186 = p183 / (v184 * math.max(v185, 0.01) ^ v_u_5.WeightSizeExponent)
	local v187 = v_u_5.CashWeightKnee
	local v188, v189 = v_u_5.CashWeightExponentsFor(p182)
	local v190
	if v186 <= v187 then
		v190 = v186 ^ v188
	else
		v190 = v187 ^ v188 * (v186 / v187) ^ v189
	end
	local v191 = v_u_5.CashSizeMultMin
	return math.max(v190, v191)
end
function v_u_5.CashSizeMult(p192, p193) -- name: CashSizeMult
	-- upvalues: (copy) v_u_5
	local v194 = v_u_5.SizeReferenceFor(p192)
	local v195 = math.max(p193 or 1, 0) / math.max(v194, 0.01)
	local v196 = v_u_5.CashSizeKnee
	local v197
	if v195 <= v196 then
		v197 = v195 ^ v_u_5.CashSizeExponent
	else
		v197 = v196 ^ v_u_5.CashSizeExponent * (v195 / v196) ^ v_u_5.CashSizeTailExponent
	end
	local v198 = v_u_5.CashSizeMultMin
	return math.max(v197, v198)
end
function v_u_5.VariantCashMult(p199) -- name: VariantCashMult
	-- upvalues: (copy) v_u_5
	return p199 and v_u_5.PoolVariantCashMult[p199] or 1
end
function v_u_5.PlacedCashPerSecond(p200, p201, p202, p203, p204) -- name: PlacedCashPerSecond
	-- upvalues: (copy) v_u_84, (copy) v_u_5, (copy) v_u_2
	local v205 = v_u_84(p200)
	local v206
	if p203 and p203 > 0 then
		v206 = v_u_5.CashWeightMult(p200, p203)
	else
		v206 = v_u_5.CashSizeMult(p200, p201)
	end
	local v207 = (v205 and v205.Cash or 1) * v206 * v_u_5.SpeciesWeightCashMult(p200) * v_u_2.CashMult(p202) * v_u_5.VariantCashMult(p204) + 0.5
	local v208 = math.floor(v207)
	return math.max(v208, 1)
end
function v_u_5.PickupLifetimeFor(p209) -- name: PickupLifetimeFor
	-- upvalues: (copy) v_u_5
	if not p209 then
		return v_u_5.PickupLifetime
	end
	local v210 = v_u_5.PickupLifetime * v_u_5.OneShotLifetimeFraction
	local v211 = v_u_5.OneShotLifetimeMin
	local v212 = v_u_5.PickupLifetime
	return math.clamp(v210, v211, v212)
end
return v_u_5
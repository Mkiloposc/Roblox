local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Shared.DiamondShopConfig)
local v_u_4 = v1.LocalPlayer
local v5 = {}
local v_u_6 = {}
local v_u_7 = {}
local v_u_8 = Instance.new("BindableEvent")
local function v_u_13(p9) -- name: ensureTool
	-- upvalues: (copy) v_u_3, (copy) v_u_4
	local v10 = p9.tool
	if v10 and v10.Parent then
		v10.Name = string.format(v_u_3.Inventory.ToolNameFormat, p9.name, p9.count)
		return
	else
		local v11 = v_u_4:FindFirstChildOfClass("Backpack")
		if v11 ~= nil then
			local v12 = Instance.new("Tool")
			v12.RequiresHandle = false
			v12.CanBeDropped = false
			v12.ManualActivationOnly = true
			v12.Name = string.format(v_u_3.Inventory.ToolNameFormat, p9.name, p9.count)
			v12.ToolTip = p9.name
			if v_u_3.Inventory.ShowIcon and p9.image then
				v12.TextureId = p9.image
			end
			v12:SetAttribute("CrateKey", p9.key)
			v12.Parent = v11
			p9.tool = v12
		end
	end
end
function v5.Add(p14, p15, p16, p17) -- name: Add
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_13, (copy) v_u_8
	if p16 > 0 then
		local v18 = v_u_7[p14]
		if v18 == nil then
			v18 = {
				["key"] = nil,
				["name"] = nil,
				["count"] = 0,
				["image"] = nil,
				["tool"] = nil,
				["key"] = p14,
				["name"] = p15,
				["image"] = p17
			}
			v_u_7[p14] = v18
			local v19 = v_u_6
			table.insert(v19, v18)
		end
		v18.count = v18.count + p16
		v_u_13(v18)
		v_u_8:Fire(p14, v18.count)
	end
end
function v5.Get(p20) -- name: Get
	-- upvalues: (copy) v_u_7
	local v21 = v_u_7[p20]
	return not v21 and 0 or v21.count
end
function v5.SlotOf(p22) -- name: SlotOf
	-- upvalues: (copy) v_u_6
	for v23, v24 in v_u_6 do
		if v24.key ~= p22 then
			continue
		end
		return v23, #v_u_6
	end
	return #v_u_6 + 1, #v_u_6 + 1
end
function v5.Observe(p25) -- name: Observe
	-- upvalues: (copy) v_u_8
	return v_u_8.Event:Connect(p25)
end
v_u_4.CharacterAdded:Connect(function()
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_13
	v_u_4:WaitForChild("Backpack")
	for _, v26 in v_u_6 do
		v26.tool = nil
		v_u_13(v26)
	end
end)
return v5
local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = require(v_u_3.Shared.BillboardAssets)
local v_u_6 = require(v_u_3.Shared.FormatNumber)
local v_u_7 = require(script.Parent.EggLocalHits)
local v8 = {}
local v_u_9 = {
	"Amount",
	"Damage",
	"Text",
	"Label"
}
local v_u_10 = TweenInfo.new(0.37, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_11 = TweenInfo.new(0.65, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
local v_u_12 = TweenInfo.new(0.28)
local v_u_13 = Random.new()
local v_u_14 = v2.LocalPlayer
local v_u_15 = v_u_13:NextNumber() < 0.5 and -1 or 1
local function v_u_19() -- name: getHolder
	-- upvalues: (copy) v_u_14
	local v16 = v_u_14
	if v16 then
		v16 = v_u_14:FindFirstChildOfClass("PlayerGui")
	end
	if not v16 then
		return nil
	end
	local v17 = v16:FindFirstChild("EggDamagePopups")
	if v17 and v17:IsA("ScreenGui") then
		return v17
	end
	local v18 = Instance.new("ScreenGui")
	v18.Name = "EggDamagePopups"
	v18.ResetOnSpawn = false
	v18.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	v18.Parent = v16
	return v18
end
local function v_u_23(p20) -- name: findAmountLabel
	-- upvalues: (copy) v_u_9
	for _, v21 in v_u_9 do
		local v22 = p20:FindFirstChild(v21, true)
		if not (v22 and v22:IsA("TextLabel")) then
			continue
		end
		return v22
	end
	return p20:FindFirstChildWhichIsA("TextLabel", true)
end
local function v_u_27(p24) -- name: collectFadeTargets
	local v25 = {}
	for _, v26 in p24:GetDescendants() do
		if v26:IsA("TextLabel") then
			table.insert(v25, {
				["Instance"] = nil,
				["Property"] = "TextTransparency",
				["Instance"] = v26
			})
		elseif v26:IsA("ImageLabel") then
			table.insert(v25, {
				["Instance"] = nil,
				["Property"] = "ImageTransparency",
				["Instance"] = v26
			})
		else
			if not v26:IsA("UIStroke") then
				continue
			end
			table.insert(v25, {
				["Instance"] = nil,
				["Property"] = "Transparency",
				["Instance"] = v26
			})
		end
	end
	return v25
end
local function v_u_48(p28, p29) -- name: showDamagePopupOn
	-- upvalues: (copy) v_u_5, (copy) v_u_19, (copy) v_u_23, (copy) v_u_6, (copy) v_u_13, (ref) v_u_15, (copy) v_u_4, (copy) v_u_10, (copy) v_u_11, (copy) v_u_27, (copy) v_u_12, (copy) v_u_1
	if p29 <= 0 then
		return
	else
		local v30 = v_u_5.Get("EggDamagePopup")
		local v31 = v_u_19()
		if v30 and v31 then
			local v_u_32 = v30:Clone()
			v_u_32.Name = "EggDamage"
			v_u_32.Adornee = p28
			v_u_32.Enabled = true
			local v33 = v_u_23(v_u_32)
			if v33 then
				local v34 = v_u_6.Short
				local v35 = math.round(p29)
				v33.Text = ("-%*"):format((v34((math.max(v35, 1)))))
			end
			local v36 = v_u_32.StudsOffsetWorldSpace + Vector3.new(0, 2.6, 0)
			v_u_32.StudsOffsetWorldSpace = v36
			local v37 = v_u_13:NextNumber(1.6, 2.6)
			local v_u_38 = v36 + Vector3.new(0, v37, 0)
			local v39 = v_u_15 * v_u_13:NextNumber(0.7, 1.5)
			v_u_15 = -v_u_15
			local v40 = v_u_32.StudsOffset + Vector3.new(v39, 0, 0)
			local v41 = v_u_32:FindFirstChildWhichIsA("GuiObject")
			local v42 = v39 * 5.333333333333333
			local v43 = math.clamp(v42, -8, 8)
			local v44 = v_u_32:FindFirstChildOfClass("UIScale")
			if not v44 then
				if v41 then
					v44 = v41:FindFirstChildOfClass("UIScale")
				else
					v44 = v41
				end
			end
			if not v44 then
				if v41 then
					v44 = Instance.new("UIScale")
					v44.Parent = v41
				else
					v44 = nil
				end
			end
			local v45 = not v44 and 1 or v44.Scale
			if v44 then
				v44.Scale = 0
			end
			v_u_32.Parent = v31
			if v44 then
				v_u_4:Create(v44, v_u_10, {
					["Scale"] = v45
				}):Play()
			end
			v_u_4:Create(v_u_32, v_u_11, {
				["StudsOffsetWorldSpace"] = v_u_38,
				["StudsOffset"] = v40
			}):Play()
			if v41 then
				v_u_4:Create(v41, v_u_11, {
					["Rotation"] = v41.Rotation + v43
				}):Play()
			end
			local v_u_46 = v_u_27(v_u_32)
			task.delay(0.55, function()
				-- upvalues: (copy) v_u_32, (copy) v_u_46, (ref) v_u_4, (ref) v_u_12, (copy) v_u_38
				if v_u_32.Parent ~= nil then
					for _, v47 in v_u_46 do
						v_u_4:Create(v47.Instance, v_u_12, {
							[v47.Property] = 1
						}):Play()
					end
					v_u_4:Create(v_u_32, v_u_12, {
						["StudsOffsetWorldSpace"] = v_u_38 + Vector3.new(0, -0.6, 0)
					}):Play()
				end
			end)
			v_u_1:AddItem(v_u_32, 0.93)
		end
	end
end
function v8.Start() -- name: Start
	-- upvalues: (copy) v_u_7, (copy) v_u_14, (copy) v_u_48, (copy) v_u_3
	v_u_7.OnHit(function(_, _, p49)
		-- upvalues: (ref) v_u_14, (ref) v_u_48
		local v50 = v_u_14.Character
		if v50 then
			v50 = v50:FindFirstChild("HumanoidRootPart")
		end
		if v50 and v50:IsA("BasePart") then
			v_u_48(v50, p49)
		end
	end)
	task.spawn(function()
		-- upvalues: (ref) v_u_3, (ref) v_u_14, (ref) v_u_48
		local v51 = v_u_3:WaitForChild("EggHitLanded", 30)
		if v51 and v51:IsA("RemoteEvent") then
			v51.OnClientEvent:Connect(function(p52, p53)
				-- upvalues: (ref) v_u_14, (ref) v_u_48
				if typeof(p52) == "Instance" and (p52:IsA("Player") and p52 ~= v_u_14) then
					if typeof(p53) == "number" then
						local v54 = p52.Character
						if v54 then
							v54 = v54:FindFirstChild("HumanoidRootPart")
						end
						local v55 = workspace.CurrentCamera
						if v54 and (v54:IsA("BasePart") and v55) then
							if (v54.Position - v55.CFrame.Position).Magnitude <= 120 then
								local v56 = p52.Character
								if v56 then
									v56 = v56:FindFirstChild("HumanoidRootPart")
								end
								if v56 and v56:IsA("BasePart") then
									v_u_48(v56, p53)
								end
							end
						else
							return
						end
					else
						return
					end
				else
					return
				end
			end)
		end
	end)
end
function v8.Show(p57, p58) -- name: Show
	-- upvalues: (copy) v_u_48
	local v59 = p57.Character
	if v59 then
		v59 = v59:FindFirstChild("HumanoidRootPart")
	end
	if v59 and v59:IsA("BasePart") then
		v_u_48(v59, p58)
	end
end
function v8.ShowOn(p60, p61) -- name: ShowOn
	-- upvalues: (copy) v_u_48
	v_u_48(p60, p61)
end
return v8
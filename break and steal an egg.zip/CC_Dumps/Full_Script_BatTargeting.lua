local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Shared.BatConfig)
local v_u_4 = require(v2.Shared.BatToolQuery)
local v_u_5 = require(v2.Shared.SafeZoneQuery)
local v_u_6 = require(v2.Shared.TutorialConfig)
local v_u_28 = {
	["BaseRange"] = function(p7) -- name: BaseRange
		-- upvalues: (copy) v_u_4, (copy) v_u_3
		if p7 then
			p7 = p7.Character
		end
		if p7 then
			p7 = v_u_4.FindIn(p7)
		end
		return v_u_3.GetToolTier(p7).Range
	end,
	["MaxRange"] = function(p8) -- name: MaxRange
		-- upvalues: (copy) v_u_3, (copy) v_u_28
		local v9 = v_u_3.Targeting
		local v10
		if p8 then
			v10 = p8:GetAttribute(v9.RangeMultiplierAttribute)
		else
			v10 = p8
		end
		local v11 = (typeof(v10) ~= "number" or v10 <= 0) and 1 or v10
		return v_u_28.BaseRange(p8) * v11 + v9.HitTolerance
	end,
	["IsEligible"] = function(p12, p13, p14) -- name: IsEligible
		-- upvalues: (copy) v_u_6, (copy) v_u_5
		local v15 = p12.Character
		local v16
		if v15 then
			v16 = v15:FindFirstChild("HumanoidRootPart")
		else
			v16 = v15
		end
		local v17
		if v15 then
			v17 = v15:FindFirstChildOfClass("Humanoid")
		else
			v17 = v15
		end
		if not v15 or (not v16 or (not v16:IsA("BasePart") or (not v17 or v17.Health <= 0))) then
			return false, (1 / 0)
		end
		if v15:GetAttribute("Ragdolled") or v15:GetAttribute("BatImmune") then
			return false, (1 / 0)
		end
		local v18 = p12:GetAttribute(v_u_6.StageAttribute)
		if v18 ~= nil and v18 ~= v_u_6.DoneStage then
			return false, (1 / 0)
		end
		if v_u_5.IsBankable(p12.UserId, v16.Position) then
			return false, (1 / 0)
		end
		local v19 = (v16.Position - p13).Magnitude
		return v19 <= p14, v19
	end,
	["SelectClosestTarget"] = function(p20, p21, p22) -- name: SelectClosestTarget
		-- upvalues: (copy) v_u_1, (copy) v_u_28
		local v23 = (1 / 0)
		local v24 = nil
		for _, v25 in v_u_1:GetPlayers() do
			if v25 == p20 then
				continue
			end
			local v26, v27 = v_u_28.IsEligible(v25, p21, p22)
			if not v26 or v27 >= v23 then
				continue
			end
			v24 = v25
			v23 = v27
		end
		return v24
	end
}
return v_u_28
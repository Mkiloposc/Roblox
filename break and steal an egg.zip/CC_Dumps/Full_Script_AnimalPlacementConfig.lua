return {
	["MaxPlaceDistance"] = 50,
	["Messages"] = nil,
	["NoticeCooldown"] = 2,
	["Messages"] = {
		["NotInBase"] = "NotInBase",
		["TooFar"] = "TooFar"
	}
}
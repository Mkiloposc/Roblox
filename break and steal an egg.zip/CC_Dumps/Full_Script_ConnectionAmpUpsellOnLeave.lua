local v_u_1 = game:GetService("CoreGui")
local v_u_2 = game:GetService("CorePackages")
local v_u_3 = game:GetService("HttpRbxApiService")
local v_u_4 = game:GetService("HttpService")
local v_u_5 = game:GetService("TelemetryService")
local v6 = require(v_u_2.Workspace.Packages.SharedFlags)
local v_u_7 = v6.FStringLuaAppPlayButtonAgeCheckAmpFeatureName
local v_u_8 = v6.FStringLuaAppPlayButtonAgeCheckAmpNameSpace
local v_u_9 = v6.FFlagConnectionUpsellAnalytics
local v_u_10 = v6.FFlagPioneerLeaveOnInExpFaeDownAge
local v_u_11 = require(v_u_2.Workspace.Packages.CoreScriptsCommon).Url
local v_u_12 = require(v_u_2.Workspace.Packages.PioneerUtils.maybeLeavePioneerOnFaeDownAge)
local v_u_13 = nil
local v_u_14 = nil
pcall(function()
	-- upvalues: (ref) v_u_13, (ref) v_u_14
	v_u_13 = Enum.ConnectionError.PlacelaunchAgeVerificationRequired
	v_u_14 = Enum.ConnectionError.PlacelaunchParentalApprovalRequired
end)
local function v_u_18(p15, p16) -- name: logTelemetry
	-- upvalues: (copy) v_u_5
	local v17 = {
		["customFields"] = {
			["selectedItem"] = p16
		}
	}
	v_u_5:LogCounter(p15, v17, 1)
end
local function v_u_26(p19) -- name: fetchUniverseIdFromPlaceIdYielding
	-- upvalues: (copy) v_u_11, (copy) v_u_3, (copy) v_u_4
	local v20 = string.format("%suniverses/v1/places/%d/universe", v_u_11.APIS_URL, p19)
	local v21, v22 = pcall(v_u_3.GetAsyncFullUrl, v_u_3, v20)
	if v21 and type(v22) == "string" then
		local v23, v24 = pcall(v_u_4.JSONDecode, v_u_4, v22)
		if v23 and type(v24) == "table" then
			local v25 = v24.universeId
			if type(v25) == "number" and v25 > 0 then
				return v25
			else
				return nil
			end
		else
			return nil
		end
	else
		return nil
	end
end
local v_u_27 = v_u_9 and {
	["eventName"] = "unlockPlayIntent",
	["backends"] = nil,
	["throttlingPercentage"] = nil,
	["lastUpdated"] = nil,
	["description"] = "Fired when a user clicks Continue on an AMP age check / parental approval upsell from a game-join flow.",
	["backends"] = { "EventIngest" },
	["throttlingPercentage"] = game:DefineFastInt("ConnectionAmpUnlockPlayIntentThrottleHundredthsPercent", 10000),
	["lastUpdated"] = { 2026, 5, 11 }
} or nil
local v_u_28 = v_u_9 and {
	["eventName"] = "gameJoinUpsellImpression",
	["backends"] = nil,
	["throttlingPercentage"] = nil,
	["lastUpdated"] = nil,
	["description"] = "Fired when an AMP age check / parental approval upsell is shown during a game-join flow.",
	["backends"] = { "EventIngest" },
	["throttlingPercentage"] = game:DefineFastInt("ConnectionAmpGameJoinUpsellImpressionThrottleHundredthsPercent", 10000),
	["lastUpdated"] = { 2026, 5, 11 }
} or nil
local v_u_29 = v_u_9 and { "addSessionInfo", "addSessionId", "addOSInfo" } or nil
local v_u_30 = v_u_9 and {
	["upsellName"] = "AgeCheckRequired",
	["playabilityStatus"] = "ContextualPlayabilityAgeCheckRequired",
	["missingPlaceIdItem"] = "AmpAgeCheckMissingPlaceId",
	["universeIdLookupFailedItem"] = "AgeCheckImpressionUniverseIdLookupFailed"
} or nil
local v_u_31 = v_u_9 and {
	["upsellName"] = "ParentApprovalRequired",
	["playabilityStatus"] = "ContextualPlayabilityRequireParentApproval",
	["missingPlaceIdItem"] = "AmpParentApprovalMissingPlaceId",
	["universeIdLookupFailedItem"] = "ParentApprovalImpressionUniverseIdLookupFailed"
} or nil
local v_u_32 = v_u_9 and {} or nil
local v_u_39 = v_u_9 and function(p33, p34, p35, p36)
	-- upvalues: (copy) v_u_5, (copy) v_u_29
	local v37 = v_u_5
	local v38 = {
		["eventContext"] = p34,
		["standardizedFields"] = v_u_29,
		["customFields"] = {
			["universeId"] = p36,
			["upsellName"] = p33.upsellName,
			["playabilityStatus"] = p33.playabilityStatus
		}
	}
	v37:LogEvent(p35, v38)
end or nil
local v_u_44 = v_u_9 and function(p40, p41, p42)
	-- upvalues: (copy) v_u_32, (copy) v_u_39, (copy) v_u_27
	local v43 = (p42 == "" or not p42) and (v_u_32[p41] or "") or p42
	if p42 and p42 ~= "" then
		v_u_32[p41] = p42
	end
	v_u_39(p40, "GameJoin", v_u_27, v43)
end or nil
local v_u_51 = v_u_9 and function(p_u_45, p_u_46, p_u_47)
	-- upvalues: (copy) v_u_18, (copy) v_u_32, (copy) v_u_39, (copy) v_u_28, (copy) v_u_26
	if p_u_47 and p_u_47 ~= 0 then
		local v48 = v_u_32[p_u_47]
		if v48 then
			v_u_39(p_u_46, p_u_46.upsellName, v_u_28, v48)
		else
			task.spawn(function()
				-- upvalues: (ref) v_u_26, (copy) p_u_47, (ref) v_u_32, (ref) v_u_18, (copy) p_u_45, (copy) p_u_46, (ref) v_u_39, (ref) v_u_28
				local v49 = v_u_26(p_u_47)
				local v50 = not v49 and "" or tostring(v49)
				if v49 then
					v_u_32[p_u_47] = v50
				else
					v_u_18(p_u_45, p_u_46.universeIdLookupFailedItem)
				end
				v_u_39(p_u_46, p_u_46.upsellName, v_u_28, v50)
			end)
		end
	else
		v_u_18(p_u_45, p_u_46.missingPlaceIdItem)
		return
	end
end or nil
local function v_u_70(p_u_52, p_u_53, p_u_54, p_u_55, p_u_56, p_u_57, p_u_58, p_u_59, p60) -- name: openWizardThenReconnect
	-- upvalues: (copy) v_u_18, (copy) v_u_2, (copy) v_u_1, (copy) v_u_10, (copy) v_u_12
	v_u_18(p_u_52, p60)
	local v61, v_u_62 = pcall(require, v_u_2.Workspace.Packages.AmpUpsell)
	if not v61 then
		v_u_62 = nil
	end
	if v_u_62 then
		local v63, v_u_64 = pcall(require, v_u_1.RobloxGui.Modules.ApolloClient)
		if not v63 then
			v_u_64 = nil
		end
		if v_u_64 then
			if not pcall(function()
				-- upvalues: (copy) v_u_62, (copy) p_u_55, (ref) v_u_18, (copy) p_u_52, (ref) v_u_10, (copy) p_u_53, (ref) v_u_12, (copy) p_u_58, (copy) p_u_57, (copy) p_u_59, (copy) p_u_56, (copy) v_u_64, (copy) p_u_54
				v_u_62.InExpAmpWizardController.OpenAmpWizardContainerInExp(p_u_55, function(p65, p66)
					-- upvalues: (ref) v_u_62, (ref) v_u_18, (ref) p_u_52, (ref) v_u_10, (ref) p_u_53, (ref) v_u_12
					local v_u_67 = p65 == v_u_62.AmpEnums.AccessResponseEnum.Granted
					if v_u_67 then
						v_u_18(p_u_52, "AmpWizardGrantedReconnect")
						if not v_u_10 then
							p_u_53()
						end
					else
						v_u_18(p_u_52, "AmpWizardNotGranted")
					end
					if v_u_10 then
						local v68 = v_u_62.AmpEnums
						local v69
						if p66 == nil then
							v69 = false
						else
							v69 = p66[v68.ActionTypeEnum.AgeEstimation] == v68.ActionStatusEnum.Success
						end
						v_u_12(v69, function()
							-- upvalues: (copy) v_u_67, (ref) p_u_53
							if v_u_67 then
								p_u_53()
							end
						end)
					end
				end, p_u_58, p_u_57, p_u_59, p_u_56, v_u_64, p_u_54, true)
			end) then
				v_u_18(p_u_52, "AmpWizardOpenError")
			end
		else
			v_u_18(p_u_52, "AmpWizardApolloLoadFailed")
		end
	else
		v_u_18(p_u_52, "AmpWizardLoadFailed")
		return
	end
end
return {
	["PrimaryButtonText"] = "Continue",
	["PrimaryButtonLocalizationKey"] = "InGame.ConnectionError.Action.Continue",
	["AgeVerificationRequiredEnum"] = nil,
	["ParentalApprovalRequiredEnum"] = nil,
	["createAgeCheckCallback"] = nil,
	["createParentalApprovalCallback"] = nil,
	["fireImpressionAgeCheck"] = nil,
	["fireImpressionParentalApproval"] = nil,
	["AgeVerificationRequiredEnum"] = v_u_13,
	["ParentalApprovalRequiredEnum"] = v_u_14,
	["createAgeCheckCallback"] = function(p_u_71, p_u_72, p73) -- name: createAgeCheckCallback
		-- upvalues: (copy) v_u_9, (copy) v_u_44, (copy) v_u_30, (copy) v_u_70, (copy) v_u_7, (copy) v_u_8
		local v_u_74 = p73 + 1
		return function()
			-- upvalues: (ref) v_u_9, (ref) v_u_44, (ref) v_u_30, (ref) v_u_70, (copy) p_u_71, (copy) p_u_72, (copy) v_u_74, (ref) v_u_7, (ref) v_u_8
			if v_u_9 then
				v_u_44(v_u_30, game.PlaceId, "")
			end
			v_u_70(p_u_71, p_u_72, v_u_74, v_u_7, v_u_8, "gameJoinAgeCheckRequired", nil, nil, "AmpAgeCheckOpened")
		end
	end,
	["createParentalApprovalCallback"] = function(p_u_75, p_u_76, p77) -- name: createParentalApprovalCallback
		-- upvalues: (copy) v_u_18, (copy) v_u_26, (copy) v_u_9, (copy) v_u_44, (copy) v_u_31, (copy) v_u_70
		local v_u_78 = p77 + 1
		return function()
			-- upvalues: (ref) v_u_18, (copy) p_u_75, (ref) v_u_26, (ref) v_u_9, (ref) v_u_44, (ref) v_u_31, (ref) v_u_70, (copy) p_u_76, (copy) v_u_78
			local v_u_79 = game.PlaceId
			if v_u_79 and v_u_79 ~= 0 then
				task.spawn(function()
					-- upvalues: (ref) v_u_26, (copy) v_u_79, (ref) v_u_9, (ref) v_u_44, (ref) v_u_31, (ref) v_u_18, (ref) p_u_75, (ref) v_u_70, (ref) p_u_76, (ref) v_u_78
					local v80 = v_u_26(v_u_79)
					if v_u_9 then
						v_u_44(v_u_31, v_u_79, not v80 and "" or tostring(v80))
					end
					if v80 then
						v_u_70(p_u_75, p_u_76, v_u_78, "CanApproveExperience", nil, "gameJoinContentMaturityLock", {
							["universeId"] = nil,
							["experienceManagementAction"] = "Approve",
							["universeId"] = tostring(v80)
						}, nil, "AmpParentApprovalOpened")
					else
						v_u_18(p_u_75, "AmpParentApprovalUniverseIdLookupFailed")
					end
				end)
			else
				v_u_18(p_u_75, "AmpParentApprovalMissingPlaceId")
			end
		end
	end,
	["fireImpressionAgeCheck"] = v_u_9 and function(p81, p82)
		-- upvalues: (copy) v_u_51, (copy) v_u_30
		v_u_51(p81, v_u_30, p82)
	end or nil,
	["fireImpressionParentalApproval"] = v_u_9 and function(p83, p84)
		-- upvalues: (copy) v_u_51, (copy) v_u_31
		v_u_51(p83, v_u_31, p84)
	end or nil
}
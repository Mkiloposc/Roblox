local v1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = require(script.Parent.RagdollPhysics)
local v4 = {}
local v_u_5 = {}
local v_u_6 = {}
local function v_u_9(p7) -- name: clearRagdollAttachments
	if p7 ~= nil then
		for _, v8 in ipairs(p7:GetChildren()) do
			if not (v8:IsA("Attachment") and v8:GetAttribute("RagdollAttachment")) then
				continue
			end
			v8:Destroy()
		end
	end
end
local function v_u_12(p10) -- name: clearRagdollConstraints
	if p10 ~= nil then
		for _, v11 in ipairs(p10:GetChildren()) do
			if not v11:GetAttribute("RagdollConstraint") then
				continue
			end
			v11:Destroy()
		end
	end
end
local function v_u_19(p13) -- name: createConstraintFromMotor6D
	local v14 = p13.Part0
	local v15 = p13.Part1
	if v14 == nil or v15 == nil then
		return nil
	end
	local v16 = Instance.new("Attachment")
	local v17 = Instance.new("Attachment")
	v16.Name = ("RagdollAttachment_%*_A"):format(p13.Name)
	v17.Name = ("RagdollAttachment_%*_B"):format(p13.Name)
	v16:SetAttribute("RagdollAttachment", p13.Name)
	v17:SetAttribute("RagdollAttachment", p13.Name)
	v16.CFrame = p13.C0
	v17.CFrame = p13.C1
	v16.Parent = v14
	v17.Parent = v15
	local v18
	if p13.Name == "Root" or p13.Name == "Neck" then
		v18 = Instance.new("HingeConstraint")
		v18.LimitsEnabled = true
	else
		v18 = Instance.new("BallSocketConstraint")
		v18.LimitsEnabled = true
		v18.TwistLimitsEnabled = true
	end
	v18.Name = ("RagdollConstraint_%*"):format(p13.Name)
	v18:SetAttribute("RagdollConstraint", p13.Name)
	v18.Attachment0 = v16
	v18.Attachment1 = v17
	v18.Parent = p13.Parent
	return v18
end
local function v_u_23(p_u_20) -- name: limpAnimationConstraint
	local v21, v22 = pcall(function()
		-- upvalues: (copy) p_u_20
		return {
			["IsKinematic"] = p_u_20.IsKinematic,
			["MaxForce"] = p_u_20.MaxForce,
			["MaxTorque"] = p_u_20.MaxTorque
		}
	end)
	if not v21 then
		p_u_20.Enabled = false
		return nil
	end
	if pcall(function()
		-- upvalues: (copy) p_u_20
		p_u_20.IsKinematic = false
		p_u_20.MaxForce = 0
		p_u_20.MaxTorque = 0
	end) then
		return v22
	end
	p_u_20.Enabled = false
	return nil
end
local function v_u_37(p24) -- name: createRagdollConstraints
	-- upvalues: (copy) v_u_19
	for _, v_u_25 in ipairs(p24:GetDescendants()) do
		if not v_u_25:IsA("Motor6D") then
			continue
		end
		local v26
		if v_u_25.Name == "Neck" then
			v26 = true
		else
			local v33, v34 = pcall(function()
				-- upvalues: (copy) v_u_25
				if v_u_25:IsA("Motor6D") then
					local v27 = v_u_25.Part0
					local v28 = v_u_25.Part1
					local v29
					if v27 == nil or v27.Name ~= "Head" then
						if v28 == nil then
							v29 = false
						else
							v29 = v28.Name == "Head"
						end
					else
						v29 = true
					end
					return v29
				else
					local v30 = v_u_25.Attachment0
					local v31 = v_u_25.Attachment1
					local v32
					if v30 == nil or (v30.Parent == nil or v30.Parent.Name ~= "Head") then
						if v31 == nil or v31.Parent == nil then
							v32 = false
						else
							v32 = v31.Parent.Name == "Head"
						end
					else
						v32 = true
					end
					return v32
				end
			end)
			v26 = v33 and v34
		end
		if v26 then
			continue
		end
		local v35
		if v_u_25:FindFirstAncestorOfClass("Tool") == nil then
			local v36 = v_u_25.Part1
			if v36 == nil then
				v35 = false
			else
				v35 = v36:FindFirstAncestorOfClass("Tool") ~= nil
			end
		else
			v35 = true
		end
		if v35 then
			continue
		end
		v_u_19(v_u_25)
		v_u_25.Enabled = false
	end
end
local function v_u_40(p38) -- name: destroyRagdollConstraints
	-- upvalues: (copy) v_u_12, (copy) v_u_9
	for _, v39 in ipairs(p38:GetDescendants()) do
		if v39:IsA("Motor6D") then
			v39.Enabled = true
		else
			if not v39:IsA("BasePart") then
				continue
			end
			v_u_12(v39)
			v_u_9(v39)
		end
	end
end
function v4.IsRagdolled(p41) -- name: IsRagdolled
	if p41 == nil then
		return false
	elseif p41:GetAttribute("Ragdolled") then
		return true
	else
		local v42 = p41:FindFirstChildOfClass("Humanoid")
		if v42 == nil then
			return false
		else
			return v42:GetState() == Enum.HumanoidStateType.Physics
		end
	end
end
function v4.IsActive(p43) -- name: IsActive
	-- upvalues: (copy) v_u_5
	local v44 = v_u_5[p43]
	local v45
	if v44 == nil then
		v45 = false
	else
		v45 = os.clock() < v44
	end
	return v45
end
function v4.RagdollFor(p_u_46) -- name: RagdollFor
	-- upvalues: (copy) v_u_5, (copy) v_u_2, (copy) v_u_3, (copy) v_u_37, (copy) v_u_23, (copy) v_u_6, (copy) v_u_40
	local v_u_47 = p_u_46.Character
	local v_u_48 = v_u_47:FindFirstChildOfClass("Humanoid")
	local v_u_49 = v_u_47:FindFirstChild("HumanoidRootPart")
	if v_u_48 == nil or (v_u_49 == nil or v_u_48.Health <= 0) then
		return false
	end
	if v_u_48:GetState() == Enum.HumanoidStateType.Physics then
		return false
	end
	local v50 = os.clock()
	if v_u_5[p_u_46.Player] and v50 < v_u_5[p_u_46.Player] then
		return false
	end
	v_u_5[p_u_46.Player] = v50 + p_u_46.Duration
	v_u_47:SetAttribute("Ragdolled", true)
	local v_u_51
	if v_u_2:IsServer() then
		v_u_51 = p_u_46.Player.DevEnableMouseLock
		p_u_46.Player.DevEnableMouseLock = false
	else
		v_u_51 = nil
	end
	local v_u_52 = v_u_48.RequiresNeck
	v_u_48.RequiresNeck = false
	local v_u_53 = 0
	local v_u_54 = {}
	for _, v_u_55 in ipairs(v_u_47:GetDescendants()) do
		if v_u_55:IsA("Motor6D") then
			local v56
			if v_u_55:FindFirstAncestorOfClass("Tool") == nil then
				local v57 = v_u_55.Part1
				if v57 == nil then
					v56 = false
				else
					v56 = v57:FindFirstAncestorOfClass("Tool") ~= nil
				end
			else
				v56 = true
			end
			if v56 then
				continue
			end
			v_u_53 = v_u_53 + 1
		else
			if not (v_u_55:IsA("AnimationConstraint") and v_u_55.Enabled) then
				continue
			end
			local v58
			if v_u_55.Name == "Neck" then
				v58 = true
			else
				local v65, v66 = pcall(function()
					-- upvalues: (copy) v_u_55
					if v_u_55:IsA("Motor6D") then
						local v59 = v_u_55.Part0
						local v60 = v_u_55.Part1
						local v61
						if v59 == nil or v59.Name ~= "Head" then
							if v60 == nil then
								v61 = false
							else
								v61 = v60.Name == "Head"
							end
						else
							v61 = true
						end
						return v61
					else
						local v62 = v_u_55.Attachment0
						local v63 = v_u_55.Attachment1
						local v64
						if v62 == nil or (v62.Parent == nil or v62.Parent.Name ~= "Head") then
							if v63 == nil or v63.Parent == nil then
								v64 = false
							else
								v64 = v63.Parent.Name == "Head"
							end
						else
							v64 = true
						end
						return v64
					end
				end)
				v58 = v65 and v66
			end
			if v58 then
				continue
			end
			table.insert(v_u_54, v_u_55)
		end
	end
	local v67 = #v_u_54 > 0
	local v68 = v_u_47:FindFirstChild("UpperTorso")
	local v69 = v_u_47:FindFirstChild("LowerTorso")
	if v68 == nil or not v68:IsA("BasePart") then
		v68 = nil
	end
	local v_u_70
	if v_u_2:IsServer() and not p_u_46.ClientDriven then
		v_u_70 = v_u_3.SetCharacterNetworkOwner(v_u_47, nil)
	else
		v_u_70 = false
	end
	local v_u_71 = v_u_48:GetStateEnabled(Enum.HumanoidStateType.GettingUp)
	v_u_48:SetStateEnabled(Enum.HumanoidStateType.GettingUp, false)
	local v_u_72 = v_u_48.AutoRotate
	v_u_48.AutoRotate = false
	local v_u_73 = v_u_48.PlatformStand
	if v67 then
		v_u_48.PlatformStand = true
	end
	v_u_48:ChangeState(Enum.HumanoidStateType.Physics)
	local v_u_74
	if p_u_46.ClientDriven then
		v_u_74 = nil
	else
		v_u_74 = p_u_46.Velocity
	end
	local v_u_75 = Vector3.new(0, 0, 0)
	if v_u_74 ~= nil then
		local v76 = v_u_74.X
		local v77 = v_u_74.Z
		local v78 = Vector3.new(v76, 0, v77)
		local v79 = p_u_46.TumbleSpin or 0
		if v79 ~= 0 and v78.Magnitude > 0.01 then
			v_u_75 = (Vector3.new(0, 1, 0)):Cross(v78.Unit) * v79
		end
		v_u_3.SetCharacterVelocity(v_u_47, v_u_74, v_u_75)
	end
	if v_u_53 > 0 then
		v_u_37(v_u_47)
	end
	local v_u_80 = {}
	for v81, v82 in ipairs(v_u_54) do
		v_u_80[v81] = v_u_23(v82)
	end
	local v_u_83 = {}
	local v84 = {}
	for _, v85 in ipairs(v_u_47:GetChildren()) do
		if not v85:IsA("BasePart") or v85 == v_u_49 or v85.Name ~= "Head" and v_u_48:GetBodyPartR15(v85) == Enum.BodyPartR15.Unknown then
			continue
		end
		v_u_83[v85] = v85.CanCollide
		v85.CanCollide = true
		table.insert(v84, v85)
	end
	v_u_49.CanCollide = false
	local v_u_86 = v_u_49.CustomPhysicalProperties
	local v_u_87
	if v67 and v68 ~= nil then
		v_u_87 = Instance.new("Motor6D")
		v_u_87.Name = "RagdollAltRoot"
		if v69 ~= nil and v69:IsA("BasePart") then
			v_u_87.C0 = CFrame.new(0, v69.Size.Y * 0.7, 0)
		end
		v_u_87.Part0 = v_u_49
		v_u_87.Part1 = v68
		v_u_87.Parent = v68
		v_u_49.CustomPhysicalProperties = PhysicalProperties.new(0.0001, 0, 0, 0, 0)
	else
		v_u_87 = nil
	end
	if v_u_70 then
		v_u_3.SetCharacterNetworkOwner(v_u_47, nil)
	end
	if v_u_74 == nil then
		if not p_u_46.ClientDriven then
			local v88
			if v67 and v68 ~= nil then
				v88 = v68
			else
				v88 = v_u_49
			end
			v88:ApplyImpulse(p_u_46.Impulse or Vector3.new(0, 0, 0))
		end
	else
		v_u_3.SetCharacterVelocity(v_u_47, v_u_74, v_u_75)
	end
	v_u_3.ApplyLowGravity(v_u_47, p_u_46.GravityScale or 1)
	local v89 = p_u_46.GravityDuration
	if v89 ~= nil and v89 > 0 then
		local v_u_90 = v_u_5[p_u_46.Player]
		task.delay(v89, function()
			-- upvalues: (copy) v_u_47, (ref) v_u_5, (copy) p_u_46, (copy) v_u_90, (ref) v_u_3
			if v_u_47.Parent ~= nil and v_u_5[p_u_46.Player] == v_u_90 then
				v_u_3.RemoveLowGravity(v_u_47)
			end
		end)
	end
	local v_u_91
	if v_u_2:IsServer() and not p_u_46.ClientDriven then
		v_u_91 = v_u_3.StartAntiTunnelGuard(v_u_47, p_u_46.Duration + 1, {
			["CollideParts"] = v84,
			["ReferencePart"] = v68 or v_u_49
		})
	else
		v_u_91 = nil
	end
	if v_u_74 ~= nil then
		local v_u_92 = v_u_5[p_u_46.Player]
		v_u_2.Heartbeat:Once(function()
			-- upvalues: (copy) v_u_47, (ref) v_u_5, (copy) p_u_46, (copy) v_u_92, (ref) v_u_3, (copy) v_u_74, (ref) v_u_75
			if v_u_47.Parent ~= nil and v_u_5[p_u_46.Player] == v_u_92 then
				v_u_3.SetCharacterVelocity(v_u_47, v_u_74, v_u_75)
			end
		end)
	end
	local v_u_93
	if v67 or p_u_46.ClientDriven then
		v_u_93 = nil
	else
		v_u_93 = v_u_48.StateChanged:Connect(function(_, p94)
			-- upvalues: (copy) v_u_48
			if p94 ~= Enum.HumanoidStateType.Physics and p94 ~= Enum.HumanoidStateType.Dead then
				v_u_48:ChangeState(Enum.HumanoidStateType.Physics)
			end
		end)
	end
	local v_u_95 = false
	local function v102() -- name: release
		-- upvalues: (ref) v_u_95, (ref) v_u_93, (ref) v_u_91, (ref) v_u_5, (copy) p_u_46, (ref) v_u_6, (copy) v_u_47, (ref) v_u_51, (copy) v_u_48, (ref) v_u_70, (ref) v_u_3, (ref) v_u_53, (ref) v_u_40, (copy) v_u_54, (copy) v_u_80, (copy) v_u_83, (ref) v_u_87, (copy) v_u_49, (copy) v_u_86, (copy) v_u_52, (copy) v_u_73, (copy) v_u_72, (copy) v_u_71
		if v_u_95 then
			return
		else
			v_u_95 = true
			if v_u_93 ~= nil then
				v_u_93:Disconnect()
			end
			if v_u_91 ~= nil then
				v_u_91()
				v_u_91 = nil
			end
			v_u_5[p_u_46.Player] = nil
			v_u_6[v_u_47] = nil
			v_u_47:SetAttribute("Ragdolled", nil)
			if v_u_51 ~= nil and p_u_46.Player.Parent ~= nil then
				p_u_46.Player.DevEnableMouseLock = v_u_51
			end
			if v_u_47.Parent == nil or (v_u_48.Parent == nil or v_u_48.Health <= 0) then
				if v_u_70 and v_u_47.Parent ~= nil then
					v_u_3.SetCharacterNetworkOwner(v_u_47, p_u_46.Player)
				end
			else
				if v_u_53 > 0 then
					v_u_40(v_u_47)
				end
				for v96, v_u_97 in ipairs(v_u_54) do
					if v_u_97.Parent == nil then
						continue
					end
					local v_u_98 = v_u_80[v96]
					if v_u_98 == nil then
						v_u_97.Enabled = true
					else
						pcall(function()
							-- upvalues: (copy) v_u_97, (copy) v_u_98
							v_u_97.MaxForce = v_u_98.MaxForce
							v_u_97.MaxTorque = v_u_98.MaxTorque
							v_u_97.IsKinematic = v_u_98.IsKinematic
						end)
					end
				end
				v_u_3.RemoveLowGravity(v_u_47)
				for v99, v100 in pairs(v_u_83) do
					if v99.Parent == nil then
						continue
					end
					v99.CanCollide = v100
				end
				if v_u_87 ~= nil then
					v_u_87:Destroy()
				end
				v_u_49.CustomPhysicalProperties = v_u_86
				for _, v101 in ipairs(v_u_47:GetDescendants()) do
					if not v101:IsA("BasePart") then
						continue
					end
					v101.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
					v101.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
				end
				v_u_48.RequiresNeck = v_u_52
				v_u_48.PlatformStand = v_u_73
				v_u_48.AutoRotate = v_u_72
				v_u_49.CanCollide = true
				if not p_u_46.ClientDriven then
					v_u_3.SnapUpright(v_u_47)
				end
				v_u_48:SetStateEnabled(Enum.HumanoidStateType.GettingUp, v_u_71)
				v_u_48:ChangeState(Enum.HumanoidStateType.GettingUp)
				if p_u_46.OnRelease ~= nil then
					task.spawn(p_u_46.OnRelease)
				end
				if v_u_70 then
					v_u_3.SetCharacterNetworkOwner(v_u_47, p_u_46.Player)
				end
			end
		end
	end
	v_u_6[v_u_47] = v102
	task.delay(p_u_46.Duration, v102)
	return true
end
function v4.Release(p103) -- name: Release
	-- upvalues: (copy) v_u_6
	if p103 ~= nil then
		local v104 = v_u_6[p103]
		if v104 ~= nil then
			v104()
		end
	end
end
v1.PlayerRemoving:Connect(function(p105)
	-- upvalues: (copy) v_u_5
	v_u_5[p105] = nil
end)
return v4
local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v_u_1.Shared.AdminConfig)
local v_u_3 = require(v_u_1.Shared.PublicTreadmillConfig)
local v_u_4 = require(script.Parent.Parent.Controllers.NotificationController)
local v_u_5 = require(script.Parent.UnitTextBox)
return {
	["Bind"] = function(p_u_6, p7) -- name: Bind
		-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_4, (copy) v_u_1, (copy) v_u_3
		local v_u_8 = p7:FindFirstChild("Multiplier")
		if v_u_8 then
			v_u_8 = v_u_8:FindFirstChildWhichIsA("TextBox")
		end
		if not (v_u_8 and v_u_8:IsA("TextBox")) then
			v_u_8 = nil
		end
		local v9 = p7:FindFirstChild("SpawnTime")
		local v_u_10 = v9
		if v_u_10 then
			v_u_10 = v9:FindFirstChildWhichIsA("TextBox")
		end
		if not (v_u_10 and v_u_10:IsA("TextBox")) then
			v_u_10 = nil
		end
		local v11 = p7:FindFirstChild("Spawn")
		if v_u_8 and (v_u_10 and (v11 and v11:IsA("GuiButton"))) then
			v11:SetAttribute("HoverScale", v_u_2.PanelHoverScale)
			v11:SetAttribute("PressScale", v_u_2.PanelPressScale)
			v_u_5.BindPrefix(v_u_8, "x")
			v_u_5.Bind(v_u_10, "s")
			local v_u_12 = false
			local function v_u_22() -- name: spawn
				-- upvalues: (ref) v_u_12, (ref) v_u_5, (copy) v_u_8, (ref) v_u_4, (copy) v_u_10, (ref) v_u_1, (ref) v_u_2, (copy) p_u_6, (ref) v_u_3
				if v_u_12 then
					return
				else
					local v_u_13 = v_u_5.PrefixNumber(v_u_8.Text, "x")
					if v_u_13 and v_u_13 > 0 then
						local v_u_14 = v_u_5.Number(v_u_10.Text, "s")
						if v_u_14 and v_u_14 > 0 then
							local v_u_15 = v_u_1:FindFirstChild(v_u_2.PanelRemotes.Treadmill)
							if v_u_15 and v_u_15:IsA("RemoteFunction") then
								local v_u_16 = p_u_6:GetAttribute("Scope")
								if type(v_u_16) ~= "string" or not v_u_3.AdminSpawn.Scopes[v_u_16] then
									v_u_16 = v_u_3.AdminSpawn.DefaultScope
								end
								v_u_12 = true
								local function v17()
									-- upvalues: (copy) v_u_15, (copy) v_u_13, (copy) v_u_14, (ref) v_u_16
									return v_u_15:InvokeServer(v_u_13, v_u_14, v_u_16)
								end
								local v18, v19, v20 = pcall(v17)
								v_u_12 = false
								if v18 and (v19 == true and (v_u_16 == "Global" and type(v20) == "string")) then
									v_u_4.Show(v20, "Success")
								elseif not v18 or v19 ~= true then
									local v21 = (not v18 or type(v20) ~= "string") and "couldn\'t spawn" or v20
									v_u_4.Show(("Admin Treadmill failed: %*"):format(v21), "Error")
								end
							else
								v_u_4.Show("The Admin Treadmill isn\'t ready yet", "Error")
							end
						else
							v_u_4.Show("Type how long it stays, in seconds (e.g. 300)", "Error")
							return
						end
					else
						v_u_4.Show("Type a multiplier (e.g. 2)", "Error")
						return
					end
				end
			end
			v11.Activated:Connect(function()
				-- upvalues: (copy) v_u_22
				task.spawn(v_u_22)
			end)
		else
			warn("[AdminPanelTreadmill] card needs Container.Multiplier / SpawnTime TextBoxes + Container.Spawn")
		end
	end
}
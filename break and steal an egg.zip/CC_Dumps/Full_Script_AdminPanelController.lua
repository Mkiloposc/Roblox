local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Shared.AdminConfig)
local v_u_4 = require(script.Parent.Parent.Modules.AdminEditDropdown)
local v_u_5 = require(script.Parent.Parent.Modules.AdminPanelAnnounce)
local v_u_6 = require(script.Parent.Parent.Modules.AdminPanelBoosts)
local v_u_7 = require(script.Parent.Parent.Modules.AdminPanelGifting)
local v_u_8 = require(script.Parent.Parent.Modules.AdminPanelBossSpawn)
local v_u_9 = require(script.Parent.Parent.Modules.AdminPanelEvents)
local v_u_10 = require(script.Parent.Parent.Modules.AdminPanelEventRsvp)
local v_u_11 = require(script.Parent.Parent.Modules.AdminPanelPoll)
local v_u_12 = require(script.Parent.Parent.Modules.AdminPanelTitanicEgg)
local v_u_13 = require(script.Parent.Parent.Modules.AdminPanelTreadmill)
local v_u_14 = require(script.Parent.Parent.Modules.MainGui)
local v_u_15 = require(script.Parent.UiFrames)
local v_u_16 = v1.LocalPlayer
local v17 = {}
local function v_u_19() -- name: waitForVerdict
	-- upvalues: (copy) v_u_16, (copy) v_u_3
	local v18 = v_u_16:GetAttribute(v_u_3.PanelAttribute)
	while v18 == nil do
		v_u_16:GetAttributeChangedSignal(v_u_3.PanelAttribute):Wait()
		v18 = v_u_16:GetAttribute(v_u_3.PanelAttribute)
	end
	return v18 == true
end
local function v_u_23(p20) -- name: findPanel
	-- upvalues: (copy) v_u_3
	local v21 = p20:FindFirstChild("LeftHUD")
	local v22 = p20:FindFirstChild("Frames")
	if v21 then
		v21 = v21:FindFirstChild(v_u_3.PanelButtonName)
	end
	if v22 then
		v22 = v22:FindFirstChild(v_u_3.PanelFrameName)
	end
	if not (v21 and v21:IsA("GuiButton")) then
		v21 = nil
	end
	if v22 and v22:IsA("GuiObject") then
		return v21, v22
	else
		return v21, nil
	end
end
local function v_u_29(p24) -- name: findAdminWindows
	-- upvalues: (copy) v_u_3
	local v25 = p24:FindFirstChild("Frames")
	local v26 = {}
	for _, v27 in v_u_3.AdminOnlyFrames do
		local v28
		if v25 then
			v28 = v25:FindFirstChild(v27)
		else
			v28 = v25
		end
		if not (v28 and v28:IsA("GuiObject")) then
			continue
		end
		table.insert(v26, v28)
	end
	return v26
end
local function v_u_34(p_u_30, p_u_31) -- name: waitForChild
	local v32 = p_u_30:FindFirstChild(p_u_31)
	if v32 then
		return v32
	end
	local v_u_33 = false
	task.delay(15, function()
		-- upvalues: (ref) v_u_33, (copy) p_u_30, (copy) p_u_31
		if not v_u_33 then
			warn((("[AdminPanelController] still waiting for %*.%* from the server (AdminUiService)"):format(p_u_30.Name, p_u_31)))
		end
	end)
	while not v32 do
		p_u_30.ChildAdded:Wait()
		v32 = p_u_30:FindFirstChild(p_u_31)
	end
	v_u_33 = true
	return v32
end
local function v_u_41(p35) -- name: removeAll
	-- upvalues: (copy) v_u_23, (copy) v_u_29, (copy) v_u_15
	local v36, v37 = v_u_23(p35)
	local v38 = {}
	local v39 = v_u_29(p35)
	__set_list(v38, 1, {v37, table.unpack(v39)})
	for _, v40 in v38 do
		if not v40 then
			continue
		end
		if v_u_15.IsOpen(v40) then
			v_u_15.Close(v40)
		end
		v40:Destroy()
	end
	if v36 then
		v36:Destroy()
	end
end
local function v_u_74(p_u_42) -- name: adopt
	-- upvalues: (copy) v_u_19, (copy) v_u_41, (copy) v_u_34, (copy) v_u_3, (copy) v_u_16, (copy) v_u_23, (copy) v_u_29, (copy) v_u_4, (copy) v_u_5, (copy) v_u_11, (copy) v_u_8, (copy) v_u_13, (copy) v_u_9, (copy) v_u_6, (copy) v_u_12, (copy) v_u_10, (copy) v_u_7, (copy) v_u_15
	if v_u_19() then
		local v43 = p_u_42:FindFirstChild("LeftHUD")
		local v44 = p_u_42:FindFirstChild("Frames")
		if v43 and v44 then
			v_u_34(v44, v_u_3.PanelFrameName)
			for _, v45 in v_u_3.AdminOnlyFrames do
				v_u_34(v44, v45)
			end
			v_u_34(v43, v_u_3.PanelButtonName)
			if v_u_16:GetAttribute(v_u_3.PanelAttribute) == true and p_u_42.Parent then
				local v46, v_u_47 = v_u_23(p_u_42)
				for _, v48 in v_u_29(p_u_42) do
					v48.Visible = false
				end
				if v_u_47 then
					v_u_47.Visible = false
				end
				if v46 and v_u_47 then
					local v_u_49 = {}
					local v_u_50 = {}
					local v_u_51 = setmetatable({}, {
						["__mode"] = "k"
					})
					local function v68(p_u_52) -- name: bindCard
						-- upvalues: (copy) v_u_51, (ref) v_u_3, (ref) v_u_4, (copy) v_u_49, (ref) v_u_5, (ref) v_u_11, (copy) p_u_42, (ref) v_u_8, (ref) v_u_13, (ref) v_u_9, (ref) v_u_6, (ref) v_u_12, (ref) v_u_10, (ref) v_u_7, (copy) v_u_47, (copy) v_u_50
						local v53 = p_u_52:FindFirstChild("Container")
						if v53 and not v_u_51[p_u_52] then
							v_u_51[p_u_52] = true
							for _, v54 in { "Edit", "Select" } do
								local v55 = v53:FindFirstChild(v54)
								if not (v55 and v55:IsA("GuiButton")) then
									continue
								end
								v55:SetAttribute("HoverScale", v_u_3.PanelHoverScale)
								v55:SetAttribute("PressScale", v_u_3.PanelPressScale)
							end
							local v56 = p_u_52:GetAttribute("Scope")
							local v57 = v_u_4.Bind
							if type(v56) ~= "string" then
								v56 = v_u_3.PanelDefaultScope
							end
							local v59 = v57(v53, v56, function(p58)
								-- upvalues: (copy) p_u_52
								p_u_52:SetAttribute("Scope", p58)
							end)
							if v59 then
								p_u_52:SetAttribute("Scope", v59.GetValue())
								local v60 = v_u_49
								table.insert(v60, v59)
							end
							if p_u_52.Name == v_u_3.PanelCards.Announce then
								v_u_5.Bind(p_u_52, v53)
								return
							elseif p_u_52.Name == v_u_3.PanelCards.Poll then
								v_u_11.Bind(p_u_52, v53, p_u_42)
								return
							elseif p_u_52.Name == v_u_3.PanelCards.BossSpawn then
								v_u_8.Bind(p_u_52, v53)
								return
							elseif p_u_52.Name == v_u_3.PanelCards.Treadmill then
								v_u_13.Bind(p_u_52, v53)
								return
							elseif p_u_52.Name == v_u_3.PanelCards.AdminAbuse then
								v_u_9.BindAdminAbuse(p_u_52, v53)
								return
							elseif p_u_52.Name == v_u_3.PanelCards.GlobalBoost then
								v_u_6.Bind(p_u_52, v53)
							elseif p_u_52.Name == v_u_3.PanelCards.TitanicEgg then
								local v61 = v_u_12.Bind(p_u_52, v53)
								if v61 then
									local v62 = v_u_49
									table.insert(v62, v61)
									return
								end
							else
								if p_u_52.Name == v_u_3.PanelCards.EventRsvp then
									v_u_10.Bind(p_u_52, v53)
									return
								end
								if p_u_52.Name == v_u_3.PanelCards.Gift then
									local v63 = v_u_7.Bind(p_u_52, v53, v_u_47)
									for _, v64 in v63.Dropdowns do
										local v65 = v_u_49
										table.insert(v65, v64)
									end
									local v66 = v_u_50
									local v67 = v63.Reset
									table.insert(v66, v67)
								end
							end
						else
							return
						end
					end
					local v69 = v_u_47:FindFirstChild("CommandsList")
					if v69 then
						for _, v70 in v69:GetChildren() do
							v68(v70)
						end
						v69.ChildAdded:Connect(v68)
					end
					v_u_15.Observe(v_u_47, function(p71)
						-- upvalues: (copy) v_u_49, (copy) v_u_50
						if not p71 then
							for _, v72 in v_u_49 do
								v72.Close(true)
							end
							for _, v73 in v_u_50 do
								v73()
							end
						end
					end)
					v46.Visible = true
					v46.Activated:Connect(function()
						-- upvalues: (ref) v_u_16, (ref) v_u_3, (ref) v_u_15, (copy) v_u_47
						if v_u_16:GetAttribute(v_u_3.PanelAttribute) == true then
							v_u_15.Toggle(v_u_47)
						end
					end)
				else
					warn((("[AdminPanelController] missing LeftHUD.%* or Frames.%*"):format(v_u_3.PanelButtonName, v_u_3.PanelFrameName)))
				end
			else
				return
			end
		else
			warn("[AdminPanelController] MainGUI.LeftHUD / MainGUI.Frames missing")
			return
		end
	else
		v_u_41(p_u_42)
		return
	end
end
function v17.Start() -- name: Start
	-- upvalues: (copy) v_u_14, (copy) v_u_74, (copy) v_u_16, (copy) v_u_3, (copy) v_u_41
	v_u_14.Observe(v_u_74)
	v_u_16:GetAttributeChangedSignal(v_u_3.PanelAttribute):Connect(function()
		-- upvalues: (ref) v_u_16, (ref) v_u_3, (ref) v_u_41
		if v_u_16:GetAttribute(v_u_3.PanelAttribute) == false then
			local v75 = v_u_16:FindFirstChild("PlayerGui")
			if v75 then
				v75 = v75:FindFirstChild("MainGUI")
			end
			if v75 and v75:IsA("ScreenGui") then
				v_u_41(v75)
			end
		end
	end)
end
return v17
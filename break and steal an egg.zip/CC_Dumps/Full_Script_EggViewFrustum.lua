local v1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("RunService")
local v3 = require(v1.Shared.EggConfig)
local v_u_4 = {}
local v5 = v3.ViewCull
local v_u_6
if v5.DebugPreview then
	local v7 = v5.DebugShrinkDegrees
	v_u_6 = -math.rad(v7)
else
	local v8 = v5.MarginDegrees
	v_u_6 = math.rad(v8)
end
local v_u_9 = v5.DebugPreview and 0 or v5.CloseRadius * v5.CloseRadius
local v_u_10 = v5.RadiusScale * 0.5
v_u_4.RENDER_PRIORITY_AFTER = Enum.RenderPriority.Camera.Value + 2
local v_u_11 = false
local v_u_12 = CFrame.identity
local v_u_13 = Vector3.new(0, 0, 0)
local v_u_14 = 1
local v_u_15 = 1
local v_u_16 = 1
local v_u_17 = 1
local function v32() -- name: capture
	-- upvalues: (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (copy) v_u_6, (ref) v_u_15, (ref) v_u_14, (ref) v_u_17, (ref) v_u_16
	local v18 = workspace.CurrentCamera
	if v18 then
		local v19 = v18.ViewportSize
		if v19.X <= 0 or v19.Y <= 0 then
			v_u_11 = false
		else
			v_u_12 = v18.CFrame
			v_u_13 = v_u_12.Position
			local v20 = v18.FieldOfView
			local v21 = math.rad(v20) * 0.5
			local v22 = math.tan(v21) * v19.X / v19.Y
			local v23 = math.atan(v22)
			local v24 = v21 + v_u_6
			local v25 = math.clamp(v24, 0.017453292519943295, 1.5533430342749532)
			local v26 = v23 + v_u_6
			local v27 = math.clamp(v26, 0.017453292519943295, 1.5533430342749532)
			local v28 = math.tan(v25)
			local v29 = math.tan(v27)
			v_u_15 = v28
			v_u_14 = v29
			local v30 = 1 / math.cos(v25)
			local v31 = 1 / math.cos(v27)
			v_u_17 = v30
			v_u_16 = v31
			v_u_11 = true
		end
	else
		v_u_11 = false
		return
	end
end
if v5.DebugPreview then
	warn("[EggViewFrustum] DebugPreview is ON \226\128\148 eggs/animals will visibly cull near the screen edges. Turn it off in EggConfig.ViewCull before publishing.")
end
v32()
v2:BindToRenderStep("EggViewFrustum", Enum.RenderPriority.Camera.Value + 1, v32)
function v_u_4.IsSphereVisible(p33, p34) -- name: IsSphereVisible
	-- upvalues: (ref) v_u_11, (ref) v_u_13, (copy) v_u_9, (ref) v_u_12, (ref) v_u_14, (ref) v_u_16, (ref) v_u_15, (ref) v_u_17
	if not v_u_11 then
		return true
	end
	local v35 = p33 - v_u_13
	if v35:Dot(v35) <= v_u_9 then
		return true
	end
	local v36 = v_u_12:PointToObjectSpace(p33)
	local v37 = -v36.Z
	if v37 < -p34 then
		return false
	end
	local v38 = v36.X
	if math.abs(v38) > v37 * v_u_14 + p34 * v_u_16 then
		return false
	end
	local v39 = v36.Y
	return math.abs(v39) <= v37 * v_u_15 + p34 * v_u_17
end
function v_u_4.IsVisible(p40, p41) -- name: IsVisible
	-- upvalues: (copy) v_u_4, (copy) v_u_10
	return v_u_4.IsSphereVisible(p40, p41.Magnitude * v_u_10)
end
function v_u_4.IsEggVisible(p42) -- name: IsEggVisible
	-- upvalues: (copy) v_u_4, (copy) v_u_10
	return v_u_4.IsSphereVisible(p42.Position, p42.Size.Magnitude * v_u_10)
end
return v_u_4
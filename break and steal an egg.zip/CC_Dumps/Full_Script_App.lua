local v_u_1 = game:GetService("TextService")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = require(script.Parent.components.background)
local v_u_4 = require(script.Parent.Parent.roblox_packages.conch)
local v_u_5 = require(script.Parent.components.corner)
local v_u_6 = require(script.Parent.components.flex)
local v_u_7 = require(script.Parent.components.gap)
local v8 = require(script.Parent.Parent.roblox_packages.language)
local v_u_9 = require(script.Parent.levenshtein_distance)
local v_u_10 = require(script.Parent.components.loading)
local v_u_11 = require(script.Parent.components.padding)
local v_u_12 = require(script.Parent.components.screen)
local v_u_13 = require(script.Parent.state)
local v_u_14 = require(script.Parent.components.suggestion)
local v_u_15 = require(script.Parent.components.text)
local v_u_16 = require(script.Parent.components.textbox)
local v_u_17 = require(script.Parent.theme)
local v_u_18 = require(script.Parent.Parent.roblox_packages.vide)
local v_u_19 = v_u_18.source
local v_u_20 = v_u_18.derive
local v_u_21 = v_u_18.show
local v_u_22 = v_u_18.changed
local v_u_23 = v_u_18.effect
local v_u_24 = v_u_18.cleanup
local v_u_25 = v_u_18.indexes
local v_u_26 = ("conch-ui 0.3.1\tconch-language %*\tconch %*"):format(v8.version, v8.version)
local v_u_27 = 0
local v_u_28 = {}
return function()
	-- upvalues: (copy) v_u_13, (copy) v_u_4, (copy) v_u_26, (copy) v_u_19, (copy) v_u_23, (copy) v_u_20, (copy) v_u_17, (copy) v_u_1, (copy) v_u_24, (copy) v_u_2, (ref) v_u_27, (copy) v_u_28, (copy) v_u_9, (copy) v_u_12, (copy) v_u_6, (copy) v_u_11, (copy) v_u_21, (copy) v_u_18, (copy) v_u_14, (copy) v_u_3, (copy) v_u_5, (copy) v_u_25, (copy) v_u_15, (copy) v_u_7, (copy) v_u_10, (copy) v_u_16, (copy) v_u_22
	local function v33(p29) -- name: output
		-- upvalues: (ref) v_u_13
		for _, v30 in string.split(p29.text, "\n") do
			local v31 = v_u_13.logs()
			local v32 = {
				["kind"] = p29.kind,
				["text"] = v30
			}
			table.insert(v31, 1, v32)
			table.remove(v31, 100)
			v_u_13.logs(v31)
		end
	end
	v_u_4.console.output = v33
	for _, v34 in string.split(v_u_26, "\n") do
		v33({
			["kind"] = "normal",
			["text"] = nil,
			["text"] = v34
		})
	end
	v33({
		["kind"] = "warn",
		["text"] = "If you got here accidentally, run the `close-ui` command to close this UI."
	})
	local v35 = {
		["description"] = "Clears the console.",
		["permissions"] = nil,
		["arguments"] = nil,
		["callback"] = nil,
		["permissions"] = {},
		["arguments"] = function() -- name: arguments end,
		["callback"] = function() -- name: callback
			-- upvalues: (ref) v_u_13
			v_u_13.logs({})
		end
	}
	v_u_4.register("clear", v35)
	local v36 = {
		["description"] = "Close the CLI",
		["permissions"] = nil,
		["arguments"] = nil,
		["callback"] = nil,
		["permissions"] = {},
		["arguments"] = function() -- name: arguments end,
		["callback"] = function() -- name: callback
			-- upvalues: (ref) v_u_13
			v_u_13.opened(false)
			v_u_13.focused(false)
		end
	}
	v_u_4.register("close-ui", v36)
	local v_u_37 = v_u_19("")
	local v_u_38 = v_u_19(false)
	local v_u_39 = v_u_19(0)
	local v_u_40 = v_u_19(Vector2.zero)
	local v_u_41 = v_u_19(v_u_4.analyze("", 0))
	local v_u_42 = v_u_19(1)
	v_u_23(function()
		-- upvalues: (copy) v_u_42, (copy) v_u_41
		local v43 = v_u_42
		local v44 = v_u_42()
		local v45 = #v_u_41().suggestions
		local v46 = math.max(1, v45)
		v43((math.clamp(v44, 1, v46)))
	end)
	local v_u_47 = false
	v_u_23(function()
		-- upvalues: (copy) v_u_37, (copy) v_u_39, (ref) v_u_47, (copy) v_u_41, (ref) v_u_4
		v_u_37()
		v_u_39()
		if not v_u_47 then
			v_u_47 = true
			task.defer(function()
				-- upvalues: (ref) v_u_47, (ref) v_u_41, (ref) v_u_4, (ref) v_u_37, (ref) v_u_39
				v_u_47 = false
				v_u_41(v_u_4.analyze(v_u_37(), v_u_39() - 1))
			end)
		end
	end)
	local v_u_50 = v_u_20(function()
		-- upvalues: (copy) v_u_37, (copy) v_u_39
		local v48 = v_u_37()
		local v49 = v_u_39() - 1
		return string.sub(v48, 1, v49)
	end)
	local v_u_51 = v_u_19(Vector3.new(0, 0, 0))
	local v_u_52 = Instance.new("GetTextBoundsParams")
	v_u_52.Font = v_u_17.font()
	v_u_52.RichText = false
	v_u_52.Size = 20
	v_u_52.Width = 100000
	v_u_23(function()
		-- upvalues: (copy) v_u_50, (copy) v_u_52, (ref) v_u_1, (copy) v_u_51
		local v_u_53 = v_u_50()
		v_u_52.Text = v_u_53
		task.spawn(function()
			-- upvalues: (ref) v_u_1, (ref) v_u_52, (copy) v_u_53, (ref) v_u_50, (ref) v_u_51
			local v54 = v_u_1:GetTextBoundsAsync(v_u_52)
			if v_u_53 == v_u_50() then
				v_u_51(v54)
			end
		end)
	end)
	v_u_24(v_u_2.InputBegan:Connect(function(p55)
		-- upvalues: (copy) v_u_41, (ref) v_u_27, (ref) v_u_28, (copy) v_u_37, (copy) v_u_39, (copy) v_u_42
		local v56 = v_u_41()
		if p55.KeyCode == Enum.KeyCode.Down then
			if #v56.suggestions == 0 then
				if v_u_27 == 0 then
					v_u_28[v_u_27] = v_u_37()
				end
				local v57 = v_u_27 - 1
				local v58 = #v_u_28
				v_u_27 = math.clamp(v57, 0, v58)
				v_u_37(v_u_28[v_u_27] or "")
				v_u_39(#v_u_37() + 1)
			else
				local v59 = v_u_42
				local v60 = v_u_42() + 1
				local v61 = #v56.suggestions
				v59((math.min(v60, v61)))
			end
		else
			if p55.KeyCode == Enum.KeyCode.Up then
				if #v56.suggestions == 0 then
					if v_u_27 == 0 then
						v_u_28[v_u_27] = v_u_37()
					end
					local v62 = v_u_27 + 1
					local v63 = #v_u_28
					v_u_27 = math.clamp(v62, 0, v63)
					v_u_37(v_u_28[v_u_27] or "")
					v_u_39(#v_u_37() + 1)
					return
				end
				local v64 = v_u_42
				local v65 = v_u_42() - 1
				v64((math.max(1, v65)))
			end
			return
		end
	end))
	local v_u_82 = v_u_20(function()
		-- upvalues: (copy) v_u_41, (copy) v_u_37, (copy) v_u_39, (ref) v_u_9
		local v66 = v_u_41()
		local v67
		if v66 then
			v67 = v66.suggestions
		else
			v67 = v66
		end
		if not v67 then
			return {}
		end
		local v68 = v_u_37()
		local v69 = v66.replace.x + 1
		local v70 = v_u_39() - 1
		local v71 = string.sub(v68, v69, v70)
		local v72 = string.gsub(v71, "\"(.*)\"", "%1", 1)
		local v73 = string.gsub(v72, "\'(.*)\'", "%1", 1)
		local v74 = {}
		for _, v75 in v67 do
			if not string.find(v75.display, string.gsub(v73, "^%s", ""), 0, true) then
				continue
			end
			local v76 = v_u_9(v73, v75.display)
			if v76 == (-1 / 0) then
				continue
			end
			table.insert(v74, {
				["suggestion"] = v75,
				["score"] = v76
			})
		end
		table.sort(v74, function(p77, p78)
			return p77.score < p78.score
		end)
		local v79 = {}
		for _, v80 in v74 do
			local v81 = v80.suggestion
			table.insert(v79, v81)
		end
		return v79
	end)
	local v_u_83 = false
	return v_u_12({
		["name"] = "Command Executor",
		["display_order"] = 100000,
		["enabled"] = v_u_13.opened,
		v_u_6():fill("horizontal"):vertical("bottom"),
		v_u_11({
			["padding"] = 12
		}),
		v_u_21(v_u_41, function()
			-- upvalues: (ref) v_u_18, (ref) v_u_14, (copy) v_u_50, (copy) v_u_51, (copy) v_u_40, (copy) v_u_42, (copy) v_u_41, (copy) v_u_82
			return v_u_18.create("Folder")({ v_u_14({
					["x"] = function() -- name: x
						-- upvalues: (ref) v_u_50
						local v84 = string.split(v_u_50(), "\n")
						return #v84[#v84] * 10 + 10
					end,
					["y"] = function() -- name: y
						-- upvalues: (ref) v_u_51, (ref) v_u_40
						return v_u_51().Y + v_u_40().Y - 20
					end,
					["selected"] = v_u_42,
					["analysis"] = v_u_41,
					["suggestions"] = v_u_82,
					["result"] = v_u_41
				}) })
		end),
		v_u_3({
			["auto"] = "Y",
			v_u_6(),
			v_u_5(4),
			v_u_11({
				["y"] = 4
			}),
			v_u_25(function()
				-- upvalues: (copy) v_u_41
				return v_u_41().issues
			end, function(p_u_85, p86)
				-- upvalues: (ref) v_u_15, (ref) v_u_11
				return v_u_15({
					["order"] = 0 - p86 + 100,
					["h"] = 20,
					["text"] = function() -- name: text
						-- upvalues: (copy) p_u_85
						return ("%* at %*:%*:%*"):format(p_u_85().why, p_u_85().span.x, p_u_85().span.y, p_u_85().span.z)
					end,
					["text_size"] = 16,
					["text_style"] = "error",
					["xalignment"] = Enum.TextXAlignment.Left,
					v_u_11({
						["x"] = 8
					})
				})
			end),
			v_u_25(v_u_13.logs, function(p_u_87, p88)
				-- upvalues: (ref) v_u_15, (ref) v_u_11
				return v_u_15({
					["h"] = 20,
					["order"] = -p88 - 1,
					["text"] = function() -- name: text
						-- upvalues: (copy) p_u_87
						return p_u_87().text
					end,
					["text_size"] = 16,
					["text_style"] = function() -- name: text_style
						-- upvalues: (copy) p_u_87
						return p_u_87().kind
					end,
					["xalignment"] = Enum.TextXAlignment.Left,
					v_u_11({
						["x"] = 8
					})
				})
			end)
		}),
		v_u_7({
			["h"] = 4
		}),
		v_u_3({
			["auto"] = Enum.AutomaticSize.Y,
			v_u_5(4),
			v_u_21(v_u_38, function()
				-- upvalues: (ref) v_u_10
				return v_u_10({
					["h"] = 18,
					["speed"] = 6,
					["text_size"] = 18,
					["xalignment"] = nil,
					["xalignment"] = Enum.TextXAlignment.Left
				})
			end, function()
				-- upvalues: (ref) v_u_16, (copy) v_u_37, (ref) v_u_83, (copy) v_u_39, (copy) v_u_82, (copy) v_u_42, (copy) v_u_41, (ref) v_u_27, (ref) v_u_28, (ref) v_u_13, (copy) v_u_38, (ref) v_u_4, (ref) v_u_22
				return v_u_16({
					["text"] = v_u_37,
					["update_text"] = function(p89) -- name: update_text
						-- upvalues: (ref) v_u_83, (ref) v_u_39, (ref) v_u_82, (ref) v_u_42, (ref) v_u_37, (ref) v_u_41
						local v90 = v_u_83 or v_u_39()
						local v91 = v90 - 1
						local v92 = v90 - 1
						local v93 = string.sub(p89, v91, v92)
						local v94 = v_u_82()[v_u_42()]
						if v93 == "\t" and v94 then
							local v95 = v_u_37()
							local v96 = v_u_41().replace
							local v97 = v94.text
							local v98 = v96.x
							local v99 = string.sub(v95, 1, v98)
							local v100 = v96.y + 1
							local v101 = string.sub(v95, v100, -1)
							task.defer(v_u_39, v96.x + #v97 + 2)
							p89 = v99 .. v97 .. " " .. v101
						end
						v_u_37(p89)
					end,
					["placeholder"] = "Enter your command",
					["text_size"] = 18,
					["xalignment"] = Enum.TextXAlignment.Left,
					["enter"] = function(p102) -- name: enter
						-- upvalues: (ref) v_u_27, (ref) v_u_28, (ref) v_u_37, (ref) v_u_13, (ref) v_u_38, (ref) v_u_4
						v_u_27 = 0
						local v103 = v_u_28
						table.insert(v103, 1, p102)
						v_u_37("")
						v_u_13.focused(true)
						v_u_38(true)
						v_u_4.execute(p102)
						v_u_38(false)
					end,
					["focused"] = v_u_13.focused,
					["update_focused"] = v_u_13.focused,
					{
						["CursorPosition"] = v_u_39,
						v_u_22("CursorPosition", function(p104)
							-- upvalues: (ref) v_u_83, (ref) v_u_39
							if v_u_83 then
								v_u_83 = p104
							else
								v_u_83 = p104
								task.defer(function()
									-- upvalues: (ref) v_u_39, (ref) v_u_83
									v_u_39(v_u_83)
									v_u_83 = false
								end)
							end
						end)
					}
				})
			end),
			v_u_11({
				["x"] = 8,
				["y"] = 8
			}),
			v_u_6():fill():vertical("center"):horizontal("left"),
			v_u_22("AbsolutePosition", v_u_40)
		})
	})
end
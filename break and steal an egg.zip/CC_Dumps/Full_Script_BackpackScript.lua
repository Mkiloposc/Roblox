local v_u_1 = UserSettings():GetService("UserGameSettings")
local v_u_2 = game:GetService("CoreGui"):WaitForChild("RobloxGui")
local v3 = game:GetService("CorePackages")
local v4 = v_u_2.Modules
local v5 = require(v3.Packages.Signals)
local v_u_6 = require(v3.Workspace.Packages.InExperienceTopBar)
local v7 = require(v3.Workspace.Packages.CoreScriptsCommon).SettingsShowSignal
local v8 = require(v3.Workspace.Packages.AppChat.InExperienceAppChatModal)
local v_u_9 = require(v4.Flags.FFlagMountCoreGuiBackpack)
local v_u_10 = require(v3.Workspace.Packages.SharedExperimentDefinition).isInExperienceUIVREnabled
local v_u_11 = require(v3.Workspace.Packages.SharedExperimentDefinition).InExperienceUIVRIXP
local v12 = v_u_6.Flags.FFlagTopBarSignalizeSetCores
local v_u_13 = require(v3.Workspace.Packages.RobloxTranslator)
local v14 = require(v3.Workspace.Packages.Responsive)
local v15 = require(v3.Workspace.Packages.SharedFlags).FFlagBackpackResponsiveUnits
local v_u_16 = game:DefineFastFlag("EnableHotbarHide", false)
local v_u_17 = require(v3.Workspace.Packages.SharedFlags).FFlagStudioDeviceSimVRSwitchFixes
local v_u_18 = game:DefineFastFlag("SAToolEquipLuauFlag", false)
local v_u_19 = {
	["OpenClose"] = nil,
	["IsHotbarVisible"] = false,
	["IsOpen"] = false,
	["StateChanged"] = Instance.new("BindableEvent"),
	["ModuleName"] = "Backpack",
	["KeepVRTopbarOpen"] = true,
	["VRIsExclusive"] = true,
	["VRClosesNonExclusive"] = true
}
local v_u_20 = 60
local v_u_21 = Enum.FontSize.Size14
local v_u_22 = 0.5 * v_u_1.PreferredTransparency
local v_u_23 = Color3.new(0.12156862745098039, 0.12156862745098039, 0.12156862745098039)
local v_u_24 = Color3.new(0.19215686274509805, 0.19215686274509805, 0.19215686274509805)
local v_u_25 = Color3.new(0.35294117647058826, 0.5568627450980392, 0.9137254901960784)
local v_u_26 = 0.5 * v_u_1.PreferredTransparency
local v_u_27 = Color3.new(1, 1, 1)
UDim2.new(0, 14, 0, 9)
local v28 = Enum.KeyCode.Backquote.Value
local v_u_29 = Color3.new(0, 0.6352941176470588, 1)
local v_u_30 = "   Search"
local v31 = Color3.new(0.37, 0.37, 0.37)
local v_u_32 = 0.15 * v_u_1.PreferredTransparency
local v_u_33 = Enum.KeyCode.Zero.Value
local v_u_34 = Enum.KeyCode.Backspace.Value
local v_u_35 = {
	[Enum.UserInputType.Gamepad1] = true,
	[Enum.UserInputType.Gamepad2] = true,
	[Enum.UserInputType.Gamepad3] = true,
	[Enum.UserInputType.Gamepad4] = true,
	[Enum.UserInputType.Gamepad5] = true,
	[Enum.UserInputType.Gamepad6] = true,
	[Enum.UserInputType.Gamepad7] = true,
	[Enum.UserInputType.Gamepad8] = true
}
local v36 = game:GetService("Players")
local v_u_37 = game:GetService("UserInputService")
local v_u_38 = game:GetService("StarterGui")
local v_u_39 = game:GetService("GuiService")
local v_u_40 = game:GetService("ContextActionService")
local v_u_41 = game:GetService("VRService")
local v_u_42 = game:GetService("GamepadService")
v_u_2:WaitForChild("Modules"):WaitForChild("TenFootInterface")
local v_u_43 = require(v4.TenFootInterface):IsEnabled()
local v_u_44 = require(v3.Workspace.Packages.AppCommonLib).Create
local v_u_45 = require(v4.GameTranslator)
pcall(function()
	-- upvalues: (ref) v_u_30, (copy) v_u_13
	v_u_30 = v_u_13:FormatByKey("InGame.UnknownNamespace.BACKPACK_SEARCH")
end)
local v_u_46 = true
if v_u_43 then
	v_u_21 = Enum.FontSize.Size24
	v_u_20 = 100
end
local v_u_47 = false
local v48
if v15 then
	if v14.GetInputModeStore().getPreferredInputType() == v14.Input.Touch then
		v48 = v_u_39:GetScreenResolution().X < 1024
	else
		v48 = false
	end
else
	v48 = v_u_37.TouchEnabled
	if v48 then
		v48 = v_u_39:GetScreenResolution().X < 1024
	end
end
local v_u_49 = v36.LocalPlayer
local v_u_50 = nil
local v_u_51 = nil
local v_u_52 = nil
local v_u_53 = nil
local v_u_54 = nil
local v_u_55 = nil
local v_u_56 = nil
local v_u_57 = nil
local v_u_58 = nil
local v_u_59 = nil
local v_u_60 = {}
local v_u_61 = nil
local v_u_62 = {}
local v_u_63 = {}
local v_u_64 = {}
local v_u_65 = 0
local v_u_66 = nil
local v_u_67 = false
local v_u_68 = false
local v_u_69 = false
local v_u_70 = false
local v_u_71 = {}
local v_u_72 = {}
local v_u_73 = false
local v_u_74 = 0
local v_u_75 = v48 and 3 or 10
local v_u_76 = v48 and 2 or 4
local v_u_77 = nil
v_u_19.BackpackEmpty = v_u_44("BindableEvent")({
	["Name"] = "BackpackEmpty"
})
v_u_19.BackpackItemAdded = v_u_44("BindableEvent")({
	["Name"] = "BackpackAdded"
})
v_u_19.BackpackItemRemoved = v_u_44("BindableEvent")({
	["Name"] = "BackpackRemoved"
})
local function v_u_81(p78, p79) -- name: NewGui
	-- upvalues: (ref) v_u_21
	local v80 = Instance.new(p78)
	v80.Name = p79
	v80.BackgroundColor3 = Color3.new(0, 0, 0)
	v80.BackgroundTransparency = 1
	v80.BorderColor3 = Color3.new(0, 0, 0)
	v80.BorderSizePixel = 0
	v80.Size = UDim2.new(1, 0, 1, 0)
	if p78:match("Text") then
		v80.TextColor3 = Color3.new(1, 1, 1)
		v80.Text = ""
		v80.Font = Enum.Font.SourceSans
		v80.FontSize = v_u_21
		v80.TextWrapped = true
		if p78 == "TextButton" then
			v80.Font = Enum.Font.SourceSansBold
			v80.BorderSizePixel = 1
		end
	end
	return v80
end
function v_u_19.IsInventoryEmpty() -- name: isInventoryEmpty
	-- upvalues: (ref) v_u_75, (copy) v_u_60
	for v82 = v_u_75 + 1, #v_u_60 do
		local v83 = v_u_60[v82]
		if not (v83 and v83.Tool) then
			continue
		end
		return false
	end
	return true
end
local function v_u_97(p84) -- name: AdjustHotbarFrames
	-- upvalues: (ref) v_u_53, (ref) v_u_75, (ref) v_u_65, (copy) v_u_16, (copy) v_u_60, (ref) v_u_52, (copy) v_u_19
	local v85 = v_u_53.Visible
	local v86 = v85 and v_u_75 or v_u_65
	local v87 = 0
	local v88
	if v_u_16 then
		if v86 >= 1 then
			v88 = not p84
		else
			v88 = false
		end
	else
		v88 = v86 >= 1
	end
	for v89 = 1, v_u_75 do
		local v90 = v_u_60[v89]
		local v91
		if v_u_16 then
			v91 = v90.Tool
			if v91 then
				v91 = not p84
			end
		else
			v91 = v90.Tool
		end
		if v91 or v85 then
			v87 = v87 + 1
			v90:Readjust(v87, v86)
			v90.Frame.Visible = true
		else
			v90.Frame.Visible = false
		end
	end
	local v92 = v_u_52
	local v93 = not v85
	if v93 then
		if v88 then
			v93 = v88
		else
			for v94 = v_u_75 + 1, #v_u_60 do
				local v95 = v_u_60[v94]
				if not (v95 and v95.Tool) then
					continue
				end
				v96 = false
			end
			local v96 = true
			v93 = not v96
		end
	end
	v92.Visible = v93
	v_u_52.Position = UDim2.new(0.5, -15, 1, v88 and -110 or -50)
	v_u_19.IsHotbarVisible = v88
end
local function v_u_102() -- name: UpdateScrollingFrameCanvasSize
	-- upvalues: (ref) v_u_55, (ref) v_u_20, (ref) v_u_56
	local v98 = v_u_55.AbsoluteSize.X / (v_u_20 + 5)
	local v99 = math.floor(v98)
	local v100 = (#v_u_56:GetChildren() - 1) / v99
	local v101 = math.ceil(v100) * (v_u_20 + 5) + 5
	v_u_55.CanvasSize = UDim2.new(0, 0, 0, v101)
end
local function v_u_105() -- name: AdjustInventoryFrames
	-- upvalues: (ref) v_u_75, (copy) v_u_60, (copy) v_u_102
	for v103 = v_u_75 + 1, #v_u_60 do
		local v104 = v_u_60[v103]
		v104.Frame.LayoutOrder = v104.Index
		v104.Frame.Visible = v104.Tool ~= nil
	end
	v_u_102()
end
local function v106() -- name: UpdateBackpackLayout
	-- upvalues: (ref) v_u_51, (ref) v_u_75, (ref) v_u_20, (ref) v_u_53, (copy) v_u_76, (ref) v_u_55, (copy) v_u_97, (copy) v_u_105
	v_u_51.Size = UDim2.new(0, 5 + v_u_75 * (v_u_20 + 5), 0, v_u_20 + 5 + 5)
	v_u_51.Position = UDim2.new(0.5, -v_u_51.Size.X.Offset / 2, 1, -v_u_51.Size.Y.Offset)
	v_u_53.Size = UDim2.new(0, v_u_51.Size.X.Offset, 0, v_u_51.Size.Y.Offset * v_u_76 + 40)
	v_u_53.Position = UDim2.new(0.5, -v_u_53.Size.X.Offset / 2, 1, v_u_51.Position.Y.Offset - v_u_53.Size.Y.Offset)
	v_u_55.Size = UDim2.new(1, v_u_55.ScrollBarThickness + 1, 1, -40)
	v_u_55.Position = UDim2.new(0, 0, 0, 40)
	v_u_97()
	v_u_105()
end
local function v_u_109(p107) -- name: EquipNewTool
	-- upvalues: (ref) v_u_58, (ref) v_u_66, (copy) v_u_62, (copy) v_u_18, (ref) v_u_49, (ref) v_u_57
	if v_u_58 then
		v_u_58:UnequipTools()
		if v_u_66 then
			v_u_66:ToggleSelect()
			v_u_62[v_u_66]:UpdateEquipView()
			v_u_66 = nil
		end
	end
	if p107:IsA("HopperBin") then
		p107:ToggleSelect()
		v_u_62[p107]:UpdateEquipView()
		v_u_66 = p107
	else
		local v108
		if v_u_18 and game:GetEngineFeature("SAToolEquipEngineFeature") then
			v108 = workspace.AuthorityMode == Enum.AuthorityMode.Server
		else
			v108 = false
		end
		if v108 then
			v_u_49:RequestTool(p107)
		end
		p107.Parent = v_u_57
	end
end
local function v_u_204(p110, p111) -- name: MakeSlot
	-- upvalues: (copy) v_u_60, (ref) v_u_26, (copy) v_u_24, (copy) v_u_23, (ref) v_u_51, (ref) v_u_20, (copy) v_u_45, (ref) v_u_75, (ref) v_u_53, (ref) v_u_65, (ref) v_u_68, (ref) v_u_47, (copy) v_u_40, (copy) v_u_62, (ref) v_u_61, (ref) v_u_57, (ref) v_u_77, (copy) v_u_81, (copy) v_u_25, (copy) v_u_64, (copy) v_u_102, (copy) v_u_18, (ref) v_u_49, (ref) v_u_58, (ref) v_u_66, (ref) v_u_59, (copy) v_u_109, (copy) v_u_27, (copy) v_u_204, (ref) v_u_56, (ref) v_u_70, (copy) v_u_63, (copy) v_u_33, (ref) v_u_55
	local v112 = p111 or #v_u_60 + 1
	local v_u_113 = {
		["Tool"] = nil,
		["Index"] = v112,
		["Frame"] = nil
	}
	local v_u_114 = nil
	local v_u_115 = nil
	local v_u_116 = nil
	local v_u_117 = nil
	local v_u_118 = nil
	local v_u_119 = nil
	local v_u_120 = nil
	local v_u_121 = nil
	function v_u_113.Readjust(_, p122, p123) -- name: Readjust
		-- upvalues: (ref) v_u_51, (ref) v_u_20, (ref) v_u_114
		local v124 = v_u_51.Size.X.Offset / 2
		local v125 = v_u_20 + 5
		local v126 = p122 - (p123 / 2 + 0.5)
		v_u_114.Position = UDim2.new(0, v124 - v_u_20 / 2 + v125 * v126, 0, 5)
	end
	function v_u_113.Fill(p127, p_u_128) -- name: Fill
		-- upvalues: (ref) v_u_116, (ref) v_u_117, (ref) v_u_45, (ref) v_u_120, (ref) v_u_118, (ref) v_u_75, (ref) v_u_53, (ref) v_u_114, (ref) v_u_65, (ref) v_u_68, (ref) v_u_47, (ref) v_u_40, (ref) v_u_62, (ref) v_u_61, (ref) v_u_60
		if not p_u_128 then
			return p127:Clear()
		end
		p127.Tool = p_u_128
		local function v_u_131() -- name: assignToolData
			-- upvalues: (copy) p_u_128, (ref) v_u_116, (ref) v_u_117, (ref) v_u_45, (ref) v_u_120
			local v129 = p_u_128.TextureId
			v_u_116.Image = v129
			if v129 == "" then
				v_u_117.Visible = true
			else
				v_u_117.Visible = false
			end
			v_u_45:TranslateAndRegister(v_u_117, p_u_128, p_u_128.Name)
			if v_u_120 and p_u_128:IsA("Tool") then
				v_u_45:TranslateAndRegister(v_u_120, p_u_128, p_u_128.ToolTip)
				local v130 = v_u_120.TextBounds.X + 6
				v_u_120.Size = UDim2.new(0, v130, 0, 16)
				v_u_120.Position = UDim2.new(0.5, -v130 / 2, 0, -25)
			end
		end
		v_u_131()
		if v_u_118 then
			v_u_118:disconnect()
			v_u_118 = nil
		end
		v_u_118 = p_u_128.Changed:connect(function(p132)
			-- upvalues: (copy) v_u_131
			if p132 == "TextureId" or (p132 == "Name" or p132 == "ToolTip") then
				v_u_131()
			end
		end)
		local v133 = p127.Index <= v_u_75
		if not v133 or v_u_53.Visible then
			v_u_114.Draggable = true
		end
		p127:UpdateEquipView()
		if v133 then
			v_u_65 = v_u_65 + 1
			if v_u_68 and (v_u_65 >= 1 and not v_u_47) then
				v_u_47 = true
				v_u_40:BindAction("RBXHotbarEquip", changeToolFunc, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
			end
		end
		v_u_62[p_u_128] = p127
		for v134 = 1, v_u_75 do
			v135 = v_u_60[v134]
			if v135.Tool then
				continue
			end
		end
		local v135 = nil
		v_u_61 = v135
	end
	function v_u_113.Clear(p136) -- name: Clear
		-- upvalues: (ref) v_u_118, (ref) v_u_116, (ref) v_u_117, (ref) v_u_120, (ref) v_u_114, (ref) v_u_75, (ref) v_u_65, (ref) v_u_47, (ref) v_u_40, (ref) v_u_62, (ref) v_u_61, (ref) v_u_60
		if p136.Tool then
			if v_u_118 then
				v_u_118:disconnect()
				v_u_118 = nil
			end
			v_u_116.Image = ""
			v_u_117.Text = ""
			if v_u_120 then
				v_u_120.Text = ""
				v_u_120.Visible = false
			end
			v_u_114.Draggable = false
			p136:UpdateEquipView(true)
			if p136.Index <= v_u_75 then
				v_u_65 = v_u_65 - 1
				if v_u_65 < 1 then
					v_u_47 = false
					v_u_40:UnbindAction("RBXHotbarEquip")
				end
			end
			v_u_62[p136.Tool] = nil
			p136.Tool = nil
			for v137 = 1, v_u_75 do
				v138 = v_u_60[v137]
				if v138.Tool then
					continue
				end
			end
			local v138 = nil
			v_u_61 = v138
		end
	end
	function v_u_113.UpdateEquipView(p139, p140) -- name: UpdateEquipView
		-- upvalues: (ref) v_u_57, (ref) v_u_77, (copy) v_u_113, (ref) v_u_119, (ref) v_u_81, (ref) v_u_114, (ref) v_u_25, (ref) v_u_26, (ref) v_u_24, (ref) v_u_23
		if p140 then
			if v_u_119 then
				v_u_119.Parent = nil
			end
			v_u_114.SelectionImageObject = nil
			v_u_114.BackgroundTransparency = v_u_114.Draggable and 0 or v_u_26
			v_u_114.BackgroundColor3 = v_u_114.Draggable and v_u_24 or v_u_23
			return
		else
			local v141 = p139.Tool
			if not v141 or v141:IsA("HopperBin") and v141.Active or v141.Parent == v_u_57 then
				v_u_77 = v_u_113
				if not v_u_119 then
					v_u_119 = v_u_81("Frame", "Equipped")
					v_u_119.ZIndex = v_u_114.ZIndex
					for _, v142 in pairs({
						{
							0.1,
							1,
							0,
							0
						},
						{
							0.8,
							0.1,
							0.1,
							0
						},
						{
							0.1,
							1,
							0.9,
							0
						},
						{
							0.8,
							0.1,
							0.1,
							0.9
						}
					}) do
						local v143 = v_u_81("Frame", "Edge")
						v143.BackgroundTransparency = 0
						v143.BackgroundColor3 = v_u_25
						v143.Size = UDim2.new(v142[1], 0, v142[2], 0)
						v143.Position = UDim2.new(v142[3], 0, v142[4], 0)
						v143.ZIndex = v_u_119.ZIndex
						v143.Parent = v_u_119
					end
				end
				v_u_119.Parent = v_u_114
				v_u_114.SelectionImageObject = nil
				v_u_114.BackgroundTransparency = v_u_114.Draggable and 0 or v_u_26
				v_u_114.BackgroundColor3 = v_u_114.Draggable and v_u_24 or v_u_23
			else
				if v_u_119 then
					v_u_119.Parent = nil
				end
				v_u_114.SelectionImageObject = nil
				v_u_114.BackgroundTransparency = v_u_114.Draggable and 0 or v_u_26
				v_u_114.BackgroundColor3 = v_u_114.Draggable and v_u_24 or v_u_23
			end
		end
	end
	function v_u_113.IsEquipped(p144) -- name: IsEquipped
		-- upvalues: (ref) v_u_57
		local v145 = p144.Tool
		return not v145 or v145:IsA("HopperBin") and v145.Active or v145.Parent == v_u_57
	end
	function v_u_113.Delete(p146) -- name: Delete
		-- upvalues: (ref) v_u_64, (ref) v_u_114, (ref) v_u_60, (ref) v_u_102
		v_u_64[v_u_114] = nil
		v_u_114:Destroy()
		table.remove(v_u_60, p146.Index)
		local v147 = #v_u_60
		for v148 = p146.Index, v147 do
			v_u_60[v148]:SlideBack()
		end
		v_u_102()
	end
	function v_u_113.Swap(p149, p150) -- name: Swap
		local v151 = p149.Tool
		local v152 = p150.Tool
		p149:Clear()
		if v152 then
			p150:Clear()
			p149:Fill(v152)
		end
		if v151 then
			p150:Fill(v151)
		else
			p150:Clear()
		end
	end
	function v_u_113.SlideBack(p153) -- name: SlideBack
		-- upvalues: (ref) v_u_114
		p153.Index = p153.Index - 1
		v_u_114.Name = p153.Index
		v_u_114.LayoutOrder = p153.Index
	end
	function v_u_113.TurnNumber(_, p154) -- name: TurnNumber
		-- upvalues: (ref) v_u_121
		if v_u_121 then
			v_u_121.Visible = p154
		end
	end
	function v_u_113.SetClickability(p155, p156) -- name: SetClickability
		-- upvalues: (ref) v_u_114, (ref) v_u_26, (ref) v_u_24, (ref) v_u_23
		if p155.Tool then
			v_u_114.Draggable = not p156
			v_u_114.SelectionImageObject = nil
			v_u_114.BackgroundTransparency = v_u_114.Draggable and 0 or v_u_26
			v_u_114.BackgroundColor3 = v_u_114.Draggable and v_u_24 or v_u_23
		end
	end
	function v_u_113.CheckTerms(p157, p158) -- name: CheckTerms
		-- upvalues: (ref) v_u_117, (ref) v_u_120
		local v159 = 0
		local v160 = p157.Tool
		local v161
		if v160 then
			v161 = v159
			for v162 in pairs(p158) do
				local _, v163 = v_u_117.Text:lower():gsub(v162, "")
				v159 = v161 + v163
				if v160:IsA("Tool") then
					local _, v164 = (v_u_120 and v_u_120.Text or ""):lower():gsub(v162, "")
					v159 = v159 + v164
					v161 = v159
				else
					v161 = v159
				end
			end
		else
			v161 = v159
		end
		return v161
	end
	function v_u_113.Select(_, p165) -- name: Select
		-- upvalues: (copy) v_u_113, (ref) v_u_57, (ref) v_u_18, (ref) v_u_49, (ref) v_u_58, (ref) v_u_66, (ref) v_u_62, (ref) v_u_59, (ref) v_u_109
		if not p165 then
			local v166 = v_u_113.Tool
			if v166 then
				local v167
				if v166 then
					v167 = v166:IsA("HopperBin") and v166.Active or v166.Parent == v_u_57
				else
					v167 = v166
				end
				if v167 then
					local v168
					if v_u_18 and game:GetEngineFeature("SAToolEquipEngineFeature") then
						v168 = workspace.AuthorityMode == Enum.AuthorityMode.Server
					else
						v168 = false
					end
					if v168 and not v166:IsA("HopperBin") then
						v_u_49:RequestTool(nil)
					end
					if v_u_58 then
						v_u_58:UnequipTools()
						if v_u_66 then
							v_u_66:ToggleSelect()
							v_u_62[v_u_66]:UpdateEquipView()
							v_u_66 = nil
							return
						end
					end
				elseif v166.Parent == v_u_59 then
					v_u_109(v166)
				end
			end
		end
	end
	v_u_114 = v_u_81("TextButton", v112)
	v_u_114.BackgroundColor3 = v_u_23
	v_u_114.BorderColor3 = v_u_27
	v_u_114.Text = ""
	v_u_114.AutoButtonColor = false
	v_u_114.BorderSizePixel = 0
	v_u_114.Size = UDim2.new(0, v_u_20, 0, v_u_20)
	v_u_114.Active = true
	v_u_114.Draggable = false
	v_u_114.BackgroundTransparency = v_u_26
	v_u_114.MouseButton1Click:connect(function()
		-- upvalues: (copy) v_u_113
		changeSlot(v_u_113)
	end)
	v_u_113.Frame = v_u_114
	local v169 = v_u_81("Frame", "SelectionObjectClipper")
	v169.Visible = false
	v169.Parent = v_u_114
	local v170 = v_u_81("ImageLabel", "Selector")
	v170.Size = UDim2.new(1, 0, 1, 0)
	v170.Image = "rbxasset://textures/ui/Keyboard/key_selection_9slice.png"
	v170.ScaleType = Enum.ScaleType.Slice
	v170.SliceCenter = Rect.new(12, 12, 52, 52)
	v170.Parent = v169
	v_u_116 = v_u_81("ImageLabel", "Icon")
	v_u_116.Size = UDim2.new(0.8, 0, 0.8, 0)
	v_u_116.Position = UDim2.new(0.1, 0, 0.1, 0)
	v_u_116.Parent = v_u_114
	v_u_117 = v_u_81("TextLabel", "ToolName")
	v_u_117.Size = UDim2.new(1, -2, 1, -2)
	v_u_117.Position = UDim2.new(0, 1, 0, 1)
	v_u_117.Parent = v_u_114
	v_u_113.Frame.LayoutOrder = v_u_113.Index
	if v112 <= v_u_75 then
		v_u_120 = v_u_81("TextLabel", "ToolTip")
		v_u_120.TextWrapped = false
		v_u_120.TextYAlignment = Enum.TextYAlignment.Top
		v_u_120.BackgroundColor3 = Color3.new(0.4, 0.4, 0.4)
		v_u_120.BackgroundTransparency = 0
		v_u_120.Visible = false
		v_u_120.Parent = v_u_114
		v_u_114.MouseEnter:connect(function()
			-- upvalues: (ref) v_u_120
			if v_u_120.Text ~= "" then
				v_u_120.Visible = true
			end
		end)
		v_u_114.MouseLeave:connect(function()
			-- upvalues: (ref) v_u_120
			v_u_120.Visible = false
		end)
		function v_u_113.MoveToInventory(p171) -- name: MoveToInventory
			-- upvalues: (copy) v_u_113, (ref) v_u_75, (ref) v_u_204, (ref) v_u_56, (ref) v_u_57, (ref) v_u_58, (ref) v_u_66, (ref) v_u_62, (ref) v_u_70, (ref) v_u_53
			if v_u_113.Index <= v_u_75 then
				local v172 = v_u_113.Tool
				p171:Clear()
				local v173 = v_u_204(v_u_56)
				v173:Fill(v172)
				if (not v172 or v172:IsA("HopperBin") and v172.Active or v172.Parent == v_u_57) and v_u_58 then
					v_u_58:UnequipTools()
					if v_u_66 then
						v_u_66:ToggleSelect()
						v_u_62[v_u_66]:UpdateEquipView()
						v_u_66 = nil
					end
				end
				if v_u_70 then
					v173.Frame.Visible = false
					v173.Parent = v_u_53
				end
			end
		end
		if v112 < 10 or v112 == v_u_75 then
			local v174 = v112 < 10 and (v112 or 0) or 0
			v_u_121 = v_u_81("TextLabel", "Number")
			v_u_121.Text = v174
			v_u_121.Size = UDim2.new(0.15, 0, 0.15, 0)
			v_u_121.Visible = false
			v_u_121.Parent = v_u_114
			v_u_63[v_u_33 + v174] = function(p175)
				-- upvalues: (copy) v_u_113
				v_u_113:Select(p175)
			end
		end
	end
	local v_u_176 = v_u_114.Position
	local v_u_177 = 0
	local v_u_178 = nil
	v_u_114.DragBegin:connect(function(p179)
		-- upvalues: (ref) v_u_64, (ref) v_u_114, (ref) v_u_176, (ref) v_u_116, (ref) v_u_117, (ref) v_u_121, (ref) v_u_119, (ref) v_u_178, (ref) v_u_56, (ref) v_u_53, (ref) v_u_115, (ref) v_u_81
		v_u_64[v_u_114] = true
		v_u_176 = p179
		v_u_114.BorderSizePixel = 2
		v_u_114.ZIndex = 2
		v_u_116.ZIndex = 2
		v_u_117.ZIndex = 2
		v_u_114.Parent.ZIndex = 2
		if v_u_121 then
			v_u_121.ZIndex = 2
		end
		if v_u_119 then
			v_u_119.ZIndex = 2
			for _, v180 in pairs(v_u_119:GetChildren()) do
				v180.ZIndex = 2
			end
		end
		v_u_178 = v_u_114.Parent
		if v_u_178 == v_u_56 then
			local _ = v_u_114.AbsolutePosition
			local v181 = UDim2.new(0, v_u_114.AbsolutePosition.X - v_u_53.AbsolutePosition.X, 0, v_u_114.AbsolutePosition.Y - v_u_53.AbsolutePosition.Y)
			v_u_114.Parent = v_u_53
			v_u_114.Position = v181
			v_u_115 = v_u_81("Frame", "FakeSlot")
			v_u_115.LayoutOrder = v_u_114.LayoutOrder
			v_u_115.Size = v_u_114.Size
			v_u_115.BackgroundTransparency = 1
			v_u_115.Parent = v_u_56
		end
	end)
	v_u_114.DragStopped:connect(function(p182, p183)
		-- upvalues: (ref) v_u_115, (ref) v_u_114, (ref) v_u_176, (ref) v_u_178, (ref) v_u_116, (ref) v_u_117, (ref) v_u_121, (ref) v_u_119, (ref) v_u_64, (copy) v_u_113, (ref) v_u_53, (ref) v_u_75, (ref) v_u_177, (ref) v_u_61, (ref) v_u_51, (ref) v_u_60, (ref) v_u_57, (ref) v_u_58, (ref) v_u_66, (ref) v_u_62, (ref) v_u_70
		if v_u_115 then
			v_u_115:Destroy()
		end
		local v184 = tick()
		v_u_114.Position = v_u_176
		v_u_114.Parent = v_u_178
		v_u_114.BorderSizePixel = 0
		v_u_114.ZIndex = 1
		v_u_116.ZIndex = 1
		v_u_117.ZIndex = 1
		v_u_178.ZIndex = 1
		if v_u_121 then
			v_u_121.ZIndex = 1
		end
		if v_u_119 then
			v_u_119.ZIndex = 1
			for _, v185 in pairs(v_u_119:GetChildren()) do
				v185.ZIndex = 1
			end
		end
		v_u_64[v_u_114] = nil
		if v_u_113.Tool then
			local v186 = v_u_53
			local v187 = v186.AbsolutePosition
			local v188 = v186.AbsoluteSize
			local v189
			if v187.X < p182 and (p182 <= v187.X + v188.X and v187.Y < p183) then
				v189 = p183 <= v187.Y + v188.Y
			else
				v189 = false
			end
			if v189 then
				if v_u_113.Index <= v_u_75 then
					v_u_113:MoveToInventory()
				end
				if v_u_75 < v_u_113.Index and v184 - v_u_177 < 0.5 then
					if v_u_61 then
						local v190 = v_u_113.Tool
						v_u_113:Clear()
						v_u_61:Fill(v190)
						v_u_113:Delete()
						v184 = 0
					else
						v184 = 0
					end
				end
			else
				local v191 = v_u_51
				local v192 = v191.AbsolutePosition
				local v193 = v191.AbsoluteSize
				local v194
				if v192.X < p182 and (p182 <= v192.X + v193.X and v192.Y < p183) then
					v194 = p183 <= v192.Y + v193.Y
				else
					v194 = false
				end
				if v194 then
					local v195 = { (1 / 0), nil }
					for v196 = 1, v_u_75 do
						local v197 = v_u_60[v196]
						local v198 = v197.Frame
						local v199 = Vector2.new(p182, p183)
						local v200 = (v198.AbsolutePosition + v198.AbsoluteSize / 2 - v199).magnitude
						if v200 >= v195[1] then
							continue
						end
						v195 = { v200, v197 }
					end
					local v201 = v195[2]
					if v201 ~= v_u_113 then
						v_u_113:Swap(v201)
						if v_u_75 < v_u_113.Index then
							local v202 = v_u_113.Tool
							if v202 then
								if (not v202 or v202:IsA("HopperBin") and v202.Active or v202.Parent == v_u_57) and v_u_58 then
									v_u_58:UnequipTools()
									if v_u_66 then
										v_u_66:ToggleSelect()
										v_u_62[v_u_66]:UpdateEquipView()
										v_u_66 = nil
									end
								end
								if v_u_70 then
									v_u_113.Frame.Visible = false
									v_u_113.Frame.Parent = v_u_53
								end
							else
								v_u_113:Delete()
							end
						end
					end
				elseif v_u_113.Index <= v_u_75 then
					v_u_113:MoveToInventory()
				end
			end
			v_u_177 = v184
		end
	end)
	v_u_114.Parent = p110
	v_u_60[v112] = v_u_113
	if v_u_75 < v112 then
		v_u_102()
		if v_u_53.Visible and not v_u_70 then
			local v203 = v_u_55.CanvasSize.Y.Offset - v_u_55.AbsoluteSize.Y
			v_u_55.CanvasPosition = Vector2.new(0, (math.max(0, v203)))
		end
	end
	return v_u_113
end
local function v_u_213(p205) -- name: OnChildAdded
	-- upvalues: (ref) v_u_57, (ref) v_u_58, (ref) v_u_74, (ref) v_u_66, (copy) v_u_62, (ref) v_u_67, (ref) v_u_49, (ref) v_u_61, (copy) v_u_204, (ref) v_u_56, (copy) v_u_60, (ref) v_u_59, (copy) v_u_97, (ref) v_u_75, (ref) v_u_53, (copy) v_u_19
	if p205:IsA("Tool") or p205:IsA("HopperBin") then
		if p205.Parent == v_u_57 then
			v_u_74 = tick()
		end
		if v_u_66 and p205.Parent == v_u_57 then
			v_u_66:ToggleSelect()
			v_u_62[v_u_66]:UpdateEquipView()
			v_u_66 = nil
		end
		if not v_u_67 and (p205.Parent == v_u_57 and not v_u_62[p205]) then
			local v206 = v_u_49:FindFirstChild("StarterGear")
			if v206 and v206:FindFirstChild(p205.Name) then
				v_u_67 = true
				for v207 = (v_u_61 or v_u_204(v_u_56)).Index, 1, -1 do
					local v208 = v_u_60[v207]
					local v209 = v207 - 1
					if v209 > 0 then
						v_u_60[v209]:Swap(v208)
					else
						v208:Fill(p205)
					end
				end
				for _, v210 in pairs(v_u_57:GetChildren()) do
					if not v210:IsA("Tool") or v210 == p205 then
						continue
					end
					v210.Parent = v_u_59
				end
				v_u_97()
				return
			end
		end
		local v211 = v_u_62[p205]
		if v211 then
			v211:UpdateEquipView()
		else
			local v212 = v_u_61 or v_u_204(v_u_56)
			v212:Fill(p205)
			if v212.Index <= v_u_75 and not v_u_53.Visible then
				v_u_97()
			end
			if p205:IsA("HopperBin") and p205.Active then
				if v_u_58 then
					v_u_58:UnequipTools()
					if v_u_66 then
						v_u_66:ToggleSelect()
						v_u_62[v_u_66]:UpdateEquipView()
						v_u_66 = nil
					end
				end
				v_u_66 = p205
			end
		end
		v_u_19.BackpackItemAdded:Fire()
	elseif p205:IsA("Humanoid") and p205.Parent == v_u_57 then
		v_u_58 = p205
	end
end
local function v_u_220(p214) -- name: OnChildRemoved
	-- upvalues: (ref) v_u_74, (ref) v_u_57, (ref) v_u_59, (copy) v_u_62, (ref) v_u_75, (ref) v_u_53, (copy) v_u_97, (ref) v_u_66, (copy) v_u_19, (copy) v_u_60
	if p214:IsA("Tool") or p214:IsA("HopperBin") then
		v_u_74 = tick()
		local v215 = p214.Parent
		if v215 ~= v_u_57 and v215 ~= v_u_59 then
			local v216 = v_u_62[p214]
			if v216 then
				v216:Clear()
				if v_u_75 < v216.Index then
					v216:Delete()
				elseif not v_u_53.Visible then
					v_u_97()
				end
			end
			if p214 == v_u_66 then
				v_u_66 = nil
			end
			v_u_19.BackpackItemRemoved:Fire()
			for v217 = v_u_75 + 1, #v_u_60 do
				local v218 = v_u_60[v217]
				if not (v218 and v218.Tool) then
					continue
				end
				v219 = false
			end
			local v219 = true
			if v219 then
				v_u_19.BackpackEmpty:Fire()
			end
		end
	else
		return
	end
end
local function v239(p221) -- name: OnCharacterAdded
	-- upvalues: (copy) v_u_60, (ref) v_u_75, (ref) v_u_66, (ref) v_u_72, (ref) v_u_57, (copy) v_u_220, (copy) v_u_213, (ref) v_u_59, (ref) v_u_49, (copy) v_u_97
	for v222 = #v_u_60, 1, -1 do
		local v223 = v_u_60[v222]
		if v223.Tool then
			v223:Clear()
		end
		if v_u_75 >= v222 then
			continue
		end
		v223:Delete()
	end
	v_u_66 = nil
	for _, v224 in pairs(v_u_72) do
		v224:disconnect()
	end
	v_u_72 = {}
	v_u_57 = p221
	local v225 = v_u_72
	local v226 = p221.ChildRemoved
	local v227 = v_u_220
	table.insert(v225, v226:connect(v227))
	local v228 = v_u_72
	local v229 = p221.ChildAdded
	local v230 = v_u_213
	table.insert(v228, v229:connect(v230))
	for _, v231 in pairs(p221:GetChildren()) do
		v_u_213(v231)
	end
	v_u_59 = v_u_49:WaitForChild("Backpack")
	local v232 = v_u_72
	local v233 = v_u_59.ChildRemoved
	local v234 = v_u_220
	table.insert(v232, v233:connect(v234))
	local v235 = v_u_72
	local v236 = v_u_59.ChildAdded
	local v237 = v_u_213
	table.insert(v235, v236:connect(v237))
	for _, v238 in pairs(v_u_59:GetChildren()) do
		v_u_213(v238)
	end
	v_u_97()
end
local function v244(p240, p241) -- name: OnInputBegan
	-- upvalues: (ref) v_u_69, (ref) v_u_68, (copy) v_u_34, (copy) v_u_63, (ref) v_u_53, (copy) v_u_19
	local v242 = p240.UserInputType == Enum.UserInputType.Keyboard and (not v_u_69 and (v_u_68 or p240.KeyCode.Value == v_u_34)) and v_u_63[p240.KeyCode.Value]
	if v242 then
		v242(p241)
	end
	local v243 = p240.UserInputType
	if not p241 and (v243 == Enum.UserInputType.MouseButton1 or v243 == Enum.UserInputType.Touch) and v_u_53.Visible then
		v_u_19.OpenClose()
	end
end
local function v248(p245) -- name: OnUISChanged
	-- upvalues: (copy) v_u_37, (copy) v_u_41, (ref) v_u_75, (copy) v_u_60
	if p245 == "KeyboardEnabled" or p245 == "VREnabled" then
		local v246 = v_u_37.KeyboardEnabled
		if v246 then
			v246 = not v_u_41.VREnabled
		end
		for v247 = 1, v_u_75 do
			v_u_60[v247]:TurnNumber(v246)
		end
	end
end
local v_u_249 = nil
local v_u_250 = nil
local function v_u_251() end
local _ = Vector2.new(0, 0)
function unbindAllGamepadEquipActions() -- name: unbindAllGamepadEquipActions
	-- upvalues: (copy) v_u_40
	v_u_40:UnbindAction("RBXBackpackHasGamepadFocus")
	v_u_40:UnbindAction("RBXCloseInventory")
end
function changeToolFunc(_, p252, p_u_253)
	-- upvalues: (ref) v_u_249, (ref) v_u_250, (ref) v_u_58, (ref) v_u_66, (copy) v_u_62, (ref) v_u_75, (copy) v_u_60, (ref) v_u_77
	if p252 == Enum.UserInputState.Begin then
		if v_u_249 and (v_u_249.KeyCode == Enum.KeyCode.ButtonR1 and p_u_253.KeyCode == Enum.KeyCode.ButtonL1 or v_u_249.KeyCode == Enum.KeyCode.ButtonL1 and p_u_253.KeyCode == Enum.KeyCode.ButtonR1) and tick() - v_u_250 <= 0.06 then
			if v_u_58 then
				v_u_58:UnequipTools()
				if v_u_66 then
					v_u_66:ToggleSelect()
					v_u_62[v_u_66]:UpdateEquipView()
					v_u_66 = nil
				end
			end
			v_u_249 = p_u_253
			v_u_250 = tick()
		else
			v_u_249 = p_u_253
			v_u_250 = tick()
			delay(0.06, function()
				-- upvalues: (ref) v_u_249, (copy) p_u_253, (ref) v_u_75, (ref) v_u_60, (ref) v_u_58, (ref) v_u_66, (ref) v_u_62, (ref) v_u_77
				if v_u_249 == p_u_253 then
					local v254 = p_u_253.KeyCode == Enum.KeyCode.ButtonL1 and -1 or 1
					for v255 = 1, v_u_75 do
						if not v_u_60[v255]:IsEquipped() then
							continue
						end
						local v256 = v254 + v255
						local v257 = false
						if v_u_75 < v256 then
							v256 = 1
							v257 = true
						elseif v256 < 1 then
							v256 = v_u_75
							v257 = true
						end
						local v258 = v256
						while not v_u_60[v256].Tool do
							v256 = v256 + v254
							if v256 == v258 then
								return
							end
							if v_u_75 < v256 then
								v256 = 1
								v257 = true
							else
								if v256 >= 1 then
									continue
								end
								v256 = v_u_75
								v257 = true
							end
						end
						if v257 then
							if v_u_58 then
								v_u_58:UnequipTools()
								if v_u_66 then
									v_u_66:ToggleSelect()
									v_u_62[v_u_66]:UpdateEquipView()
									v_u_66 = nil
								end
							end
							v_u_77 = nil
						else
							v_u_60[v256]:Select()
						end
					end
					if v_u_77 and v_u_77.Tool then
						v_u_77:Select()
					else
						for v259 = v254 == -1 and (v_u_75 or 1) or 1, v254 == -1 and 1 or v_u_75, v254 do
							if not v_u_60[v259].Tool then
								continue
							end
							v_u_60[v259]:Select()
							return
						end
					end
				else
					return
				end
			end)
		end
	else
		return
	end
end
function getGamepadSwapSlot() -- name: getGamepadSwapSlot
	-- upvalues: (copy) v_u_60
	for v260 = 1, #v_u_60 do
		if v_u_60[v260].Frame.BorderSizePixel <= 0 then
			continue
		end
		return v_u_60[v260]
	end
end
function changeSlot(p_u_261) -- name: changeSlot
	-- upvalues: (copy) v_u_42, (copy) v_u_39, (ref) v_u_54, (ref) v_u_75
	local v262 = v_u_42.GamepadCursorEnabled
	if p_u_261.Frame == v_u_39.SelectedCoreObject and not v262 then
		local v263 = getGamepadSwapSlot()
		if not v263 then
			local v_u_264 = p_u_261.Frame.Size
			local v_u_265 = p_u_261.Frame.Position
			p_u_261.Frame:TweenSizeAndPositionInternal(v_u_264 + UDim2.new(0, 10, 0, 10), v_u_265 - UDim2.new(0, 5, 0, 5), Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.1, true, function()
				-- upvalues: (copy) p_u_261, (copy) v_u_264, (copy) v_u_265
				p_u_261.Frame:TweenSizeAndPositionInternal(v_u_264, v_u_265, Enum.EasingDirection.In, Enum.EasingStyle.Quad, 0.1, true)
			end)
			p_u_261.Frame.BorderSizePixel = 3
			v_u_54.SelectionImageObject.Visible = true
			return
		end
		v263.Frame.BorderSizePixel = 0
		if v263 ~= p_u_261 then
			p_u_261:Swap(v263)
			v_u_54.SelectionImageObject.Visible = false
			if v_u_75 < p_u_261.Index and not p_u_261.Tool then
				if v_u_39.SelectedCoreObject == p_u_261.Frame then
					v_u_39.SelectedCoreObject = v263.Frame
				end
				p_u_261:Delete()
			end
			if v_u_75 < v263.Index and not v263.Tool then
				if v_u_39.SelectedCoreObject == v263.Frame then
					v_u_39.SelectedCoreObject = p_u_261.Frame
				end
				v263:Delete()
				return
			end
		end
	else
		p_u_261:Select()
		v_u_54.SelectionImageObject.Visible = false
	end
end
function enableGamepadInventoryControl() -- name: enableGamepadInventoryControl
	-- upvalues: (ref) v_u_53, (copy) v_u_19, (copy) v_u_40, (copy) v_u_251, (copy) v_u_39, (ref) v_u_51
	local function v268(_, p266, _)
		-- upvalues: (ref) v_u_53, (ref) v_u_19
		if p266 == Enum.UserInputState.Begin then
			if getGamepadSwapSlot() then
				local v267 = getGamepadSwapSlot()
				if v267 then
					v267.Frame.BorderSizePixel = 0
					return
				end
			elseif v_u_53.Visible then
				v_u_19.OpenClose()
			end
		end
	end
	v_u_40:BindAction("RBXBackpackHasGamepadFocus", v_u_251, false, Enum.UserInputType.Gamepad1)
	v_u_40:BindAction("RBXCloseInventory", v268, false, Enum.KeyCode.ButtonB, Enum.KeyCode.ButtonStart)
	if true then
		v_u_39.SelectedCoreObject = v_u_51:FindFirstChild("1")
	end
end
function disableGamepadInventoryControl() -- name: disableGamepadInventoryControl
	-- upvalues: (ref) v_u_75, (copy) v_u_60, (copy) v_u_39, (ref) v_u_50
	unbindAllGamepadEquipActions()
	for v269 = 1, v_u_75 do
		local v270 = v_u_60[v269]
		if not (v270 and v270.Frame) then
			continue
		end
		v270.Frame.BorderSizePixel = 0
	end
	if v_u_39.SelectedCoreObject and v_u_39.SelectedCoreObject:IsDescendantOf(v_u_50) then
		v_u_39.SelectedCoreObject = nil
	end
end
function gamepadDisconnected() -- name: gamepadDisconnected
	-- upvalues: (copy) v_u_41, (ref) v_u_73
	if not v_u_41.VREnabled then
		v_u_73 = false
		disableGamepadInventoryControl()
	end
end
function gamepadConnected() -- name: gamepadConnected
	-- upvalues: (copy) v_u_41, (ref) v_u_73, (copy) v_u_17, (copy) v_u_39, (ref) v_u_50, (ref) v_u_65, (ref) v_u_68, (ref) v_u_47, (copy) v_u_40, (ref) v_u_53
	if not v_u_41.VREnabled then
		v_u_73 = true
		if v_u_17 then
			v_u_39:RemoveSelectionGroup("RBXBackpackSelection")
		end
		v_u_39:AddSelectionParent("RBXBackpackSelection", v_u_50)
		if v_u_65 >= 1 and (v_u_68 and not v_u_47) then
			v_u_47 = true
			v_u_40:BindAction("RBXHotbarEquip", changeToolFunc, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
		end
		if v_u_53.Visible then
			enableGamepadInventoryControl()
		end
	end
end
local function v_u_274(p271, p272) -- name: OnCoreGuiChanged
	-- upvalues: (ref) v_u_46, (ref) v_u_68, (copy) v_u_9, (ref) v_u_50, (copy) v_u_2, (copy) v_u_71, (copy) v_u_39, (ref) v_u_65, (ref) v_u_47, (copy) v_u_40
	if p271 == Enum.CoreGuiType.Backpack or p271 == Enum.CoreGuiType.All then
		if p272 then
			p272 = v_u_46
		end
		v_u_68 = p272
		if v_u_9 then
			if p272 then
				v_u_50.Parent = v_u_2
			else
				v_u_50.Parent = nil
			end
		else
			v_u_50.Visible = p272
		end
		for _, v273 in pairs(v_u_71) do
			if p272 then
				v_u_39:AddKey(v273)
			else
				v_u_39:RemoveKey(v273)
			end
		end
		if p272 then
			if v_u_65 >= 1 and (v_u_68 and not v_u_47) then
				v_u_47 = true
				v_u_40:BindAction("RBXHotbarEquip", changeToolFunc, false, Enum.KeyCode.ButtonL1, Enum.KeyCode.ButtonR1)
				return
			end
		else
			disableGamepadInventoryControl()
			v_u_47 = false
			v_u_40:UnbindAction("RBXHotbarEquip")
		end
	end
end
local function v280(p275, p276) -- name: MakeVRRoundButton
	-- upvalues: (copy) v_u_81
	local v277 = v_u_81("ImageButton", p275)
	v277.Size = UDim2.new(0, 40, 0, 40)
	v277.Image = "rbxasset://textures/ui/Keyboard/close_button_background.png"
	local v278 = v_u_81("ImageLabel", "Icon")
	v278.Size = UDim2.new(0.5, 0, 0.5, 0)
	v278.Position = UDim2.new(0.25, 0, 0.25, 0)
	v278.Image = p276
	v278.Parent = v277
	local v279 = v_u_81("ImageLabel", "Selection")
	v279.Size = UDim2.new(0.9, 0, 0.9, 0)
	v279.Position = UDim2.new(0.05, 0, 0.05, 0)
	v279.Image = "rbxasset://textures/ui/Keyboard/close_button_selection.png"
	v277.SelectionImageObject = v279
	return v277, v278, v279
end
local v281 = v_u_81("Frame", "Backpack")
if v_u_9 then
	if v_u_38:GetCoreGuiEnabled(Enum.CoreGuiType.Backpack) then
		v281.Parent = v_u_2
	end
else
	v281.Visible = false
	v281.Parent = v_u_2
end
local v282 = v_u_81("Frame", "Hotbar")
v282.Parent = v281
local v_u_283 = v_u_30
local v284 = v281
local v_u_285 = v282
for v286 = 1, v_u_75 do
	local v287 = v_u_204(v_u_285, v286)
	v287.Frame.Visible = false
	if v_u_61 then
		continue
	end
	local v288 = v287
	v_u_61 = v288
end
local v_u_289 = v_u_81("ImageButton", "OpenInventory")
v_u_289.Size = UDim2.new(0, 30, 0, 30)
v_u_289.Image = "rbxasset://textures/ui/Backpack/ScrollUpArrow.png"
v_u_289.MouseButton1Click:connect(function()
	-- upvalues: (copy) v_u_19
	v_u_19.OpenClose()
end)
v_u_289.SelectionGained:connect(function()
	-- upvalues: (ref) v_u_289, (copy) v_u_29
	v_u_289.ImageColor3 = v_u_29
end)
v_u_289.SelectionLost:connect(function()
	-- upvalues: (ref) v_u_289
	v_u_289.ImageColor3 = Color3.new(1, 1, 1)
end)
local v290 = v_u_81("Frame", "Selection")
v290.Visible = false
v_u_289.SelectionImageObject = v290
local v291 = v280("CloseInventory", "rbxasset://textures/ui/Keyboard/close_button_icon.png")
v291.Position = UDim2.new(0, 0, 0, -50)
v291.MouseButton1Click:connect(function()
	-- upvalues: (ref) v_u_53, (copy) v_u_19
	if v_u_53.Visible then
		v_u_19.OpenClose()
	end
end)
LeftBumperButton = v_u_81("ImageLabel", "LeftBumper")
LeftBumperButton.Size = UDim2.new(0, 40, 0, 40)
LeftBumperButton.Position = UDim2.new(0, -LeftBumperButton.Size.X.Offset, 0.5, -LeftBumperButton.Size.Y.Offset / 2)
RightBumperButton = v_u_81("ImageLabel", "RightBumper")
RightBumperButton.Size = UDim2.new(0, 40, 0, 40)
RightBumperButton.Position = UDim2.new(1, 0, 0.5, -RightBumperButton.Size.Y.Offset / 2)
local v_u_292 = v_u_81("Frame", "Inventory")
v_u_292.BackgroundTransparency = v_u_22
v_u_292.BackgroundColor3 = v_u_23
v_u_292.Active = true
v_u_292.Visible = false
v_u_292.Parent = v284
local v293 = v_u_81("TextButton", "VRInventorySelector")
v293.Position = UDim2.new(0, 0, 0, 0)
v293.Size = UDim2.new(1, 0, 1, 0)
v293.BackgroundTransparency = 1
v293.Text = ""
v293.Parent = v_u_292
local v294 = v_u_81("ImageLabel", "Selector")
v294.Size = UDim2.new(1, 0, 1, 0)
v294.Image = "rbxasset://textures/ui/Keyboard/key_selection_9slice.png"
v294.ScaleType = Enum.ScaleType.Slice
v294.SliceCenter = Rect.new(12, 12, 52, 52)
v294.Visible = false
v293.SelectionImageObject = v294
local v_u_295 = v_u_81("ScrollingFrame", "ScrollingFrame")
v_u_295.Selectable = false
v_u_295.CanvasSize = UDim2.new(0, 0, 0, 0)
v_u_295.Parent = v_u_292
local v_u_296 = v_u_81("Frame", "UIGridFrame")
v_u_296.Selectable = false
v_u_296.Size = UDim2.new(1, -10, 1, 0)
v_u_296.Position = UDim2.new(0, 5, 0, 0)
v_u_296.Parent = v_u_295
local v297 = Instance.new("UIGridLayout")
v297.SortOrder = Enum.SortOrder.LayoutOrder
v297.CellSize = UDim2.new(0, v_u_20, 0, v_u_20)
v297.CellPadding = UDim2.new(0, 5, 0, 5)
v297.Parent = v_u_296
local v_u_298 = v280("ScrollUpButton", "rbxasset://textures/ui/Backpack/ScrollUpArrow.png")
v_u_298.Size = UDim2.new(0, 34, 0, 34)
v_u_298.Position = UDim2.new(0.5, -v_u_298.Size.X.Offset / 2, 0, 43)
v_u_298.Icon.Position = v_u_298.Icon.Position - UDim2.new(0, 0, 0, 2)
v_u_298.MouseButton1Click:connect(function()
	-- upvalues: (ref) v_u_295, (ref) v_u_20
	local v299 = v_u_295
	local v300 = Vector2.new
	local v301 = v_u_295.CanvasPosition.X
	local v302 = v_u_295.CanvasSize.Y.Offset - v_u_295.AbsoluteWindowSize.Y
	local v303 = v_u_295.CanvasPosition.Y - (v_u_20 + 5)
	local v304 = math.max(0, v303)
	v299.CanvasPosition = v300(v301, (math.min(v302, v304)))
end)
local v_u_305 = v280("ScrollDownButton", "rbxasset://textures/ui/Backpack/ScrollUpArrow.png")
v_u_305.Rotation = 180
v_u_305.Icon.Position = v_u_305.Icon.Position - UDim2.new(0, 0, 0, 2)
v_u_305.Size = UDim2.new(0, 34, 0, 34)
v_u_305.Position = UDim2.new(0.5, -v_u_305.Size.X.Offset / 2, 1, -v_u_305.Size.Y.Offset - 3)
v_u_305.MouseButton1Click:connect(function()
	-- upvalues: (ref) v_u_295, (ref) v_u_20
	local v306 = v_u_295
	local v307 = Vector2.new
	local v308 = v_u_295.CanvasPosition.X
	local v309 = v_u_295.CanvasSize.Y.Offset - v_u_295.AbsoluteWindowSize.Y
	local v310 = v_u_295.CanvasPosition.Y + (v_u_20 + 5)
	local v311 = math.max(0, v310)
	v306.CanvasPosition = v307(v308, (math.min(v309, v311)))
end)
v_u_295.Changed:connect(function(p312)
	-- upvalues: (ref) v_u_295, (ref) v_u_298, (ref) v_u_305
	if p312 == "AbsoluteWindowSize" or (p312 == "CanvasPosition" or p312 == "CanvasSize") then
		local v313 = v_u_295.CanvasPosition.Y ~= 0
		local v314 = v_u_295.CanvasPosition.Y < v_u_295.CanvasSize.Y.Offset - v_u_295.AbsoluteWindowSize.Y
		v_u_298.Visible = v313
		v_u_305.Visible = v314
	end
end)
v106()
local v_u_315 = v_u_44("Frame")({
	["Name"] = "GamepadHintsFrame",
	["Size"] = nil,
	["BackgroundTransparency"] = 1,
	["Visible"] = false,
	["Parent"] = nil,
	["Size"] = UDim2.new(0, v_u_285.Size.X.Offset, 0, v_u_43 and 95 or 60),
	["Parent"] = v284
})
local function v323(p316, p317, p318) -- name: addGamepadHint
	-- upvalues: (copy) v_u_44, (copy) v_u_315, (copy) v_u_43
	local v319 = v_u_44("Frame")({
		["Name"] = "HintFrame",
		["Size"] = nil,
		["Position"] = nil,
		["BackgroundTransparency"] = 1,
		["Parent"] = nil,
		["Size"] = UDim2.new(1, 0, 1, -5),
		["Position"] = UDim2.new(0, 0, 0, 0),
		["Parent"] = v_u_315
	})
	local v320 = v_u_44("ImageLabel")
	local v321 = {
		["Name"] = "HintImage",
		["Size"] = nil,
		["BackgroundTransparency"] = 1,
		["Image"] = nil,
		["Parent"] = nil,
		["Size"] = v_u_43 and UDim2.new(0, 90, 0, 90) or UDim2.new(0, 60, 0, 60)
	}
	if v_u_43 then
		p316 = p317 or p316
	end
	v321.Image = p316
	v321.Parent = v319
	v320(v321)
	local v322 = v_u_44("TextLabel")({
		["Name"] = "HintText",
		["Position"] = nil,
		["Size"] = nil,
		["Font"] = nil,
		["FontSize"] = nil,
		["BackgroundTransparency"] = 1,
		["Text"] = nil,
		["TextColor3"] = nil,
		["TextXAlignment"] = nil,
		["TextWrapped"] = true,
		["Parent"] = nil,
		["Position"] = UDim2.new(0, v_u_43 and 100 or 70, 0, 0),
		["Size"] = UDim2.new(1, -(v_u_43 and 100 or 70), 1, 0),
		["Font"] = Enum.Font.SourceSansBold,
		["FontSize"] = v_u_43 and Enum.FontSize.Size36 or Enum.FontSize.Size24,
		["Text"] = p318,
		["TextColor3"] = Color3.new(1, 1, 1),
		["TextXAlignment"] = Enum.TextXAlignment.Left,
		["Parent"] = v319
	})
	Instance.new("UITextSizeConstraint", v322).MaxTextSize = v322.TextSize
end
local function v_u_329() -- name: resizeGamepadHintsFrame
	-- upvalues: (copy) v_u_315, (ref) v_u_285, (copy) v_u_43, (ref) v_u_292
	v_u_315.Size = UDim2.new(v_u_285.Size.X.Scale, v_u_285.Size.X.Offset, 0, v_u_43 and 95 or 60)
	v_u_315.Position = UDim2.new(v_u_285.Position.X.Scale, v_u_285.Position.X.Offset, v_u_292.Position.Y.Scale, v_u_292.Position.Y.Offset - v_u_315.Size.Y.Offset)
	local v324 = v_u_315:GetChildren()
	local v325 = 0
	for v326 = 1, #v324 do
		v324[v326].Size = UDim2.new(1, 0, 1, -5)
		v324[v326].Position = UDim2.new(0, 0, 0, 0)
		v325 = v325 + (v324[v326].HintText.Position.X.Offset + v324[v326].HintText.TextBounds.X)
	end
	local v327 = (v_u_315.AbsoluteSize.X - v325) / (#v324 - 1)
	for v328 = 1, #v324 do
		v324[v328].Position = v328 == 1 and UDim2.new(0, 0, 0, 0) or UDim2.new(0, v324[v328 - 1].Position.X.Offset + v324[v328 - 1].Size.X.Offset + v327, 0, 0)
		v324[v328].Size = UDim2.new(0, v324[v328].HintText.Position.X.Offset + v324[v328].HintText.TextBounds.X, 1, -5)
	end
end
v323("rbxasset://textures/ui/Controls/DesignSystem/ButtonX.png", "rbxasset://textures/ui/Controls/DesignSystem/ButtonX@2x.png", "Remove From Hotbar")
v323("rbxasset://textures/ui/Controls/DesignSystem/ButtonA.png", "rbxasset://textures/ui/Controls/DesignSystem/ButtonA@2x.png", "Select/Swap")
v323("rbxasset://textures/ui/Controls/DesignSystem/ButtonB.png", "rbxasset://textures/ui/Controls/DesignSystem/ButtonB@2x.png", "Close Backpack")
local v_u_330 = v_u_81("Frame", "Search")
v_u_330.BackgroundColor3 = v31
v_u_330.BackgroundTransparency = v_u_32
v_u_330.Size = UDim2.new(0, 190, 0, 30)
v_u_330.Position = UDim2.new(1, -v_u_330.Size.X.Offset - 5, 0, 5)
v_u_330.Parent = v_u_292
local v_u_331 = v_u_81("TextBox", "TextBox")
v_u_331.Text = v_u_283
v_u_331.ClearTextOnFocus = false
v_u_331.FontSize = Enum.FontSize.Size24
v_u_331.TextXAlignment = Enum.TextXAlignment.Left
v_u_331.Size = v_u_330.Size - UDim2.new(0, 0, 0, 0)
v_u_331.Position = UDim2.new(0, 0, 0, 0)
v_u_331.Parent = v_u_330
local v_u_332 = v_u_81("TextButton", "X")
v_u_332.Text = "x"
v_u_332.TextColor3 = v_u_25
v_u_332.FontSize = Enum.FontSize.Size24
v_u_332.TextYAlignment = Enum.TextYAlignment.Bottom
v_u_332.BackgroundColor3 = v31
v_u_332.BackgroundTransparency = 0
v_u_332.Size = UDim2.new(0, v_u_330.Size.Y.Offset - 10, 0, v_u_330.Size.Y.Offset - 10)
v_u_332.Position = UDim2.new(1, -v_u_332.Size.X.Offset - 10, 0.5, -v_u_332.Size.Y.Offset / 2)
v_u_332.ZIndex = 0
v_u_332.Visible = false
v_u_332.BorderSizePixel = 0
v_u_332.Parent = v_u_330
local function v_u_344() -- name: search
	-- upvalues: (copy) v_u_331, (ref) v_u_75, (copy) v_u_60, (ref) v_u_292, (ref) v_u_70, (ref) v_u_296, (ref) v_u_295, (copy) v_u_102, (copy) v_u_332
	local v333 = {}
	for v334 in v_u_331.Text:gmatch("%S+") do
		v333[v334:lower()] = true
	end
	local v335 = {}
	for v336 = v_u_75 + 1, #v_u_60 do
		local v337 = v_u_60[v336]
		local v338 = { v337, (v337:CheckTerms(v333)) }
		table.insert(v335, v338)
		v337.Frame.Visible = false
		v337.Frame.Parent = v_u_292
	end
	table.sort(v335, function(p339, p340)
		return p339[2] > p340[2]
	end)
	v_u_70 = true
	local v341 = 0
	for _, v342 in ipairs(v335) do
		local v343 = v342[1]
		if v342[2] <= 0 then
			continue
		end
		v343.Frame.Visible = true
		v343.Frame.Parent = v_u_296
		v343.Frame.LayoutOrder = v_u_75 + v341
		v341 = v341 + 1
	end
	v_u_295.CanvasPosition = Vector2.new(0, 0)
	v_u_102()
	v_u_332.ZIndex = 3
end
local function v_u_347() -- name: clearResults
	-- upvalues: (copy) v_u_332, (ref) v_u_70, (ref) v_u_75, (copy) v_u_60, (ref) v_u_296, (copy) v_u_102
	if v_u_332.ZIndex > 0 then
		v_u_70 = false
		for v345 = v_u_75 + 1, #v_u_60 do
			local v346 = v_u_60[v345]
			v346.Frame.LayoutOrder = v346.Index
			v346.Frame.Parent = v_u_296
			v346.Frame.Visible = true
		end
		v_u_332.ZIndex = 0
	end
	v_u_102()
end
v_u_331.Focused:connect(function() -- name: onFocused
	-- upvalues: (copy) v_u_331, (ref) v_u_283
	if v_u_331.Text == v_u_283 then
		v_u_331.Text = ""
	end
end)
v_u_332.MouseButton1Click:connect(function() -- name: reset
	-- upvalues: (copy) v_u_347, (copy) v_u_331, (ref) v_u_283
	v_u_347()
	v_u_331.Text = v_u_283
end)
v_u_331.Changed:connect(function(p348) -- name: onChanged
	-- upvalues: (copy) v_u_331, (copy) v_u_347, (ref) v_u_283, (copy) v_u_344, (copy) v_u_332
	if p348 == "Text" then
		local v349 = v_u_331.Text
		if v349 == "" then
			v_u_347()
		elseif v349 ~= v_u_283 then
			v_u_344()
		end
		local v350 = v_u_332
		local v351
		if v349 == "" then
			v351 = false
		else
			v351 = v349 ~= v_u_283
		end
		v350.Visible = v351
	end
end)
v_u_331.FocusLost:connect(function(p352) -- name: focusLost
	-- upvalues: (copy) v_u_344, (copy) v_u_331, (ref) v_u_283
	if p352 then
		v_u_344()
	elseif v_u_331.Text == "" then
		v_u_331.Text = v_u_283
	end
end)
v_u_19.StateChanged.Event:connect(function(p353)
	-- upvalues: (copy) v_u_332, (copy) v_u_347, (copy) v_u_331, (ref) v_u_283
	v_u_332.Modal = p353
	if not p353 then
		v_u_347()
		v_u_331.Text = v_u_283
	end
end)
v_u_63[Enum.KeyCode.Escape.Value] = function(p354)
	-- upvalues: (copy) v_u_347, (copy) v_u_331, (ref) v_u_283, (ref) v_u_292, (copy) v_u_19
	if p354 then
		v_u_347()
		v_u_331.Text = v_u_283
	elseif v_u_292.Visible then
		v_u_19.OpenClose()
	end
end
v_u_37.LastInputTypeChanged:connect(function(p355) -- name: detectGamepad
	-- upvalues: (copy) v_u_41, (copy) v_u_330
	if p355 == Enum.UserInputType.Gamepad1 and not v_u_41.VREnabled then
		v_u_330.Visible = false
	else
		v_u_330.Visible = true
	end
end)
local function v_u_358(_, p356, _)
	-- upvalues: (copy) v_u_39, (ref) v_u_75, (copy) v_u_60
	if p356 == Enum.UserInputState.Begin then
		if v_u_39.SelectedCoreObject then
			for v357 = 1, v_u_75 do
				if v_u_60[v357].Frame ~= v_u_39.SelectedCoreObject or not v_u_60[v357].Tool then
					continue
				end
				v_u_60[v357]:MoveToInventory()
				return
			end
		end
	else
		return
	end
end
local function v_u_361() -- name: openClose
	-- upvalues: (copy) v_u_64, (ref) v_u_292, (copy) v_u_97, (ref) v_u_285, (ref) v_u_75, (copy) v_u_60, (ref) v_u_73, (copy) v_u_35, (copy) v_u_37, (copy) v_u_329, (copy) v_u_315, (copy) v_u_40, (copy) v_u_358, (copy) v_u_19
	if not next(v_u_64) then
		v_u_292.Visible = not v_u_292.Visible
		local v359 = v_u_292.Visible
		v_u_97()
		v_u_285.Active = not v_u_285.Active
		for v360 = 1, v_u_75 do
			v_u_60[v360]:SetClickability(not v359)
		end
	end
	if v_u_292.Visible then
		if v_u_73 then
			if v_u_35[v_u_37:GetLastInputType()] then
				v_u_329()
				v_u_315.Visible = true
			end
			enableGamepadInventoryControl()
		end
	else
		if v_u_73 then
			v_u_315.Visible = false
		end
		disableGamepadInventoryControl()
	end
	if v_u_292.Visible then
		v_u_40:BindAction("RBXRemoveSlot", v_u_358, false, Enum.KeyCode.ButtonX)
	else
		v_u_40:UnbindAction("RBXRemoveSlot")
	end
	v_u_19.IsOpen = v_u_292.Visible
	v_u_19.StateChanged:Fire(v_u_292.Visible)
end
v_u_63[v28] = function()
	-- upvalues: (copy) v_u_39, (copy) v_u_361
	if not v_u_39.MenuIsOpen then
		v_u_361()
	end
end
v_u_19.OpenClose = v_u_361
local v_u_362 = v_u_292
while not v_u_49 do
	wait()
	v_u_49 = v36.LocalPlayer
end
v_u_49.CharacterAdded:connect(v239)
if v_u_49.Character then
	v239(v_u_49.Character)
end
for v363 = 0, 9 do
	local v364 = tostring(v363)
	table.insert(v_u_71, v364)
end
table.insert(v_u_71, "`")
v_u_37.InputBegan:connect(v244)
v_u_37.TextBoxFocused:connect(function()
	-- upvalues: (ref) v_u_69
	v_u_69 = true
end)
v_u_37.TextBoxFocusReleased:connect(function()
	-- upvalues: (ref) v_u_69
	v_u_69 = false
end)
v_u_63[v_u_34] = function()
	-- upvalues: (ref) v_u_66, (ref) v_u_58, (copy) v_u_62
	if v_u_66 and v_u_58 then
		v_u_58:UnequipTools()
		if v_u_66 then
			v_u_66:ToggleSelect()
			v_u_62[v_u_66]:UpdateEquipView()
			v_u_66 = nil
		end
	end
end
v_u_37.Changed:connect(v248)
local v365 = v_u_37.KeyboardEnabled
if v365 then
	v365 = not v_u_41.VREnabled
end
for v366 = 1, v_u_75 do
	v_u_60[v366]:TurnNumber(v365)
end
if v_u_37:GetGamepadConnected(Enum.UserInputType.Gamepad1) then
	gamepadConnected()
end
v_u_37.GamepadConnected:connect(function(p367)
	if p367 == Enum.UserInputType.Gamepad1 then
		gamepadConnected()
	end
end)
v_u_37.GamepadDisconnected:connect(function(p368)
	if p368 == Enum.UserInputType.Gamepad1 then
		gamepadDisconnected()
	end
end)
function v_u_19.TopbarEnabledChanged(_, p369) -- name: TopbarEnabledChanged
	-- upvalues: (ref) v_u_46, (copy) v_u_274, (copy) v_u_38
	v_u_46 = p369
	v_u_274(Enum.CoreGuiType.Backpack, v_u_38:GetCoreGuiEnabled(Enum.CoreGuiType.Backpack))
end
if v12 then
	v_u_19.disposeEffect = v5.createEffect(function(p370)
		-- upvalues: (copy) v_u_6, (copy) v_u_19
		local v371 = v_u_6.Stores.GetTopBarStore
		if v371 then
			v_u_19:TopbarEnabledChanged(v371(p370).getTopBarCoreGuiEnabled(p370))
		end
	end)
end
v_u_38.CoreGuiChangedSignal:connect(v_u_274)
local v372 = Enum.CoreGuiType.Backpack
local v373 = Enum.CoreGuiType.Health
v_u_274(v372, v_u_38:GetCoreGuiEnabled(v372))
v_u_274(v373, v_u_38:GetCoreGuiEnabled(v373))
if v_u_16 then
	v7:connect(function(p374)
		-- upvalues: (copy) v_u_19, (copy) v_u_97
		if p374 then
			if v_u_19.IsHotbarVisible then
				v_u_97(true)
				return
			end
		else
			v_u_97(false)
		end
	end)
end
v_u_39.MenuOpened:Connect(function()
	-- upvalues: (copy) v_u_19, (copy) v_u_10, (copy) v_u_11, (copy) v_u_41
	if v_u_19.IsOpen and (not v_u_10 or v_u_11:isMovePanelToCenter() or not v_u_41.VREnabled) then
		v_u_19.OpenClose()
	end
end)
v8.default.visibilitySignal.Event:Connect(function(p375)
	-- upvalues: (copy) v_u_19
	if p375 and v_u_19.IsOpen then
		v_u_19.OpenClose()
	end
end)
v_u_1:GetPropertyChangedSignal("PreferredTransparency"):connect(function() -- name: OnPreferredTransparencyChanged
	-- upvalues: (copy) v_u_1, (ref) v_u_22, (ref) v_u_362, (ref) v_u_26, (copy) v_u_60, (ref) v_u_32, (copy) v_u_330
	local v376 = v_u_1.PreferredTransparency
	v_u_22 = 0.5 * v_u_1.PreferredTransparency
	v_u_362.BackgroundTransparency = v_u_22
	v_u_26 = 0.5 * v376
	for _, v377 in ipairs(v_u_60) do
		v377.Frame.BackgroundTransparency = v_u_26
	end
	v_u_32 = 0.15 * v_u_1.PreferredTransparency
	v_u_330.BackgroundTransparency = v_u_32
end)
return v_u_19
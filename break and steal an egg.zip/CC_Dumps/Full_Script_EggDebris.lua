local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(v1.Shared.EggConfig)
local v5 = {}
local v_u_6 = Random.new()
local v_u_7 = nil
local function v_u_16(p_u_8) -- name: despawn
	-- upvalues: (copy) v_u_4, (copy) v_u_2
	local v_u_9 = v_u_4.Debris
	p_u_8.Anchored = true
	p_u_8.CanCollide = false
	local v10 = p_u_8.Size
	local v_u_11 = v10 * v_u_9.PopScale
	local v12 = (v_u_11.Y - v10.Y) / 2
	local v13 = v_u_2:Create(p_u_8, TweenInfo.new(v_u_9.PopTime, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["Size"] = v_u_11,
		["CFrame"] = p_u_8.CFrame + Vector3.new(0, v12, 0)
	})
	v13.Completed:Connect(function()
		-- upvalues: (copy) v_u_11, (ref) v_u_2, (copy) p_u_8, (copy) v_u_9
		local v14 = v_u_11.Y / 2 - 0.025
		local v15 = v_u_2:Create(p_u_8, TweenInfo.new(v_u_9.ShrinkTime, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
			["Size"] = Vector3.new(0.05, 0.05, 0.05),
			["CFrame"] = nil,
			["CFrame"] = p_u_8.CFrame - Vector3.new(0, v14, 0)
		})
		v15.Completed:Connect(function()
			-- upvalues: (ref) p_u_8
			p_u_8:Destroy()
		end)
		v15:Play()
	end)
	v13:Play()
end
function v5.Erupt(p17, p18) -- name: Erupt
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (ref) v_u_7, (copy) v_u_3, (copy) v_u_2, (copy) v_u_16
	local v19 = math.max(p18 or 1, 0.5)
	local v_u_20 = v_u_4.Debris
	local v21 = v_u_6:NextInteger(v_u_20.MinCount, v_u_20.MaxCount) * v19 + 0.5
	local v22 = math.floor(v21)
	local v23 = p17.Size.X
	local v24 = p17.Size.Z
	local v25 = math.min(v23, v24) / 2
	local v26 = v_u_4.VFXScaleForWidth(v25 * 2)
	local v27 = math.sqrt(v26)
	local v28 = v_u_6:NextNumber(0, 6.283185307179586)
	local v29 = 6.283185307179586 / v22
	local v30 = v_u_20.Size * v26 * math.min(v19, 1.6)
	local v31 = math.min(v19, 1.5) * v27
	for v32 = 1, v22 do
		local v33 = v28 + v29 * (v32 - 1) + v_u_6:NextNumber(-v29 * 0.25, v29 * 0.25)
		local v34 = math.cos(v33)
		local v35 = math.sin(v33)
		local v36 = Vector3.new(v34, 0, v35)
		local v_u_37 = Instance.new("Part")
		v_u_37.Name = "EggChunk"
		v_u_37.Size = Vector3.new(1, 1, 1) * (v30 * v_u_20.SpawnScale)
		v_u_37.Color = p17.Color
		v_u_37.Material = Enum.Material.Plastic
		v_u_37.MaterialVariant = v_u_20.MaterialVariant
		v_u_37.CollisionGroup = "EggDebris"
		v_u_37.CanCollide = true
		v_u_37.CanTouch = false
		v_u_37.CanQuery = false
		local v38 = p17.Position
		local v39 = p17.Size.Y * v_u_6:NextNumber(0.3, 0.42)
		local v40 = v38 + Vector3.new(0, v39, 0) + v36 * (v25 * v_u_6:NextNumber(0.05, 0.25))
		v_u_37.CFrame = CFrame.new(v40) * CFrame.Angles(v_u_6:NextNumber(0, 3.141592653589793), v_u_6:NextNumber(0, 3.141592653589793), v_u_6:NextNumber(0, 3.141592653589793))
		if not (v_u_7 and v_u_7.Parent) then
			v_u_7 = Instance.new("Folder")
			v_u_7.Name = "EggDebrisParts"
			v_u_7.Parent = v_u_3
		end
		v_u_37.Parent = v_u_7
		v_u_2:Create(v_u_37, TweenInfo.new(v_u_20.GrowTime, Enum.EasingStyle.Back, Enum.EasingDirection.Out), {
			["Size"] = Vector3.new(1, 1, 1) * v30
		}):Play()
		local v41 = v_u_6:NextNumber(v_u_20.SideSpeed[1], v_u_20.SideSpeed[2]) * v31
		local v42 = v_u_6:NextNumber(v_u_20.UpSpeed[1], v_u_20.UpSpeed[2]) * v31
		v_u_37.AssemblyLinearVelocity = v36 * v41 + Vector3.new(0, v42, 0)
		local v43 = v_u_6:NextNumber(-8, 8)
		local v44 = v_u_6:NextNumber(-8, 8)
		local v45 = v_u_6
		v_u_37.AssemblyAngularVelocity = Vector3.new(v43, v44, v45:NextNumber(-8, 8))
		task.spawn(function()
			-- upvalues: (copy) v_u_20, (copy) v_u_37, (ref) v_u_6, (ref) v_u_16
			task.wait(v_u_20.MinLifetime)
			local v46 = os.clock()
			while v_u_37.Parent and (os.clock() - v46 < v_u_20.SettleTimeout and v_u_37.AssemblyLinearVelocity.Magnitude >= 1) do
				task.wait(0.05)
			end
			if v_u_37.Parent then
				task.wait(v_u_6:NextNumber(v_u_20.RestTime[1], v_u_20.RestTime[2]))
				if v_u_37.Parent then
					v_u_16(v_u_37)
				end
			end
		end)
	end
end
return v5
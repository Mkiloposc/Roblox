local v1 = require(script.Parent.Parent.Parent.roblox_packages.vide)
local v_u_2 = v1.create
local v_u_3 = v1.read
return function(p_u_4)
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	return v_u_2("Frame")({
		["Size"] = function() -- name: Size
			-- upvalues: (ref) v_u_3, (copy) p_u_4
			return UDim2.fromOffset(v_u_3(p_u_4.w) or 0, v_u_3(p_u_4.h) or 0)
		end,
		["Position"] = function() -- name: Position
			-- upvalues: (ref) v_u_3, (copy) p_u_4
			return UDim2.new(v_u_3(p_u_4.xs) or 0, v_u_3(p_u_4.x) or 0, v_u_3(p_u_4.ys) or 0, v_u_3(p_u_4.y) or 0)
		end,
		["AnchorPoint"] = p_u_4.anchor and function()
			-- upvalues: (ref) v_u_3, (copy) p_u_4
			return Vector2.new(v_u_3(p_u_4.anchor)[1] or 0, v_u_3(p_u_4.anchor)[2] or 0)
		end or nil,
		["AutomaticSize"] = p_u_4.auto,
		["LayoutOrder"] = p_u_4.layout,
		["ZIndex"] = p_u_4.zindex,
		["BackgroundTransparency"] = 1,
		unpack(p_u_4)
	})
end
local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("ContextActionService")
local v_u_3 = game:GetService("GuiService")
local v4 = game:GetService("Players")
local v_u_5 = game:GetService("ReplicatedStorage")
local v_u_6 = game:GetService("StarterGui")
local v_u_7 = game:GetService("TextChatService")
local v_u_8 = game:GetService("UserInputService")
local v_u_9 = require(v_u_5.Shared.BackpackUiConfig)
local v_u_10 = require(v_u_5.Shared.FloatingIconConfig)
local v_u_11 = require(v_u_5.Shared.GamepadConfig)
local v_u_12 = require(v_u_5.Shared.IndexConfig)
local v_u_13 = require(v_u_5.Shared.PickaxeConfig)
local v_u_14 = require(v_u_5.Shared.RideConfig)
local v_u_15 = require(v_u_5.Shared.RideEggConfig)
local v_u_16 = require(script.Parent.Parent.Modules.BackpackAnimalInfo)
local v_u_17 = require(script.Parent.Parent.Modules.BackpackFeedback)
local v_u_18 = require(script.Parent.Parent.Modules.BackpackGui)
local v_u_19 = require(script.Parent.Parent.Modules.BackpackHover)
local v_u_20 = require(script.Parent.Parent.Modules.BackpackRideables)
local v_u_21 = require(script.Parent.Parent.Modules.BackpackSlotVisuals)
local v_u_22 = require(script.Parent.Parent.Modules.FloatingIconFX)
local v_u_23 = {}
local v_u_24 = Enum.ContextActionPriority.High.Value + 10
local v_u_25 = {
	[Enum.UserInputType.MouseButton1] = true,
	[Enum.UserInputType.MouseButton2] = true,
	[Enum.UserInputType.MouseButton3] = true,
	[Enum.UserInputType.MouseMovement] = true,
	[Enum.UserInputType.MouseWheel] = true
}
local v_u_26 = v4.LocalPlayer
local v_u_27 = nil
local v_u_28 = nil
local v_u_29 = nil
local v_u_30 = nil
local v_u_31 = nil
local v_u_32 = nil
local v_u_33 = nil
local v_u_34 = nil
local v_u_35 = nil
local v_u_36 = nil
local v_u_37 = {}
local v_u_38 = v_u_9.HotbarSlotsFull
local v_u_39 = {}
local v_u_40 = {}
local v_u_41 = {}
local v_u_42 = 0
local v_u_43 = {}
local v_u_44 = false
local v_u_45 = false
local v_u_46 = v_u_9.DefaultCategory
local v_u_47 = {}
local v_u_48 = true
local v_u_49 = nil
local v_u_50 = nil
local v_u_51 = nil
local v_u_52 = {}
local v_u_53 = {}
local v_u_54 = 0
local v_u_55 = nil
local v_u_56 = 0
local v_u_57 = nil
local v_u_58 = nil
local v_u_59 = nil
local v_u_60 = nil
local v_u_61 = {}
local v_u_62 = {}
local v_u_63 = false
local v_u_64 = nil
local v_u_65 = 0
local function v_u_70(p_u_66) -- name: equip
	-- upvalues: (ref) v_u_50, (ref) v_u_65, (ref) v_u_49, (copy) v_u_9, (ref) v_u_51
	local v_u_67 = v_u_50
	if v_u_67 and v_u_67.Health > 0 then
		v_u_65 = v_u_65 + 1
		local v_u_68 = v_u_65
		local v69 = v_u_49
		if v69 then
			v69 = v_u_49:FindFirstChildOfClass("Tool")
		end
		if v69 and v69 ~= p_u_66 then
			v_u_67:UnequipTools()
		end
		v_u_67:EquipTool(p_u_66)
		task.spawn(function()
			-- upvalues: (ref) v_u_9, (copy) v_u_68, (ref) v_u_65, (ref) v_u_50, (copy) v_u_67, (copy) p_u_66, (ref) v_u_51
			for _ = 1, v_u_9.EquipRetryCount do
				task.wait(v_u_9.EquipRetryDelay)
				if v_u_68 ~= v_u_65 or (v_u_50 ~= v_u_67 or v_u_67.Health <= 0) then
					return
				end
				if p_u_66.Parent ~= v_u_51 or v_u_51 == nil then
					return
				end
				v_u_67:EquipTool(p_u_66)
			end
		end)
	end
end
local function v_u_74(p71) -- name: categoryOf
	-- upvalues: (copy) v_u_9, (copy) v_u_1
	for v72, v73 in v_u_9.Categories do
		if not (v73.MatchTag and v_u_1:HasTag(p71, v73.MatchTag)) then
			continue
		end
		return v72
	end
	return v_u_9.DefaultCategory
end
local function v_u_76(p75) -- name: toVector2
	return Vector2.new(p75.X, p75.Y)
end
local function v_u_81(p77, ...) -- name: iconCall
	-- upvalues: (ref) v_u_58
	if v_u_58 then
		local v78 = v_u_58[p77]
		if type(v78) == "function" then
			local v79 = v_u_58[p77]
			local v80 = v_u_58
			pcall(v79, v80, ...)
		end
	end
end
local function v_u_90() -- name: refreshLabels
	-- upvalues: (copy) v_u_9, (ref) v_u_46, (ref) v_u_35, (ref) v_u_36, (copy) v_u_20, (copy) v_u_41, (copy) v_u_1, (copy) v_u_37
	local v82 = v_u_9.Categories[v_u_46]
	if v82 then
		if v_u_35 then
			v_u_35.Text = v82.Title
		end
		if v_u_36 then
			v_u_36.Visible = not v82.HideCount
			local v83 = 0
			if v82.Rideables then
				v83 = v_u_20.Count()
			else
				for v84 in v_u_41 do
					if not v_u_1:HasTag(v84, v82.CountTag) then
						continue
					end
					v83 = v83 + 1
				end
			end
			local v85 = v_u_36
			local v86
			if v82.Capacity then
				v86 = ("%*: %*/%*"):format(v82.CountLabel, v83, v82.Capacity)
			else
				v86 = ("%*: %*"):format(v82.CountLabel, v83)
			end
			v85.Text = v86
		end
		for v87, v88 in v_u_37 do
			local v89 = v88:FindFirstChild(v_u_9.SelectedStrokeName)
			if not (v89 and v89:IsA("UIStroke")) then
				continue
			end
			v89.Enabled = v87 == v_u_46
		end
	end
end
local function v_u_92() -- name: notifyChanged
	-- upvalues: (ref) v_u_63, (copy) v_u_90, (copy) v_u_62
	if not v_u_63 then
		v_u_63 = true
		task.defer(function()
			-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
			v_u_63 = false
			v_u_90()
			for _, v91 in v_u_62 do
				task.spawn(v91)
			end
		end)
	end
end
local function v_u_99(p93) -- name: setLockedTints
	-- upvalues: (copy) v_u_39, (copy) v_u_17, (copy) v_u_21
	for _, v94 in v_u_39 do
		local v95 = v_u_17.SetLockedTint
		local v96 = v94.Button
		local v97
		if p93 then
			local v98 = v94.Tool
			if v98 == nil then
				v97 = false
			else
				v97 = v_u_21.IsLocked(v98)
			end
		else
			v97 = p93
		end
		v95(v96, v97)
	end
end
local function v_u_119(p_u_100, p_u_101) -- name: fill
	-- upvalues: (copy) v_u_41, (copy) v_u_21, (copy) v_u_16, (ref) v_u_63, (copy) v_u_90, (copy) v_u_62, (ref) v_u_64, (ref) v_u_49, (copy) v_u_1, (copy) v_u_15, (copy) v_u_26, (copy) v_u_14, (ref) v_u_60
	for _, v102 in p_u_100.ToolConns do
		v102:Disconnect()
	end
	table.clear(p_u_100.ToolConns)
	p_u_100.Tool = p_u_101
	v_u_41[p_u_101] = p_u_100
	v_u_21.Render(p_u_100.Parts, p_u_101)
	local function v104() -- name: rerender
		-- upvalues: (copy) p_u_100, (copy) p_u_101, (ref) v_u_21, (ref) v_u_16, (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
		if p_u_100.Tool == p_u_101 then
			v_u_21.Render(p_u_100.Parts, p_u_101)
			v_u_16.Refresh(p_u_101)
			if v_u_63 then
				return
			end
			v_u_63 = true
			task.defer(function()
				-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
				v_u_63 = false
				v_u_90()
				for _, v103 in v_u_62 do
					task.spawn(v103)
				end
			end)
		end
	end
	local v105 = p_u_100.ToolConns
	local v106 = p_u_101.Changed
	local function v109(p107)
		-- upvalues: (copy) p_u_100, (copy) p_u_101, (ref) v_u_21, (ref) v_u_16, (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
		if (p107 == "Name" or (p107 == "TextureId" or p107 == "ToolTip")) and p_u_100.Tool == p_u_101 then
			v_u_21.Render(p_u_100.Parts, p_u_101)
			v_u_16.Refresh(p_u_101)
			if v_u_63 then
				return
			end
			v_u_63 = true
			task.defer(function()
				-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
				v_u_63 = false
				v_u_90()
				for _, v108 in v_u_62 do
					task.spawn(v108)
				end
			end)
		end
	end
	table.insert(v105, v106:Connect(v109))
	local v110 = p_u_100.ToolConns
	local v111 = p_u_101.AttributeChanged
	table.insert(v110, v111:Connect(v104))
	if not p_u_100.IsHotbar then
		local v112 = p_u_100.ToolConns
		local v113 = p_u_101.AttributeChanged
		local v114 = v_u_64
		table.insert(v112, v113:Connect(v114))
	end
	local v115 = p_u_100.Tool
	local v116 = v_u_21.SetEquipped
	local v117 = p_u_100.Parts
	local v118
	if v115 == nil or v_u_49 == nil then
		v118 = false
	else
		v118 = v115.Parent == v_u_49
	end
	if not v118 then
		if v115 == nil then
			v118 = false
		else
			v118 = v_u_1:HasTag(v115, v_u_15.Held.ToolTag)
		end
		if v118 then
			v118 = v_u_26:GetAttribute(v_u_14.MountedAttribute) == true
		end
	end
	v116(v117, v118)
	if v_u_60 then
		v_u_60(p_u_100.Tool, p_u_100.Parts)
	end
end
local function v_u_128(p120) -- name: clear
	-- upvalues: (copy) v_u_41, (copy) v_u_16, (copy) v_u_21, (ref) v_u_49, (copy) v_u_1, (copy) v_u_15, (copy) v_u_26, (copy) v_u_14, (ref) v_u_55, (copy) v_u_39, (copy) v_u_17, (ref) v_u_60
	local v121 = p120.Tool
	if v121 then
		for _, v122 in p120.ToolConns do
			v122:Disconnect()
		end
		table.clear(p120.ToolConns)
		if v_u_41[v121] == p120 then
			v_u_41[v121] = nil
		end
		p120.Tool = nil
		v_u_16.Hide(v121)
		v_u_21.Render(p120.Parts, nil)
		local v123 = p120.Tool
		local v124 = v_u_21.SetEquipped
		local v125 = p120.Parts
		local v126
		if v123 == nil or v_u_49 == nil then
			v126 = false
		else
			v126 = v123.Parent == v_u_49
		end
		if not v126 then
			if v123 == nil then
				v126 = false
			else
				v126 = v_u_1:HasTag(v123, v_u_15.Held.ToolTag)
			end
			if v126 then
				v126 = v_u_26:GetAttribute(v_u_14.MountedAttribute) == true
			end
		end
		v124(v125, v126)
		if v_u_55 == p120 then
			if v_u_55 then
				v_u_21.SetSwapMark(v_u_55.Parts, false)
			end
			v_u_55 = nil
			for _, v127 in v_u_39 do
				v_u_17.SetLockedTint(v127.Button, false)
			end
		end
		if v_u_60 then
			v_u_60(p120.Tool, p120.Parts)
		end
	end
end
local function v_u_132() -- name: refreshHotbar
	-- upvalues: (copy) v_u_39, (ref) v_u_45, (ref) v_u_48
	for _, v129 in v_u_39 do
		v129.Frame.Visible = v129.Tool ~= nil and true or v_u_45
		if not v129.Parts.Number then
			continue
		end
		local v130 = v129.Parts.Number
		local v131 = v_u_48
		if v131 then
			v131 = v129.Parts.Number.Text ~= ""
		end
		v130.Visible = v131
	end
end
local v_u_137 = {
	["Rarity"] = function(p133) -- name: Rarity
		-- upvalues: (copy) v_u_21, (copy) v_u_12
		local v134 = v_u_21.RarityOf(p133)
		return not (v134 and table.find(v_u_12.RarityOrder, v134)) and 0 or v_u_12.RarityIndex(v134)
	end,
	["Kg"] = function(p135) -- name: Kg
		local v136 = p135:GetAttribute("WeightKg")
		return (typeof(v136) ~= "number" or v136 ~= v136) and 0 or v136
	end
}
local v_u_138 = {
	["WeightKg"] = true,
	["Rarity"] = true,
	["AnimalName"] = true
}
local function v_u_159() -- name: refreshInventory
	-- upvalues: (copy) v_u_9, (ref) v_u_46, (copy) v_u_40, (copy) v_u_74, (copy) v_u_47, (copy) v_u_21, (copy) v_u_137, (copy) v_u_20
	local v139 = (v_u_9.Categories[v_u_46] or {}).SortBy or {}
	local v140 = {}
	for _, v141 in v_u_40 do
		local v142 = v141.Tool
		local v143
		if v142 == nil then
			v143 = false
		else
			v143 = v_u_74(v142) == v_u_46
		end
		local v144
		if v143 and (v142 and #v_u_47 > 0) then
			v144 = v_u_21.SearchHits(v142, v_u_47)
			if v144 > 0 then
				v143 = true
			else
				v143 = false
			end
		else
			v144 = 0
		end
		v141.Frame.Visible = v143
		if not (v143 and v142) then
			continue
		end
		local v145 = table.create(#v139)
		for v146, v147 in v139 do
			local v148 = v_u_137[v147]
			v145[v146] = not v148 and 0 or v148(v142)
		end
		table.insert(v140, { v141, v144, v145 })
	end
	table.sort(v140, function(p149, p150)
		if p149[2] ~= p150[2] then
			return p149[2] > p150[2]
		end
		local v151 = p149[3]
		local v152 = p150[3]
		for v153 = 1, #v151 do
			if v151[v153] == v152[v153] then
				continue
			end
			return v151[v153] > v152[v153]
		end
		return p149[1].Index < p150[1].Index
	end)
	for v154, v155 in v140 do
		v155[1].Frame.LayoutOrder = v154
	end
	local v156 = v_u_9.Categories[v_u_46]
	local v157 = v_u_20.SetShown
	local v158
	if v156 == nil then
		v158 = false
	else
		v158 = v156.Rideables == true
	end
	v157(v158, v_u_47)
end
local v_u_160 = false
v_u_64 = function(p161)
	-- upvalues: (copy) v_u_138, (ref) v_u_160, (copy) v_u_159
	if v_u_138[p161] and not v_u_160 then
		v_u_160 = true
		task.defer(function()
			-- upvalues: (ref) v_u_160, (ref) v_u_159
			v_u_160 = false
			v_u_159()
		end)
	end
end
local v_u_162 = false
local v_u_163 = nil
local v_u_164 = nil
local v_u_165 = {}
local function v_u_170(p166) -- name: pcSlotStroke
	-- upvalues: (copy) v_u_165, (copy) v_u_6, (copy) v_u_9
	local v167 = v_u_165[p166]
	if v167 ~= nil then
		return v167 or nil
	end
	local v168 = v_u_6:FindFirstChild(v_u_9.GuiName)
	local v169
	if v168 then
		if p166 then
			v169 = v168:FindFirstChild(v_u_9.HotbarName, true)
			if v169 then
				v169 = v169:FindFirstChild(v_u_9.TemplateName)
			end
			if v169 then
				v169 = v169:FindFirstChild(v_u_9.SelectedStrokeName)
			end
		else
			v169 = v168:FindFirstChild(v_u_9.InventoryName, true)
			if v169 then
				v169 = v169:FindFirstChild("ScrollingFrame")
			end
			if v169 then
				v169 = v169:FindFirstChild(v_u_9.TemplateName)
			end
			if v169 then
				v169 = v169:FindFirstChild("Container")
			end
			if v169 then
				v169 = v169:FindFirstChild(v_u_9.SelectedStrokeName)
			end
		end
	else
		v169 = nil
	end
	if not (v169 and v169:IsA("UIStroke")) then
		v169 = nil
	end
	v_u_165[p166] = v169 or false
	return v169
end
local function v_u_181(p171, p172, p173, p174) -- name: newSlot
	-- upvalues: (copy) v_u_21, (ref) v_u_32, (ref) v_u_33, (copy) v_u_170, (copy) v_u_9, (copy) v_u_19, (ref) v_u_45, (copy) v_u_16, (ref) v_u_163, (ref) v_u_164
	local v175 = v_u_21.Collect(p173, p174)
	if v_u_32 then
		v_u_21.AdoptSellOverlay(v175, v_u_32)
	end
	v_u_21.AdoptStrokes(v175, v_u_33, (v_u_170(p171)))
	v_u_21.SetSellSelected(v175, false)
	v_u_21.Render(v175, nil)
	v_u_21.AttachImageFX(v175)
	local v176 = p174:FindFirstChild("InfoList")
	if v176 and v176:IsA("GuiObject") then
		local v177
		if p171 then
			v177 = v_u_9.HotbarShowInfo
		else
			v177 = v_u_9.InventoryShowInfo
		end
		v176.Visible = v177
	end
	local v_u_178 = {
		["IsHotbar"] = nil,
		["Index"] = nil,
		["Tool"] = nil,
		["Frame"] = nil,
		["Button"] = nil,
		["Parts"] = nil,
		["ToolConns"] = nil,
		["IsHotbar"] = p171,
		["Index"] = p172,
		["Frame"] = p173,
		["Button"] = p174,
		["Parts"] = v175,
		["ToolConns"] = {}
	}
	v_u_19.Attach(p174)
	if not p171 then
		p174.MouseEnter:Connect(function()
			-- upvalues: (ref) v_u_45, (ref) v_u_16, (copy) v_u_178
			if v_u_45 then
				v_u_16.Show(v_u_178.Tool)
			end
		end)
		p174.MouseLeave:Connect(function()
			-- upvalues: (ref) v_u_16, (copy) v_u_178
			v_u_16.Hide(v_u_178.Tool)
		end)
	end
	p174.InputBegan:Connect(function(p179)
		-- upvalues: (ref) v_u_163, (copy) v_u_178
		v_u_163(v_u_178, p179)
	end)
	p174.Activated:Connect(function(p180)
		-- upvalues: (ref) v_u_164, (copy) v_u_178
		v_u_164(v_u_178, p180)
	end)
	return v_u_178
end
local function v_u_186(p182) -- name: makeHotbarSlot
	-- upvalues: (ref) v_u_31, (copy) v_u_181, (ref) v_u_28
	local v183 = v_u_31:Clone()
	v183.Name = tostring(p182)
	v183.LayoutOrder = p182
	v183.Visible = false
	local v184 = v_u_181(true, p182, v183, v183)
	local v185 = v184.Parts.Number
	if v185 then
		if p182 < 10 then
			v185.Text = tostring(p182)
		elseif p182 == 10 then
			v185.Text = "0"
		else
			v185.Text = ""
		end
	end
	v183.Parent = v_u_28
	return v184
end
local function v_u_192() -- name: makeInventorySlot
	-- upvalues: (ref) v_u_42, (ref) v_u_32, (copy) v_u_181, (ref) v_u_30, (copy) v_u_40
	v_u_42 = v_u_42 + 1
	local v187 = v_u_32:Clone()
	v187.Name = "Slot"
	v187.LayoutOrder = v_u_42
	v187.Visible = false
	local v188 = v187:FindFirstChild("Container")
	local v189
	if v188 then
		v189 = v188:IsA("GuiButton")
	else
		v189 = v188
	end
	assert(v189, "[BackpackController] Inventory Template.Container must be a button")
	local v190 = v_u_181(false, v_u_42, v187, v188)
	v187.Parent = v_u_30
	local v191 = v_u_40
	table.insert(v191, v190)
	return v190
end
local function v_u_196(p193) -- name: deleteInventorySlot
	-- upvalues: (copy) v_u_128, (copy) v_u_40, (ref) v_u_55, (copy) v_u_21, (copy) v_u_39, (copy) v_u_17
	v_u_128(p193)
	local v194 = table.find(v_u_40, p193)
	if v194 then
		table.remove(v_u_40, v194)
	end
	if v_u_55 == p193 then
		if v_u_55 then
			v_u_21.SetSwapMark(v_u_55.Parts, false)
		end
		v_u_55 = nil
		for _, v195 in v_u_39 do
			v_u_17.SetLockedTint(v195.Button, false)
		end
	end
	p193.Frame:Destroy()
end
local function v_u_202(p197) -- name: selectSlot
	-- upvalues: (copy) v_u_1, (copy) v_u_15, (copy) v_u_26, (copy) v_u_14, (copy) v_u_5, (ref) v_u_49, (ref) v_u_65, (ref) v_u_50, (ref) v_u_51, (copy) v_u_70
	local v198 = p197.Tool
	if v198 then
		local v199
		if v198 == nil then
			v199 = false
		else
			v199 = v_u_1:HasTag(v198, v_u_15.Held.ToolTag)
		end
		if v199 and v_u_26:GetAttribute(v_u_14.MountedAttribute) == true then
			local v200 = v_u_5:FindFirstChild(v_u_14.RemoteName)
			if v200 and v200:IsA("RemoteEvent") then
				v200:FireServer("Dismount")
			end
		else
			local v201
			if v198 == nil or v_u_49 == nil then
				v201 = false
			else
				v201 = v198.Parent == v_u_49
			end
			if v201 then
				v_u_65 = v_u_65 + 1
				if v_u_50 then
					v_u_50:UnequipTools()
					return
				end
			elseif v_u_51 and v198.Parent == v_u_51 then
				v_u_70(v198)
			end
		end
	else
		return
	end
end
local function v_u_208(p203) -- name: moveToInventory
	-- upvalues: (copy) v_u_21, (copy) v_u_128, (copy) v_u_192, (copy) v_u_119, (ref) v_u_49, (ref) v_u_65, (ref) v_u_50, (copy) v_u_132, (copy) v_u_159, (ref) v_u_63, (copy) v_u_90, (copy) v_u_62
	local v204 = p203.Tool
	if p203.IsHotbar and v204 then
		local v205
		if v204 == nil then
			v205 = false
		else
			v205 = v_u_21.IsLocked(v204)
		end
		if not v205 then
			v_u_128(p203)
			v_u_119(v_u_192(), v204)
			local v206
			if v204 == nil or v_u_49 == nil then
				v206 = false
			else
				v206 = v204.Parent == v_u_49
			end
			if v206 then
				v_u_65 = v_u_65 + 1
				if v_u_50 then
					v_u_50:UnequipTools()
				end
			end
			v_u_132()
			v_u_159()
			if not v_u_63 then
				v_u_63 = true
				task.defer(function()
					-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
					v_u_63 = false
					v_u_90()
					for _, v207 in v_u_62 do
						task.spawn(v207)
					end
				end)
			end
		end
	end
end
local function v_u_219(p209, p210) -- name: swap
	-- upvalues: (copy) v_u_21, (copy) v_u_128, (copy) v_u_119, (copy) v_u_196, (ref) v_u_49, (ref) v_u_65, (ref) v_u_50, (copy) v_u_132, (copy) v_u_159, (ref) v_u_63, (copy) v_u_90, (copy) v_u_62
	if p209 ~= p210 then
		local v211 = p209.Tool
		local v212 = p210.Tool
		local v213
		if v211 == nil then
			v213 = false
		else
			v213 = v_u_21.IsLocked(v211)
		end
		if not v213 then
			local v214
			if v212 == nil then
				v214 = false
			else
				v214 = v_u_21.IsLocked(v212)
			end
			if not v214 then
				v_u_128(p209)
				v_u_128(p210)
				if v212 then
					v_u_119(p209, v212)
				end
				if v211 then
					v_u_119(p210, v211)
				end
				for _, v215 in { p209, p210 } do
					if v215.IsHotbar then
						continue
					end
					if v215.Tool then
						local v216 = v215.Tool
						local v217
						if v216 == nil or v_u_49 == nil then
							v217 = false
						else
							v217 = v216.Parent == v_u_49
						end
						if not v217 then
							continue
						end
						v_u_65 = v_u_65 + 1
						if not v_u_50 then
							continue
						end
						v_u_50:UnequipTools()
					else
						v_u_196(v215)
					end
				end
				v_u_132()
				v_u_159()
				if not v_u_63 then
					v_u_63 = true
					task.defer(function()
						-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
						v_u_63 = false
						v_u_90()
						for _, v218 in v_u_62 do
							task.spawn(v218)
						end
					end)
				end
			end
		end
	end
end
local v_u_220 = nil
local function v_u_248(p221) -- name: onToolAdded
	-- upvalues: (ref) v_u_49, (ref) v_u_50, (copy) v_u_41, (copy) v_u_21, (copy) v_u_1, (copy) v_u_15, (copy) v_u_26, (copy) v_u_14, (ref) v_u_63, (copy) v_u_90, (copy) v_u_62, (copy) v_u_9, (copy) v_u_39, (copy) v_u_128, (copy) v_u_119, (copy) v_u_192, (ref) v_u_220, (ref) v_u_162, (copy) v_u_132, (copy) v_u_159
	if p221:IsA("Tool") then
		local v222 = v_u_41[p221]
		if v222 then
			local v223 = v222.Tool
			local v224 = v_u_21.SetEquipped
			local v225 = v222.Parts
			local v226
			if v223 == nil or v_u_49 == nil then
				v226 = false
			else
				v226 = v223.Parent == v_u_49
			end
			if not v226 then
				if v223 == nil then
					v226 = false
				else
					v226 = v_u_1:HasTag(v223, v_u_15.Held.ToolTag)
				end
				if v226 then
					v226 = v_u_26:GetAttribute(v_u_14.MountedAttribute) == true
				end
			end
			v224(v225, v226)
			if not v_u_63 then
				v_u_63 = true
				task.defer(function()
					-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
					v_u_63 = false
					v_u_90()
					for _, v227 in v_u_62 do
						task.spawn(v227)
					end
				end)
			end
		else
			local v228 = v_u_9.RestoredGoToInventory
			if v228 then
				v228 = p221:GetAttribute(v_u_9.RestoredAttribute) == true
			end
			local v229
			if p221 == nil then
				v229 = false
			else
				v229 = v_u_21.IsLocked(p221)
			end
			if v229 then
				local v230 = nil
				for _, v231 in v_u_39 do
					local v232 = v231.Tool
					local v233
					if v232 == nil then
						v233 = false
					else
						v233 = v_u_21.IsLocked(v232)
					end
					if v233 then
						continue
					end
					v230 = v231
				end
				if v230 then
					local v234 = v230.Tool
					v_u_128(v230)
					v_u_119(v230, p221)
					if v234 then
						local v235 = v_u_119
						for _, v237 in v_u_39 do
							if v237.Tool then
								continue
							end
						end
						local v237 = nil
						v235(v237 or v_u_192(), v234)
					end
				else
					v_u_119(v_u_192(), p221)
				end
				v_u_220()
				if not v_u_162 then
					v_u_162 = true
					task.defer(function()
						-- upvalues: (ref) v_u_162, (ref) v_u_132, (ref) v_u_159, (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
						v_u_162 = false
						v_u_132()
						v_u_159()
						if not v_u_63 then
							v_u_63 = true
							task.defer(function()
								-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
								v_u_63 = false
								v_u_90()
								for _, v238 in v_u_62 do
									task.spawn(v238)
								end
							end)
						end
					end)
				end
			else
				local v240
				if v228 then
					v240 = nil
				else
					for _, v240 in v_u_39 do
						if v240.Tool then
							continue
						end
					end
					v240 = nil
				end
				if not v240 then
					local v241
					if p221 == nil then
						v241 = false
					else
						v241 = v_u_1:HasTag(p221, v_u_15.Held.ToolTag)
					end
					if v241 then
						for v242 = #v_u_39, 1, -1 do
							local v243 = v_u_39[v242]
							local v244 = v243.Tool
							if not v244 then
								continue
							end
							local v245
							if v244 == nil then
								v245 = false
							else
								v245 = v_u_21.IsLocked(v244)
							end
							if v245 then
								continue
							end
							local v246
							if v244 == nil or v_u_49 == nil then
								v246 = false
							else
								v246 = v244.Parent == v_u_49
							end
							if v246 then
								continue
							end
							v_u_128(v243)
							v_u_119(v_u_192(), v244)
							v240 = v243
						end
					end
				end
				v_u_119(v240 or v_u_192(), p221)
				if not v_u_162 then
					v_u_162 = true
					task.defer(function()
						-- upvalues: (ref) v_u_162, (ref) v_u_132, (ref) v_u_159, (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
						v_u_162 = false
						v_u_132()
						v_u_159()
						if not v_u_63 then
							v_u_63 = true
							task.defer(function()
								-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
								v_u_63 = false
								v_u_90()
								for _, v247 in v_u_62 do
									task.spawn(v247)
								end
							end)
						end
					end)
				end
			end
		end
	else
		if p221:IsA("Humanoid") and p221.Parent == v_u_49 then
			v_u_50 = p221
		end
		return
	end
end
v_u_220 = function() -- name: orderLocked
	-- upvalues: (copy) v_u_39, (copy) v_u_21, (copy) v_u_13, (copy) v_u_41, (copy) v_u_128, (copy) v_u_119
	local v249 = {}
	for _, v250 in v_u_39 do
		local v251 = v250.Tool
		if not v251 then
			continue
		end
		local v252
		if v251 == nil then
			v252 = false
		else
			v252 = v_u_21.IsLocked(v251)
		end
		if not v252 then
			continue
		end
		table.insert(v249, v251)
	end
	table.sort(v249, function(p253, p254)
		-- upvalues: (ref) v_u_13
		return (p253.Name == v_u_13.ToolName and 1 or 2) < (p254.Name == v_u_13.ToolName and 1 or 2)
	end)
	for v255, v256 in v249 do
		local v257 = v_u_39[v255]
		local v258 = v_u_41[v256]
		if not v257 or (not v258 or v258 == v257) then
			continue
		end
		local v259 = v257.Tool
		v_u_128(v258)
		v_u_128(v257)
		v_u_119(v257, v256)
		if not v259 then
			continue
		end
		v_u_119(v258, v259)
	end
end
local function v_u_269() -- name: compactLocked
	-- upvalues: (copy) v_u_39, (copy) v_u_21, (copy) v_u_128, (copy) v_u_119
	for v260, v261 in v_u_39 do
		local v262 = v261.Tool
		local v263
		if v262 == nil then
			v263 = false
		else
			v263 = v_u_21.IsLocked(v262)
		end
		if v263 then
			continue
		end
		for v264 = v260 + 1, #v_u_39 do
			local v265 = v_u_39[v264]
			local v266 = v265.Tool
			if not v266 then
				continue
			end
			local v267
			if v266 == nil then
				v267 = false
			else
				v267 = v_u_21.IsLocked(v266)
			end
			if not v267 then
				continue
			end
			local v268 = v261.Tool
			v_u_128(v265)
			if v268 then
				v_u_128(v261)
			end
			v_u_119(v261, v266)
			if not v268 then
				break
			end
			v_u_119(v265, v268)
		end
	end
end
local function v_u_275(p270) -- name: onToolRemoved
	-- upvalues: (ref) v_u_49, (ref) v_u_51, (copy) v_u_41, (copy) v_u_128, (copy) v_u_21, (copy) v_u_269, (ref) v_u_220, (copy) v_u_196, (ref) v_u_162, (copy) v_u_132, (copy) v_u_159, (ref) v_u_63, (copy) v_u_90, (copy) v_u_62
	if p270:IsA("Tool") then
		local v271 = p270.Parent
		if v271 == nil or v271 ~= v_u_49 and v271 ~= v_u_51 then
			local v272 = v_u_41[p270]
			if v272 then
				if v272.IsHotbar then
					v_u_128(v272)
					local v273
					if p270 == nil then
						v273 = false
					else
						v273 = v_u_21.IsLocked(p270)
					end
					if v273 then
						v_u_269()
						v_u_220()
					end
				else
					v_u_196(v272)
				end
				if not v_u_162 then
					v_u_162 = true
					task.defer(function()
						-- upvalues: (ref) v_u_162, (ref) v_u_132, (ref) v_u_159, (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
						v_u_162 = false
						v_u_132()
						v_u_159()
						if not v_u_63 then
							v_u_63 = true
							task.defer(function()
								-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
								v_u_63 = false
								v_u_90()
								for _, v274 in v_u_62 do
									task.spawn(v274)
								end
							end)
						end
					end)
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_281() -- name: pruneLostTools
	-- upvalues: (copy) v_u_41, (ref) v_u_49, (ref) v_u_51, (copy) v_u_128, (copy) v_u_196, (ref) v_u_162, (copy) v_u_132, (copy) v_u_159, (ref) v_u_63, (copy) v_u_90, (copy) v_u_62
	local v276 = false
	for v277, v278 in v_u_41 do
		local v279 = v277.Parent
		if v279 ~= nil and (v279 == v_u_49 or v279 == v_u_51) then
			continue
		end
		v276 = true
		if v278.IsHotbar then
			v_u_128(v278)
		else
			v_u_196(v278)
		end
	end
	if v276 then
		if v_u_162 then
			return
		end
		v_u_162 = true
		task.defer(function()
			-- upvalues: (ref) v_u_162, (ref) v_u_132, (ref) v_u_159, (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
			v_u_162 = false
			v_u_132()
			v_u_159()
			if not v_u_63 then
				v_u_63 = true
				task.defer(function()
					-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
					v_u_63 = false
					v_u_90()
					for _, v280 in v_u_62 do
						task.spawn(v280)
					end
				end)
			end
		end)
	end
end
local function v_u_291(p282) -- name: hookBackpack
	-- upvalues: (ref) v_u_51, (copy) v_u_53, (copy) v_u_248, (copy) v_u_275, (copy) v_u_281
	if v_u_51 ~= p282 then
		for _, v283 in v_u_53 do
			v283:Disconnect()
		end
		table.clear(v_u_53)
		v_u_51 = p282
		local v284 = v_u_53
		local v285 = p282.ChildAdded
		local v286 = v_u_248
		table.insert(v284, v285:Connect(v286))
		local v287 = v_u_53
		local v288 = p282.ChildRemoved
		local v289 = v_u_275
		table.insert(v287, v288:Connect(v289))
		v_u_281()
		for _, v290 in p282:GetChildren() do
			v_u_248(v290)
		end
	end
end
local function v_u_306(p292) -- name: hookCharacter
	-- upvalues: (ref) v_u_54, (copy) v_u_39, (copy) v_u_128, (copy) v_u_40, (copy) v_u_196, (copy) v_u_52, (ref) v_u_49, (ref) v_u_50, (copy) v_u_248, (copy) v_u_275, (ref) v_u_51, (copy) v_u_26, (copy) v_u_291, (copy) v_u_132, (copy) v_u_159, (ref) v_u_63, (copy) v_u_90, (copy) v_u_62
	v_u_54 = v_u_54 + 1
	local v293 = v_u_54
	for _, v294 in v_u_39 do
		v_u_128(v294)
	end
	for v295 = #v_u_40, 1, -1 do
		v_u_196(v_u_40[v295])
	end
	for _, v296 in v_u_52 do
		v296:Disconnect()
	end
	table.clear(v_u_52)
	v_u_49 = p292
	v_u_50 = p292:FindFirstChildOfClass("Humanoid")
	local v297 = v_u_52
	local v298 = p292.ChildAdded
	local v299 = v_u_248
	table.insert(v297, v298:Connect(v299))
	local v300 = v_u_52
	local v301 = p292.ChildRemoved
	local v302 = v_u_275
	table.insert(v300, v301:Connect(v302))
	for _, v303 in p292:GetChildren() do
		v_u_248(v303)
	end
	v_u_51 = nil
	local v304 = v_u_26:FindFirstChildOfClass("Backpack") or v_u_26:WaitForChild("Backpack")
	if v293 == v_u_54 then
		if v304 and v304:IsA("Backpack") then
			v_u_291(v304)
		end
		v_u_132()
		v_u_159()
		if not v_u_63 then
			v_u_63 = true
			task.defer(function()
				-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
				v_u_63 = false
				v_u_90()
				for _, v305 in v_u_62 do
					task.spawn(v305)
				end
			end)
		end
	else
		return
	end
end
local v_u_307 = Vector2.zero
local function v_u_318(p308, p309) -- name: beginDrag
	-- upvalues: (ref) v_u_55, (copy) v_u_21, (copy) v_u_39, (copy) v_u_17, (copy) v_u_19, (ref) v_u_27, (ref) v_u_307, (ref) v_u_30, (copy) v_u_81
	p308.dragging = true
	if v_u_55 then
		v_u_21.SetSwapMark(v_u_55.Parts, false)
	end
	v_u_55 = nil
	for _, v310 in v_u_39 do
		v_u_17.SetLockedTint(v310.Button, false)
	end
	local v311 = p308.slot.Button
	local v312 = v311:Clone()
	v312.Name = "DragGhost"
	v312.AnchorPoint = Vector2.new(0.5, 0.5)
	v312.Size = UDim2.fromOffset(v311.AbsoluteSize.X, v311.AbsoluteSize.Y)
	v312.ZIndex = 100
	v312.Active = false
	v312.Selectable = false
	v312.Visible = true
	v_u_19.Reset(v312)
	v_u_21.ResetCopy(p308.slot.Parts, v312)
	v312.Parent = v_u_27
	v312.Position = UDim2.fromOffset(0, 0)
	v_u_307 = v312.AbsolutePosition + v312.AbsoluteSize / 2
	v312.Position = UDim2.fromOffset(p309.X - v_u_307.X, p309.Y - v_u_307.Y)
	p308.ghost = v312
	if v_u_30 then
		v_u_30.ScrollingEnabled = false
	end
	for _, v313 in v_u_39 do
		local v314 = v_u_17.SetLockedTint
		local v315 = v313.Button
		local v316 = v313.Tool
		local v317
		if v316 == nil then
			v317 = false
		else
			v317 = v_u_21.IsLocked(v316)
		end
		v314(v315, v317)
	end
	v_u_81("lock")
end
local function v_u_326(p319) -- name: hotbarContains
	-- upvalues: (copy) v_u_39, (copy) v_u_9
	for _, v320 in v_u_39 do
		if not v320.Frame.Visible then
			continue
		end
		local v321 = v320.Frame
		local v322 = v_u_9.HotbarDropMargin or 0
		local v323 = v321.AbsolutePosition
		local v324 = v321.AbsoluteSize
		local v325
		if p319.X >= v323.X - v322 and (p319.X <= v323.X + v324.X + v322 and p319.Y >= v323.Y - v322) then
			v325 = p319.Y <= v323.Y + v324.Y + v322
		else
			v325 = false
		end
		if not v325 then
			continue
		end
		return true
	end
	return false
end
local function v_u_332(p327) -- name: closestHotbarSlot
	-- upvalues: (copy) v_u_39
	local v328 = (1 / 0)
	local v329 = nil
	for _, v330 in v_u_39 do
		if not v330.Frame.Visible then
			continue
		end
		local v331 = (v330.Frame.AbsolutePosition + v330.Frame.AbsoluteSize / 2 - p327).Magnitude
		if v331 >= v328 then
			continue
		end
		v329 = v330
		v328 = v331
	end
	return v329
end
local function v_u_342(p333, p334) -- name: drop
	-- upvalues: (ref) v_u_29, (ref) v_u_45, (copy) v_u_208, (copy) v_u_326, (copy) v_u_332, (copy) v_u_21, (copy) v_u_17, (copy) v_u_219
	if not p333.Tool or p333.Frame.Parent == nil then
		return
	end
	local v335, v336, v337
	if v_u_29 and v_u_45 then
		local v338 = v_u_29
		local v339 = v338.AbsolutePosition
		local v340 = v338.AbsoluteSize
		local v341
		if p334.X >= v339.X - 0 and (p334.X <= v339.X + v340.X + 0 and p334.Y >= v339.Y - 0) then
			v341 = p334.Y <= v339.Y + v340.Y + 0
		else
			v341 = false
		end
		if v341 then
			if p333.IsHotbar then
				v_u_208(p333)
				return
			end
		elseif v_u_326(p334) then
			v335 = v_u_332(p334)
			if v335 and v335 ~= p333 then
				v336 = v335.Tool
				if v336 == nil then
					v337 = false
				else
					v337 = v_u_21.IsLocked(v336)
				end
				if v337 then
					v_u_17.Shake(v335.Button)
				else
					v_u_219(p333, v335)
				end
			end
		elseif p333.IsHotbar then
			v_u_208(p333)
		end
	else
		if v_u_326(p334) then
			v335 = v_u_332(p334)
			if v335 and v335 ~= p333 then
				v336 = v335.Tool
				if v336 == nil then
					v337 = false
				else
					v337 = v_u_21.IsLocked(v336)
				end
				if v337 then
					v_u_17.Shake(v335.Button)
				else
					v_u_219(p333, v335)
				end
			end
		elseif p333.IsHotbar then
			v_u_208(p333)
		end
		return
	end
end
local function v_u_345() -- name: cancelPress
	-- upvalues: (ref) v_u_57, (ref) v_u_30, (copy) v_u_39, (copy) v_u_17, (copy) v_u_81
	local v343 = v_u_57
	v_u_57 = nil
	if v343 and v343.dragging then
		if v343.ghost then
			v343.ghost:Destroy()
			v343.ghost = nil
		end
		if v_u_30 then
			v_u_30.ScrollingEnabled = true
		end
		for _, v344 in v_u_39 do
			v_u_17.SetLockedTint(v344.Button, false)
		end
		v_u_81("unlock")
	end
end
local function v_u_357(p346) -- name: gamepadPick
	-- upvalues: (ref) v_u_55, (copy) v_u_21, (copy) v_u_17, (copy) v_u_99, (ref) v_u_56, (copy) v_u_39, (copy) v_u_11, (copy) v_u_8, (copy) v_u_9, (copy) v_u_219, (copy) v_u_3
	local v347 = v_u_55
	if v347 then
		if v_u_55 then
			v_u_21.SetSwapMark(v_u_55.Parts, false)
		end
		v_u_55 = nil
		for _, v348 in v_u_39 do
			v_u_17.SetLockedTint(v348.Button, false)
		end
		if v347 == p346 then
			if not p346.IsHotbar and (v_u_11.IsGamepadInput(v_u_8:GetLastInputType()) and os.clock() - v_u_56 <= v_u_9.GamepadDoubleTapTime) then
				for _, v350 in v_u_39 do
					if v350.Tool then
						continue
					end
				end
				local v350 = nil
				if not v350 or (not p346.Tool or p346.IsHotbar) then
					v_u_17.Shake(p346.Button)
					return
				end
				v_u_219(p346, v350)
				if v350.Frame.Parent ~= nil then
					v_u_3.SelectedObject = v350.Button
				end
			end
			return
		elseif v347.Frame.Parent ~= nil then
			local v351 = p346.Tool
			local v352
			if v351 == nil then
				v352 = false
			else
				v352 = v_u_21.IsLocked(v351)
			end
			if v352 then
				v_u_17.Shake(p346.Button)
			else
				v_u_219(v347, p346)
				local v353 = v_u_3.SelectedObject
				if v353 == nil or v353.Parent == nil then
					local v354
					if p346.Frame.Parent ~= nil then
						v354 = p346.Button
					elseif v347.Frame.Parent ~= nil then
						v354 = v347.Button
					else
						v354 = nil
					end
					v_u_3.SelectedObject = v354
				end
			end
		else
			return
		end
	else
		local v355 = p346.Tool
		local v356
		if v355 == nil then
			v356 = false
		else
			v356 = v_u_21.IsLocked(v355)
		end
		if v356 then
			v_u_17.Shake(p346.Button)
		elseif p346.Tool then
			if v_u_55 then
				v_u_21.SetSwapMark(v_u_55.Parts, false)
			end
			v_u_55 = p346
			if p346 then
				v_u_21.SetSwapMark(p346.Parts, true)
			end
			v_u_99(p346 ~= nil)
			v_u_56 = os.clock()
		end
	end
end
v_u_163 = function(p_u_358, p359)
	-- upvalues: (ref) v_u_57, (ref) v_u_30, (copy) v_u_9, (ref) v_u_59, (ref) v_u_27, (copy) v_u_21, (ref) v_u_45, (copy) v_u_318, (copy) v_u_76, (copy) v_u_17
	if v_u_57 or p359.UserInputState ~= Enum.UserInputState.Begin then
		return
	else
		local v360 = p359.UserInputType
		if v360 == Enum.UserInputType.MouseButton1 or v360 == Enum.UserInputType.Touch then
			local v_u_361 = {
				["slot"] = nil,
				["input"] = nil,
				["start"] = nil,
				["dragging"] = false,
				["scrolled"] = false,
				["canvasStart"] = nil,
				["denied"] = false,
				["hoverLocked"] = nil,
				["ghost"] = nil,
				["slot"] = p_u_358,
				["input"] = p359
			}
			local v362 = p359.Position
			v_u_361.start = Vector2.new(v362.X, v362.Y)
			local v363
			if v360 == Enum.UserInputType.Touch and (not p_u_358.IsHotbar and v_u_30) then
				v363 = v_u_30.CanvasPosition
			else
				v363 = nil
			end
			v_u_361.canvasStart = v363
			v_u_57 = v_u_361
			if v360 == Enum.UserInputType.Touch then
				task.delay(v_u_9.TouchHoldTime, function()
					-- upvalues: (ref) v_u_57, (copy) v_u_361, (copy) p_u_358, (ref) v_u_59, (ref) v_u_27, (ref) v_u_21, (ref) v_u_45, (ref) v_u_318, (ref) v_u_76, (ref) v_u_17
					if v_u_57 == v_u_361 and not (v_u_361.dragging or v_u_361.scrolled) then
						local v364 = p_u_358
						local v365
						if v_u_59 or not v364.Tool then
							v365 = false
						else
							local v366
							if v_u_27 == nil then
								v366 = false
							else
								v366 = v_u_27.Enabled
							end
							if v366 then
								local v367 = v364.Tool
								local v368
								if v367 == nil then
									v368 = false
								else
									v368 = v_u_21.IsLocked(v367)
								end
								if v368 then
									v365 = false
								else
									v365 = v_u_45
								end
							else
								v365 = false
							end
						end
						if v365 then
							v_u_318(v_u_361, v_u_76(v_u_361.input.Position))
							return
						end
						local v369 = v_u_361
						local v370 = v369.slot
						if not v369.denied and (v_u_45 and not v_u_59) then
							local v371 = v370.Tool
							local v372
							if v371 == nil then
								v372 = false
							else
								v372 = v_u_21.IsLocked(v371)
							end
							if not v372 then
								return
							end
							v369.denied = true
							v_u_17.Shake(v370.Button)
						end
					end
				end)
			end
		end
	end
end
v_u_164 = function(p373, p374)
	-- upvalues: (ref) v_u_27, (ref) v_u_59, (ref) v_u_45, (copy) v_u_357, (copy) v_u_202
	if p374 and (p374.UserInputType == Enum.UserInputType.MouseButton1 or p374.UserInputType == Enum.UserInputType.Touch) then
		return
	else
		local v375
		if v_u_27 == nil then
			v375 = false
		else
			v375 = v_u_27.Enabled
		end
		if v375 then
			local v376 = p373.Tool
			if v_u_59 and (v376 and v_u_59(v376)) then
				return
			elseif v_u_45 then
				v_u_357(p373)
			elseif v376 then
				v_u_202(p373)
			end
		else
			return
		end
	end
end
local function v_u_404(p377, p378) -- name: touchMoved
	-- upvalues: (ref) v_u_29, (ref) v_u_59, (ref) v_u_27, (copy) v_u_21, (ref) v_u_45, (ref) v_u_30, (copy) v_u_318, (copy) v_u_9, (copy) v_u_17
	if p377.denied then
		return
	elseif p377.scrolled then
		if v_u_29 then
			local v379 = v_u_29
			local v380 = v379.AbsolutePosition
			local v381 = v379.AbsoluteSize
			local v382
			if p378.X >= v380.X - 0 and (p378.X <= v380.X + v381.X + 0 and p378.Y >= v380.Y - 0) then
				v382 = p378.Y <= v380.Y + v381.Y + 0
			else
				v382 = false
			end
			if not v382 then
				local v383 = p377.slot
				local v384
				if v_u_59 or not v383.Tool then
					v384 = false
				else
					local v385
					if v_u_27 == nil then
						v385 = false
					else
						v385 = v_u_27.Enabled
					end
					if v385 then
						local v386 = v383.Tool
						local v387
						if v386 == nil then
							v387 = false
						else
							v387 = v_u_21.IsLocked(v386)
						end
						if v387 then
							v384 = false
						else
							v384 = v_u_45
						end
					else
						v384 = false
					end
				end
				if v384 then
					if v_u_30 and p377.canvasStart then
						v_u_30.CanvasPosition = p377.canvasStart
					end
					p377.scrolled = false
					v_u_318(p377, p378)
				end
			end
		end
		return
	else
		local v388 = p378 - p377.start
		if v388.Magnitude < v_u_9.TouchDragSlop then
			return
		else
			local v389
			if p377.slot.IsHotbar or not (v_u_30 and v_u_30.ScrollingEnabled) then
				v389 = false
			else
				local v390 = v_u_30.AbsoluteWindowSize
				local v391 = v_u_30.AbsoluteCanvasSize
				local v392 = v388.X
				local v393 = math.abs(v392)
				local v394 = v388.Y
				if math.abs(v394) < v393 then
					v389 = v391.X > v390.X + 1
				else
					v389 = v391.Y > v390.Y + 1
				end
			end
			if v389 then
				p377.scrolled = true
				return
			else
				local v395 = p377.slot
				local v396
				if v_u_59 or not v395.Tool then
					v396 = false
				else
					local v397
					if v_u_27 == nil then
						v397 = false
					else
						v397 = v_u_27.Enabled
					end
					if v397 then
						local v398 = v395.Tool
						local v399
						if v398 == nil then
							v399 = false
						else
							v399 = v_u_21.IsLocked(v398)
						end
						if v399 then
							v396 = false
						else
							v396 = v_u_45
						end
					else
						v396 = false
					end
				end
				if v396 then
					v_u_318(p377, p378)
				else
					local v400 = p377.slot
					local v401
					if p377.denied or (not v_u_45 or v_u_59) then
						v401 = false
					else
						local v402 = v400.Tool
						local v403
						if v402 == nil then
							v403 = false
						else
							v403 = v_u_21.IsLocked(v402)
						end
						if v403 then
							p377.denied = true
							v_u_17.Shake(v400.Button)
							v401 = true
						else
							v401 = false
						end
					end
					if not v401 then
						p377.scrolled = true
					end
				end
			end
		end
	end
end
local function v_u_427(p405) -- name: onInputChanged
	-- upvalues: (ref) v_u_57, (ref) v_u_307, (copy) v_u_39, (copy) v_u_21, (copy) v_u_17, (copy) v_u_404, (copy) v_u_9, (ref) v_u_59, (ref) v_u_27, (ref) v_u_45, (copy) v_u_318
	local v406 = v_u_57
	if v406 then
		local v407 = v406.input.UserInputType
		local v408
		if v407 == Enum.UserInputType.MouseButton1 then
			v408 = p405.UserInputType == Enum.UserInputType.MouseMovement
		else
			v408 = p405 == v406.input
		end
		if v408 then
			local v409 = p405.Position
			local v410 = Vector2.new(v409.X, v409.Y)
			if v406.dragging then
				if v406.ghost then
					v406.ghost.Position = UDim2.fromOffset(v410.X - v_u_307.X, v410.Y - v_u_307.Y)
				end
				local v411 = nil
				for _, v412 in v_u_39 do
					if not v412.Frame.Visible then
						continue
					end
					local v413 = v412.Tool
					local v414
					if v413 == nil then
						v414 = false
					else
						v414 = v_u_21.IsLocked(v413)
					end
					if not v414 then
						continue
					end
					local v415 = v412.Frame
					local v416 = v415.AbsolutePosition
					local v417 = v415.AbsoluteSize
					local v418
					if v410.X >= v416.X - 0 and (v410.X <= v416.X + v417.X + 0 and v410.Y >= v416.Y - 0) then
						v418 = v410.Y <= v416.Y + v417.Y + 0
					else
						v418 = false
					end
					if not v418 then
						continue
					end
					v411 = v412
				end
				if v411 ~= v406.hoverLocked then
					v406.hoverLocked = v411
					if v411 then
						v_u_17.Shake(v411.Button)
					end
				end
				return
			elseif v407 == Enum.UserInputType.Touch then
				v_u_404(v406, v410)
				return
			elseif (v410 - v406.start).Magnitude < v_u_9.DragThreshold then
				return
			else
				local v419 = v406.slot
				local v420
				if v_u_59 or not v419.Tool then
					v420 = false
				else
					local v421
					if v_u_27 == nil then
						v421 = false
					else
						v421 = v_u_27.Enabled
					end
					if v421 then
						local v422 = v419.Tool
						local v423
						if v422 == nil then
							v423 = false
						else
							v423 = v_u_21.IsLocked(v422)
						end
						if v423 then
							v420 = false
						else
							v420 = v_u_45
						end
					else
						v420 = false
					end
				end
				if v420 then
					v_u_318(v406, v410)
				else
					local v424 = v406.slot
					if not v406.denied and (v_u_45 and not v_u_59) then
						local v425 = v424.Tool
						local v426
						if v425 == nil then
							v426 = false
						else
							v426 = v_u_21.IsLocked(v425)
						end
						if not v426 then
							return
						end
						v406.denied = true
						v_u_17.Shake(v424.Button)
					end
				end
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_441(p428) -- name: onInputEnded
	-- upvalues: (ref) v_u_57, (ref) v_u_30, (copy) v_u_39, (copy) v_u_17, (copy) v_u_81, (copy) v_u_342, (ref) v_u_27, (ref) v_u_59, (copy) v_u_202
	local v429 = v_u_57
	if v429 then
		local v430
		if v429.input.UserInputType == Enum.UserInputType.MouseButton1 then
			v430 = p428.UserInputType == Enum.UserInputType.MouseButton1
		else
			v430 = p428 == v429.input
		end
		if v430 then
			v_u_57 = nil
			local v431 = p428.Position
			local v432 = Vector2.new(v431.X, v431.Y)
			if v429.dragging then
				if v429.ghost then
					v429.ghost:Destroy()
					v429.ghost = nil
				end
				if v_u_30 then
					v_u_30.ScrollingEnabled = true
				end
				for _, v433 in v_u_39 do
					v_u_17.SetLockedTint(v433.Button, false)
				end
				v_u_81("unlock")
				v_u_342(v429.slot, v432)
				return
			elseif not (v429.scrolled or v429.denied) and v429.slot.Frame.Parent ~= nil then
				local v434 = v429.slot.Button
				local v435 = v434.AbsolutePosition
				local v436 = v434.AbsoluteSize
				local v437
				if v432.X >= v435.X - 0 and (v432.X <= v435.X + v436.X + 0 and v432.Y >= v435.Y - 0) then
					v437 = v432.Y <= v435.Y + v436.Y + 0
				else
					v437 = false
				end
				if v437 then
					local v438 = v429.slot
					local v439 = v438.Tool
					if v439 then
						local v440
						if v_u_27 == nil then
							v440 = false
						else
							v440 = v_u_27.Enabled
						end
						if not v440 then
							return
						end
						if v_u_59 and v_u_59(v439) then
							return
						end
						v_u_202(v438)
					end
				end
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_445(p442) -- name: applySearch
	-- upvalues: (copy) v_u_47, (copy) v_u_159, (ref) v_u_30
	table.clear(v_u_47)
	for v443 in string.gmatch(string.lower(p442), "%S+") do
		local v444 = v_u_47
		table.insert(v444, v443)
	end
	v_u_159()
	if v_u_30 then
		v_u_30.CanvasPosition = Vector2.zero
	end
end
local function v_u_448(_, p446) -- name: onGamepadClose
	-- upvalues: (ref) v_u_55, (copy) v_u_21, (copy) v_u_39, (copy) v_u_17, (copy) v_u_23
	if p446 ~= Enum.UserInputState.Begin then
		return Enum.ContextActionResult.Pass
	end
	if v_u_55 then
		if v_u_55 then
			v_u_21.SetSwapMark(v_u_55.Parts, false)
		end
		v_u_55 = nil
		for _, v447 in v_u_39 do
			v_u_17.SetLockedTint(v447.Button, false)
		end
	else
		v_u_23.SetOpen(false)
	end
	return Enum.ContextActionResult.Sink
end
local function v_u_454(_, p449) -- name: onGamepadRemove
	-- upvalues: (copy) v_u_3, (copy) v_u_39, (copy) v_u_21, (copy) v_u_17, (copy) v_u_208
	if p449 ~= Enum.UserInputState.Begin then
		return Enum.ContextActionResult.Pass
	end
	local v450 = v_u_3.SelectedObject
	for _, v451 in v_u_39 do
		if v451.Button ~= v450 or not v451.Tool then
			continue
		end
		local v452 = v451.Tool
		local v453
		if v452 == nil then
			v453 = false
		else
			v453 = v_u_21.IsLocked(v452)
		end
		if v453 then
			v_u_17.Shake(v451.Button)
		else
			v_u_208(v451)
		end
		return Enum.ContextActionResult.Sink
	end
	return Enum.ContextActionResult.Pass
end
local function v_u_464(p455) -- name: setOpenInternal
	-- upvalues: (ref) v_u_44, (ref) v_u_45, (ref) v_u_27, (ref) v_u_57, (ref) v_u_30, (copy) v_u_39, (copy) v_u_17, (copy) v_u_81, (ref) v_u_29, (copy) v_u_2, (copy) v_u_448, (copy) v_u_24, (copy) v_u_454, (ref) v_u_55, (copy) v_u_21, (ref) v_u_34, (copy) v_u_47, (copy) v_u_445, (copy) v_u_3, (copy) v_u_16, (copy) v_u_132, (copy) v_u_159, (ref) v_u_63, (copy) v_u_90, (copy) v_u_62, (copy) v_u_11, (copy) v_u_8, (ref) v_u_58, (copy) v_u_61
	if v_u_44 and p455 ~= v_u_45 then
		if p455 then
			local v456
			if v_u_27 == nil then
				v456 = false
			else
				v456 = v_u_27.Enabled
			end
			if not v456 then
				return
			end
		end
		if not (v_u_57 and v_u_57.dragging) then
			local v457 = v_u_57
			v_u_57 = nil
			if v457 and v457.dragging then
				if v457.ghost then
					v457.ghost:Destroy()
					v457.ghost = nil
				end
				if v_u_30 then
					v_u_30.ScrollingEnabled = true
				end
				for _, v458 in v_u_39 do
					v_u_17.SetLockedTint(v458.Button, false)
				end
				v_u_81("unlock")
			end
			v_u_45 = p455
			if v_u_29 then
				v_u_29.Visible = p455
			end
			if p455 then
				v_u_2:BindActionAtPriority("BackpackCloseInventory", v_u_448, false, v_u_24, Enum.KeyCode.ButtonB)
				v_u_2:BindActionAtPriority("BackpackRemoveSlot", v_u_454, false, v_u_24, Enum.KeyCode.ButtonX)
			else
				v_u_2:UnbindAction("BackpackCloseInventory")
				v_u_2:UnbindAction("BackpackRemoveSlot")
				if v_u_55 then
					v_u_21.SetSwapMark(v_u_55.Parts, false)
				end
				v_u_55 = nil
				for _, v459 in v_u_39 do
					v_u_17.SetLockedTint(v459.Button, false)
				end
				if v_u_34 and v_u_34.Text ~= "" then
					v_u_34.Text = ""
				elseif #v_u_47 > 0 then
					v_u_445("")
				end
				local v460 = v_u_3.SelectedObject
				if v460 and (v_u_27 and v460:IsDescendantOf(v_u_27)) then
					v_u_3.SelectedObject = nil
				end
				v_u_16.Hide()
			end
			v_u_132()
			v_u_159()
			if not v_u_63 then
				v_u_63 = true
				task.defer(function()
					-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
					v_u_63 = false
					v_u_90()
					for _, v461 in v_u_62 do
						task.spawn(v461)
					end
				end)
			end
			if p455 and v_u_11.IsGamepadInput(v_u_8:GetLastInputType()) then
				for _, v462 in v_u_39 do
					if not v462.Frame.Visible then
						continue
					end
					v_u_3.SelectedObject = v462.Button
				end
			end
			if v_u_58 and v_u_58.isSelected ~= p455 then
				v_u_81(p455 and "select" or "deselect")
			end
			for _, v463 in v_u_61 do
				task.spawn(v463, p455)
			end
		end
	else
		return
	end
end
local function v_u_468() -- name: refreshIconEnabled
	-- upvalues: (copy) v_u_81, (ref) v_u_27, (copy) v_u_3
	local v465 = v_u_81
	local v466 = "setEnabled"
	local v467
	if v_u_27 == nil then
		v467 = false
	else
		v467 = v_u_27.Enabled
	end
	if v467 then
		v467 = not v_u_3.MenuIsOpen
	end
	v465(v466, v467)
end
local function v_u_472() -- name: refreshNumbers
	-- upvalues: (copy) v_u_8, (copy) v_u_25, (copy) v_u_11, (ref) v_u_48, (copy) v_u_132
	local v469 = v_u_8:GetLastInputType()
	local v470 = v469 == Enum.UserInputType.Keyboard and true or v_u_25[v469] == true
	local v471 = v469 == Enum.UserInputType.Touch and true or v_u_11.IsGamepadInput(v469)
	if v470 then
		v_u_48 = true
	elseif v471 then
		v_u_48 = false
	end
	v_u_132()
end
local function v_u_481(p473, p474) -- name: onInputBegan
	-- upvalues: (ref) v_u_34, (copy) v_u_47, (copy) v_u_445, (ref) v_u_27, (copy) v_u_3, (copy) v_u_8, (copy) v_u_7, (copy) v_u_43, (copy) v_u_39, (copy) v_u_202, (copy) v_u_21, (copy) v_u_9, (ref) v_u_58, (copy) v_u_23, (ref) v_u_45, (ref) v_u_57
	if p473.UserInputType == Enum.UserInputType.Keyboard then
		if p473.KeyCode == Enum.KeyCode.Escape and p474 then
			if v_u_34 and v_u_34.Text ~= "" then
				v_u_34.Text = ""
			elseif #v_u_47 > 0 then
				v_u_445("")
			end
		else
			local v475
			if v_u_27 == nil then
				v475 = false
			else
				v475 = v_u_27.Enabled
			end
			if v475 and not (v_u_3.MenuIsOpen or v_u_8:GetFocusedTextBox()) then
				local v476 = v_u_7:FindFirstChildOfClass("ChatInputBarConfiguration")
				local v477
				if v476 == nil then
					v477 = false
				else
					v477 = v476.IsFocused
				end
				if not v477 then
					local v478 = v_u_43[p473.KeyCode.Value]
					if v478 then
						local v479 = v_u_39[v478]
						if v479 and v479.Tool then
							v_u_202(v479)
							v_u_21.Pulse(v479.Parts)
						end
					elseif p473.KeyCode == v_u_9.ToggleKey and not v_u_58 then
						v_u_23.SetOpen(not v_u_45)
					end
				end
			end
			return
		end
	else
		if not p474 and (v_u_45 and not v_u_57) then
			local v480 = p473.UserInputType
			if v480 == Enum.UserInputType.MouseButton1 or v480 == Enum.UserInputType.Touch then
				v_u_23.SetOpen(false)
			end
		end
		return
	end
end
local function v_u_484() -- name: findTopbarPlus
	-- upvalues: (copy) v_u_5, (copy) v_u_9
	local v482 = v_u_5
	for _, v483 in v_u_9.TopbarPlusPath do
		if not v482 then
			continue
		end
		v482 = v482:FindFirstChild(v483)
	end
	if v482 and v482:IsA("ModuleScript") then
		return v482
	else
		return nil
	end
end
local function v_u_492() -- name: createIcon
	-- upvalues: (copy) v_u_484, (copy) v_u_9, (ref) v_u_58, (copy) v_u_464, (ref) v_u_45, (copy) v_u_81
	local v_u_485 = v_u_484()
	if v_u_485 then
		local function v488()
			-- upvalues: (copy) v_u_485, (ref) v_u_9
			local v486 = require(v_u_485)
			local v487 = v_u_9.Icon
			return v486.new():setName(v487.Name):setImage(v487.ImageOpen, "Selected"):setImage(v487.ImageClosed, "Deselected"):setImageScale(1):setCaption(v487.Caption):bindToggleKey(v_u_9.ToggleKey):autoDeselect(false):setOrder(v487.Order)
		end
		local v489, v490 = pcall(v488)
		if v489 then
			v_u_58 = v490
			v_u_58.toggled:Connect(function(p491)
				-- upvalues: (ref) v_u_464, (ref) v_u_45, (ref) v_u_58, (ref) v_u_81
				v_u_464(p491)
				if p491 ~= v_u_45 then
					task.defer(function()
						-- upvalues: (ref) v_u_58, (ref) v_u_45, (ref) v_u_81
						if v_u_58.isSelected ~= v_u_45 then
							v_u_81(v_u_45 and "select" or "deselect")
						end
					end)
				end
			end)
		else
			warn((("[BackpackController] couldn\'t create the topbar icon: %*"):format(v490)))
		end
	else
		warn("[BackpackController] TopbarPlus not found \226\128\148 inventory opens with the toggle key only")
		return
	end
end
local function v_u_498(p493, p494, p495) -- name: waitForDescendant
	local v496 = os.clock() + p495
	local v497 = p493:FindFirstChild(p494, true)
	while not v497 and os.clock() < v496 do
		task.wait(0.1)
		v497 = p493:FindFirstChild(p494, true)
	end
	return v497
end
local function v_u_521(p499) -- name: findUi
	-- upvalues: (copy) v_u_498, (copy) v_u_9, (ref) v_u_27, (ref) v_u_28, (ref) v_u_29, (ref) v_u_30, (ref) v_u_31, (ref) v_u_32, (copy) v_u_37, (copy) v_u_19, (copy) v_u_22, (copy) v_u_10, (ref) v_u_46, (ref) v_u_55, (copy) v_u_21, (copy) v_u_39, (copy) v_u_17, (copy) v_u_159, (ref) v_u_63, (copy) v_u_90, (copy) v_u_62, (ref) v_u_33, (copy) v_u_20, (copy) v_u_170, (ref) v_u_59, (copy) v_u_92, (ref) v_u_35, (ref) v_u_36, (ref) v_u_34, (copy) v_u_445, (copy) v_u_16
	local v500 = v_u_498(p499, v_u_9.HotbarName, 30)
	local v501 = v_u_498(p499, v_u_9.InventoryName, 30)
	if not (v500 and (v501 and (v500:IsA("GuiObject") and v501:IsA("GuiObject")))) then
		warn("[BackpackController] Scatchel UI is missing BottomHUD / Inventory")
		return false
	end
	local v502 = v500:WaitForChild(v_u_9.TemplateName, 30)
	local v503 = v501:WaitForChild("ScrollingFrame", 30)
	local v504
	if v503 then
		v504 = v503:WaitForChild(v_u_9.TemplateName, 30)
	else
		v504 = v503
	end
	if not (v502 and v502:IsA("GuiButton")) then
		warn("[BackpackController] BottomHUD.Template (TextButton) not found")
		return false
	end
	if not (v503 and (v503:IsA("ScrollingFrame") and (v504 and v504:IsA("GuiObject")))) then
		warn("[BackpackController] Inventory.ScrollingFrame.Template not found")
		return false
	end
	v_u_27 = p499
	v_u_28 = v500
	v_u_29 = v501
	v_u_30 = v503
	v_u_31 = v502
	v_u_32 = v504
	for _, v505 in { v500, v503 } do
		for _, v506 in v505:GetChildren() do
			if v506.Name ~= v_u_9.TemplateName or not v506:IsA("GuiObject") then
				continue
			end
			v506.Visible = false
		end
	end
	for _, v507 in v503:GetChildren() do
		if not v507:IsA("UIPadding") then
			continue
		end
		v507:Destroy()
	end
	local v508 = v501:FindFirstChild("SideBarList")
	for v_u_509, v510 in v_u_9.Categories do
		local v511
		if v508 then
			v511 = v508:FindFirstChild(v510.Button)
		else
			v511 = v508
		end
		if not (v511 and v511:IsA("GuiButton")) then
			continue
		end
		v_u_37[v_u_509] = v511
		v_u_19.Attach(v511)
		local v512 = v511:FindFirstChild("Icon")
		if v512 and v512:IsA("GuiObject") then
			v_u_22.Attach(v512, v_u_10.Styles.AnimalTile, v511)
		end
		v511.Activated:Connect(function()
			-- upvalues: (copy) v_u_509, (ref) v_u_9, (ref) v_u_46, (ref) v_u_55, (ref) v_u_21, (ref) v_u_39, (ref) v_u_17, (ref) v_u_159, (ref) v_u_30, (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
			local v513 = v_u_509
			if v_u_9.Categories[v513] then
				if v513 == v_u_46 then
					return
				end
				v_u_46 = v513
				if v_u_55 then
					v_u_21.SetSwapMark(v_u_55.Parts, false)
				end
				v_u_55 = nil
				for _, v514 in v_u_39 do
					v_u_17.SetLockedTint(v514.Button, false)
				end
				v_u_159()
				if v_u_30 then
					v_u_30.CanvasPosition = Vector2.zero
				end
				if v_u_63 then
					return
				end
				v_u_63 = true
				task.defer(function()
					-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
					v_u_63 = false
					v_u_90()
					for _, v515 in v_u_62 do
						task.spawn(v515)
					end
				end)
			end
		end)
		local v516 = v511:FindFirstChild(v_u_9.SelectedStrokeName)
		if v_u_33 or not (v516 and v516:IsA("UIStroke")) then
			continue
		end
		v_u_33 = v516
	end
	v_u_20.Init({
		["Scrolling"] = v503,
		["Template"] = v504,
		["StrokeTemplate"] = v_u_33,
		["SlotStroke"] = v_u_170(false),
		["CanClick"] = function() -- name: CanClick
			-- upvalues: (ref) v_u_59
			return v_u_59 == nil
		end,
		["OnChanged"] = v_u_92
	})
	local v517 = v501:FindFirstChild("Title")
	if not (v517 and v517:IsA("TextLabel")) then
		v517 = nil
	end
	v_u_35 = v517
	local v518 = v501:FindFirstChild("InventoryCapacity")
	if not (v518 and v518:IsA("TextLabel")) then
		v518 = nil
	end
	v_u_36 = v518
	local v_u_519 = v501:FindFirstChild("Search")
	if v_u_519 then
		v_u_519 = v_u_519:FindFirstChildWhichIsA("TextBox")
	end
	if v_u_519 then
		v_u_34 = v_u_519
		v_u_519.ClearTextOnFocus = false
		v_u_519.Text = ""
		v_u_519:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (ref) v_u_445, (copy) v_u_519
			v_u_445(v_u_519.Text)
		end)
	end
	v_u_16.Init(p499)
	v501.Active = true
	local v520 = v501:FindFirstChild("CashSellValue")
	if v520 and v520:IsA("GuiObject") then
		v520.Active = true
	end
	v501.Visible = false
	return true
end
local function v_u_524() -- name: buildHotbar
	-- upvalues: (ref) v_u_38, (copy) v_u_18, (copy) v_u_9, (copy) v_u_39, (copy) v_u_186, (copy) v_u_43
	local v522
	if v_u_18.IsMobile() then
		v522 = v_u_9.HotbarSlotsMini
	else
		v522 = v_u_9.HotbarSlotsFull
	end
	v_u_38 = v522
	for v523 = 1, v_u_38 do
		v_u_39[v523] = v_u_186(v523)
		if v523 < 10 then
			v_u_43[Enum.KeyCode.Zero.Value + v523] = v523
		else
			if v523 ~= 10 then
				continue
			end
			v_u_43[Enum.KeyCode.Zero.Value] = v523
		end
	end
end
function v_u_23.IsOpen() -- name: IsOpen
	-- upvalues: (ref) v_u_45
	return v_u_45
end
function v_u_23.SetOpen(p525) -- name: SetOpen
	-- upvalues: (copy) v_u_464
	v_u_464(p525)
end
function v_u_23.Toggle() -- name: Toggle
	-- upvalues: (copy) v_u_464, (ref) v_u_45
	v_u_464(not v_u_45)
end
function v_u_23.ObserveOpen(p526) -- name: ObserveOpen
	-- upvalues: (copy) v_u_61
	local v527 = v_u_61
	table.insert(v527, p526)
end
function v_u_23.ObserveChanged(p528) -- name: ObserveChanged
	-- upvalues: (copy) v_u_62
	local v529 = v_u_62
	table.insert(v529, p528)
end
function v_u_23.SetClickInterceptor(p530) -- name: SetClickInterceptor
	-- upvalues: (ref) v_u_59, (ref) v_u_57, (ref) v_u_30, (copy) v_u_39, (copy) v_u_17, (copy) v_u_81, (ref) v_u_55, (copy) v_u_21
	v_u_59 = p530
	if p530 then
		local v531 = v_u_57
		v_u_57 = nil
		if v531 and v531.dragging then
			if v531.ghost then
				v531.ghost:Destroy()
				v531.ghost = nil
			end
			if v_u_30 then
				v_u_30.ScrollingEnabled = true
			end
			for _, v532 in v_u_39 do
				v_u_17.SetLockedTint(v532.Button, false)
			end
			v_u_81("unlock")
		end
		if v_u_55 then
			v_u_21.SetSwapMark(v_u_55.Parts, false)
		end
		v_u_55 = nil
		for _, v533 in v_u_39 do
			v_u_17.SetLockedTint(v533.Button, false)
		end
	end
end
function v_u_23.SetSlotDecorator(p534) -- name: SetSlotDecorator
	-- upvalues: (ref) v_u_60, (copy) v_u_23
	v_u_60 = p534
	v_u_23.RefreshDecorations()
end
function v_u_23.RefreshDecorations() -- name: RefreshDecorations
	-- upvalues: (copy) v_u_39, (ref) v_u_60, (copy) v_u_40
	for _, v535 in v_u_39 do
		if not v_u_60 then
			continue
		end
		v_u_60(v535.Tool, v535.Parts)
	end
	for _, v536 in v_u_40 do
		if not v_u_60 then
			continue
		end
		v_u_60(v536.Tool, v536.Parts)
	end
end
function v_u_23.UnequipIfHeld(p537) -- name: UnequipIfHeld
	-- upvalues: (ref) v_u_49, (ref) v_u_65, (ref) v_u_50
	local v538
	if p537 == nil or v_u_49 == nil then
		v538 = false
	else
		v538 = p537.Parent == v_u_49
	end
	if v538 then
		v_u_65 = v_u_65 + 1
		if v_u_50 then
			v_u_50:UnequipTools()
		end
	end
end
function v_u_23.HasTool(p539) -- name: HasTool
	-- upvalues: (copy) v_u_41
	return v_u_41[p539] ~= nil
end
function v_u_23.GetHotbarTools() -- name: GetHotbarTools
	-- upvalues: (copy) v_u_39
	local v540 = {}
	for _, v541 in v_u_39 do
		if not v541.Tool then
			continue
		end
		local v542 = v541.Tool
		table.insert(v540, v542)
	end
	return v540
end
function v_u_23.FindHotbarSlot(p543, p544) -- name: FindHotbarSlot
	-- upvalues: (copy) v_u_39, (ref) v_u_27
	local v545 = #v_u_39
	local v546, v547
	if p544 then
		v546 = #v_u_39
		v545 = 1
		v547 = -1
	else
		v546 = 1
		v547 = 1
	end
	for v548 = v546, v545, v547 do
		local v549 = v_u_39[v548]
		if not (v549.Tool and v549.Frame.Visible) then
			continue
		end
		local v550
		if v_u_27 == nil then
			v550 = false
		else
			v550 = v_u_27.Enabled
		end
		if not (v550 and p543(v549.Tool)) then
			continue
		end
		return v549.Button
	end
	return nil
end
function v_u_23.GetCategoryInfo() -- name: GetCategoryInfo
	-- upvalues: (copy) v_u_9, (ref) v_u_46
	return v_u_9.Categories[v_u_46]
end
function v_u_23.IsReady() -- name: IsReady
	-- upvalues: (ref) v_u_44
	return v_u_44
end
function v_u_23.GetInventoryFrame() -- name: GetInventoryFrame
	-- upvalues: (ref) v_u_29
	return v_u_29
end
function v_u_23.GetHotbarFrame() -- name: GetHotbarFrame
	-- upvalues: (ref) v_u_28
	return v_u_28
end
function v_u_23.Start() -- name: Start
	-- upvalues: (copy) v_u_26, (copy) v_u_14, (copy) v_u_39, (copy) v_u_40, (copy) v_u_1, (copy) v_u_15, (copy) v_u_21, (ref) v_u_49, (copy) v_u_18, (copy) v_u_521, (copy) v_u_6, (copy) v_u_524, (ref) v_u_44, (copy) v_u_492, (copy) v_u_81, (ref) v_u_27, (copy) v_u_3, (ref) v_u_57, (ref) v_u_30, (copy) v_u_17, (copy) v_u_464, (copy) v_u_468, (copy) v_u_8, (copy) v_u_481, (copy) v_u_427, (copy) v_u_441, (copy) v_u_345, (copy) v_u_472, (copy) v_u_291, (copy) v_u_306, (copy) v_u_132, (copy) v_u_159, (ref) v_u_63, (copy) v_u_90, (copy) v_u_62
	local v551 = v_u_26:WaitForChild("PlayerGui")
	v_u_26:GetAttributeChangedSignal(v_u_14.MountedAttribute):Connect(function()
		-- upvalues: (ref) v_u_39, (ref) v_u_40, (ref) v_u_1, (ref) v_u_15, (ref) v_u_21, (ref) v_u_49, (ref) v_u_26, (ref) v_u_14
		for _, v552 in { v_u_39, v_u_40 } do
			for _, v553 in v552 do
				local v554 = v553.Tool
				local v555
				if v554 == nil then
					v555 = false
				else
					v555 = v_u_1:HasTag(v554, v_u_15.Held.ToolTag)
				end
				if not v555 then
					continue
				end
				local v556 = v553.Tool
				local v557 = v_u_21.SetEquipped
				local v558 = v553.Parts
				local v559
				if v556 == nil or v_u_49 == nil then
					v559 = false
				else
					v559 = v556.Parent == v_u_49
				end
				if not v559 then
					if v556 == nil then
						v559 = false
					else
						v559 = v_u_1:HasTag(v556, v_u_15.Held.ToolTag)
					end
					if v559 then
						v559 = v_u_26:GetAttribute(v_u_14.MountedAttribute) == true
					end
				end
				v557(v558, v559)
			end
		end
	end)
	local v_u_560 = v_u_18.UnusedName()
	local function v562(p561) -- name: dropUnused
		-- upvalues: (copy) v_u_560
		if p561.Name == v_u_560 and p561:IsA("ScreenGui") then
			p561:Destroy()
		end
	end
	for _, v563 in v551:GetChildren() do
		if v563.Name ~= v_u_560 or not v563:IsA("ScreenGui") then
			continue
		end
		v563:Destroy()
	end
	v551.ChildAdded:Connect(v562)
	local v_u_564 = v551:WaitForChild(v_u_18.Name())
	if v_u_564:IsA("ScreenGui") then
		v_u_564.ResetOnSpawn = false
		v_u_564.Enabled = true
		if v_u_521(v_u_564) then
			local v565 = v_u_6.SetCoreGuiEnabled
			local v566 = v_u_6
			local v567 = Enum.CoreGuiType.Backpack
			pcall(v565, v566, v567, false)
			v_u_524()
			v_u_44 = true
			v_u_492()
			local v568 = v_u_81
			local v569 = "setEnabled"
			local v570
			if v_u_27 == nil then
				v570 = false
			else
				v570 = v_u_27.Enabled
			end
			if v570 then
				v570 = not v_u_3.MenuIsOpen
			end
			v568(v569, v570)
			v_u_564:GetPropertyChangedSignal("Enabled"):Connect(function()
				-- upvalues: (copy) v_u_564, (ref) v_u_57, (ref) v_u_30, (ref) v_u_39, (ref) v_u_17, (ref) v_u_81, (ref) v_u_464, (ref) v_u_27, (ref) v_u_3
				if not v_u_564.Enabled then
					local v571 = v_u_57
					v_u_57 = nil
					if v571 and v571.dragging then
						if v571.ghost then
							v571.ghost:Destroy()
							v571.ghost = nil
						end
						if v_u_30 then
							v_u_30.ScrollingEnabled = true
						end
						for _, v572 in v_u_39 do
							v_u_17.SetLockedTint(v572.Button, false)
						end
						v_u_81("unlock")
					end
					v_u_464(false)
				end
				local v573 = v_u_81
				local v574 = "setEnabled"
				local v575
				if v_u_27 == nil then
					v575 = false
				else
					v575 = v_u_27.Enabled
				end
				if v575 then
					v575 = not v_u_3.MenuIsOpen
				end
				v573(v574, v575)
			end)
			v_u_3.MenuOpened:Connect(v_u_468)
			v_u_3.MenuClosed:Connect(v_u_468)
			v_u_8.InputBegan:Connect(v_u_481)
			v_u_8.InputChanged:Connect(v_u_427)
			v_u_8.InputEnded:Connect(v_u_441)
			v_u_8.WindowFocusReleased:Connect(v_u_345)
			v_u_8.LastInputTypeChanged:Connect(v_u_472)
			v_u_472()
			v_u_26.ChildAdded:Connect(function(p576)
				-- upvalues: (ref) v_u_49, (ref) v_u_291
				if p576:IsA("Backpack") and v_u_49 then
					v_u_291(p576)
				end
			end)
			v_u_26.CharacterAdded:Connect(v_u_306)
			if v_u_26.Character then
				task.spawn(v_u_306, v_u_26.Character)
			end
			v_u_132()
			v_u_159()
			if not v_u_63 then
				v_u_63 = true
				task.defer(function()
					-- upvalues: (ref) v_u_63, (ref) v_u_90, (ref) v_u_62
					v_u_63 = false
					v_u_90()
					for _, v577 in v_u_62 do
						task.spawn(v577)
					end
				end)
			end
		else
			return
		end
	else
		return
	end
end
return v_u_23
local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = require(script.Parent.Parent.UiSounds)
local v_u_7 = require(script.Parent.Assets)
local v_u_8 = v_u_2.LocalPlayer
local v9 = {}
local v_u_10 = Random.new()
local v_u_11 = nil
local v_u_12 = {}
local v_u_13 = {}
local v_u_14 = nil
local function v_u_40(p15) -- name: bounds
	local v16 = Vector3.new(inf, inf, inf)
	local v17 = -v16
	for _, v18 in p15:GetDescendants() do
		if not v18:IsA("BasePart") then
			continue
		end
		local v19 = v18.CFrame
		local v20 = v18.Size / 2
		local v21 = v19.XVector.X
		local v22 = math.abs(v21) * v20.X
		local v23 = v19.YVector.X
		local v24 = v22 + math.abs(v23) * v20.Y
		local v25 = v19.ZVector.X
		local v26 = v24 + math.abs(v25) * v20.Z
		local v27 = v19.XVector.Y
		local v28 = math.abs(v27) * v20.X
		local v29 = v19.YVector.Y
		local v30 = v28 + math.abs(v29) * v20.Y
		local v31 = v19.ZVector.Y
		local v32 = v30 + math.abs(v31) * v20.Z
		local v33 = v19.XVector.Z
		local v34 = math.abs(v33) * v20.X
		local v35 = v19.YVector.Z
		local v36 = v34 + math.abs(v35) * v20.Y
		local v37 = v19.ZVector.Z
		local v38 = v36 + math.abs(v37) * v20.Z
		local v39 = Vector3.new(v26, v32, v38)
		v16 = v16:Min(v19.Position - v39)
		v17 = v17:Max(v19.Position + v39)
	end
	return v16, v17
end
local function v_u_77(p41, p42) -- name: buildRig
	-- upvalues: (copy) v_u_7, (copy) v_u_40
	local v43 = p42.EggHeight
	local v44
	if p41:IsA("Model") then
		v44 = p41:Clone()
	else
		if not p41:IsA("BasePart") then
			return nil
		end
		v44 = Instance.new("Model")
		local v45 = p41:Clone()
		v45.Parent = v44
		v44.PrimaryPart = v45
	end
	v44.Name = "Egg"
	local v46 = v44.PrimaryPart
	if v46 == nil then
		local v47 = 0
		for _, v48 in v44:GetDescendants() do
			if not v48:IsA("BasePart") or v47 >= v48.Size.X * v48.Size.Y * v48.Size.Z then
				continue
			end
			v47 = v48.Size.X * v48.Size.Y * v48.Size.Z
			v46 = v48
		end
	end
	local v49 = v_u_7.VfxFolder()
	if v46 and v49 then
		for _, v50 in p42.VfxAttachments do
			local v51 = v49:FindFirstChild(v50)
			if not (v51 and v51:IsA("Attachment")) then
				continue
			end
			local v52 = v51:Clone()
			v52.CFrame = CFrame.identity
			v52.Parent = v46
		end
	end
	local v53, v54 = v_u_40(v44)
	local v55 = v54.Y - v53.Y
	if v55 <= 0 then
		v44:Destroy()
		return nil
	end
	v44:ScaleTo(v44:GetScale() * v43 / v55)
	local v56, v57 = v_u_40(v44)
	local v58 = v57 - v56
	local v59 = CFrame.new((v56.X + v57.X) / 2, v56.Y, (v56.Z + v57.Z) / 2)
	local v60 = v44.PrimaryPart
	local v61 = 0
	local v62 = {}
	local v63 = {}
	local v64 = {}
	local v65 = {}
	for _, v66 in v44:GetDescendants() do
		if v66:IsA("ParticleEmitter") then
			if v66:FindFirstAncestor(p42.OpenEffectName) then
				v66.Enabled = false
			end
			if v66:FindFirstAncestor(p42.ImpactEffectName) then
				table.insert(v62, v66)
			end
			if table.find(p42.BreakBurstEffects, v66.Name) then
				table.insert(v63, v66)
			end
		end
		if v66:IsA("BasePart") then
			v66.Anchored = true
			v66.CanCollide = false
			v66.CanTouch = false
			v66.CanQuery = false
			local v67 = v59:ToObjectSpace(v66.CFrame)
			local v68 = v67.XVector
			local v69 = v67.YVector
			local v70 = v67.ZVector
			local v71 = {
				["part"] = v66,
				["offset"] = v67,
				["size"] = v66.Size,
				["xXZ"] = v68.X * v68.X + v68.Z * v68.Z,
				["xY"] = v68.Y * v68.Y,
				["yXZ"] = v69.X * v69.X + v69.Z * v69.Z,
				["yY"] = v69.Y * v69.Y,
				["zXZ"] = v70.X * v70.X + v70.Z * v70.Z,
				["zY"] = v70.Y * v70.Y
			}
			table.insert(v64, v71)
			local v72 = v66.Size.X * v66.Size.Y * v66.Size.Z
			if v44.PrimaryPart ~= nil or v61 >= v72 then
				continue
			end
			v60 = v66
			v61 = v72
		else
			if not ((v66:IsA("ParticleEmitter") or (v66:IsA("Beam") or v66:IsA("Trail"))) and v66.Enabled) then
				continue
			end
			table.insert(v65, v66)
			v66.Enabled = false
		end
	end
	if v60 == nil then
		v44:Destroy()
		return nil
	end
	local v73 = {
		["model"] = nil,
		["root"] = nil,
		["pieces"] = nil,
		["effects"] = nil,
		["impacts"] = nil,
		["breakBursts"] = nil,
		["openEffect"] = nil,
		["height"] = nil,
		["width"] = nil,
		["sizedXZ"] = -1,
		["sizedY"] = -1,
		["model"] = v44,
		["root"] = v60,
		["pieces"] = v64,
		["effects"] = v65,
		["impacts"] = v62,
		["breakBursts"] = v63
	}
	local v74 = v44:FindFirstChild(p42.OpenEffectName, true)
	if not (v74 and v74:IsA("Attachment")) then
		v74 = nil
	end
	v73.openEffect = v74
	v73.height = v58.Y
	local v75 = v58.X
	local v76 = v58.Z
	v73.width = math.max(v75, v76)
	return v73
end
local v_u_78 = {}
local v_u_79 = {}
local function v_u_109(p80, p81, p82, p83, p84) -- name: pose
	-- upvalues: (copy) v_u_78, (copy) v_u_79
	local v85 = p82 ~= p80.sizedXZ and true or p83 ~= p80.sizedY
	if v85 then
		p80.sizedXZ = p82
		p80.sizedY = p83
	end
	local v86 = p82 * p82
	local v87 = p83 * p83
	for _, v88 in p80.pieces do
		if v85 then
			local v89 = v88.size
			local v90 = v88.part
			local v91 = v89.X
			local v92 = v86 * v88.xXZ + v87 * v88.xY
			local v93 = v91 * math.sqrt(v92)
			local v94 = math.max(v93, 0.01)
			local v95 = v89.Y
			local v96 = v86 * v88.yXZ + v87 * v88.yY
			local v97 = v95 * math.sqrt(v96)
			local v98 = math.max(v97, 0.01)
			local v99 = v89.Z
			local v100 = v86 * v88.zXZ + v87 * v88.zY
			local v101 = v99 * math.sqrt(v100)
			local v102 = math.max(v101, 0.01)
			v90.Size = Vector3.new(v94, v98, v102)
		end
		local v103 = v88.offset
		local v104 = v103.Position
		local v105 = p81 * CFrame.new(v104.X * p82, v104.Y * p83, v104.Z * p82) * v103.Rotation
		if p84 then
			local v106 = v_u_78
			local v107 = v88.part
			table.insert(v106, v107)
			local v108 = v_u_79
			table.insert(v108, v105)
		else
			v88.part.CFrame = v105
		end
	end
end
local function v_u_121(p110, p111, p112, p113) -- name: ring
	-- upvalues: (copy) v_u_5, (copy) v_u_1, (copy) v_u_4
	local v114 = p113.RingTime + 0.2
	local v115 = Instance.new("Attachment")
	v115.Name = "EggFX"
	v115.WorldPosition = p110
	v115.Parent = v_u_5.Terrain
	v_u_1:AddItem(v115, v114)
	local v116 = Instance.new("BillboardGui")
	v116.Name = "EggRing"
	v116.Adornee = v115
	v116.Size = UDim2.fromScale(p111, p111)
	v116.LightInfluence = 0
	v116.ResetOnSpawn = false
	local v117 = Instance.new("Frame")
	v117.AnchorPoint = Vector2.new(0.5, 0.5)
	v117.Position = UDim2.fromScale(0.5, 0.5)
	v117.Size = UDim2.fromScale(1, 1)
	v117.BackgroundTransparency = 1
	local v118 = Instance.new("UICorner")
	v118.CornerRadius = UDim.new(0.5, 0)
	v118.Parent = v117
	local v119 = Instance.new("UIStroke")
	v119.Color = p113.RingColor
	v119.Thickness = p113.RingThickness
	v119.Parent = v117
	v117.Parent = v116
	v116.Parent = v115
	local v120 = TweenInfo.new(p113.RingTime, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
	v_u_4:Create(v116, v120, {
		["Size"] = UDim2.fromScale(p112, p112)
	}):Play()
	v_u_4:Create(v119, v120, {
		["Transparency"] = 1,
		["Thickness"] = 1
	}):Play()
end
local function v_u_137(p122, p123, p_u_124) -- name: sparkleBurst
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	local v125 = p_u_124.SparkleLife.Max + 0.3
	local v_u_126 = Instance.new("Attachment")
	v_u_126.Name = "EggFX"
	v_u_126.WorldPosition = p122
	v_u_126.Parent = v_u_5.Terrain
	v_u_1:AddItem(v_u_126, v125)
	local function v133(p127, p128, p129, p130, p131) -- name: emitter
		-- upvalues: (copy) p_u_124, (copy) v_u_126
		local v132 = Instance.new("ParticleEmitter")
		v132.Texture = p_u_124.SparkleTexture
		v132.Color = ColorSequence.new(p127)
		v132.LightEmission = 1
		v132.LightInfluence = 0
		v132.Rate = 0
		v132.Speed = p130
		v132.SpreadAngle = Vector2.new(180, 180)
		v132.Drag = p_u_124.SparkleDrag
		v132.Lifetime = p131
		v132.Rotation = NumberRange.new(0, 360)
		v132.RotSpeed = NumberRange.new(-200, 200)
		v132.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, p129), NumberSequenceKeypoint.new(0.2, p129), NumberSequenceKeypoint.new(1, 0) })
		v132.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0), NumberSequenceKeypoint.new(0.7, 0), NumberSequenceKeypoint.new(1, 1) })
		v132.Parent = v_u_126
		v132:Emit(p128)
	end
	local v134 = NumberRange.new(p_u_124.SparkleSpeed.Min * p123, p_u_124.SparkleSpeed.Max * p123)
	local v135 = NumberRange.new(p_u_124.SparkleLife.Min, p_u_124.SparkleLife.Max)
	for _, v136 in p_u_124.SparkleColors do
		v133(v136, p_u_124.SparklesPerColor, p_u_124.SparkleSize * p123, v134, v135)
	end
	v133(Color3.new(1, 1, 1), 1, p_u_124.FlareSize * p123, NumberRange.new(0), NumberRange.new(p_u_124.FlareLife))
end
local v_u_138 = nil
local function v_u_142(p139) -- name: flashScreen
	-- upvalues: (ref) v_u_138, (copy) v_u_8, (copy) v_u_4
	local v140 = v_u_138
	if v140 == nil or v140.Parent == nil then
		local v141 = Instance.new("ScreenGui")
		v141.Name = "EggHatchFlash"
		v141.ResetOnSpawn = false
		v141.IgnoreGuiInset = true
		v141.DisplayOrder = 50
		v141.Parent = v_u_8:WaitForChild("PlayerGui")
		v140 = Instance.new("Frame")
		v140.Size = UDim2.fromScale(1, 1)
		v140.BorderSizePixel = 0
		v140.BackgroundColor3 = Color3.new(1, 1, 1)
		v140.BackgroundTransparency = 1
		v140.Active = false
		v140.Parent = v141
		v_u_138 = v140
	end
	v140.BackgroundTransparency = p139.ScreenFlashTransparency
	v_u_4:Create(v140, TweenInfo.new(p139.ScreenFlashTime, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["BackgroundTransparency"] = 1
	}):Play()
end
local function v_u_156(p143, p_u_144) -- name: neonBurst
	-- upvalues: (ref) v_u_11, (copy) v_u_5, (copy) v_u_4
	local v_u_145 = p143.model:Clone()
	v_u_145.Name = "EggNeonBurst"
	local v_u_146 = {}
	for _, v147 in v_u_145:GetDescendants() do
		if v147:IsA("BasePart") then
			v147.Material = Enum.Material.Neon
			v147.Color = p_u_144.TapGhostColor
			if v147:IsA("MeshPart") then
				v147.TextureID = ""
			end
			v147.CastShadow = false
			v147.Transparency = p_u_144.TapGhostTransparency
			table.insert(v_u_146, v147)
		else
			if v147:IsA("JointInstance") or v147:IsA("WeldConstraint") then
				continue
			end
			v147:Destroy()
		end
	end
	local v148 = v_u_11
	if v148 == nil or v148.Parent == nil then
		v148 = Instance.new("Folder")
		v148.Name = "SpawnedEggs"
		v148.Parent = v_u_5
		v_u_11 = v148
	end
	v_u_145.Parent = v148
	local v_u_149 = v_u_145:GetScale()
	local v_u_150 = Instance.new("NumberValue")
	v_u_150.Changed:Connect(function(p151)
		-- upvalues: (copy) v_u_145, (copy) v_u_149, (copy) p_u_144, (copy) v_u_146
		if v_u_145.Parent ~= nil then
			v_u_145:ScaleTo(v_u_149 * ((p_u_144.TapGhostScale - 1) * p151 + 1))
			local v152 = p_u_144.TapGhostTransparency
			local v153 = v152 + (1 - v152) * p151
			for _, v154 in v_u_146 do
				v154.Transparency = v153
			end
		end
	end)
	local v155 = v_u_4:Create(v_u_150, TweenInfo.new(p_u_144.TapGhostTime, Enum.EasingStyle.Quart, Enum.EasingDirection.Out), {
		["Value"] = 1
	})
	v155.Completed:Once(function()
		-- upvalues: (copy) v_u_145, (copy) v_u_150
		v_u_145:Destroy()
		v_u_150:Destroy()
	end)
	v155:Play()
end
local function v_u_160(p157) -- name: ensureHighlight
	local v158 = p157.highlight
	if v158 == nil then
		local v159 = p157.settings
		v158 = Instance.new("Highlight")
		v158.FillColor = v159.HighlightColor
		v158.OutlineColor = v159.OutlineColor
		v158.FillTransparency = 1
		v158.OutlineTransparency = v159.OutlineTransparency
		v158.DepthMode = Enum.HighlightDepthMode.Occluded
		v158.Adornee = p157.egg.rig.model
		v158.Parent = p157.egg.rig.model
		p157.highlight = v158
	end
	return v158
end
local function v_u_166(p161) -- name: finish
	-- upvalues: (copy) v_u_12, (copy) v_u_142
	for _, v162 in p161.attachments do
		v162:Destroy()
	end
	p161.trail:Destroy()
	p161.egg.rig.model:Destroy()
	local v163 = p161.egg
	local v164 = table.find(v_u_12, v163)
	if v164 then
		table.remove(v_u_12, v164)
	end
	local v165 = p161.batch
	v165.remaining = v165.remaining - 1
	if p161.batch.remaining <= 0 then
		v_u_142(p161.settings)
	end
end
local function v_u_294(p167) -- name: step
	-- upvalues: (copy) v_u_8, (copy) v_u_13, (copy) v_u_4, (copy) v_u_109, (copy) v_u_160, (copy) v_u_121, (copy) v_u_156, (copy) v_u_6, (copy) v_u_137, (copy) v_u_5, (copy) v_u_1, (copy) v_u_166, (copy) v_u_78, (copy) v_u_79, (ref) v_u_14
	local v168 = os.clock()
	local v169 = v_u_8.Character
	if v169 then
		v169 = v169:FindFirstChild("HumanoidRootPart")
	end
	local v170
	if v169 and v169:IsA("BasePart") then
		v170 = v169.Position
	else
		v170 = nil
	end
	for v171 = #v_u_13, 1, -1 do
		local v172 = v_u_13[v171]
		local v173 = v172.settings
		local v174 = v172.egg.rig
		if v174.model.Parent == nil or v172.egg.removed then
			table.remove(v_u_13, v171)
		else
			local v175 = v172.landedAt
			if v175 == nil then
				local v176 = (v168 - v172.started) / v173.FlightTime
				local v177 = v173.FlightStyle
				local v178 = v173.FlightDirection
				local v179 = v_u_4:GetValue(math.clamp(v176, 0, 1), v177, v178)
				local v180 = v173.FlyScale * v179
				local v181 = math.max(v180, 0.01)
				local v182 = v172.baseSize * v181
				local v183 = v172.p0
				local v184 = v172.p1
				local v185 = v172.bottom
				local v186 = v182.Y / 2
				local v187 = v185 + Vector3.new(0, v186, 0)
				local v188 = 1 - v179
				local v189 = v183 * (v188 * v188) + v184 * (v188 * 2 * v179) + v187 * (v179 * v179)
				local v190 = 6.283185307179586 * v173.Flips * math.clamp(v176, 0, 1)
				v_u_109(v174, CFrame.new(v189) * CFrame.fromAxisAngle(v172.flipAxis, v190) * v172.yaw * CFrame.new(0, -v182.Y / 2, 0), v181, v181, true)
				local v191 = v182.X * v172.settings.TrailWidth / 2
				local v192 = v172.attachments[1]
				local v193 = -v191
				v192.Position = Vector3.new(v193, 0, 0)
				v172.attachments[2].Position = Vector3.new(v191, 0, 0)
				v_u_160(v172)
				if v176 < 1 then
					continue
				end
				v172.landedAt = v168
				v172.trail.Enabled = false
				for _, v194 in v174.effects do
					if not v194.Parent then
						continue
					end
					v194.Enabled = true
				end
				v_u_160(v172)
				v172.flashAt = v168
				local v195 = v172.baseSize.Y * v173.FlyScale
				local v196 = v_u_121
				local v197 = v172.bottom
				local v198 = v195 / 2
				v196(v197 + Vector3.new(0, v198, 0), v195 * 0.8, v195 * v173.LandRingScale, v173)
			else
				local v199 = v168 - v175
				if v172.egg.forceBreak and v199 < v172.finaleAt then
					v172.finaleAt = v199
				end
				local v200
				if v199 < v173.ShakeTime then
					local v201 = v173.LandLean
					local v202 = math.rad(v201)
					local v203 = -v173.ShakeDamping * v199
					local v204 = v202 * math.exp(v203)
					local v205 = 6.283185307179586 * v173.ShakeFrequency * v199
					v200 = v204 * math.sin(v205)
				else
					v200 = 0
				end
				local v206 = v173.FlyScale
				local v207 = v173.Surges
				local v208 = v172.surgeTimes[1]
				local v209 = v199 - v208
				local v210 = v172.finaleAt - v208
				local v211 = v209 / math.max(v210, 0.01)
				local v212 = math.clamp(v211, 0, 1)
				if v173.SitTime <= v199 then
					local v213 = v172.spin
					local v214 = v173.SpinStart
					local v215 = v173.SpinMax
					local v216 = v212 * v212
					v172.spin = v213 + (v214 + (v215 - v214) * v216) * p167
				end
				local v217 = 0
				for v218 = v207, 1, -1 do
					if v172.surgeTimes[v218] > v199 then
						continue
					end
					v217 = v218
				end
				while v172.surgesShown < v217 do
					v172.surgesShown = v172.surgesShown + 1
					v172.flashAt = v168
					v_u_156(v174, v173)
					for _, v219 in v174.impacts do
						local v220 = v219:GetAttribute("EmitCount")
						v219:Emit(typeof(v220) ~= "number" and 1 or v220)
					end
					if v173.SurgeSound then
						v_u_6.PlayOn(v174.root, v173.SurgeSound, v173.SurgeSoundFolder, v173.SurgePitchStart + v173.SurgePitchStep * (v172.surgesShown - 1))
					end
					local v221 = v172.baseSize.Y * v206
					local v222 = v_u_121
					local v223 = v172.bottom
					local v224 = v221 / 2
					v222(v223 + Vector3.new(0, v224, 0), v221 * 0.9, v221 * v173.SurgeRingScale, v173)
				end
				local v225 = CFrame.identity
				local v226 = 1
				local v227 = 1
				local v228
				if v217 > 0 and v199 < v172.finaleAt then
					local v229 = v199 - v172.surgeTimes[v217]
					local v230 = v207 <= 1 and 1 or (v217 - 1) / (v207 - 1)
					local v231 = v172.surgeSeeds[v217]
					local v232 = Vector3.new(0, 0, -1)
					if v170 then
						local v233 = v170.X - v172.bottom.X
						local v234 = v170.Z - v172.bottom.Z
						local v235 = Vector3.new(v233, 0, v234)
						if v235.Magnitude > 0.001 then
							v232 = v235.Unit
						end
					end
					local v236 = v217 % 2 == 0 and -1 or 1
					local v237 = -v173.SurgeShakeDamping * v229
					local v238 = v236 * math.exp(v237)
					local v239 = 6.283185307179586 * v173.SurgeShakeFrequency * v229
					local v240 = v238 * math.cos(v239)
					local v241 = v173.SurgeShakeStart
					local v242 = (v241 + (v173.SurgeShakeEnd - v241) * v230) * v231
					local v243 = math.rad(v242) * v240
					v225 = CFrame.fromAxisAngle(v232, v243)
					v228 = (Vector3.new(0, 1, 0)):Cross(v232) * (v173.SurgeShakeNudge * (v230 * 0.6 + 0.4) * v231 * v172.baseSize.Y * v240)
					local v244 = v229 / v173.SurgeSquishTime
					if v244 < 1 then
						local v245 = (1 - v244) ^ 3
						local v246 = v173.SurgeSizeDownStart
						local v247 = (v246 + (v173.SurgeSizeDownEnd - v246) * v230) * v231
						local v248 = v173.SurgeSquishStart
						local v249 = (v248 + (v173.SurgeSquishEnd - v248) * v230) * v231
						local v250 = 1 - v247 * v245
						v226 = v250 * (1 + v249 * 0.6 * v245)
						v227 = v250 * (1 - v249 * v245)
					end
				else
					v228 = Vector3.new(0, 0, 0)
				end
				local v251 = v_u_160(v172)
				local v252 = v206 * v226
				local v253 = v206 * v227
				local v254 = v199 - v172.finaleAt
				local v255
				if v254 >= 0 then
					local v256 = v254 / v173.FinalFillTime
					local v257 = v173.FinalFillStyle
					local v258 = v173.FinalFillDirection
					v255 = 1 - v_u_4:GetValue(math.clamp(v256, 0, 1), v257, v258)
					if not v172.finaleSounded then
						v172.finaleSounded = true
						if v173.FinaleSound then
							v_u_6.PlayAt(v174.model:GetPivot().Position, v173.FinaleSound, v173.FinaleSoundFolder)
						end
					end
					local v259 = v173.SquishTime
					local v260 = v259 + v173.StretchTime
					local v261 = v260 + v173.VanishTime
					if v254 < v259 then
						local v262 = v254 / v173.SquishTime
						local v263 = Enum.EasingStyle.Quad
						local v264 = Enum.EasingDirection.Out
						local v265 = v_u_4:GetValue(math.clamp(v262, 0, 1), v263, v264)
						v252 = (1 + v173.SquishWiden - 1) * v265 + 1
						v253 = (1 - v173.SquishFlatten - 1) * v265 + 1
					elseif v254 < v260 then
						local v266 = (v254 - v259) / v173.StretchTime
						local v267 = Enum.EasingStyle.Back
						local v268 = Enum.EasingDirection.Out
						local v269 = v_u_4:GetValue(math.clamp(v266, 0, 1), v267, v268)
						local v270 = 1 + v173.SquishWiden
						v252 = v270 + (1 - v173.StretchThin - v270) * v269
						local v271 = 1 - v173.SquishFlatten
						v253 = v271 + (1 + v173.StretchTall - v271) * v269
					else
						if not v172.burst then
							v172.burst = true
							local v272 = v172.baseSize.Y
							local v273 = v172.bottom
							local v274 = v272 / 2
							local v275 = v273 + Vector3.new(0, v274, 0)
							v_u_121(v275, v272, v272 * v173.HatchRingScale, v173)
							v_u_137(v275, v272, v173)
							local v276 = v174.openEffect
							if v276 then
								local v277 = v276:Clone()
								local v278 = 0
								for _, v279 in v277:GetDescendants() do
									if not v279:IsA("ParticleEmitter") then
										continue
									end
									local v280 = v279.Lifetime.Max
									v278 = math.max(v278, v280)
								end
								v277.Parent = v_u_5.Terrain
								v277.WorldPosition = v275
								v_u_1:AddItem(v277, v278 + 0.5)
								for _, v281 in v277:GetDescendants() do
									if not v281:IsA("ParticleEmitter") then
										continue
									end
									v281.Enabled = false
									local v282 = v281:GetAttribute("EmitCount")
									v281:Emit(typeof(v282) ~= "number" and 1 or v282)
								end
							end
							for _, v283 in v174.breakBursts do
								local v284 = v283:Clone()
								v284.Enabled = false
								local v285 = v284.Lifetime.Max + 0.5
								local v286 = Instance.new("Attachment")
								v286.Name = "EggFX"
								v286.WorldPosition = v275
								v286.Parent = v_u_5.Terrain
								v_u_1:AddItem(v286, v285)
								v284.Parent = v286
								local v287 = v283:GetAttribute("EmitCount")
								v284:Emit(typeof(v287) ~= "number" and 1 or v287)
							end
							for _, v288 in v173.HatchSounds do
								v_u_6.PlayAt(v275, v288, v173.HatchSoundFolder)
							end
							if v172.onHatch then
								task.spawn(v172.onHatch, v172.index, v172.bottom, v172.yaw, v272)
							end
						end
						local v289 = (v254 - v260) / v173.VanishTime
						local v290 = Enum.EasingStyle.Back
						local v291 = Enum.EasingDirection.In
						local v292 = 1 - v_u_4:GetValue(math.clamp(v289, 0, 1), v290, v291)
						local v293 = math.max(v292, 0)
						v252 = (1 - v173.StretchThin) * v293
						v253 = (1 + v173.StretchTall) * v293
					end
					if v261 <= v254 then
						v_u_166(v172)
						table.remove(v_u_13, v171)
					else
						if v172.fill ~= v255 then
							v172.fill = v255
							v251.FillTransparency = v255
						end
						v_u_109(v174, CFrame.new(v172.bottom + v228) * CFrame.fromAxisAngle(v172.flipAxis, v200) * v225 * v172.yaw * CFrame.Angles(0, v172.spin, 0), math.max(v252, 0.001), math.max(v253, 0.001), true)
					end
				else
					v255 = 1
					if v172.fill ~= v255 then
						v172.fill = v255
						v251.FillTransparency = v255
					end
					v_u_109(v174, CFrame.new(v172.bottom + v228) * CFrame.fromAxisAngle(v172.flipAxis, v200) * v225 * v172.yaw * CFrame.Angles(0, v172.spin, 0), math.max(v252, 0.001), math.max(v253, 0.001), true)
				end
			end
		end
	end
	if #v_u_78 > 0 then
		v_u_5:BulkMoveTo(v_u_78, v_u_79, Enum.BulkMoveMode.FireCFrameChanged)
		table.clear(v_u_78)
		table.clear(v_u_79)
	end
	if #v_u_13 == 0 and v_u_14 then
		v_u_14:Disconnect()
		v_u_14 = nil
	end
end
local function v_u_298(p295) -- name: trimOldest
	-- upvalues: (copy) v_u_12
	local v296 = #v_u_12 - p295.MaxEggs
	for _, v297 in v_u_12 do
		if v296 <= 0 then
			break
		end
		if v297.forceBreak then
			continue
		end
		v297.forceBreak = true
		v296 = v296 - 1
	end
end
local function v_u_335(p_u_299, p300, p301, p302) -- name: makeGround
	-- upvalues: (ref) v_u_11, (copy) v_u_5, (copy) v_u_2
	local v_u_303 = p302.MaxStepUp or 2
	local v_u_304 = p302.MaxStepDown or 6
	local v305 = {}
	local v306 = v_u_11
	if v306 == nil or v306.Parent == nil then
		v306 = Instance.new("Folder")
		v306.Name = "SpawnedEggs"
		v306.Parent = v_u_5
		v_u_11 = v306
	end
	__set_list(v305, 1, {v306})
	for _, v307 in v_u_2:GetPlayers() do
		if not v307.Character then
			continue
		end
		local v308 = v307.Character
		table.insert(v305, v308)
	end
	local v_u_309 = RaycastParams.new()
	v_u_309.FilterType = Enum.RaycastFilterType.Exclude
	v_u_309.FilterDescendantsInstances = v305
	v_u_309.RespectCanCollide = true
	local v_u_310 = OverlapParams.new()
	v_u_310.FilterType = Enum.RaycastFilterType.Exclude
	v_u_310.FilterDescendantsInstances = v305
	v_u_310.RespectCanCollide = true
	local v311 = p301 * 0.5
	local v_u_312 = math.min(v_u_303, v311)
	local v313 = p300 * 0.8
	local v314 = p301 - v_u_312
	local v315 = p300 * 0.8
	local v_u_316 = Vector3.new(v313, v314, v315)
	local v_u_317 = {}
	return function(p318, p319)
		-- upvalues: (copy) v_u_317, (copy) p_u_299, (copy) v_u_303, (ref) v_u_5, (copy) v_u_304, (copy) v_u_309, (copy) v_u_312, (copy) v_u_316, (copy) v_u_310
		local v320 = string.format
		local v321 = p318 * 2
		local v322 = math.round(v321)
		local v323 = p319 * 2
		local v324 = v320("%d,%d", v322, (math.round(v323)))
		local v325 = v_u_317[v324]
		if v325 ~= nil then
			return v325 or nil
		end
		local v326 = false
		local v327 = p_u_299 + v_u_303
		local v328 = Vector3.new(p318, v327, p319)
		local v329 = v_u_5
		local v330 = -(v_u_303 + v_u_304)
		local v331 = v329:Raycast(v328, Vector3.new(0, v330, 0), v_u_309)
		local v332
		if v331 then
			v332 = v331.Position.Y
			local v333 = v332 + v_u_312 + v_u_316.Y / 2
			local v334 = Vector3.new(p318, v333, p319)
			if #v_u_5:GetPartBoundsInBox(CFrame.new(v334), v_u_316, v_u_310) ~= 0 then
				v332 = v326
			end
		else
			v332 = v326
		end
		v_u_317[v324] = v332
		return v332 or nil
	end
end
local function v_u_389(p336, p337, p_u_338, p_u_339, p340, p_u_341) -- name: chooseSpots
	-- upvalues: (copy) v_u_12, (copy) v_u_10
	local v342 = p_u_338 * 2 * p_u_341.Spacing
	local v_u_343 = {}
	for _, v344 in v_u_12 do
		local v345 = {
			["rest"] = v344.rest,
			["radius"] = v344.radius
		}
		table.insert(v_u_343, v345)
	end
	local v346 = v_u_10:NextNumber(0, 6.283185307179586)
	local v347 = p_u_341.Radius
	local function v354(p348) -- name: isFree
		-- upvalues: (copy) v_u_343, (copy) p_u_338, (copy) p_u_341, (copy) p_u_339
		for _, v349 in v_u_343 do
			local v350 = v349.rest
			if Vector2.new(p348.X - v350.X, p348.Z - v350.Z).Magnitude >= (p_u_338 + v349.radius) * p_u_341.Clearance then
				continue
			end
			return nil
		end
		local v351 = p_u_339(p348.X, p348.Z)
		if not v351 then
			return nil
		end
		local v352 = p348.X
		local v353 = p348.Z
		return Vector3.new(v352, v351, v353)
	end
	local v355 = {}
	for _ = 1, p_u_341.MaxRings do
		local v356 = p337 - #v355
		if v356 <= 0 then
			break
		end
		local v357 = 6.283185307179586 * v347 / v342
		local v358 = math.floor(v357)
		local v359 = math.max(v358, 1)
		local v360 = 6.283185307179586 / v359
		local v361 = {}
		for v362 = 0, 5 do
			local v363 = {}
			for v364 = 0, v359 - 1 do
				local v365 = v346 + (v364 + v362 / 6) * v360
				local v366 = math.cos(v365)
				local v367 = math.sin(v365)
				local v368 = v354(p336 + Vector3.new(v366, 0, v367) * v347)
				if not v368 then
					continue
				end
				table.insert(v363, v368)
			end
			if #v363 <= #v361 then
				v363 = v361
			end
			if #v363 == v359 then
				v361 = v363
				break
			end
			v361 = v363
		end
		local v369 = #v361
		local v370 = math.min(v356, v369)
		for v371 = 0, v370 - 1 do
			local v372 = v371 * #v361 / v370
			local v373 = v361[math.floor(v372) + 1]
			table.insert(v355, v373)
			table.insert(v_u_343, {
				["rest"] = v373,
				["radius"] = p_u_338
			})
		end
		v347 = v347 + v342
	end
	local v374 = p337 - #v355
	local v375 = #v355
	for v376 = 1, v374 do
		local v377 = v346 + (v376 - 1) / v374 * 6.283185307179586
		local v378 = math.cos(v377)
		local v379 = math.sin(v377)
		local v380 = p336 + Vector3.new(v378, 0, v379) * v347
		local v381 = p_u_339(v380.X, v380.Z)
		if v381 then
			local v382 = v380.X
			local v383 = v380.Z
			local v384 = Vector3.new(v382, v381, v383)
			table.insert(v355, v384)
		elseif v375 > 0 then
			local v385 = v355[(v376 - 1) % v375 + 1]
			table.insert(v355, v385)
		else
			local v386 = p336.X
			local v387 = p336.Z
			local v388 = Vector3.new(v386, p340, v387)
			table.insert(v355, v388)
		end
	end
	return v355
end
local function v_u_395(p390, p_u_391) -- name: makeTrail
	local v392 = Instance.new("Attachment")
	v392.Name = "EggTrail0"
	v392.Parent = p390
	local v393 = Instance.new("Attachment")
	v393.Name = "EggTrail1"
	v393.Parent = p390
	local v_u_394 = Instance.new("Trail")
	v_u_394.Name = "EggTrail"
	v_u_394.Attachment0 = v392
	v_u_394.Attachment1 = v393
	v_u_394.Color = ColorSequence.new(p_u_391.TrailColor)
	v_u_394.LightEmission = 1
	v_u_394.LightInfluence = 0
	v_u_394.FaceCamera = true
	v_u_394.Lifetime = p_u_391.TrailLifetime
	v_u_394.MinLength = 0.05
	v_u_394.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, p_u_391.TrailTransparency), NumberSequenceKeypoint.new(1, 1) })
	v_u_394.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
	pcall(function()
		-- upvalues: (copy) v_u_394, (copy) p_u_391
		v_u_394.Brightness = p_u_391.TrailBrightness
	end)
	v_u_394.Parent = p390
	return v_u_394, { v392, v393 }
end
function v9.Spawn(p396, p397, p_u_398, p_u_399) -- name: Spawn
	-- upvalues: (copy) v_u_8, (copy) v_u_77, (copy) v_u_6, (copy) v_u_335, (copy) v_u_389, (copy) v_u_12, (copy) v_u_298, (copy) v_u_109, (ref) v_u_11, (copy) v_u_5, (copy) v_u_395, (copy) v_u_13, (copy) v_u_10, (ref) v_u_14, (copy) v_u_3, (copy) v_u_294
	local v400 = v_u_8.Character
	local v_u_401
	if v400 then
		v_u_401 = v400:FindFirstChild("HumanoidRootPart")
	else
		v_u_401 = v400
	end
	if v400 and (v_u_401 and (v_u_401:IsA("BasePart") and p397 > 0)) then
		local v402 = v400:FindFirstChildOfClass("Humanoid")
		local v403 = v_u_77(p396, p_u_398)
		if v403 == nil then
			warn("[EggSpawnFX] egg template has no parts")
		else
			local v404 = v403.width
			local v405 = v403.height
			local v406 = v403.width
			local v_u_407 = Vector3.new(v404, v405, v406)
			local v408 = v403.width / 2
			local v_u_409 = v_u_401.Position
			local v410 = v_u_409.Y - v_u_401.Size.Y / 2 - (not v402 and 2 or v402.HipHeight)
			local v_u_411 = p_u_398.SitTime
			local v412 = p_u_398.SurgeFirstGap
			local v_u_413 = {}
			for v414 = 1, p_u_398.Surges do
				v_u_413[v414] = v_u_411
				v_u_411 = v_u_411 + v412
				v412 = v412 * p_u_398.SurgeSpeedup
			end
			local v_u_415 = {
				["remaining"] = p397
			}
			if p_u_398.RollSound then
				local v416 = os.clock()
				local v_u_417 = v416 + p_u_398.FlightTime + p_u_398.SitTime
				local v_u_418 = v416 + (p397 - 1) * p_u_398.Stagger + p_u_398.FlightTime + v_u_411
				task.spawn(function()
					-- upvalues: (copy) v_u_417, (copy) v_u_418, (copy) p_u_398, (ref) v_u_6, (copy) v_u_409
					local v419 = os.clock()
					if v419 < v_u_417 then
						task.wait(v_u_417 - v419)
					end
					local v420 = v_u_418 - v_u_417
					local v421 = math.max(v420, 0.01)
					local v422 = {}
					while os.clock() < v_u_418 do
						local v423 = (os.clock() - v_u_417) / v421
						local v424 = math.clamp(v423, 0, 1) ^ p_u_398.RollCurve
						local v425 = v_u_6.PlayAt
						local v426 = v_u_409
						local v427 = p_u_398.RollSound
						local v428 = p_u_398.RollSoundFolder
						local v429 = p_u_398.RollPitchStart
						local v430 = v425(v426, v427, v428, v429 + (p_u_398.RollPitchEnd - v429) * v424)
						if v430 then
							local v431 = v430.Volume
							local v432 = p_u_398.RollVolumeStart
							v430.Volume = v431 * (v432 + (p_u_398.RollVolumeEnd - v432) * v424)
							table.insert(v422, v430)
							while #v422 > p_u_398.RollMaxVoices do
								local v433 = table.remove(v422, 1)
								if not v433.Parent then
									continue
								end
								v433:Destroy()
							end
						end
						local v434 = task.wait
						local v435 = p_u_398.RollStartInterval
						v434(v435 + (p_u_398.RollEndInterval - v435) * v424)
					end
				end)
			end
			local v436 = {}
			for v437, v438 in v_u_389(v_u_409, p397, v408, v_u_335(v410, v403.width, v403.height, p_u_398), v410, p_u_398) do
				local v439 = v438.Y
				local v440
				if v437 == 1 then
					v440 = v403
				else
					v440 = v_u_77(p396, p_u_398)
				end
				local v441 = {
					["rig"] = nil,
					["rest"] = nil,
					["radius"] = nil,
					["removed"] = false,
					["forceBreak"] = false,
					["rig"] = v440
				}
				local v442 = v438.X
				local v443 = v439 + v_u_407.Y / 2
				local v444 = v438.Z
				v441.rest = Vector3.new(v442, v443, v444)
				v441.radius = v408
				local v445 = v_u_12
				table.insert(v445, v441)
				v436[v437] = v441
			end
			v_u_298(p_u_398)
			for v_u_446, v_u_447 in v436 do
				task.delay((v_u_446 - 1) * p_u_398.Stagger, function()
					-- upvalues: (copy) v_u_447, (copy) v_u_401, (ref) v_u_12, (copy) v_u_415, (copy) p_u_398, (copy) v_u_407, (ref) v_u_109, (ref) v_u_11, (ref) v_u_5, (ref) v_u_395, (ref) v_u_13, (copy) v_u_413, (ref) v_u_10, (copy) v_u_411, (copy) v_u_446, (copy) p_u_399, (ref) v_u_14, (ref) v_u_3, (ref) v_u_294, (ref) v_u_6
					if v_u_447.removed or v_u_401.Parent == nil then
						v_u_447.rig.model:Destroy()
						local v448 = v_u_447
						local v449 = table.find(v_u_12, v448)
						if v449 then
							table.remove(v_u_12, v449)
						end
						local v450 = v_u_415
						v450.remaining = v450.remaining - 1
					else
						local v451 = v_u_447.rig
						local v452 = v_u_401.Position
						local v453 = p_u_398.OriginRise
						local v454 = v452 + Vector3.new(0, v453, 0)
						local v455 = v_u_447.rest
						local v456 = v_u_407.Y / 2
						local v457 = v455 - Vector3.new(0, v456, 0)
						local v458 = (v454 + v457) / 2
						local v459 = p_u_398.ArcHeight + Vector2.new(v454.X - v457.X, v454.Z - v457.Z).Magnitude * 0.25
						local v460 = v458 + Vector3.new(0, v459, 0)
						local v461 = v457.X - v454.X
						local v462 = v457.Z - v454.Z
						local v463 = Vector3.new(v461, 0, v462)
						local v464 = v463.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v463.Unit
						local v465 = CFrame.lookAt(Vector3.new(0, 0, 0), v464).Rotation
						v_u_109(v451, CFrame.new(v454) * v465, 0.01, 0.01)
						local v466 = v451.model
						local v467 = v_u_11
						if v467 == nil or v467.Parent == nil then
							v467 = Instance.new("Folder")
							v467.Name = "SpawnedEggs"
							v467.Parent = v_u_5
							v_u_11 = v467
						end
						v466.Parent = v467
						local v468, v469 = v_u_395(v451.root, p_u_398)
						local v470 = v_u_13
						local v471 = {
							["egg"] = nil,
							["baseSize"] = nil,
							["p0"] = nil,
							["p1"] = nil,
							["bottom"] = nil,
							["yaw"] = nil,
							["flipAxis"] = nil,
							["trail"] = nil,
							["attachments"] = nil,
							["highlight"] = nil,
							["fill"] = 1,
							["started"] = nil,
							["landedAt"] = nil,
							["spin"] = 0,
							["surgeTimes"] = nil,
							["surgeSeeds"] = nil,
							["surgesShown"] = 0,
							["finaleAt"] = nil,
							["flashAt"] = (-1 / 0),
							["burst"] = false,
							["finaleSounded"] = false,
							["batch"] = nil,
							["settings"] = nil,
							["index"] = nil,
							["onHatch"] = nil,
							["egg"] = v_u_447,
							["baseSize"] = v_u_407,
							["p0"] = v454,
							["p1"] = v460,
							["bottom"] = v457,
							["yaw"] = v465,
							["flipAxis"] = (Vector3.new(0, 1, 0)):Cross(v464),
							["trail"] = v468,
							["attachments"] = v469,
							["started"] = os.clock(),
							["surgeTimes"] = v_u_413
						}
						local v472 = {}
						for v473 = 1, p_u_398.Surges do
							v472[v473] = v_u_10:NextNumber(p_u_398.SurgeRandomMin, p_u_398.SurgeRandomMax)
						end
						v471.surgeSeeds = v472
						v471.finaleAt = v_u_411
						v471.batch = v_u_415
						v471.settings = p_u_398
						v471.index = v_u_446
						v471.onHatch = p_u_399
						table.insert(v470, v471)
						if v_u_14 == nil then
							v_u_14 = v_u_3.RenderStepped:Connect(v_u_294)
						end
						if p_u_398.PopSound then
							local v474 = p_u_398.PitchStart + p_u_398.PitchStep * (v_u_446 - 1)
							local v475 = p_u_398.PitchMax
							local v476 = math.min(v474, v475)
							v_u_6.PlayOn(v451.root, p_u_398.PopSound, p_u_398.PopSoundFolder, v476)
						end
					end
				end)
			end
		end
	else
		return
	end
end
return v9
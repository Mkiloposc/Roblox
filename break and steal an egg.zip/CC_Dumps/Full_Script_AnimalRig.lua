local v_u_1 = game:GetService("PhysicsService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Shared.AnimalWalker)
local v_u_4 = require(v2.Shared.CollisionGroups)
local v_u_5 = require(v2.Shared.WaitFor)
local v_u_6 = {}
local v_u_7 = {
	["HumanoidRootPart"] = true,
	["BodyHitbox"] = true,
	["BodyCenter"] = true,
	["MouthPoint"] = true,
	["BillboardAnchor"] = true,
	["FloorPoint"] = true
}
local v_u_8 = PhysicalProperties.new(0.7, 1, 0, 10, 0)
local v_u_9 = false
local function v_u_12(p_u_10) -- name: assignGroup
	-- upvalues: (copy) v_u_4, (ref) v_u_9
	local function v11()
		-- upvalues: (copy) p_u_10, (ref) v_u_4
		p_u_10.CollisionGroup = v_u_4.Animals
	end
	if not (pcall(v11) or v_u_9) then
		v_u_9 = true
		warn(("[AnimalRig] collision group \"%*\" is not registered yet; "):format(v_u_4.Animals) .. "animals will collide with each other until CollisionGroupService runs")
	end
end
function v_u_6.WaitForCollisionGroups(p13) -- name: WaitForCollisionGroups
	-- upvalues: (copy) v_u_5, (copy) v_u_1, (copy) v_u_4
	v_u_5.Until(function()
		-- upvalues: (ref) v_u_1, (ref) v_u_4
		local function v14()
			-- upvalues: (ref) v_u_1, (ref) v_u_4
			return v_u_1:IsCollisionGroupRegistered(v_u_4.Animals)
		end
		local v15, v16 = pcall(v14)
		return not v15 or v16
	end, p13 or 5)
end
function v_u_6.ResolveMesh(p17) -- name: ResolveMesh
	-- upvalues: (copy) v_u_3, (copy) v_u_7
	local v18 = v_u_3.Find(p17)
	local v19 = p17.PrimaryPart
	if v19 ~= nil and not v_u_7[v19.Name] then
		local v20
		if v18 == nil then
			v20 = false
		else
			v20 = v19:IsDescendantOf(v18)
		end
		if not v20 then
			return v19
		end
	end
	local v21 = -1
	local v22 = nil
	for _, v23 in ipairs(p17:GetDescendants()) do
		if not v23:IsA("BasePart") or v_u_7[v23.Name] then
			continue
		end
		local v24
		if v18 == nil then
			v24 = false
		else
			v24 = v23:IsDescendantOf(v18)
		end
		if v24 then
			continue
		end
		local v25 = v23.Size
		local v26 = v25.X * v25.Y * v25.Z
		if v21 >= v26 then
			continue
		end
		v22 = v23
		v21 = v26
	end
	return v22
end
local function v_u_32(p27, p28) -- name: ensureWeld
	for _, v29 in ipairs(p28:GetChildren()) do
		if not v29:IsA("WeldConstraint") or (v29.Part0 ~= p27 or v29.Part1 ~= p28) and (v29.Part0 ~= p28 or v29.Part1 ~= p27) then
			continue
		end
		return
	end
	for _, v30 in ipairs(p28:GetChildren()) do
		if not v30:IsA("Motor6D") or (v30.Part0 ~= p27 or v30.Part1 ~= p28) and (v30.Part0 ~= p28 or v30.Part1 ~= p27) then
			continue
		end
		return
	end
	local v31 = Instance.new("WeldConstraint")
	v31.Name = "RigWeld"
	v31.Part0 = p27
	v31.Part1 = p28
	v31.Parent = p28
end
local function v_u_41(p33, p34) -- name: buildRoot
	-- upvalues: (copy) v_u_32, (copy) v_u_12
	local v35 = p33:FindFirstChild("HumanoidRootPart")
	if v35 ~= nil and v35:IsA("BasePart") then
		v_u_32(v35, p34)
		return v35
	end
	local v36 = p34.Position.Y - p34.Size.Y * 0.5
	local v37 = Instance.new("Part")
	v37.Name = "HumanoidRootPart"
	local v38 = p34.Size.X
	local v39 = p34.Size.Z
	v37.Size = Vector3.new(v38, 1, v39)
	v37.CFrame = p34.CFrame
	v37.Transparency = 1
	v37.CanQuery = false
	v37.CanTouch = false
	v37.Parent = p33
	v_u_32(v37, p34)
	local v40 = Instance.new("Part")
	v40.Name = "FloorPoint"
	v40.Size = Vector3.new(0.2, 0.2, 0.2)
	v40.CFrame = CFrame.new(p34.Position.X, v36, p34.Position.Z)
	v40.Transparency = 1
	v40.Anchored = false
	v40.CanCollide = false
	v40.CanQuery = false
	v40.CanTouch = false
	v40.Massless = true
	v40.Parent = p33
	v_u_32(v37, v40)
	v_u_12(v40)
	return v37
end
local v_u_42 = Vector3.new(2.05, 1.62, 2.23) / Vector3.new(2.37, 3.34, 3.98)
local v_u_43 = Vector3.new(0, 0.18, -0.11) / Vector3.new(2.37, 3.34, 3.98)
local v_u_44 = Vector3.new(0, 0.14, 0) / Vector3.new(2.37, 3.34, 3.98)
local v_u_45 = Vector3.new(0, 1.06, -1.79) / Vector3.new(2.37, 3.34, 3.98)
local v_u_46 = Vector3.new(0, 4.85, -1.04) / Vector3.new(2.37, 3.34, 3.98)
local function v_u_54(p47, p48, p49, p50, p51) -- name: buildMarker
	-- upvalues: (copy) v_u_32, (copy) v_u_12
	local v52 = p47:FindFirstChild(p49)
	if v52 ~= nil and v52:IsA("BasePart") then
		v_u_32(p48, v52)
		return v52
	end
	local v53 = Instance.new("Part")
	v53.Name = p49
	v53.Size = p50
	v53.CFrame = p48.CFrame * CFrame.new(p51)
	v53.Transparency = 1
	v53.Anchored = false
	v53.CanCollide = false
	v53.CanQuery = false
	v53.CanTouch = false
	v53.Massless = true
	v53.Parent = p47
	v_u_32(p48, v53)
	v_u_12(v53)
	return v53
end
local function v_u_59(p55, p56, p57) -- name: buildMarkers
	-- upvalues: (copy) v_u_54, (copy) v_u_42, (copy) v_u_43, (copy) v_u_44, (copy) v_u_45, (copy) v_u_46
	local v58 = p56.Size
	v_u_54(p55, p57, "BodyHitbox", v58 * v_u_42, v58 * v_u_43)
	v_u_54(p55, p57, "BodyCenter", Vector3.new(1, 1, 1) * (v58.Y * 0.29940119760479045), v58 * v_u_44)
	v_u_54(p55, p57, "MouthPoint", Vector3.new(0.2, 0.2, 0.2), v58 * v_u_45)
	v_u_54(p55, p57, "BillboardAnchor", Vector3.new(0.2, 0.2, 0.2), v58 * v_u_46)
end
local v_u_60 = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_6.Build(p61) -- name: Build
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (copy) v_u_41, (copy) v_u_7, (copy) v_u_12, (copy) v_u_8, (copy) v_u_59, (copy) v_u_60
	local v62 = v_u_3.Find(p61)
	if v62 ~= nil then
		return v_u_3.Build(p61, v62)
	end
	local v63 = v_u_6.ResolveMesh(p61)
	local v64 = ("%* has no BasePart to rig"):format((p61:GetFullName()))
	assert(v63, v64)
	local v_u_65 = v_u_41(p61, v63)
	for _, v66 in ipairs(p61:GetDescendants()) do
		if not v66:IsA("BasePart") or v66 == v_u_65 then
			continue
		end
		v66.Anchored = false
		v66.CanCollide = false
		v66.Massless = v_u_7[v66.Name] == true
		v_u_12(v66)
	end
	v_u_65.Anchored = false
	v_u_65.CanCollide = true
	v_u_65.Massless = false
	v_u_65.CustomPhysicalProperties = v_u_8
	v_u_12(v_u_65)
	p61.PrimaryPart = v_u_65
	v_u_59(p61, v63, v_u_65)
	local v_u_67 = p61:FindFirstChildOfClass("Humanoid")
	if v_u_67 == nil then
		v_u_67 = Instance.new("Humanoid")
		v_u_67.RequiresNeck = false
		v_u_67.BreakJointsOnDeath = false
		v_u_67.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
		v_u_67.HealthDisplayType = Enum.HumanoidHealthDisplayType.AlwaysOff
		v_u_67.Parent = p61
	end
	v_u_67.AutomaticScalingEnabled = false
	local v_u_68 = v63.Size.Y * 0.5 - v_u_65.Size.Y * 0.5
	if v_u_68 <= 0 then
		warn(("[AnimalRig] %*: computed HipHeight %* from mesh \"%*\" "):format(p61.Name, v_u_68, v63.Name) .. ("(height %*) and root height %*. The resolved mesh is not "):format(v63.Size.Y, v_u_65.Size.Y) .. "the body - the animal will stand in the ground.")
	end
	v_u_67.HipHeight = v_u_68
	local v69 = v_u_60[p61]
	if v69 then
		v_u_60[p61] = nil
		for _, v70 in v69 do
			v70:Disconnect()
		end
	end
	local v_u_71 = {}
	v_u_60[p61] = v_u_71
	local v72 = v_u_67:GetPropertyChangedSignal("HipHeight")
	local function v73()
		-- upvalues: (ref) v_u_67, (copy) v_u_68
		if v_u_67.HipHeight ~= v_u_68 then
			v_u_67.HipHeight = v_u_68
		end
	end
	table.insert(v_u_71, v72:Connect(v73))
	local v74 = p61.Destroying
	table.insert(v_u_71, v74:Once(function()
		-- upvalues: (copy) v_u_71
		for _, v75 in v_u_71 do
			v75:Disconnect()
		end
	end))
	p61:SetAttribute("RigHipHeight", v_u_68)
	v_u_67.AutoRotate = true
	v_u_67.PlatformStand = false
	v_u_67:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
	v_u_67:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false)
	v_u_67:SetStateEnabled(Enum.HumanoidStateType.PlatformStanding, false)
	local v76 = p61.DescendantAdded
	local function v78(p77)
		-- upvalues: (copy) v_u_65, (ref) v_u_7, (ref) v_u_12
		if p77:IsA("BasePart") and p77 ~= v_u_65 then
			p77.CanCollide = false
			p77.Massless = v_u_7[p77.Name] == true
			v_u_12(p77)
		end
	end
	table.insert(v_u_71, v76:Connect(v78))
	return v_u_67, v_u_65
end
function v_u_6.EnforcePhysics(p79) -- name: EnforcePhysics
	-- upvalues: (copy) v_u_7
	if p79:GetAttribute("RigMode") == "Walker" then
		return
	else
		local v80 = p79:FindFirstChild("HumanoidRootPart")
		if v80 ~= nil and v80:IsA("BasePart") then
			for _, v81 in ipairs(p79:GetDescendants()) do
				if not v81:IsA("BasePart") or v81 == v80 then
					continue
				end
				v81.CanCollide = false
				v81.Massless = v_u_7[v81.Name] == true
			end
			v80.CanCollide = true
			v80.Massless = false
			local v82 = p79:FindFirstChildOfClass("Humanoid")
			local v83 = p79:GetAttribute("RigHipHeight")
			if v82 ~= nil and typeof(v83) == "number" then
				v82.AutomaticScalingEnabled = false
				v82.HipHeight = v83
			end
		end
	end
end
return v_u_6
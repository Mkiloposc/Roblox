local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = require(v_u_1.Shared.AdminConchTypes)
local v_u_4 = require(v_u_1.Shared.AdminConfig)
local v_u_5 = require(v_u_1.Shared.PotionConfig)
local v_u_6 = require(script.Parent.Parent.Controllers.NotificationController)
local v_u_7 = require(script.Parent.UnitTextBox)
local v8 = {}
local v_u_9 = v_u_4.GlobalBoost
local function v_u_14(p10) -- name: idsOf
	-- upvalues: (copy) v_u_3, (copy) v_u_5
	if p10 ~= v_u_3.ALL_POTIONS then
		return { p10 }
	end
	local v11 = {}
	for _, v12 in v_u_5.Potions do
		local v13 = v12.Id
		table.insert(v11, v13)
	end
	return v11
end
local function v_u_25(p15) -- name: statusText
	-- upvalues: (copy) v_u_14, (copy) v_u_5, (copy) v_u_3, (copy) v_u_9
	local v16 = 0
	local v17 = nil
	for _, v18 in v_u_14(p15) do
		local v19 = v_u_5.GlobalRemaining(v18)
		if v16 >= v19 then
			continue
		end
		v17 = v18
		v16 = v19
	end
	if not v17 then
		return "Not running"
	end
	local v20 = string.format("%g", v_u_5.GlobalMultiplier(v17))
	if p15 == v_u_3.ALL_POTIONS then
		v17 = v_u_9.AllName
	elseif v17 == v_u_3.ALL_POTIONS then
		v17 = v_u_9.AllName
	else
		local v21 = v_u_5.ById(v17)
		if v21 then
			v17 = v21.HoverName
		end
	end
	local v22 = "<font color=\"%*\">x%* %*</font>: %* left"
	local v23
	if p15 == v_u_3.ALL_POTIONS then
		v23 = v_u_9.AllColor
	else
		local v24 = v_u_5.ById(p15)
		if v24 then
			v23 = v24.Color
		else
			v23 = v_u_5.HoverMultiplierColor
		end
	end
	return v22:format(v23, v20, v17, (v_u_5.FormatTime(v16)))
end
function v8.Bind(p_u_26, p27) -- name: Bind
	-- upvalues: (copy) v_u_4, (copy) v_u_7, (copy) v_u_9, (copy) v_u_3, (copy) v_u_5, (copy) v_u_25, (copy) v_u_2, (copy) v_u_6, (copy) v_u_1
	local v28 = p27:FindFirstChild("Boost")
	if v28 then
		v28 = v28:FindFirstChild("Pick")
	end
	local v_u_29
	if v28 then
		v_u_29 = v28:FindFirstChild("Title")
	else
		v_u_29 = v28
	end
	local v_u_30 = p27:FindFirstChild("Multiplier")
	if v_u_30 then
		v_u_30 = v_u_30:FindFirstChildWhichIsA("TextBox")
	end
	if not (v_u_30 and v_u_30:IsA("TextBox")) then
		v_u_30 = nil
	end
	local v_u_31 = p27:FindFirstChild("Duration")
	if v_u_31 then
		v_u_31 = v_u_31:FindFirstChildWhichIsA("TextBox")
	end
	if not (v_u_31 and v_u_31:IsA("TextBox")) then
		v_u_31 = nil
	end
	local v32 = p27:FindFirstChild("Start")
	local v33 = p27:FindFirstChild("End")
	local v_u_34 = p27:FindFirstChild("Timer")
	if v28 and (v28:IsA("GuiButton") and (v_u_30 and (v_u_31 and (v32 and (v32:IsA("GuiButton") and (v33 and v33:IsA("GuiButton"))))))) then
		for _, v35 in { v28, v32, v33 } do
			v35:SetAttribute("HoverScale", v_u_4.PanelHoverScale)
			v35:SetAttribute("PressScale", v_u_4.PanelPressScale)
		end
		v_u_7.BindPrefix(v_u_30, v_u_9.MultiplierPrefix)
		v_u_7.Bind(v_u_31, v_u_9.MinutesSuffix)
		local v_u_36 = 1
		if v_u_29 and v_u_29:IsA("TextLabel") then
			local v37 = v_u_9.Choices[v_u_36]
			if v37 == v_u_3.ALL_POTIONS then
				v37 = v_u_9.AllName
			else
				local v38 = v_u_5.ById(v37)
				if v38 then
					v37 = v38.HoverName
				end
			end
			v_u_29.Text = v37
			local v39 = Color3.fromHex
			local v40 = v_u_9.Choices[v_u_36]
			local v41
			if v40 == v_u_3.ALL_POTIONS then
				v41 = v_u_9.AllColor
			else
				local v42 = v_u_5.ById(v40)
				if v42 then
					v41 = v42.Color
				else
					v41 = v_u_5.HoverMultiplierColor
				end
			end
			v_u_29.TextColor3 = v39(v41)
		end
		if not (v_u_34 and v_u_34:IsA("TextLabel")) then
			v_u_34 = nil
		end
		local function v44() -- name: refreshTimer
			-- upvalues: (copy) v_u_34, (ref) v_u_25, (ref) v_u_9, (ref) v_u_36
			if v_u_34 then
				local v43 = v_u_25(v_u_9.Choices[v_u_36])
				if v_u_34.Text ~= v43 then
					v_u_34.RichText = true
					v_u_34.Text = v43
				end
			end
		end
		if v_u_34 then
			local v_u_45 = {}
			for _, v46 in v_u_5.Potions do
				local v47 = v_u_2:GetAttributeChangedSignal(v_u_5.GlobalEndsAtAttribute(v46.Id))
				table.insert(v_u_45, v47:Connect(v44))
			end
			task.spawn(function()
				-- upvalues: (copy) v_u_34, (copy) v_u_34, (ref) v_u_25, (ref) v_u_9, (ref) v_u_36, (copy) v_u_45
				while v_u_34:IsDescendantOf(game) do
					if v_u_34 then
						local v48 = v_u_25(v_u_9.Choices[v_u_36])
						if v_u_34.Text ~= v48 then
							v_u_34.RichText = true
							v_u_34.Text = v48
						end
					end
					task.wait(0.25)
				end
				for _, v49 in v_u_45 do
					v49:Disconnect()
				end
			end)
		else
			warn((("[AdminPanelBoosts] %* has no Timer label"):format((p27:GetFullName()))))
		end
		v28.Activated:Connect(function()
			-- upvalues: (ref) v_u_36, (ref) v_u_9, (copy) v_u_29, (ref) v_u_3, (ref) v_u_5, (copy) v_u_34, (ref) v_u_25
			v_u_36 = v_u_36 % #v_u_9.Choices + 1
			if v_u_29 and v_u_29:IsA("TextLabel") then
				local v50 = v_u_29
				local v51 = v_u_9.Choices[v_u_36]
				if v51 == v_u_3.ALL_POTIONS then
					v51 = v_u_9.AllName
				else
					local v52 = v_u_5.ById(v51)
					if v52 then
						v51 = v52.HoverName
					end
				end
				v50.Text = v51
				local v53 = v_u_29
				local v54 = Color3.fromHex
				local v55 = v_u_9.Choices[v_u_36]
				local v56
				if v55 == v_u_3.ALL_POTIONS then
					v56 = v_u_9.AllColor
				else
					local v57 = v_u_5.ById(v55)
					if v57 then
						v56 = v57.Color
					else
						v56 = v_u_5.HoverMultiplierColor
					end
				end
				v53.TextColor3 = v54(v56)
			end
			if v_u_34 then
				local v58 = v_u_25(v_u_9.Choices[v_u_36])
				if v_u_34.Text ~= v58 then
					v_u_34.RichText = true
					v_u_34.Text = v58
				end
			end
		end)
		local v_u_59 = false
		local function v_u_79(p_u_60) -- name: send
			-- upvalues: (ref) v_u_59, (ref) v_u_7, (copy) v_u_30, (ref) v_u_9, (ref) v_u_6, (copy) v_u_31, (ref) v_u_3, (ref) v_u_1, (ref) v_u_4, (ref) v_u_36, (copy) p_u_26, (copy) v_u_34, (ref) v_u_25
			if v_u_59 then
				return
			else
				local v_u_61, v_u_62
				if p_u_60 == "Start" then
					v_u_61 = v_u_7.PrefixNumber(v_u_30.Text, v_u_9.MultiplierPrefix)
					if not v_u_61 or v_u_61 <= 1 then
						v_u_6.Show("Type a multiplier above 1 (e.g. 2)", "Error")
						return
					end
					if v_u_9.MaxMultiplier < v_u_61 then
						v_u_6.Show(("The max multiplier is x%*"):format(v_u_9.MaxMultiplier), "Error")
						return
					end
					local v63 = v_u_31.Text
					local v64 = v_u_7.Number(v63, v_u_9.MinutesSuffix)
					if v64 then
						local v65 = v64 * 60
						v_u_62 = math.floor(v65)
					else
						v_u_62 = v_u_3.ParsePotionDuration(v63)
					end
					if not v_u_62 or v_u_62 < 1 then
						v_u_6.Show("Type how long it lasts, in minutes (e.g. 10)", "Error")
						return
					end
				else
					v_u_61 = nil
					v_u_62 = nil
				end
				local v_u_66 = v_u_1:FindFirstChild(v_u_4.PanelRemotes.GlobalBoost)
				if v_u_66 and v_u_66:IsA("RemoteFunction") then
					v_u_59 = true
					local function v73()
						-- upvalues: (copy) v_u_66, (copy) p_u_60, (ref) v_u_9, (ref) v_u_36, (ref) v_u_61, (ref) v_u_62, (ref) p_u_26
						local v67 = v_u_66
						local v68 = p_u_60
						local v69 = v_u_9.Choices[v_u_36]
						local v70 = v_u_61
						local v71 = v_u_62
						local v72 = p_u_26:GetAttribute("Scope")
						if type(v72) ~= "string" or not v_u_9.Scopes[v72] then
							v72 = v_u_9.DefaultScope
						end
						return v67:InvokeServer(v68, v69, v70, v71, v72)
					end
					local v74, v75, v76 = pcall(v73)
					v_u_59 = false
					if v74 and v75 == true then
						if type(v76) == "string" then
							v_u_6.Show(v76, "Success")
						end
					else
						local v77 = (not v74 or type(v76) ~= "string") and "something went wrong" or v76
						v_u_6.Show(("Global Boost failed: %*"):format(v77), "Error")
					end
					if v_u_34 then
						local v78 = v_u_25(v_u_9.Choices[v_u_36])
						if v_u_34.Text ~= v78 then
							v_u_34.RichText = true
							v_u_34.Text = v78
						end
					end
				else
					v_u_6.Show("Global Boosts aren\'t ready yet", "Error")
				end
			end
		end
		v32.Activated:Connect(function()
			-- upvalues: (copy) v_u_79
			task.spawn(v_u_79, "Start")
		end)
		v33.Activated:Connect(function()
			-- upvalues: (copy) v_u_79
			task.spawn(v_u_79, "End")
		end)
	else
		warn("[AdminPanelBoosts] card needs Container.Boost.Pick, Multiplier / Duration TextBoxes, Container.Start + Container.End")
	end
end
return v8
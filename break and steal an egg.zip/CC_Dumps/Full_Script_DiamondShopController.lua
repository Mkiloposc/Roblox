local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.DiamondShopConfig)
local v_u_3 = require(script.Parent.UiFrames)
local v_u_4 = require(script.Parent.NotificationController)
local v_u_5 = require(script.Parent.Parent.Modules.DiamondShop.Gui)
local v6 = require(script.Parent.Parent.Modules.DiamondShop.Diamonds)
local v7 = require(script.Parent.Parent.Modules.DiamondShop.Shop)
local v8 = require(script.Parent.Parent.Modules.DiamondShop.GemPacks)
local v9 = require(script.Parent.Parent.Modules.DiamondShop.Plots)
local v_u_10 = {
	{
		["name"] = "Shop",
		["module"] = nil,
		["module"] = v7
	},
	{
		["name"] = "GemPacks",
		["module"] = nil,
		["module"] = v8
	},
	{
		["name"] = "Plots",
		["module"] = nil,
		["module"] = v9
	},
	{
		["name"] = "DiamondsHud",
		["module"] = nil,
		["module"] = require(script.Parent.Parent.Modules.DiamondShop.DiamondsHud)
	}
}
local v11 = {
	["PurchaseRequested"] = v7.PurchaseRequested,
	["PlotEquipped"] = v9.Equipped,
	["Diamonds"] = v6
}
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = {}
local function v_u_19(p_u_15) -- name: wireCloseButtons
	-- upvalues: (copy) v_u_3
	local function v17(p16) -- name: tryWire
		-- upvalues: (ref) v_u_3, (copy) p_u_15
		if p16.Name == "Close" and p16:IsA("GuiButton") then
			p16.Activated:Connect(function()
				-- upvalues: (ref) v_u_3, (ref) p_u_15
				v_u_3.Close(p_u_15)
			end)
		end
	end
	for _, v18 in p_u_15:GetDescendants() do
		if v18.Name ~= "Close" or not v18:IsA("GuiButton") then
			continue
		end
		v18.Activated:Connect(function()
			-- upvalues: (ref) v_u_3, (copy) p_u_15
			v_u_3.Close(p_u_15)
		end)
	end
	p_u_15.DescendantAdded:Connect(v17)
end
local function v_u_25(p_u_20) -- name: adopt
	-- upvalues: (copy) v_u_2, (ref) v_u_12, (ref) v_u_13, (copy) v_u_19, (copy) v_u_3, (copy) v_u_4, (copy) v_u_14
	local v_u_21 = p_u_20:FindFirstChild("Frames")
	if v_u_21 then
		v_u_21 = v_u_21:FindFirstChild(v_u_2.ShopName)
	end
	if v_u_21 and v_u_21:IsA("GuiObject") then
		v_u_12 = p_u_20
		v_u_13 = v_u_21
		v_u_21.Visible = false
		p_u_20.Enabled = true
		v_u_19(v_u_21)
		v_u_3.Observe(v_u_21, function(p22)
			-- upvalues: (ref) v_u_13, (copy) v_u_21, (ref) v_u_4, (copy) p_u_20, (ref) v_u_14
			if v_u_13 == v_u_21 then
				if p22 then
					v_u_4.Raise(p_u_20)
				else
					v_u_4.Lower(p_u_20)
				end
				for _, v23 in v_u_14 do
					task.spawn(v23, p22)
				end
			end
		end)
		p_u_20.Destroying:Once(function()
			-- upvalues: (ref) v_u_12, (copy) p_u_20, (ref) v_u_13, (ref) v_u_4, (ref) v_u_14
			if v_u_12 == p_u_20 then
				v_u_12 = nil
				v_u_13 = nil
				v_u_4.Lower(p_u_20)
				for _, v24 in v_u_14 do
					task.spawn(v24, false)
				end
			end
		end)
	else
		warn((("[DiamondShopController] %*.Frames.%* not found"):format(p_u_20:GetFullName(), v_u_2.ShopName)))
	end
end
function v11.Open() -- name: Open
	-- upvalues: (ref) v_u_13, (copy) v_u_3
	local v26
	if v_u_13 and v_u_13.Parent then
		v26 = v_u_13
	else
		v26 = nil
	end
	if v26 then
		v_u_3.Open(v26)
	end
end
function v11.Close() -- name: Close
	-- upvalues: (ref) v_u_13, (copy) v_u_3
	local v27
	if v_u_13 and v_u_13.Parent then
		v27 = v_u_13
	else
		v27 = nil
	end
	if v27 then
		v_u_3.Close(v27)
	end
end
function v11.Toggle() -- name: Toggle
	-- upvalues: (ref) v_u_13, (copy) v_u_3
	local v28
	if v_u_13 and v_u_13.Parent then
		v28 = v_u_13
	else
		v28 = nil
	end
	if v28 then
		v_u_3.Toggle(v28)
	end
end
function v11.IsOpen() -- name: IsOpen
	-- upvalues: (ref) v_u_13, (copy) v_u_3
	local v29
	if v_u_13 and v_u_13.Parent then
		v29 = v_u_13
	else
		v29 = nil
	end
	local v30
	if v29 == nil then
		v30 = false
	else
		v30 = v_u_3.IsOpen(v29)
	end
	return v30
end
function v11.GetFrame() -- name: GetFrame
	-- upvalues: (ref) v_u_13
	if v_u_13 and v_u_13.Parent then
		return v_u_13
	else
		return nil
	end
end
function v11.Observe(p31) -- name: Observe
	-- upvalues: (copy) v_u_14
	local v32 = v_u_14
	table.insert(v32, p31)
end
function v11.Start() -- name: Start
	-- upvalues: (copy) v_u_5, (copy) v_u_25, (copy) v_u_10
	v_u_5.Observe(v_u_25)
	for _, v_u_33 in v_u_10 do
		task.spawn(function()
			-- upvalues: (copy) v_u_33
			local v34 = v_u_33.module.Start
			local v35, v36 = pcall(v34)
			if not v35 then
				warn((("[DiamondShopController] %*.Start errored: %*"):format(v_u_33.name, v36)))
			end
		end)
	end
end
return v11
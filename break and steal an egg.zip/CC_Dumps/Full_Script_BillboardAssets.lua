local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = {
	["FolderName"] = "BillboardGui"
}
local v_u_3 = {}
function v_u_2.Find(p4) -- name: Find
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v5 = v_u_1:FindFirstChild("Assets")
	if v5 then
		v5 = v5:FindFirstChild(v_u_2.FolderName)
	end
	if v5 then
		v5 = v5:FindFirstChild(p4)
	end
	if v5 then
		if v5:IsA("BillboardGui") then
			return v5
		else
			return v5:FindFirstChildWhichIsA("BillboardGui")
		end
	else
		return nil
	end
end
function v_u_2.Get(p6) -- name: Get
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v7 = v_u_2.Find(p6)
	if not (v7 or v_u_3[p6]) then
		v_u_3[p6] = true
		warn((("[BillboardAssets] ReplicatedStorage.Assets.%*.%* (BillboardGui) not found"):format(v_u_2.FolderName, p6)))
	end
	return v7
end
return v_u_2
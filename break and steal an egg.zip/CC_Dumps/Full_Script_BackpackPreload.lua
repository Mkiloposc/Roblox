local v_u_1 = game:GetService("ContentProvider")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(v_u_3.Shared.AnimalRenders)
local v_u_5 = require(v_u_3.Shared.BatConfig)
local v_u_6 = require(v_u_3.Shared.EggTypeConfig)
local v_u_7 = require(v_u_3.Shared.PickaxeConfig)
local v_u_8 = require(script.Parent.BackpackSlotVisuals)
local v9 = {}
local v_u_10 = {}
local function v_u_16(p11) -- name: ownedToolImages
	-- upvalues: (copy) v_u_2, (copy) v_u_8, (copy) v_u_10
	local v12 = v_u_2.LocalPlayer
	for _, v13 in { v12.Character, v12:FindFirstChildOfClass("Backpack") } do
		if not v13 then
			continue
		end
		for _, v14 in v13:GetChildren() do
			if not v14:IsA("Tool") then
				continue
			end
			local v15 = v_u_8.ImageFor(v14)
			if not v15 or (v15 == "" or v_u_10[v15]) then
				continue
			end
			v_u_10[v15] = true
			table.insert(p11, v15)
		end
	end
end
local function v_u_22(p17) -- name: templateToolImages
	-- upvalues: (copy) v_u_7, (copy) v_u_5, (copy) v_u_3, (copy) v_u_10
	for _, v18 in { v_u_7.TemplatesFolderName, v_u_5.TemplatesFolderName } do
		local v19 = v_u_3:FindFirstChild(v18)
		if not v19 then
			continue
		end
		for _, v20 in v19:GetDescendants() do
			if not v20:IsA("Tool") then
				continue
			end
			local v21 = v20.TextureId
			if not v21 or (v21 == "" or v_u_10[v21]) then
				continue
			end
			v_u_10[v21] = true
			table.insert(p17, v21)
		end
	end
end
local function v_u_29(p23) -- name: warm
	-- upvalues: (copy) v_u_1
	local v24 = {}
	for v25, v26 in p23 do
		table.insert(v24, v26)
		if #v24 < 20 and v25 ~= #p23 then
			continue
		end
		local v27 = v_u_1.PreloadAsync
		local v28 = v_u_1
		pcall(v27, v28, v24)
		table.clear(v24)
		task.wait(0.05)
	end
end
function v9.Warm() -- name: Warm
	-- upvalues: (copy) v_u_16, (copy) v_u_22, (copy) v_u_6, (copy) v_u_10, (copy) v_u_4, (copy) v_u_29
	local v30 = {}
	v_u_16(v30)
	v_u_22(v30)
	for _, v31 in v_u_6.Types do
		local v32 = v31.Icon
		if not v32 or (v32 == "" or v_u_10[v32]) then
			continue
		end
		v_u_10[v32] = true
		table.insert(v30, v32)
	end
	for _, v33 in v_u_4.AllImages() do
		if not v33 or (v33 == "" or v_u_10[v33]) then
			continue
		end
		v_u_10[v33] = true
		table.insert(v30, v33)
	end
	v_u_29(v30)
end
return v9
local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Shared.BatConfig)
local v_u_8 = {
	["IsBatWeapon"] = function(p4) -- name: IsBatWeapon
		-- upvalues: (copy) v_u_3, (copy) v_u_1
		local v5 = p4 ~= nil and p4:IsA("Tool")
		if v5 then
			if p4.Name == v_u_3.ToolName then
				v5 = not v_u_1:HasTag(p4, "AnimalTool")
			else
				v5 = false
			end
		end
		return v5
	end,
	["FindIn"] = function(p6) -- name: FindIn
		-- upvalues: (copy) v_u_8
		if not p6 then
			return nil
		end
		for _, v7 in p6:GetChildren() do
			if not v_u_8.IsBatWeapon(v7) then
				continue
			end
			return v7
		end
		return nil
	end
}
return v_u_8
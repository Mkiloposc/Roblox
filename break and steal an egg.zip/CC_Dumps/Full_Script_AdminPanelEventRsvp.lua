local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = require(v_u_1.Shared.AdminConfig)
local v_u_4 = require(v_u_1.Shared.EventRsvpConfig)
local v_u_5 = require(script.Parent.Parent.Controllers.NotificationController)
return {
	["Bind"] = function(_, p6) -- name: Bind
		-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_2, (copy) v_u_1, (copy) v_u_5
		local v7 = p6:FindFirstChild("Prompt")
		local v_u_8 = p6:FindFirstChild("Status")
		if v7 and (v7:IsA("GuiButton") and (v_u_8 and v_u_8:IsA("TextLabel"))) then
			v7:SetAttribute("HoverScale", v_u_3.PanelHoverScale)
			v7:SetAttribute("PressScale", v_u_3.PanelPressScale)
			v7.Interactable = true
			local v9 = v7:FindFirstChild("Title")
			if v9 and v9:IsA("TextLabel") then
				v9.Text = "Prompt"
			end
			local v10
			if v_u_4.IsUnlocked(v_u_2:GetServerTimeNow()) then
				v10 = "Auto-prompt: <font color=\"#55FF7F\">Live</font>"
			else
				local v11 = "Auto-prompt starts in <font color=\"#FFD23C\">%*</font>"
				local v12 = v_u_4.PromptStartTime - v_u_2:GetServerTimeNow()
				local v13 = math.ceil(v12)
				local v14 = math.max(v13, 0)
				local v15 = v14 // 3600
				local v16 = v14 % 3600 // 60
				local v17 = v14 % 60
				local v18
				if v15 > 0 then
					v18 = string.format("%d:%02d:%02d", v15, v16, v17)
				else
					v18 = string.format("%d:%02d", v16, v17)
				end
				v10 = v11:format(v18)
			end
			if v_u_8.Text ~= v10 then
				v_u_8.Text = v10
			end
			task.spawn(function()
				-- upvalues: (copy) v_u_8, (ref) v_u_4, (ref) v_u_2
				while v_u_8:IsDescendantOf(game) and not v_u_4.IsUnlocked(v_u_2:GetServerTimeNow()) do
					task.wait(0.5)
					local v19
					if v_u_4.IsUnlocked(v_u_2:GetServerTimeNow()) then
						v19 = "Auto-prompt: <font color=\"#55FF7F\">Live</font>"
					else
						local v20 = "Auto-prompt starts in <font color=\"#FFD23C\">%*</font>"
						local v21 = v_u_4.PromptStartTime - v_u_2:GetServerTimeNow()
						local v22 = math.ceil(v21)
						local v23 = math.max(v22, 0)
						local v24 = v23 // 3600
						local v25 = v23 % 3600 // 60
						local v26 = v23 % 60
						local v27
						if v24 > 0 then
							v27 = string.format("%d:%02d:%02d", v24, v25, v26)
						else
							v27 = string.format("%d:%02d", v25, v26)
						end
						v19 = v20:format(v27)
					end
					if v_u_8.Text == v19 then
						continue
					end
					v_u_8.Text = v19
				end
			end)
			local v_u_28 = false
			local function v_u_34() -- name: send
				-- upvalues: (ref) v_u_28, (ref) v_u_1, (ref) v_u_3, (ref) v_u_5
				if v_u_28 then
					return
				else
					local v_u_29 = v_u_1:FindFirstChild(v_u_3.PanelRemotes.EventRsvp)
					if v_u_29 and v_u_29:IsA("RemoteFunction") then
						v_u_28 = true
						local v30, v31, v32 = pcall(function()
							-- upvalues: (copy) v_u_29
							return v_u_29:InvokeServer()
						end)
						v_u_28 = false
						if v30 and v31 == true then
							v_u_5.Show(type(v32) ~= "string" and "Event prompt sent" or v32, "Success")
						else
							local v33 = (not v30 or type(v32) ~= "string") and "something went wrong" or v32
							v_u_5.Show(("Event prompt failed: %*"):format(v33), "Error")
						end
					else
						v_u_5.Show("The event prompt isn\'t ready yet", "Error")
						return
					end
				end
			end
			v7.Activated:Connect(function()
				-- upvalues: (copy) v_u_34
				task.spawn(v_u_34)
			end)
		else
			warn("[AdminPanelEventRsvp] card needs Container.Prompt (button) + Container.Status (label)")
		end
	end
}
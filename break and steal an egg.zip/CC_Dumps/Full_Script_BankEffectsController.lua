local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(v_u_2.Shared.SafeZoneQuery)
local v_u_5 = require(script.Parent.ClaimFeedback)
local v6 = require(script.Parent.Parent.Modules.LocalCharacter)
local v7 = {}
local v_u_8 = v1.LocalPlayer
local v_u_9 = false
local v_u_10 = v6.GetRoot
function v7.Start() -- name: Start
	-- upvalues: (copy) v_u_3, (copy) v_u_8, (ref) v_u_9, (copy) v_u_10, (copy) v_u_4, (copy) v_u_5, (copy) v_u_2
	v_u_3.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_4, (ref) v_u_5
		if v_u_8:GetAttribute("Carrying") == nil then
			v_u_9 = false
			return
		elseif v_u_9 then
			return
		else
			local v11 = v_u_10()
			if v11 then
				if v_u_4.IsBankable(v_u_8.UserId, v11.Position) then
					v_u_9 = true
					v_u_5.PlayBank()
				end
			end
		end
	end)
	local v12 = v_u_2:WaitForChild("AnimalBankedRemote", 30)
	if v12 and v12:IsA("RemoteEvent") then
		v12.OnClientEvent:Connect(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_5
			v_u_9 = true
			v_u_5.PlayBank()
		end)
	else
		warn("[BankEffectsController] AnimalBankedRemote missing")
	end
	v_u_8.CharacterAdded:Connect(function()
		-- upvalues: (ref) v_u_9, (ref) v_u_5
		v_u_9 = false
		v_u_5.Stop()
	end)
end
return v7
local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v_u_1.Shared.AdminConfig)
local v_u_3 = require(v_u_1.Shared.GlobalAnnouncementConfig)
local v_u_4 = require(script.Parent.Parent.Controllers.NotificationController)
local v_u_5 = require(script.Parent.UnitTextBox)
return {
	["Bind"] = function(p_u_6, p7) -- name: Bind
		-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_2, (copy) v_u_1, (copy) v_u_3
		local v_u_8 = p7:FindFirstChild("UserNameVerify")
		if v_u_8 then
			v_u_8 = v_u_8:FindFirstChild("TextBox")
		end
		local v9 = p7:FindFirstChild("Select")
		if not (v_u_8 and (v_u_8:IsA("TextBox") and (v9 and v9:IsA("GuiButton")))) then
			return false
		end
		v_u_8.ClearTextOnFocus = false
		local v_u_10 = p7:FindFirstChild("LastingTime")
		if v_u_10 then
			v_u_10 = v_u_10:FindFirstChild("TextBox")
		end
		if not (v_u_10 and v_u_10:IsA("TextBox")) then
			v_u_10 = nil
		end
		v_u_5.Bind(v_u_10, "s")
		local v_u_11 = false
		local function v_u_23() -- name: announce
			-- upvalues: (ref) v_u_11, (copy) v_u_8, (ref) v_u_4, (copy) p_u_6, (ref) v_u_2, (ref) v_u_1, (copy) v_u_10, (ref) v_u_5, (ref) v_u_3
			if v_u_11 then
				return
			else
				local v12 = string.gsub(v_u_8.Text, "^%s+", "")
				local v_u_13 = string.gsub(v12, "%s+$", "")
				if v_u_13 == "" then
					v_u_4.Show("Type something to announce first", "Error")
					return
				else
					local v_u_14 = p_u_6:GetAttribute("Scope")
					if type(v_u_14) ~= "string" then
						v_u_14 = v_u_2.PanelDefaultScope
					end
					local v_u_15 = v_u_1:FindFirstChild(v_u_2.PanelRemotes.Announce)
					if v_u_15 and v_u_15:IsA("RemoteFunction") then
						local v_u_16
						if v_u_10 and string.match(v_u_10.Text, "%S") then
							local v17 = v_u_5.Number(v_u_10.Text, "s")
							if not v17 then
								v_u_4.Show("Type how long it lasts in seconds (e.g. 3)", "Error")
								return
							end
							v_u_16 = v_u_3.ClampHold(v17)
						else
							v_u_16 = nil
						end
						v_u_11 = true
						local function v18()
							-- upvalues: (copy) v_u_15, (ref) v_u_13, (ref) v_u_14, (ref) v_u_16
							return v_u_15:InvokeServer(v_u_13, v_u_14, v_u_16)
						end
						local v19, v20, v21 = pcall(v18)
						v_u_11 = false
						if v19 and v20 == true then
							v_u_8.Text = ""
						else
							local v22 = (not v19 or type(v21) ~= "string") and "couldn\'t announce" or v21
							v_u_4.Show(("Announce failed: %*"):format(v22), "Error")
						end
					else
						v_u_4.Show("Announcements aren\'t ready yet", "Error")
					end
				end
			end
		end
		v9.Activated:Connect(function()
			-- upvalues: (copy) v_u_23
			task.spawn(v_u_23)
		end)
		v_u_8.FocusLost:Connect(function(p24)
			-- upvalues: (copy) v_u_23
			if p24 then
				task.spawn(v_u_23)
			end
		end)
		return true
	end
}
local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Shared.StrokeColors)
local v_u_4 = require(v2.Shared.PurchaseButtonStyles)
local v_u_5 = {}
local v_u_6 = {
	{
		["Time"] = 0,
		["SaturationScale"] = 0.78,
		["Brightness"] = 1
	},
	{
		["Time"] = 0.5,
		["SaturationScale"] = 1,
		["Brightness"] = 0.93
	},
	{
		["Time"] = 1,
		["SaturationScale"] = 1,
		["Brightness"] = 0.62
	}
}
local v_u_7 = v1.LocalPlayer
local v_u_8 = {}
local v_u_9 = {}
local function v_u_17(p10, p11) -- name: rampSequence
	-- upvalues: (copy) v_u_6
	local v12 = {}
	for _, v13 in v_u_6 do
		local v14 = Color3.fromHSV(p10, p11 * v13.SaturationScale, v13.Brightness)
		local v15 = ColorSequenceKeypoint.new
		local v16 = v13.Time
		table.insert(v12, v15(v16, v14))
	end
	return ColorSequence.new(v12)
end
local v_u_18 = {
	["CPS"] = true
}
local function v_u_30(p19, p20, p21) -- name: resolveStrokes
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v22 = {}
	for _, v23 in p19:GetChildren() do
		if not v23:IsA("UIStroke") then
			continue
		end
		local v24 = v_u_4.SnapshotStroke(v23)
		if p20 then
			for _, v25 in p20.Strokes do
				if v25.Stroke ~= v23 then
					continue
				end
				v24 = v25.Authored
			end
		end
		local v26 = {
			["Stroke"] = v23,
			["Authored"] = v24
		}
		local v27 = v24.Color
		if v23.Name == "Inner" then
			v27 = v_u_3.InnerFromSequence(p21)
		else
			local _, v28, v29 = Color3.toHSV(v27)
			if v28 >= 0.15 and v29 > 0.15 then
				v27 = Color3.fromHSV(0.13, 0.9450000000000001, 0.5)
			end
		end
		v26.Yellow = v27
		table.insert(v22, v26)
	end
	return v22
end
local function v_u_38(p31, p32) -- name: resolveLabelStrokes
	local v33 = {}
	for _, v34 in p31:GetDescendants() do
		if not v34:IsA("UIStroke") then
			continue
		end
		local v35 = v34.Parent
		if v35 == nil or (v35 == p31 or not (v35:IsA("TextLabel") or v35:IsA("TextButton"))) then
			continue
		end
		local v36 = v34.Color
		if p32 then
			for _, v37 in p32.LabelStrokes do
				if v37.Stroke ~= v34 then
					continue
				end
				v36 = v37.Authored
			end
		end
		table.insert(v33, {
			["Stroke"] = v34,
			["Label"] = v35,
			["Authored"] = v36
		})
	end
	return v33
end
local function v_u_49(p39, p40, p41) -- name: resolveExtraGradients
	-- upvalues: (copy) v_u_18
	local v42 = {}
	for _, v46 in p39:GetDescendants() do
		if not v46:IsA("UIGradient") or v46 == p40 then
			continue
		end
		local v44 = v46
		while true do
			local v45
			if v46 == nil or v46 == p39 then
				v45 = false
				break
			end
			if v_u_18[v46.Name] then
				v45 = true
				break
			end
			local v46 = v46.Parent
		end
		if v45 then
			break
		end
		local v47 = v44.Color
		if p41 then
			for _, v48 in p41.ExtraGradients do
				if v48.Gradient ~= v44 then
					continue
				end
				v47 = v48.Authored
			end
		end
		table.insert(v42, {
			["Gradient"] = v44,
			["Authored"] = v47
		})
	end
	return v42
end
local function v_u_59(p50) -- name: paintLabelStrokes
	-- upvalues: (copy) v_u_3
	for _, v51 in p50.LabelStrokes do
		local v52 = v51.Label.TextColor3
		local _, v53, v54 = Color3.toHSV(v52)
		local v55
		if v53 < 0.15 and true or v54 <= 0.15 then
			local v56 = v51.Authored
			local _, v57, v58 = Color3.toHSV(v56)
			if v57 < 0.15 and true or v58 <= 0.15 then
				v55 = v51.Authored
				if v51.Stroke.Color == v55 then
					continue
				end
				v51.Stroke.Color = v55
			else
				v55 = v_u_3.Outer(v52)
				if v51.Stroke.Color == v55 then
					continue
				end
				v51.Stroke.Color = v55
			end
		else
			v55 = v_u_3.Outer(v52)
			if v51.Stroke.Color == v55 then
				continue
			end
			v51.Stroke.Color = v55
		end
	end
end
local function v_u_67(p60, p61) -- name: applyTemplate
	-- upvalues: (copy) v_u_4
	local v62 = v_u_4.Get(p61)
	v_u_4.ApplyGradient(p60.Gradient, v62 and v62.Gradient or p60.Authored)
	for _, v63 in p60.Strokes do
		local v64
		if v62 then
			v64 = v62.Strokes[v63.Stroke.Name]
		else
			v64 = v62
		end
		v_u_4.ApplyStroke(v63.Stroke, v64 or v63.Authored)
	end
	local v65 = v62 and v62.Gradient
	if v65 then
		v65 = v62.Gradient.Color
	end
	for _, v66 in p60.ExtraGradients do
		v66.Gradient.Color = v65 or v66.Authored
	end
end
local function v_u_71(p68) -- name: applyMaxed
	-- upvalues: (copy) v_u_4
	v_u_4.ApplyGradient(p68.Gradient, {
		["Color"] = nil,
		["Rotation"] = 90,
		["Transparency"] = nil,
		["Offset"] = nil,
		["Color"] = p68.Yellow,
		["Transparency"] = p68.Authored.Transparency,
		["Offset"] = p68.Authored.Offset
	})
	for _, v69 in p68.Strokes do
		v_u_4.ApplyStroke(v69.Stroke, {
			["Color"] = v69.Yellow,
			["Transparency"] = v69.Authored.Transparency
		})
	end
	for _, v70 in p68.ExtraGradients do
		v70.Gradient.Color = p68.Yellow
	end
end
local function v_u_76(p72, p73) -- name: paint
	-- upvalues: (copy) v_u_59, (copy) v_u_67, (copy) v_u_4, (copy) v_u_71
	v_u_59(p72)
	local v74 = p72.CostOf()
	local v75 = v74 == nil and "Maxed" or (v74 <= p73 and "Affordable" or "TooPoor")
	if v75 == p72.State then
		return
	else
		p72.State = v75
		if v75 == "Affordable" then
			v_u_67(p72, v_u_4.Affordable)
			return
		elseif v75 == "TooPoor" then
			v_u_67(p72, v_u_4.NoneAffordable)
		else
			v_u_71(p72)
		end
	end
end
function v_u_5.Refresh() -- name: Refresh
	-- upvalues: (copy) v_u_8, (copy) v_u_76, (copy) v_u_7
	for v77, v78 in v_u_8 do
		if v78.Gradient.Parent == nil then
			v_u_8[v77] = nil
		else
			local v79 = v_u_76
			local v80 = v_u_7:GetAttribute(v78.Currency)
			v79(v78, typeof(v80) ~= "number" and 0 or v80)
		end
	end
end
function v_u_5.Bind(p81, p82, p83) -- name: Bind
	-- upvalues: (copy) v_u_8, (copy) v_u_4, (copy) v_u_17, (copy) v_u_30, (copy) v_u_38, (copy) v_u_49, (copy) v_u_9, (copy) v_u_7, (copy) v_u_5, (copy) v_u_76
	local v84 = p83 or "Cash"
	local v85 = p81:FindFirstChild("UiGradient")
	if not (v85 and v85:IsA("UIGradient")) then
		v85 = p81:FindFirstChildWhichIsA("UIGradient")
	end
	if v85 then
		local v86 = v_u_8[p81]
		local v87
		if v86 == nil then
			v87 = false
		else
			v87 = v86.Gradient == v85
		end
		local v88
		if v87 and v86 then
			v88 = v86.Authored
		else
			v88 = v_u_4.SnapshotGradient(v85)
		end
		local v89 = v_u_17(0.13, 0.9)
		local v90 = {
			["Gradient"] = nil,
			["Authored"] = nil,
			["Yellow"] = nil,
			["Strokes"] = nil,
			["LabelStrokes"] = nil,
			["ExtraGradients"] = nil,
			["CostOf"] = nil,
			["Currency"] = nil,
			["State"] = nil,
			["Gradient"] = v85,
			["Authored"] = v88,
			["Yellow"] = v89,
			["Strokes"] = v_u_30(p81, v86, v89),
			["LabelStrokes"] = v_u_38(p81, v86),
			["ExtraGradients"] = v_u_49(p81, v85, v86),
			["CostOf"] = p82,
			["Currency"] = v84
		}
		v_u_8[p81] = v90
		if not v_u_9[v84] then
			v_u_9[v84] = true
			v_u_7:GetAttributeChangedSignal(v84):Connect(v_u_5.Refresh)
		end
		local v91 = v_u_76
		local v92 = v_u_7:GetAttribute(v84)
		v91(v90, typeof(v92) ~= "number" and 0 or v92)
	end
end
return v_u_5
local v_u_1 = require(script.Parent.BillboardAssets)
local v_u_2 = require(script.Parent.EggRewards)
local v_u_3 = require(script.Parent.FormatNumber)
local v_u_4 = require(script.Parent.RarityGradientFX)
local v_u_5 = require(script.Parent.VariantLabel)
local v_u_6 = {
	["TemplateName"] = "AnimalOverhead",
	["AttachmentName"] = "AnimalOverheadAttachment",
	["HeightAboveHead"] = 0.25,
	["MinScale"] = 0.85,
	["MaxScale"] = 2.2,
	["TimerLowSeconds"] = 10,
	["TimerLowColor"] = Color3.fromRGB(255, 80, 80)
}
local v_u_7 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_14(p8) -- name: resolveTimerRefs
	-- upvalues: (copy) v_u_7, (copy) v_u_6
	local v9 = v_u_7[p8]
	if v9 and v9.Billboard.Parent then
		return v9
	end
	local v10 = p8.PrimaryPart or p8:FindFirstChildWhichIsA("BasePart", true)
	if v10 then
		v10 = v10:FindFirstChild(v_u_6.AttachmentName)
	end
	if v10 then
		v10 = v10:FindFirstChildWhichIsA("BillboardGui")
	end
	if not v10 then
		return nil
	end
	local v11 = v10:FindFirstChild("SelfDestructTimer", true)
	local v12 = {
		["Billboard"] = v10
	}
	local v13
	if v11 and v11:IsA("GuiObject") then
		v13 = v11
	else
		v13 = nil
	end
	v12.Row = v13
	if v11 then
		if not v11:IsA("TextLabel") then
			v11 = v11:FindFirstChildWhichIsA("TextLabel", true)
		end
	else
		v11 = nil
	end
	v12.Label = v11
	v_u_7[p8] = v12
	return v12
end
function v_u_6.UpdateTimer(p15, p16) -- name: UpdateTimer
	-- upvalues: (copy) v_u_14, (copy) v_u_6
	local v17 = v_u_14(p15)
	if v17 then
		local v18 = v17.Row
		if v18 and not v18.Visible then
			v18.Visible = true
		end
		local v19 = v17.Label
		if v19 then
			local v20 = v19:GetAttribute("AuthoredTimerColor")
			if v20 == nil then
				v20 = v19.TextColor3
				v19:SetAttribute("AuthoredTimerColor", v20)
			end
			local v21 = math.ceil(p16)
			local v22 = math.max(v21, 0)
			local v23
			if v22 >= 60 then
				v23 = ("%*:%*"):format(v22 // 60, (string.format("%02d", v22 % 60)))
			else
				v23 = ("%*s"):format(v22)
			end
			if v19.Text ~= v23 then
				v19.Text = v23
			end
			if p16 <= v_u_6.TimerLowSeconds then
				v20 = v_u_6.TimerLowColor
			end
			if v19.TextColor3 ~= v20 then
				v19.TextColor3 = v20
			end
		end
	end
end
function v_u_6.Attach(p24, p25) -- name: Attach
	-- upvalues: (copy) v_u_1, (copy) v_u_6, (copy) v_u_3, (copy) v_u_2, (copy) v_u_4, (copy) v_u_5
	local v26 = p24.PrimaryPart or p24:FindFirstChildWhichIsA("BasePart", true)
	if not (v26 and p24.Parent) then
		return nil
	end
	local v27 = v_u_1.Get(v_u_6.TemplateName)
	if not v27 then
		return nil
	end
	local v28 = v26:FindFirstChild(v_u_6.AttachmentName)
	if not (v28 and v28:IsA("Attachment")) then
		v28 = Instance.new("Attachment")
		v28.Name = v_u_6.AttachmentName
		v28.Parent = v26
		local v29, v30 = p24:GetBoundingBox()
		local v31 = v29.Position
		local v32 = v30.Y / 2 + v_u_6.HeightAboveHead
		v28.WorldPosition = v31 + Vector3.new(0, v32, 0)
	end
	local v33 = v28:FindFirstChildWhichIsA("BillboardGui")
	if v33 then
		v33:Destroy()
	end
	local v34 = v27:Clone()
	if p25.CashPerSecond then
		local v35 = ("$%*/s"):format((v_u_3.Short(p25.CashPerSecond)))
		local v36 = v34:FindFirstChild("CashPerSecond", true)
		if v36 then
			if v35 then
				if not v36:IsA("TextLabel") then
					v36 = v36:FindFirstChildWhichIsA("TextLabel", true)
				end
				if v36 then
					v36.Text = v35
				end
			elseif v36:IsA("GuiObject") then
				v36.Visible = false
			end
		end
	elseif p25.StatText then
		local v37 = p25.StatText
		local v38 = v34:FindFirstChild("CashPerSecond", true)
		if v38 then
			if v37 then
				if not v38:IsA("TextLabel") then
					v38 = v38:FindFirstChildWhichIsA("TextLabel", true)
				end
				if v38 then
					v38.Text = v37
				end
			elseif v38:IsA("GuiObject") then
				v38.Visible = false
			end
		end
	else
		local v39 = v34:FindFirstChild("CashPerSecond", true)
		if v39 and v39:IsA("GuiObject") then
			v39.Visible = false
		end
	end
	local v40 = p25.Rarity
	local v41
	if p25.Rarity then
		v41 = v_u_2.RarityColors[p25.Rarity] or nil
	else
		v41 = nil
	end
	local v42 = v34:FindFirstChild("Rarity", true)
	if v42 then
		if v40 then
			if not v42:IsA("TextLabel") then
				v42 = v42:FindFirstChildWhichIsA("TextLabel", true)
			end
			if v42 then
				v42.Text = v40
				if v41 then
					v42.TextColor3 = v41
				end
			end
		elseif v42:IsA("GuiObject") then
			v42.Visible = false
		end
	end
	if p25.Rarity then
		local v43 = v34:FindFirstChild("Rarity", true)
		if v43 and not v43:IsA("TextLabel") then
			v43 = v43:FindFirstChildWhichIsA("TextLabel", true)
		end
		if v43 then
			v_u_4.ApplyToLabel(v43, p25.Rarity)
		end
	end
	local v44 = v34:FindFirstChild("Traits", true)
	if v44 and v44:IsA("GuiObject") then
		v44.Visible = false
	end
	v_u_5.Fill(v34, p25.Variant, p25.Mutation)
	local v45
	if p25.DespawnSeconds then
		local v46 = p25.DespawnSeconds
		local v47 = math.ceil(v46)
		local v48 = math.max(v47, 0)
		local v49
		if v48 >= 60 then
			v49 = ("%*:%*"):format(v48 // 60, (string.format("%02d", v48 % 60)))
		else
			v49 = ("%*s"):format(v48)
		end
		v45 = v49 or nil
	else
		v45 = nil
	end
	local v50 = v34:FindFirstChild("SelfDestructTimer", true)
	if v50 then
		if v45 then
			if not v50:IsA("TextLabel") then
				v50 = v50:FindFirstChildWhichIsA("TextLabel", true)
			end
			if v50 then
				v50.Text = v45
			end
		elseif v50:IsA("GuiObject") then
			v50.Visible = false
		end
	end
	local v51 = p25.SizeMult or 1
	local v52 = v_u_6.MinScale
	local v53 = v_u_6.MaxScale
	local v54 = math.clamp(v51, v52, v53)
	v34.Size = UDim2.new(v34.Size.X.Scale * v54, v34.Size.X.Offset * v54, v34.Size.Y.Scale * v54, v34.Size.Y.Offset * v54)
	v34.SizeOffset = Vector2.new(0, 0.5)
	v34.Enabled = true
	v34.Parent = v28
	return v34
end
return v_u_6
local v1 = game:GetService("CorePackages")
return require(v1.Workspace.Packages.RobloxApolloClient).initializeApolloClient({})
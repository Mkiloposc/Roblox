local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v_u_1.Shared.AdminConfig)
local v_u_3 = require(v_u_1.Shared.TitanicEggConfig)
local v_u_4 = require(v_u_1.Shared.ZoneDisplayInfo)
local v_u_5 = require(v_u_1.Shared.ZonesConfig)
local v_u_6 = require(script.Parent.AdminEditDropdown)
local v_u_7 = require(script.Parent.Parent.Controllers.NotificationController)
local v8 = {}
local v_u_9 = v_u_2.TitanicEgg
local v_u_10 = v_u_3.AdminSpawn
local function v_u_20(p11) -- name: buildZoneRows
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
	local v12 = {}
	local v13 = p11:FindFirstChild("Template")
	if not (v13 and v13:IsA("GuiObject")) then
		warn("[AdminPanelTitanicEgg] ZoneList.Template is missing \226\128\148 only Random can be picked")
		return v12
	end
	v13.Visible = false
	local v14 = v_u_3.FirstZone
	while true do
		local v15 = v_u_4[("Zone%*"):format(v14)]
		if not v15 then
			break
		end
		local v16 = v_u_5.Get((("Zone%*"):format(v14)))
		if v16 and v16.NoEggs then
			v14 = v14 + 1
		else
			v12[v15.Name] = v14
			if not p11:FindFirstChild(v15.Name) then
				local v17 = v13:Clone()
				v17.Name = v15.Name
				v17.LayoutOrder = v13.LayoutOrder + v14
				v17.Visible = true
				local v18 = v15.Name
				local v19 = v17:FindFirstChild("Button")
				if v19 then
					v19 = v19:FindFirstChild("Title")
				end
				if v19 and v19:IsA("TextLabel") then
					v19.Text = v18
				end
				v17.Parent = p11
			end
			v14 = v14 + 1
		end
	end
	return v12
end
function v8.Bind(p_u_21, p22) -- name: Bind
	-- upvalues: (copy) v_u_9, (copy) v_u_2, (copy) v_u_20, (copy) v_u_6, (copy) v_u_1, (copy) v_u_7, (copy) v_u_10
	local v23 = p22:FindFirstChild(v_u_9.ToggleName)
	local v24 = p22:FindFirstChild(v_u_9.ListName)
	local v25 = p22:FindFirstChild("Spawn")
	if not (v23 and (v23:IsA("GuiButton") and (v24 and (v24:IsA("GuiObject") and (v25 and v25:IsA("GuiButton")))))) then
		warn((("[AdminPanelTitanicEgg] card needs Container.%* + Container.%* + Container.Spawn"):format(v_u_9.ToggleName, v_u_9.ListName)))
		return nil
	end
	for _, v26 in { v23, v25 } do
		v26:SetAttribute("HoverScale", v_u_2.PanelHoverScale)
		v26:SetAttribute("PressScale", v_u_2.PanelPressScale)
	end
	local v_u_27 = v_u_20(v24)
	local v28 = p22:FindFirstChild(v_u_9.SettingName)
	local v29 = v_u_6.Bind
	local v30 = v_u_9.RandomOption
	local v31 = nil
	local v32 = {
		["Toggle"] = v23,
		["List"] = v24
	}
	if not (v28 and v28:IsA("TextLabel")) then
		v28 = false
	end
	v32.Setting = v28
	local v_u_33 = v29(p22, v30, v31, v32)
	local v_u_34 = false
	local function v_u_44() -- name: spawn
		-- upvalues: (ref) v_u_34, (ref) v_u_1, (ref) v_u_2, (ref) v_u_7, (copy) v_u_33, (ref) v_u_9, (copy) v_u_27, (copy) p_u_21, (ref) v_u_10
		if v_u_34 then
			return
		else
			local v_u_35 = v_u_1:FindFirstChild(v_u_2.PanelRemotes.TitanicEgg)
			if v_u_35 and v_u_35:IsA("RemoteFunction") then
				local v36
				if v_u_33 then
					v36 = v_u_33.GetValue()
				else
					v36 = v_u_9.RandomOption
				end
				local v_u_37 = v_u_27[v36]
				local v_u_38 = p_u_21:GetAttribute("Scope")
				if type(v_u_38) ~= "string" or not v_u_10.Scopes[v_u_38] then
					v_u_38 = v_u_10.DefaultScope
				end
				v_u_34 = true
				local function v39()
					-- upvalues: (copy) v_u_35, (copy) v_u_37, (ref) v_u_38
					return v_u_35:InvokeServer(v_u_37, v_u_38)
				end
				local v40, v41, v42 = pcall(v39)
				v_u_34 = false
				if v40 and v41 == true then
					v_u_7.Show(type(v42) ~= "string" and "Titanic Egg spawned" or v42, "Success")
				else
					local v43 = (not v40 or type(v42) ~= "string") and "couldn\'t spawn" or v42
					v_u_7.Show(("Titanic Egg failed: %*"):format(v43), "Error")
				end
			else
				v_u_7.Show("Titanic spawning isn\'t ready yet", "Error")
			end
		end
	end
	v25.Activated:Connect(function()
		-- upvalues: (copy) v_u_44
		task.spawn(v_u_44)
	end)
	return v_u_33
end
return v8
local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.EggConfig)
return {
	["Of"] = function(p3, p4, p5) -- name: Of
		-- upvalues: (copy) v_u_2
		if p5 then
			p5 = v_u_2.Eggs[p5]
		end
		if not (p5 and p5.NormalizeWholeModel) then
			local v6 = p4.Size.Y
			return math.max(v6, 0.001)
		end
		local _, v7 = p3:GetBoundingBox()
		local v8 = v7.Y
		return math.max(v8, 0.001)
	end
}
local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("ReplicatedStorage")
local v_u_5 = game:GetService("RunService")
local v_u_6 = game:GetService("SoundService")
local v_u_7 = game:GetService("TweenService")
local v_u_8 = game:GetService("Workspace")
local v_u_9 = require(v_u_4.Shared.ModelScaler)
local v10 = {}
local v_u_11 = (-1 / 0)
local function v_u_17() -- name: playCollectSound
	-- upvalues: (ref) v_u_11, (copy) v_u_6, (copy) v_u_2
	local v12 = os.clock()
	if v12 - v_u_11 < 0.1 then
		return
	else
		v_u_11 = v12
		local v13 = v_u_6:FindFirstChild("rransCustomSFX")
		if v13 then
			v13 = v13:FindFirstChild("Correct Reveal")
		end
		if v13 and v13:IsA("Sound") then
			local v_u_14 = v13:Clone()
			v_u_14.Parent = v_u_6
			v_u_14.Ended:Once(function()
				-- upvalues: (copy) v_u_14
				v_u_14:Destroy()
			end)
			local v15 = v_u_2
			local v16 = v_u_14.TimeLength
			v15:AddItem(v_u_14, math.max(v16, 1) + 1)
			v_u_14:Play()
		else
			warn("[AnimalPlaceVFXController] SoundService.rransCustomSFX.Correct Reveal missing")
		end
	end
end
local v_u_18 = {}
local v_u_19 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_24(p20) -- name: armPop
	-- upvalues: (copy) v_u_18
	local v21 = os.clock()
	for v22 = #v_u_18, 1, -1 do
		if v21 - v_u_18[v22].stamp <= 3 then
			continue
		end
		table.remove(v_u_18, v22)
	end
	local v23 = v_u_18
	table.insert(v23, {
		["position"] = p20,
		["stamp"] = v21
	})
end
local function v_u_32(p25) -- name: consumePopAt
	-- upvalues: (copy) v_u_18
	local v26 = os.clock()
	local v27 = (1 / 0)
	local v28 = nil
	for v29 = #v_u_18, 1, -1 do
		local v30 = v_u_18[v29]
		if v26 - v30.stamp > 3 then
			table.remove(v_u_18, v29)
		else
			local v31 = (v30.position - p25).Magnitude
			if v31 > 15 or v31 >= v27 then
				continue
			end
			v28 = v29
			v27 = v31
		end
	end
	if not v28 then
		return false
	end
	table.remove(v_u_18, v28)
	return true
end
local function v_u_40(p33) -- name: getRoot
	local v34 = p33.PrimaryPart
	if v34 then
		return v34
	end
	local v35 = -1
	local v36 = nil
	for _, v37 in p33:GetDescendants() do
		if not v37:IsA("BasePart") then
			continue
		end
		local v38 = v37.Size
		local v39 = v38.X * v38.Y * v38.Z
		if v35 >= v39 then
			continue
		end
		v36 = v37
		v35 = v39
	end
	return v36
end
local function v_u_52(p41) -- name: elasticPopIn
	-- upvalues: (copy) v_u_40, (copy) v_u_32, (copy) v_u_18, (copy) v_u_5, (copy) v_u_9, (copy) v_u_7
	local v42 = os.clock() + 3
	local v43 = nil
	local v44 = false
	local v45 = 0
	while os.clock() < v42 do
		if not p41.Parent then
			return
		end
		if not v43 and v45 <= os.clock() then
			v43 = v_u_40(p41)
			v45 = os.clock() + 0.1
		end
		if v43 and v_u_32(v43.Position) then
			v44 = true
			break
		end
		if #v_u_18 > 0 then
			v_u_5.RenderStepped:Wait()
		else
			task.wait(0.1)
		end
	end
	if not (v44 and (v43 and p41.Parent)) then
		return
	end
	local v46 = v_u_9.Capture(p41, v43.CFrame)
	local v47 = os.clock()
	while p41.Parent and v43.Parent do
		local v48 = os.clock() - v47
		local v49 = v_u_7
		local v50 = v48 / 0.7
		local v51 = 0.05 + 0.95 * v49:GetValue(math.clamp(v50, 0, 1), Enum.EasingStyle.Elastic, Enum.EasingDirection.Out)
		v_u_9.Apply(v46, math.max(v51, 0.01), v43.CFrame)
		if v48 >= 0.7 then
			break
		end
		v_u_5.RenderStepped:Wait()
	end
	if p41.Parent and v43.Parent then
		v_u_9.Apply(v46, 1, v43.CFrame)
	end
end
local function v_u_54(p53) -- name: watchPlacedModel
	-- upvalues: (copy) v_u_19, (copy) v_u_52
	if p53:IsA("Model") and not v_u_19[p53] then
		v_u_19[p53] = true
		task.spawn(v_u_52, p53)
	end
end
local function v_u_66(p55) -- name: play
	-- upvalues: (copy) v_u_24, (copy) v_u_4, (copy) v_u_8
	v_u_24(p55)
	local v56 = v_u_4:FindFirstChild("VFX")
	if v56 then
		v56 = v56:FindFirstChild("AnimalPlace")
	end
	if not (v56 and v56:IsA("BasePart")) then
		v56 = nil
	end
	if v56 then
		local v_u_57 = v56:Clone()
		v_u_57.Anchored = true
		v_u_57.CanCollide = false
		v_u_57.CanQuery = false
		v_u_57.CanTouch = false
		v_u_57.CFrame = CFrame.new(p55 + Vector3.new(0, 0.5, 0))
		local v58 = {}
		local v59 = 0
		for _, v60 in v_u_57:GetDescendants() do
			if not v60:IsA("ParticleEmitter") then
				continue
			end
			v60.Enabled = false
			table.insert(v58, v60)
			local v61 = v60.Lifetime.Max
			local v62 = v60.TimeScale
			local v63 = v61 / math.max(v62, 0.05)
			v59 = math.max(v59, v63)
		end
		v_u_57.Parent = v_u_8
		for _, v64 in v58 do
			local v65 = v64:GetAttribute("EmitCount") or v64.Rate
			v64:Emit((math.max(v65, 1)))
		end
		task.delay(v59 + 0.5, function()
			-- upvalues: (copy) v_u_57
			v_u_57:Destroy()
		end)
	else
		warn("[AnimalPlaceVFXController] ReplicatedStorage.VFX.AnimalPlace missing")
	end
end
local v_u_67 = {}
local function v_u_69() -- name: prunePredictions
	-- upvalues: (copy) v_u_67
	for v68 = #v_u_67, 1, -1 do
		if os.clock() - v_u_67[v68] <= 3 then
			continue
		end
		table.remove(v_u_67, v68)
	end
end
function v10.PredictPlacement(p70) -- name: PredictPlacement
	-- upvalues: (copy) v_u_69, (copy) v_u_67, (copy) v_u_17, (copy) v_u_66
	v_u_69()
	local v71 = v_u_67
	local v72 = os.clock
	table.insert(v71, v72())
	v_u_17()
	v_u_66(p70)
end
function v10.CancelPrediction() -- name: CancelPrediction
	-- upvalues: (copy) v_u_69, (copy) v_u_67
	v_u_69()
	table.remove(v_u_67)
end
function v10.Start() -- name: Start
	-- upvalues: (copy) v_u_1, (copy) v_u_54, (copy) v_u_4, (copy) v_u_3, (copy) v_u_69, (copy) v_u_67, (copy) v_u_17, (copy) v_u_8, (copy) v_u_66
	v_u_1:GetInstanceAddedSignal("PlacedAnimal"):Connect(v_u_54)
	local v73 = v_u_4:WaitForChild("AnimalPlacedVFXRemote", 30)
	if v73 and v73:IsA("RemoteEvent") then
		v73.OnClientEvent:Connect(function(p74, p75, p76)
			-- upvalues: (ref) v_u_3, (ref) v_u_69, (ref) v_u_67, (ref) v_u_17, (ref) v_u_8, (ref) v_u_66
			if typeof(p74) == "Vector3" then
				if p75 == v_u_3.LocalPlayer and p76 ~= false then
					v_u_69()
					if #v_u_67 > 0 then
						table.remove(v_u_67, 1)
						return
					end
					v_u_17()
				end
				local v77 = v_u_8.CurrentCamera
				if not v77 or (v77.CFrame.Position - p74).Magnitude <= 250 then
					v_u_66(p74)
				end
			else
				return
			end
		end)
	else
		warn("[AnimalPlaceVFXController] AnimalPlacedVFXRemote missing")
	end
end
return v10
local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = require(v1.Shared.EggConfig)
local v_u_4 = {}
local v_u_5 = nil
function v_u_4.Settings() -- name: Settings
	-- upvalues: (ref) v_u_5, (copy) v_u_3
	local v6 = v_u_5
	if v6 then
		return v6
	end
	local v7 = v_u_3.Spawn
	if v7 then
		v7 = v_u_3.Spawn.SlowTail
	end
	local v8 = v7 and (v7.Seconds or 0) or 0
	local v9 = math.max(v8, 0)
	local v10 = v7 and (v7.Multiplier or 1) or 1
	local v11 = math.max(v10, 1)
	if v9 <= 0 or v11 <= 1 then
		v9 = 0
		v11 = 1
	end
	local v12 = table.freeze
	local v13 = {
		["Seconds"] = v9,
		["Multiplier"] = v11
	}
	local v14 = v7 and v7.HealthFraction or 0
	v13.HealthFraction = math.clamp(v14, 0, 1)
	local v15 = v12(v13)
	v_u_5 = v15
	return v15
end
function v_u_4.MaxExtraSeconds() -- name: MaxExtraSeconds
	-- upvalues: (copy) v_u_4
	local v16 = v_u_4.Settings()
	return v16.Seconds * (v16.Multiplier - 1)
end
function v_u_4.ShownRemaining(p17) -- name: ShownRemaining
	-- upvalues: (copy) v_u_2
	local v18 = p17:GetAttribute("DespawnAt")
	if not v18 then
		return nil
	end
	local v19 = v18 - v_u_2:GetServerTimeNow()
	return math.max(v19, 0)
end
function v_u_4.IsHurtEnough(p20) -- name: IsHurtEnough
	-- upvalues: (copy) v_u_4
	local v21 = v_u_4.Settings().HealthFraction
	if v21 <= 0 then
		return false
	elseif p20:GetAttribute("Hatching") or (p20:GetAttribute("Broken") or p20:GetAttribute("Despawning")) then
		return false
	else
		local v22 = p20:GetAttribute("Health") or 0
		local v23 = p20:GetAttribute("MaxHealth") or 0
		if v22 <= 0 or v23 <= 0 then
			return false
		else
			return v22 / v23 < v21
		end
	end
end
function v_u_4.IsSlowed(p24) -- name: IsSlowed
	-- upvalues: (copy) v_u_4
	local v25 = v_u_4.Settings()
	if v25.Seconds <= 0 then
		return false
	else
		local v26 = v_u_4.ShownRemaining(p24)
		if v26 and (v26 > 0 and v25.Seconds >= v26) then
			return v_u_4.IsHurtEnough(p24)
		else
			return false
		end
	end
end
function v_u_4.TickDelay(p27, p28) -- name: TickDelay
	if p28 then
		return 0.1
	end
	local v29 = p27 % 1
	return math.clamp(v29, 0.1, 1)
end
return v_u_4
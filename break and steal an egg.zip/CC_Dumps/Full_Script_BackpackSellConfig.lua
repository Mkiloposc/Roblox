local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Shared.EggRewards)
local v4 = require(v2.Shared.MergeConfig)
local v_u_18 = {
	["RemoteName"] = "BackpackSellRemote",
	["PetIncomeSeconds"] = 60,
	["EggIncomeSeconds"] = 60,
	["MaxPerRequest"] = 200,
	["SellText"] = "Sell",
	["ConfirmText"] = "Confirm",
	["SelectedScale"] = 0.85,
	["SelectedTweenInfo"] = nil,
	["AnimalToolTag"] = "AnimalTool",
	["EggToolTag"] = nil,
	["SelectedTweenInfo"] = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
	["EggToolTag"] = v4.EggToolTag,
	["PetValue"] = function(p5, p6, p7, p8, p9) -- name: PetValue
		-- upvalues: (copy) v_u_3, (copy) v_u_18
		local v10 = v_u_3.PlacedCashPerSecond(p5, p6, p7, p8, p9) * v_u_18.PetIncomeSeconds
		return (v10 ~= v10 or (v10 == (1 / 0) or v10 < 0)) and 0 or math.floor(v10)
	end,
	["EggValue"] = function(p11, p12) -- name: EggValue
		-- upvalues: (copy) v_u_3, (copy) v_u_18
		local v13 = v_u_3.PlacedCashPerSecond(p11, nil, nil, p12, nil) * v_u_18.EggIncomeSeconds
		return (v13 ~= v13 or (v13 == (1 / 0) or v13 < 0)) and 0 or math.floor(v13)
	end,
	["IsSellable"] = function(p14) -- name: IsSellable
		-- upvalues: (copy) v_u_1, (copy) v_u_18
		return v_u_1:HasTag(p14, v_u_18.AnimalToolTag) or v_u_1:HasTag(p14, v_u_18.EggToolTag)
	end,
	["ToolValue"] = function(p15) -- name: ToolValue
		-- upvalues: (copy) v_u_1, (copy) v_u_18
		local v16 = p15:GetAttribute("AnimalName")
		if typeof(v16) == "string" then
			local v17 = p15:GetAttribute("WeightKg")
			if v_u_1:HasTag(p15, v_u_18.EggToolTag) then
				return v_u_18.EggValue(v16, v17)
			else
				return not v_u_1:HasTag(p15, v_u_18.AnimalToolTag) and 0 or v_u_18.PetValue(v16, p15:GetAttribute("SizeMult"), p15:GetAttribute("Mutation"), v17, (p15:GetAttribute("Variant")))
			end
		else
			return 0
		end
	end
}
return v_u_18
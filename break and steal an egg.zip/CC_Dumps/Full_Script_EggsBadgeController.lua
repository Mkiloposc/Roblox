local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(v3.Shared.MergeConfig)
local v_u_5 = require(script.Parent.HudBadge)
local v_u_6 = require(script.Parent.Parent.Modules.MainGui)
local v7 = {}
local v_u_8 = v2.LocalPlayer
local v_u_9 = nil
local v_u_10 = {}
local function v_u_14() -- name: refresh
	-- upvalues: (ref) v_u_9, (copy) v_u_10, (copy) v_u_8
	if v_u_9 then
		local v11 = 0
		for v12 in v_u_10 do
			local v13 = v12:IsA("Model")
			if v13 then
				if v12:GetAttribute("OwnerUserId") == v_u_8.UserId then
					v13 = v12:GetAttribute("Ready") == true
				else
					v13 = false
				end
			end
			if not v13 then
				continue
			end
			v11 = v11 + 1
		end
		v_u_9.SetCount(v11)
	end
end
local function v_u_18(p15) -- name: unwatch
	-- upvalues: (copy) v_u_10, (copy) v_u_14
	local v16 = v_u_10[p15]
	if v16 then
		v_u_10[p15] = nil
		for _, v17 in v16 do
			v17:Disconnect()
		end
		v_u_14()
	end
end
local function v_u_20(p19) -- name: watch
	-- upvalues: (copy) v_u_10, (copy) v_u_14
	if not v_u_10[p19] then
		v_u_10[p19] = { p19:GetAttributeChangedSignal("Ready"):Connect(v_u_14), p19:GetAttributeChangedSignal("OwnerUserId"):Connect(v_u_14) }
		v_u_14()
	end
end
local function v_u_27(p21) -- name: adopt
	-- upvalues: (ref) v_u_9, (copy) v_u_5, (copy) v_u_14
	local v22 = p21:WaitForChild("RightHUD", 10)
	if v22 then
		v22 = v22:FindFirstChild("Eggs")
	end
	if v22 then
		v22 = v22:FindFirstChild("Notification")
	end
	if v22 then
		local v23 = v22:FindFirstChild("Inner")
		local v24 = v_u_5.Attach
		local v25 = {}
		local v26
		if v23 and v23:IsA("UIStroke") then
			v26 = v23.Color
		else
			v26 = nil
		end
		v25.RingColor = v26
		v_u_9 = v24(v22, v25)
		v_u_14()
	else
		warn("[EggsBadgeController] missing RightHUD.Eggs.Notification")
		v_u_9 = nil
	end
end
function v7.Start() -- name: Start
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_20, (copy) v_u_18, (copy) v_u_6, (copy) v_u_27
	v_u_1:GetInstanceAddedSignal(v_u_4.PlacedEggTag):Connect(v_u_20)
	v_u_1:GetInstanceRemovedSignal(v_u_4.PlacedEggTag):Connect(v_u_18)
	for _, v28 in v_u_1:GetTagged(v_u_4.PlacedEggTag) do
		v_u_20(v28)
	end
	v_u_6.Observe(v_u_27)
end
return v7
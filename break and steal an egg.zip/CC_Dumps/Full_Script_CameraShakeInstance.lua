local v_u_1 = {}
v_u_1.__index = v_u_1
v_u_1.CameraShakeState = {
	["FadingIn"] = 0,
	["FadingOut"] = 1,
	["Sustained"] = 2,
	["Inactive"] = 3
}
local v_u_2 = Random.new()
function v_u_1.new(p3, p4, p5, p6) -- name: new
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v7 = p5 == nil and 0 or p5
	local v8 = p6 == nil and 0 or p6
	local v9 = type(p3) == "number"
	assert(v9, "Magnitude must be a number")
	local v10 = type(p4) == "number"
	assert(v10, "Roughness must be a number")
	local v11 = {
		["Magnitude"] = nil,
		["Roughness"] = nil,
		["PositionInfluence"] = Vector3.new(0, 0, 0),
		["RotationInfluence"] = Vector3.new(0, 0, 0),
		["DeleteOnInactive"] = true,
		["roughMod"] = 1,
		["magnMod"] = 1,
		["fadeOutDuration"] = nil,
		["fadeInDuration"] = nil,
		["sustain"] = nil,
		["currentFadeTime"] = nil,
		["tick"] = nil,
		["Magnitude"] = p3,
		["Roughness"] = p4,
		["fadeOutDuration"] = v8,
		["fadeInDuration"] = v7,
		["sustain"] = v7 > 0,
		["currentFadeTime"] = v7 > 0 and 0 or 1,
		["tick"] = v_u_2:NextNumber(-100, 100)
	}
	local v12 = v_u_1
	return setmetatable(v11, v12)
end
function v_u_1.UpdateShake(p13, p14) -- name: UpdateShake
	local v15 = p13.tick
	local v16 = p13.currentFadeTime
	local v17 = math.noise(v15, 0) * 0.5
	local v18 = math.noise(0, v15) * 0.5
	local v19 = math.noise(v15, v15) * 0.5
	local v20 = Vector3.new(v17, v18, v19)
	if p13.fadeInDuration > 0 and p13.sustain then
		if v16 < 1 then
			v16 = v16 + p14 / p13.fadeInDuration
		elseif p13.fadeOutDuration > 0 then
			p13.sustain = false
		end
	end
	if not p13.sustain then
		v16 = p13.fadeOutDuration <= 0 and 0 or v16 - p14 / p13.fadeOutDuration
	end
	if p13.sustain then
		p13.tick = v15 + p14 * p13.Roughness * p13.roughMod
	else
		p13.tick = v15 + p14 * p13.Roughness * p13.roughMod * v16
	end
	local v21 = math.clamp(v16, 0, 1)
	p13.currentFadeTime = v21
	return v20 * p13.Magnitude * p13.magnMod * v21
end
function v_u_1.StartFadeOut(p22, p23) -- name: StartFadeOut
	if p23 == 0 then
		p22.currentFadeTime = 0
	end
	p22.fadeOutDuration = p23
	p22.fadeInDuration = 0
	p22.sustain = false
end
function v_u_1.StartFadeIn(p24, p25) -- name: StartFadeIn
	if p25 == 0 then
		p24.currentFadeTime = 1
	end
	p24.fadeInDuration = p25 or p24.fadeInDuration
	p24.fadeOutDuration = 0
	p24.sustain = true
end
function v_u_1.GetScaleRoughness(p26) -- name: GetScaleRoughness
	return p26.roughMod
end
function v_u_1.SetScaleRoughness(p27, p28) -- name: SetScaleRoughness
	p27.roughMod = p28
end
function v_u_1.GetScaleMagnitude(p29) -- name: GetScaleMagnitude
	return p29.magnMod
end
function v_u_1.SetScaleMagnitude(p30, p31) -- name: SetScaleMagnitude
	p30.magnMod = p31
end
function v_u_1.GetNormalizedFadeTime(p32) -- name: GetNormalizedFadeTime
	return p32.currentFadeTime
end
function v_u_1.IsShaking(p33) -- name: IsShaking
	return p33.currentFadeTime > 0 and true or p33.sustain
end
function v_u_1.IsFadingOut(p34) -- name: IsFadingOut
	local v35 = not p34.sustain
	if v35 then
		v35 = p34.currentFadeTime > 0
	end
	return v35
end
function v_u_1.IsFadingIn(p36) -- name: IsFadingIn
	local v37 = p36.currentFadeTime < 1 and p36.sustain
	if v37 then
		v37 = p36.fadeInDuration > 0
	end
	return v37
end
function v_u_1.GetState(p38) -- name: GetState
	-- upvalues: (copy) v_u_1
	if p38:IsFadingIn() then
		return v_u_1.CameraShakeState.FadingIn
	elseif p38:IsFadingOut() then
		return v_u_1.CameraShakeState.FadingOut
	elseif p38:IsShaking() then
		return v_u_1.CameraShakeState.Sustained
	else
		return v_u_1.CameraShakeState.Inactive
	end
end
return v_u_1
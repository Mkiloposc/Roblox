local v_u_1 = game:GetService("Lighting")
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("SoundService")
local v_u_6 = game:GetService("TweenService")
local v_u_7 = game:GetService("Workspace")
local v_u_8 = require(v3.Shared.BinaryTransitionConfig)
local v_u_9 = require(script.Parent.Parent.Controllers.CameraFovController)
local v_u_10 = {
	["TransitionCovered"] = Instance.new("BindableEvent")
}
v_u_10.TransitionCovered.Name = "TransitionCovered"
v_u_10.SceneReady = Instance.new("BindableEvent")
v_u_10.SceneReady.Name = "SceneReady"
v_u_10.Finished = Instance.new("BindableEvent")
v_u_10.Finished.Name = "Finished"
local v_u_11 = false
function v_u_10.IsPlaying() -- name: IsPlaying
	-- upvalues: (ref) v_u_11
	return v_u_11
end
local v_u_12 = v_u_8.FIRE_PALETTE
local function v_u_17(p13) -- name: fireColor
	-- upvalues: (copy) v_u_12
	if p13 <= v_u_12[1][1] then
		return v_u_12[1][2]
	end
	for v14 = 2, #v_u_12 do
		local v15 = v_u_12[v14]
		if p13 > v15[1] then
			continue
		end
		local v16 = v_u_12[v14 - 1]
		return v16[2]:Lerp(v15[2], (p13 - v16[1]) / (v15[1] - v16[1]))
	end
	return v_u_12[#v_u_12][2]
end
local v18 = v_u_8.EDGE_BLEED_COLUMNS or 0
local v_u_19 = math.max(0, v18)
local function v_u_34(p20, p21, p22, p23) -- name: buildTile
	-- upvalues: (copy) v_u_17, (copy) v_u_8
	local v24 = Instance.new("Frame")
	v24.Name = ("Tile_%*_%*"):format(p22, p23)
	v24.AnchorPoint = Vector2.new(0.5, 0.5)
	v24.BackgroundColor3 = v_u_17(v_u_8.EDGE_GLOW_HEAT)
	v24.BackgroundTransparency = 0
	v24.BorderSizePixel = 0
	v24.Visible = false
	v24.ZIndex = 2
	if v_u_8.CORNER_RADIUS > 0 then
		local v25 = Instance.new("UICorner")
		v25.CornerRadius = UDim.new(0, v_u_8.CORNER_RADIUS)
		v25.Parent = v24
	end
	local v26 = Instance.new("UIStroke")
	v26.ApplyStrokeMode = Enum.ApplyStrokeMode.Border
	v26.Color = v_u_8.EDGE_STROKE_COLOR
	v26.Thickness = v_u_8.EDGE_STROKE_THICKNESS
	v26.Transparency = v_u_8.EDGE_STROKE_TRANSPARENCY
	v26.Parent = v24
	local v27 = Instance.new("UIScale")
	v27.Scale = 0
	v27.Parent = v24
	local v28
	if v_u_8.SHOW_DIGITS then
		v28 = Instance.new("TextLabel")
		v28.Name = "Digit"
		v28.BackgroundTransparency = 1
		v28.Size = UDim2.fromScale(1, 1)
		v28.FontFace = v_u_8.FONT
		v28.Text = p21:NextNumber() < 0.5 and "0" or "1"
		v28.TextColor3 = v_u_8.EDGE_TEXT_COLOR
		v28.TextTransparency = 0
		v28.TextXAlignment = Enum.TextXAlignment.Center
		v28.TextYAlignment = Enum.TextYAlignment.Center
		v28.Parent = v24
	else
		v28 = nil
	end
	v24.Parent = p20
	local v29 = {
		["Frame"] = nil,
		["Label"] = nil,
		["Stroke"] = nil,
		["Scale"] = nil,
		["Column"] = nil,
		["Row"] = nil,
		["Settled"] = nil,
		["Appear"] = 0,
		["CoolAt"] = 0,
		["WhiteOffset"] = 0,
		["RemoveOffset"] = 0,
		["FlashUntil"] = (-1 / 0),
		["ShownVisible"] = false,
		["ShownScale"] = 0,
		["ShownWhite"] = 1,
		["ShownChar"] = 0,
		["ShownBackground"] = nil,
		["Leaving"] = false,
		["Frame"] = v24,
		["Label"] = v28,
		["Stroke"] = v26,
		["Scale"] = v27,
		["Column"] = p22,
		["Row"] = p23
	}
	local v30 = v_u_8.SETTLED_COLOR:Lerp(v_u_8.SETTLED_COLOR_ALT, p21:NextNumber())
	local v31 = p21:NextNumber(v_u_8.SETTLED_BRIGHTNESS_MIN, 1)
	v29.Settled = Color3.new(v30.R * v31, v30.G * v31, v30.B * v31)
	local v32 = v_u_8.EDGE_GLOW_HEAT
	local v33 = math.clamp(v32, 0, 1) * 40 + 0.5
	v29.ShownBackground = math.floor(v33) / 40
	return v29
end
local function v_u_63(p35) -- name: layout
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_19
	local v36 = p35.Gui
	local v37 = v_u_7.CurrentCamera
	local v38
	if v37 then
		v38 = v37.ViewportSize
	else
		v38 = Vector2.new(1372, 758)
	end
	if v36 then
		local v39 = v36.AbsoluteSize
		local v40 = Vector2.new
		local v41 = v38.X
		local v42 = v39.X
		local v43 = math.max(v41, v42)
		local v44 = v38.Y
		local v45 = v39.Y
		v38 = v40(v43, (math.max(v44, v45)))
	end
	local v46
	if v38.Y < v_u_8.SMALL_SCREEN_HEIGHT then
		v46 = v_u_8.SMALL_SCREEN_COLUMNS
	else
		v46 = v_u_8.COLUMNS
	end
	local v47 = v38.X / v46
	local v48 = math.floor(v47)
	local v49 = math.max(1, v48)
	local v50 = v38.X
	local v51 = p35.Columns - v_u_19 * 2
	local v52 = v50 / math.max(v51, 1)
	local v53 = math.ceil(v52)
	local v54 = v38.Y / p35.Rows
	local v55 = math.ceil(v54)
	local v56 = math.max(v49, v53, v55, 1)
	local v57 = v56 - v_u_8.TILE_GAP
	local v58 = math.max(1, v57)
	local v59 = v56 * v_u_8.TEXT_SIZE_RATIO
	local v60 = math.floor(v59)
	local v61 = math.max(1, v60)
	for _, v62 in p35.Tiles do
		v62.Frame.Position = UDim2.fromOffset((v62.Column - v_u_19) * v56 + v56 * 0.5, v62.Row * v56 + v56 * 0.5)
		v62.Frame.Size = UDim2.fromOffset(v58, v58)
		if not v62.Label then
			continue
		end
		v62.Label.TextSize = v61
	end
end
local function v_u_89(p64, p65) -- name: scheduleCover
	-- upvalues: (copy) v_u_8
	local v66 = p64.Rows
	local v67 = {}
	local v68 = {}
	local v69 = 0
	for v70 = 1, p64.Columns do
		v67[v70] = p65:NextNumber(0, v_u_8.DELAY_MAX)
		v68[v70] = p65:NextNumber(v_u_8.SPEED_MIN, v_u_8.SPEED_MAX)
		local v71 = v67[v70] + (v66 - 1) * v68[v70]
		v69 = math.max(v69, v71)
	end
	local v72 = v69 <= 0 and 1 or (v_u_8.COVER_TIME - v_u_8.POP_TIME) / v69
	for v73 = 1, p64.Columns do
		local v74 = p64.ByColumn[v73]
		local v75 = v67[v73] * v72
		local v76 = v68[v73] * v72
		for v77 = 1, v66 do
			v74[v77].Appear = v75 + (v77 - 1) * v76
		end
		local v78 = p65:NextInteger(v_u_8.SPARK_ROWS_MIN, v_u_8.SPARK_ROWS_MAX)
		if p65:NextNumber() < v_u_8.SPARK_CHANCE and v66 - 1 >= v78 + 2 then
			local v79 = p65:NextInteger(v78 + 2, v66 - 1)
			v74[v79].Appear = v74[v79 - v78].Appear + v76 * p65:NextNumber(0.2, 0.8)
		end
		for v80 = 1, v66 do
			local v81 = v74[v80]
			local v82 = v74[v80 + 1]
			if v82 then
				local v83 = v81.Appear + v_u_8.POP_TIME
				local v84 = v82.Appear
				v81.CoolAt = math.max(v83, v84)
			else
				local v85 = v81.Appear
				local v86 = v81.Appear + v76
				local v87 = v_u_8.COVER_TIME - v_u_8.SETTLE_TIME
				local v88 = math.min(v86, v87)
				v81.CoolAt = math.max(v85, v88)
			end
		end
	end
end
local function v_u_111(p90, p91) -- name: scheduleReveal
	-- upvalues: (copy) v_u_8
	local v92 = p90.Rows
	local v93 = 0
	for v94 = 1, p90.Columns do
		local v95 = p90.ByColumn[v94]
		local v96 = p91:NextNumber(0, v_u_8.REVEAL_DELAY_MAX)
		local v97 = p91:NextNumber(v_u_8.REVEAL_SPEED_MIN, v_u_8.REVEAL_SPEED_MAX)
		for v98 = 1, v92 do
			local v99 = v96 + (v98 - 1) * v97
			if v92 - v_u_8.STRAGGLER_ROWS < v98 then
				v99 = v99 + p91:NextNumber(0, v_u_8.STRAGGLER_JITTER)
			end
			v95[v98].RemoveOffset = v99
			v93 = math.max(v93, v99)
		end
	end
	local v100 = v93 <= 0 and 1 or (v_u_8.REVEAL_TIME - v_u_8.SHRINK_TIME) / v93
	for v101 = 1, p90.Columns do
		local v102 = p90.ByColumn[v101]
		for v103 = 1, v92 do
			local v104 = v102[v103]
			v104.RemoveOffset = v104.RemoveOffset * v100
		end
		for v105 = 1, v92 do
			local v106 = v102[v105]
			local v107 = v102[v105 - 1]
			local v108 = v106.RemoveOffset - v_u_8.REVEAL_EDGE_LEAD
			local v109 = 0
			if v107 then
				local v110 = v107.RemoveOffset
				v108 = math.min(v110, v108)
			end
			v106.WhiteOffset = math.max(v109, v108)
		end
	end
end
local function v_u_129(p112) -- name: fireStep
	-- upvalues: (copy) v_u_8
	local v113 = p112.Heat
	local v114 = p112.Rng
	local v115 = p112.Columns
	local v116 = p112.Rows
	local v117
	if p112.Covered then
		local v118 = (p112.Time - p112.CoveredAt) / v_u_8.FIRE_IGNITE_TIME
		v117 = math.clamp(v118, 0, 1)
		if p112.RevealStart then
			local v119 = (p112.Time - p112.RevealStart) / v_u_8.FIRE_DIE_TIME
			v117 = v117 * (1 - math.clamp(v119, 0, 1))
		end
	else
		v117 = 0
	end
	local v120 = v_u_8.FIRE_WIND
	local v121 = v120 > 0 and 1 or -1
	for v122 = 1, v115 do
		v113[v122][v116] = v117 * v114:NextNumber(v_u_8.FIRE_FUEL_MIN, 1)
	end
	for v123 = 1, v116 - 1 do
		for v124 = 1, v115 do
			local v125 = v114:NextInteger(-1, 1)
			if v120 ~= 0 then
				if v114:NextNumber() < math.abs(v120) then
					v125 = v121
				end
			end
			local v126 = v124 + v125
			local v127 = v113[math.clamp(v126, 1, v115)]
			local v128 = v113[v124][v123 + 1] - v114:NextNumber(0, v_u_8.FIRE_DECAY_MAX)
			v127[v123] = math.max(0, v128)
		end
	end
end
local function v_u_132(p130, p131) -- name: advanceFire
	-- upvalues: (copy) v_u_8, (copy) v_u_129
	if p130.Covered then
		p130.FireClock = p130.FireClock + p131
		while p130.FireClock >= v_u_8.FIRE_STEP do
			p130.FireClock = p130.FireClock - v_u_8.FIRE_STEP
			v_u_129(p130)
		end
	end
end
local function v_u_146(p133, p134) -- name: buildSounds
	-- upvalues: (copy) v_u_5, (copy) v_u_8
	local v135 = v_u_5:FindFirstChild(v_u_8.SFX_FOLDER)
	p133.Ticks = {}
	for _ = 1, v_u_8.TICK_POOL do
		local v136 = v_u_8.TICK_SOUND
		local v137 = v_u_8.TICK_VOLUME
		local v138
		if v135 then
			v138 = v135:FindFirstChild(v136)
		else
			v138 = v135
		end
		local v139
		if v138 and v138:IsA("Sound") then
			v139 = v138:Clone()
			v139.Looped = false
			v139.PlayOnRemove = false
			v139.Volume = v137
			v139.Parent = p134
		else
			v139 = nil
		end
		if not v139 then
			break
		end
		local v140 = p133.Ticks
		table.insert(v140, v139)
	end
	local v141 = v_u_8.WHOOSH_SOUND
	local v142 = v_u_8.WHOOSH_VOLUME
	if v135 then
		v135 = v135:FindFirstChild(v141)
	end
	local v143
	if v135 and v135:IsA("Sound") then
		v143 = v135:Clone()
		v143.Looped = false
		v143.PlayOnRemove = false
		v143.Volume = v142
		v143.Parent = p134
	else
		v143 = nil
	end
	p133.Whoosh = v143
	if p133.Whoosh then
		p133.Whoosh.PlaybackSpeed = v_u_8.WHOOSH_PITCH
	end
	if v_u_8.IGNITE_SOUND_ID ~= "" then
		local v144 = Instance.new("Sound")
		v144.Name = "Ignite"
		v144.SoundId = v_u_8.IGNITE_SOUND_ID
		v144.Volume = v_u_8.IGNITE_VOLUME
		v144.PlaybackSpeed = v_u_8.IGNITE_PITCH
		local v145
		if p133.Whoosh then
			v145 = p133.Whoosh.SoundGroup
		else
			v145 = nil
		end
		v144.SoundGroup = v145
		v144.Parent = p134
		p133.Ignite = v144
	end
end
local function v_u_150(p147) -- name: playTick
	-- upvalues: (copy) v_u_8
	local v148 = p147.Ticks
	if #v148 ~= 0 and p147.Time - p147.LastTick >= 1 / v_u_8.TICK_MAX_PER_SECOND then
		p147.LastTick = p147.Time
		p147.TickIndex = p147.TickIndex % #v148 + 1
		local v149 = v148[p147.TickIndex]
		v149.PlaybackSpeed = p147.Rng:NextNumber(v_u_8.TICK_PITCH_MIN, v_u_8.TICK_PITCH_MAX)
		v149.TimePosition = 0
		v149:Play()
	end
end
local function v_u_159(p151, p152, p153) -- name: paintDigit
	-- upvalues: (copy) v_u_8
	p151.ShownWhite = p152
	p151.ShownChar = p153
	p151.Frame.ZIndex = p152 > 0 and 2 or 1
	local v154 = p151.Label
	if v154 then
		local v155 = p151.Settled:Lerp(v_u_8.EDGE_TEXT_COLOR, p152)
		local v156 = p153 * (1 - p152)
		if v156 > 0 then
			v155 = v155:Lerp(v_u_8.FIRE_DIGIT_COLOR, v156)
		end
		v154.TextColor3 = v155
		local v157 = v_u_8.SETTLED_TEXT_TRANSPARENCY
		local v158 = math.max(p152, v156)
		v154.TextTransparency = v157 + (0 - v157) * v158
	end
	if p152 <= 0 then
		p151.Stroke.Enabled = false
	else
		p151.Stroke.Enabled = true
		p151.Stroke.Transparency = (v_u_8.EDGE_STROKE_TRANSPARENCY - 1) * p152 + 1
	end
end
local function v_u_169(p160, p161) -- name: flicker
	-- upvalues: (copy) v_u_8
	p160.FlickerClock = p160.FlickerClock + p161
	while p160.FlickerClock >= v_u_8.FLICKER_INTERVAL do
		p160.FlickerClock = p160.FlickerClock - v_u_8.FLICKER_INTERVAL
		local v162 = p160.Tiles
		local v163 = p160.Rng
		local v164 = #v162 * v_u_8.FLICKER_FRACTION + 0.5
		local v165 = math.floor(v164)
		for _ = 1, math.max(1, v165) do
			local v166 = v162[v163:NextInteger(1, #v162)]
			local v167 = v166.Label
			if v167 then
				local v168 = v167.Text
				if v163:NextNumber() < v_u_8.DEVIL_DIGIT_CHANCE then
					v167.Text = v_u_8.DEVIL_DIGIT
				elseif v168 == "0" then
					v167.Text = "1"
				elseif v168 == "1" then
					v167.Text = "0"
				else
					v167.Text = v163:NextNumber() < 0.5 and "0" or "1"
				end
			end
			v166.FlashUntil = p160.Time + v_u_8.FLICKER_FLASH_TIME
		end
	end
end
local function v_u_197(p170) -- name: render
	-- upvalues: (copy) v_u_8, (copy) v_u_150, (copy) v_u_159, (copy) v_u_17
	local v171 = p170.Time
	local v172 = p170.RevealStart
	local v173 = p170.Heat
	local v174 = 0
	for _, v175 in p170.Tiles do
		local v176 = false
		local v177 = 0
		local v178 = 0
		local v179 = 0
		if v172 and v172 + v175.RemoveOffset <= v171 then
			local v180 = (v171 - v172 - v175.RemoveOffset) / v_u_8.SHRINK_TIME
			if v180 < 1 then
				local v181 = 1 - math.clamp(v180, 0, 1)
				v177 = v181 * v181
				v179 = v_u_8.EMBER_HEAT
				v178 = 1
				v176 = true
			end
			if not v175.Leaving then
				v175.Leaving = true
				v_u_150(p170)
			end
		elseif v172 and v172 + v175.WhiteOffset <= v171 then
			v178 = 1
			v176 = true
			v177 = 1
		elseif v175.Appear <= v171 then
			v176 = true
			local v182 = (v171 - v175.Appear) / v_u_8.POP_TIME
			if v182 >= 1 then
				v177 = 1
			elseif v182 <= 0 then
				v177 = 0
			else
				local v183 = v_u_8.POP_OVERSHOOT
				local v184 = v183 + 1
				local v185 = v182 - 1
				v177 = 1 + v184 * v185 * v185 * v185 + v183 * v185 * v185
			end
			if v171 < v175.CoolAt then
				v178 = 1
			else
				local v186 = (v171 - v175.CoolAt) / v_u_8.SETTLE_TIME
				v178 = 1 - math.clamp(v186, 0, 1)
			end
			if v171 < v175.FlashUntil then
				v178 = 1
			end
		end
		if v176 ~= v175.ShownVisible then
			v175.ShownVisible = v176
			v175.Frame.Visible = v176
			if v176 and not v172 then
				v_u_150(p170)
			end
		end
		if not v176 then
			continue
		end
		v174 = v174 + 1
		local v187 = v177 - v175.ShownScale
		if math.abs(v187) > 0.001 then
			v175.ShownScale = v177
			v175.Scale.Scale = v177
		end
		local v188 = v173[v175.Column + 1][v175.Row + 1]
		local v189 = v188 * v_u_8.FIRE_DIGIT_CHAR
		local v190 = math.clamp(v189, 0, 1) * 40 + 0.5
		local v191 = math.floor(v190) / 40
		local v192 = v178 - v175.ShownWhite
		if math.abs(v192) > 0.001 or v191 ~= v175.ShownChar then
			v_u_159(v175, v178, v191)
		end
		local v193 = v178 * v_u_8.EDGE_GLOW_HEAT
		local v194 = math.max(v188, v193, v179)
		local v195 = math.clamp(v194, 0, 1) * 40 + 0.5
		local v196 = math.floor(v195) / 40
		if v196 == v175.ShownBackground then
			continue
		end
		v175.ShownBackground = v196
		v175.Frame.BackgroundColor3 = v_u_17(v196)
	end
	return v174
end
local v_u_198 = nil
local function v_u_202(p199) -- name: runOnCovered
	if p199 then
		local v200, v201 = pcall(p199)
		if not v200 then
			warn((("[BinaryTransition] onCovered errored: %*"):format(v201)))
		end
	end
end
function v_u_10.Play(p_u_203, p204) -- name: Play
	-- upvalues: (copy) v_u_8, (ref) v_u_11, (copy) v_u_2, (copy) v_u_7, (copy) v_u_19, (copy) v_u_34, (copy) v_u_89, (copy) v_u_111, (copy) v_u_63, (copy) v_u_146, (copy) v_u_1, (ref) v_u_198, (copy) v_u_9, (copy) v_u_4, (copy) v_u_6, (copy) v_u_10, (copy) v_u_169, (copy) v_u_132, (copy) v_u_197, (copy) v_u_202
	local v_u_205 = p204 or v_u_8.HOLD_TIME
	if v_u_11 then
		if p_u_203 then
			local v206, v207 = pcall(p_u_203)
			if not v206 then
				warn((("[BinaryTransition] onCovered errored: %*"):format(v207)))
			end
		end
	else
		v_u_11 = true
		local v208 = v_u_2.LocalPlayer:WaitForChild("PlayerGui")
		local v209 = Random.new()
		local v_u_210 = Instance.new("ScreenGui")
		v_u_210.Name = "BinaryTransition"
		v_u_210.IgnoreGuiInset = true
		v_u_210.ScreenInsets = Enum.ScreenInsets.None
		v_u_210.ResetOnSpawn = false
		v_u_210.DisplayOrder = v_u_8.DISPLAY_ORDER
		v_u_210.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		v_u_210.Parent = v208
		local v211 = v_u_7.CurrentCamera
		local v212
		if v211 then
			v212 = v211.ViewportSize
		else
			v212 = Vector2.new(1372, 758)
		end
		if v_u_210 then
			local v213 = v_u_210.AbsoluteSize
			local v214 = Vector2.new
			local v215 = v212.X
			local v216 = v213.X
			local v217 = math.max(v215, v216)
			local v218 = v212.Y
			local v219 = v213.Y
			v212 = v214(v217, (math.max(v218, v219)))
		end
		local v220
		if v212.Y < v_u_8.SMALL_SCREEN_HEIGHT then
			v220 = v_u_8.SMALL_SCREEN_COLUMNS
		else
			v220 = v_u_8.COLUMNS
		end
		local v221 = v212.X / v220
		local v222 = math.floor(v221)
		local v223 = math.max(1, v222)
		local v224 = v212.X / v223
		local v225 = math.ceil(v224) + v_u_19 * 2
		local v226 = v212.Y / v223
		local v227 = math.ceil(v226) + 1
		local v228 = v225
		local v_u_229 = {
			["Gui"] = nil,
			["Rng"] = nil,
			["Columns"] = nil,
			["Rows"] = nil,
			["Tiles"] = nil,
			["ByColumn"] = nil,
			["Heat"] = nil,
			["Time"] = 0,
			["Covered"] = false,
			["CoveredAt"] = 0,
			["Ready"] = false,
			["RevealStart"] = nil,
			["FlickerClock"] = 0,
			["FireClock"] = 0,
			["LastTick"] = (-1 / 0),
			["TickIndex"] = 0,
			["Ticks"] = nil,
			["Whoosh"] = nil,
			["Ignite"] = nil,
			["Gui"] = v_u_210,
			["Rng"] = v209,
			["Columns"] = v228,
			["Rows"] = v227,
			["Tiles"] = {},
			["ByColumn"] = {},
			["Heat"] = {},
			["Ticks"] = {}
		}
		for v230 = 1, v228 do
			local v231 = {}
			local v232 = table.create(v227, 0)
			v_u_229.ByColumn[v230] = v231
			v_u_229.Heat[v230] = v232
			for v233 = 1, v227 do
				local v234 = v_u_34(v_u_210, v209, v230 - 1, v233 - 1)
				v231[v233] = v234
				local v235 = v_u_229.Tiles
				table.insert(v235, v234)
			end
		end
		v_u_89(v_u_229, v209)
		v_u_111(v_u_229, v209)
		v_u_63(v_u_229)
		v_u_146(v_u_229, v_u_210)
		local v236 = v_u_7.CurrentCamera
		local v_u_237
		if v_u_8.BLUR_MAX > 0 then
			v_u_237 = Instance.new("BlurEffect")
			v_u_237.Name = "BinaryTransitionBlur"
			v_u_237.Size = 0
			v_u_237.Parent = v_u_1
		else
			v_u_237 = nil
		end
		if v_u_198 then
			v_u_198:Disconnect()
			v_u_198 = nil
		end
		local v_u_238
		if v_u_8.CAMERA_FOV_TARGET == nil then
			v_u_238 = 0
		else
			local v239 = v_u_8.CAMERA_FOV_TARGET
			v_u_238 = math.max(v239, 1) - v_u_9.GetOriginal()
		end
		local v_u_240 = 0
		local v_u_241 = false
		local function v_u_254(p242) -- name: stepCinematics
			-- upvalues: (ref) v_u_237, (copy) v_u_229, (ref) v_u_8, (copy) v_u_238, (ref) v_u_241, (ref) v_u_240, (ref) v_u_198, (ref) v_u_4, (ref) v_u_9, (ref) v_u_6
			if v_u_237 then
				local v243
				if v_u_229.RevealStart then
					local v244 = (p242 - v_u_229.RevealStart) / v_u_8.REVEAL_TIME
					v243 = 1 - math.clamp(v244, 0, 1)
				else
					local v245 = p242 / v_u_8.BLUR_IN_TIME
					v243 = math.clamp(v245, 0, 1)
				end
				local v246 = v_u_237
				local v247 = v_u_8.BLUR_MAX
				local v248 = math.clamp(v243, 0, 1) * 3.141592653589793
				v246.Size = v247 * (0.5 - math.cos(v248) * 0.5)
			end
			if v_u_238 == 0 or v_u_241 then
				return
			elseif v_u_229.RevealStart then
				v_u_241 = true
				local v_u_249 = v_u_240
				if v_u_198 then
					v_u_198:Disconnect()
					v_u_198 = nil
				end
				local v_u_250 = os.clock()
				v_u_198 = v_u_4.RenderStepped:Connect(function()
					-- upvalues: (copy) v_u_250, (ref) v_u_8, (ref) v_u_198, (ref) v_u_9, (ref) v_u_6, (copy) v_u_249
					local v251 = (os.clock() - v_u_250) / v_u_8.FOV_OUT_TIME
					if v251 >= 1 then
						if v_u_198 then
							v_u_198:Disconnect()
							v_u_198 = nil
						end
						v_u_9.Clear("BinaryTransition")
					else
						local v252 = v_u_6:GetValue(v251, v_u_8.FOV_OUT_STYLE, Enum.EasingDirection.Out)
						v_u_9.Set("BinaryTransition", v_u_249 * (1 - v252))
					end
				end)
			else
				local v253 = p242 / v_u_8.FOV_IN_TIME
				v_u_240 = v_u_238 * v_u_6:GetValue(math.clamp(v253, 0, 1), v_u_8.FOV_IN_STYLE, Enum.EasingDirection.In)
				v_u_9.Set("BinaryTransition", v_u_240)
			end
		end
		local v_u_255 = coroutine.running()
		local v_u_256 = {}
		local v_u_257 = false
		local function v_u_259() -- name: finish
			-- upvalues: (ref) v_u_257, (copy) v_u_256, (ref) v_u_237, (ref) v_u_241, (ref) v_u_9, (copy) v_u_210, (ref) v_u_11, (ref) v_u_10, (copy) v_u_255
			if not v_u_257 then
				v_u_257 = true
				for _, v258 in v_u_256 do
					v258:Disconnect()
				end
				if v_u_237 then
					v_u_237:Destroy()
					v_u_237 = nil
				end
				if not v_u_241 then
					v_u_9.Clear("BinaryTransition")
				end
				v_u_210:Destroy()
				v_u_11 = false
				v_u_10.Finished:Fire()
				task.spawn(v_u_255)
			end
		end
		local function v_u_270(p260) -- name: step
			-- upvalues: (copy) v_u_229, (ref) v_u_8, (copy) p_u_203, (ref) v_u_10, (copy) v_u_205, (ref) v_u_169, (ref) v_u_132, (copy) v_u_254, (ref) v_u_197, (copy) v_u_259
			local v261 = v_u_229
			v261.Time = v261.Time + p260
			local v262 = v_u_229.Time
			if not v_u_229.Covered and v_u_8.COVER_TIME <= v262 then
				v_u_229.Covered = true
				v_u_229.CoveredAt = v_u_229.Time
				local v263 = v_u_229.Ignite
				if v263 then
					v263.TimePosition = 0
					v263:Play()
				end
				task.spawn(function()
					-- upvalues: (ref) p_u_203, (ref) v_u_229, (ref) v_u_10
					local v264 = p_u_203
					if v264 then
						local v265, v266 = pcall(v264)
						if not v265 then
							warn((("[BinaryTransition] onCovered errored: %*"):format(v266)))
						end
					end
					v_u_229.Ready = true
					v_u_10.SceneReady:Fire()
				end)
				v_u_10.TransitionCovered:Fire()
			end
			if v_u_229.Covered and not v_u_229.RevealStart then
				local v267 = v262 - v_u_229.CoveredAt
				if (v_u_229.Ready or v_u_8.SCENE_READY_TIMEOUT <= v267) and v_u_205 <= v267 then
					v_u_229.RevealStart = v262
					local v268 = v_u_229.Whoosh
					if v268 then
						v268.TimePosition = 0
						v268:Play()
					end
				else
					v_u_169(v_u_229, p260)
				end
			end
			v_u_132(v_u_229, p260)
			v_u_254(v262)
			local v269 = v_u_197(v_u_229)
			if v_u_229.RevealStart and (v269 == 0 and v_u_229.RevealStart + v_u_8.SHRINK_TIME <= v262) then
				v_u_259()
			end
		end
		local v271 = v_u_10.SceneReady.Event
		table.insert(v_u_256, v271:Connect(function()
			-- upvalues: (copy) v_u_229
			if v_u_229.Covered then
				v_u_229.Ready = true
			end
		end))
		if v236 then
			local v272 = v236:GetPropertyChangedSignal("ViewportSize")
			local function v273()
				-- upvalues: (ref) v_u_63, (copy) v_u_229
				v_u_63(v_u_229)
			end
			table.insert(v_u_256, v272:Connect(v273))
		end
		local v274 = v_u_210:GetPropertyChangedSignal("AbsoluteSize")
		local function v275()
			-- upvalues: (ref) v_u_63, (copy) v_u_229
			v_u_63(v_u_229)
		end
		table.insert(v_u_256, v274:Connect(v275))
		local v276 = v_u_4.RenderStepped
		local function v281(p277)
			-- upvalues: (copy) v_u_270, (copy) v_u_229, (ref) v_u_202, (copy) p_u_203, (copy) v_u_259
			local v278 = v_u_270
			local v279, v280 = pcall(v278, p277)
			if not v279 then
				warn((("[BinaryTransition] %*"):format(v280)))
				if not v_u_229.Covered then
					task.spawn(v_u_202, p_u_203)
				end
				v_u_259()
			end
		end
		table.insert(v_u_256, v276:Connect(v281))
		local v282 = v_u_229.Whoosh
		if v282 then
			v282.TimePosition = 0
			v282:Play()
		end
		coroutine.yield()
	end
end
return v_u_10
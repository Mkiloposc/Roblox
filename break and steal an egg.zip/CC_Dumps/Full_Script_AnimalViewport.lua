local v_u_1 = require(script.Parent.ViewportLighting)
local v2 = {}
local v_u_3 = Color3.fromRGB(70, 70, 70)
local v_u_4 = {
	["ARGENTAVIS"] = {
		["nudgeRight"] = 0.05,
		["nudgeUp"] = -0.05
	},
	["AZHDARCHID"] = {
		["nudgeRight"] = 0.07,
		["nudgeUp"] = -0.05
	},
	["Anglerfish"] = {
		["nudgeUp"] = 0.05
	},
	["Fenrir"] = {
		["yaw"] = -65,
		["depth"] = 0.1
	},
	["Raiju"] = {
		["yaw"] = -65,
		["depth"] = 0.1
	},
	["ARCHAEOPTERYX"] = {
		["nudgeRight"] = 0.06,
		["nudgeUp"] = -0.07,
		["zoom"] = 0.85
	},
	["Amphiptere"] = {
		["nudgeRight"] = -0.05,
		["nudgeUp"] = -0.06
	},
	["CALADRIUS"] = {
		["nudgeUp"] = -0.12
	},
	["CERBERUS"] = {
		["nudgeRight"] = 0.05,
		["nudgeUp"] = 0.05
	},
	["Dullahan"] = {
		["nudgeRight"] = 0.08
	},
	["HYDRA"] = {
		["nudgeRight"] = -0.08
	},
	["LEVIATHAN"] = {
		["nudgeRight"] = 0.06
	},
	["Lionfish"] = {
		["nudgeUp"] = -0.05
	},
	["MICRORAPTOR"] = {
		["nudgeUp"] = -0.08
	},
	["PEGASUS"] = {
		["nudgeRight"] = 0.06,
		["zoom"] = 0.8
	},
	["SIMURGH"] = {
		["nudgeUp"] = -0.1,
		["zoom"] = 0.8
	},
	["STEGOSAURUS"] = {
		["nudgeRight"] = 0.06,
		["nudgeUp"] = 0.06
	},
	["STYMPHALIANBIRD"] = {
		["nudgeUp"] = -0.04
	},
	["WYVERN"] = {
		["nudgeRight"] = 0.04
	},
	["sailfish"] = {
		["nudgeRight"] = 0.08,
		["zoom"] = 1.2
	},
	["tuna"] = {
		["nudgeRight"] = 0.08,
		["nudgeUp"] = -0.05
	},
	["Regal"] = {
		["zoom"] = 1.5
	},
	["SPHINX"] = {
		["zoom"] = 1.35,
		["nudgeUp"] = -0.05
	},
	["Snail"] = {
		["zoom"] = 1.4
	},
	["Snake"] = {
		["zoom"] = 1.8
	},
	["Turtle"] = {
		["zoom"] = 1.5
	},
	["Whale"] = {
		["zoom"] = 1.4,
		["nudgeRight"] = 0.05
	}
}
function v2.CloneForViewport(p5) -- name: CloneForViewport
	local v6 = {}
	local v7 = p5:FindFirstChild("AnimSaves")
	if v7 and v7.Archivable then
		v7.Archivable = false
		table.insert(v6, v7)
	end
	for _, v8 in p5:GetChildren() do
		local v9 = v8:IsA("Model")
		if v9 then
			if v8:FindFirstChildOfClass("Humanoid") == nil then
				v9 = false
			else
				v9 = v8:FindFirstChild("HumanoidRootPart") ~= nil
			end
		end
		if not (v9 and (v8 and v8.Archivable)) then
			continue
		end
		v8.Archivable = false
		table.insert(v6, v8)
	end
	local v10 = p5:Clone()
	for _, v11 in v6 do
		v11.Archivable = true
	end
	return v10
end
function v2.PrepareModel(p12) -- name: PrepareModel
	-- upvalues: (copy) v_u_1
	local v13 = p12:FindFirstChild("AnimSaves")
	if v13 then
		v13:Destroy()
	end
	for _, v14 in p12:GetChildren() do
		local v15 = v14:IsA("Model")
		if v15 then
			if v14:FindFirstChildOfClass("Humanoid") == nil then
				v15 = false
			else
				v15 = v14:FindFirstChild("HumanoidRootPart") ~= nil
			end
		end
		if not v15 then
			continue
		end
		v14:Destroy()
	end
	for _, v16 in p12:GetDescendants() do
		if v16:IsA("Humanoid") or (v16:IsA("ProximityPrompt") or v16:IsA("BillboardGui")) then
			v16:Destroy()
		else
			if not v16:IsA("SurfaceAppearance") then
				continue
			end
			v16:Destroy()
		end
	end
	v_u_1.Unshadow(p12)
end
function v2.AttachCamera(p17, p18, p19, p20) -- name: AttachCamera
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_1
	local v21 = p19 and v_u_4[p19] or {}
	local v22 = p20 or {}
	local v23 = v22.fill or (v21.fill or 1.05)
	local v24 = v22.depth or (v21.depth or 0.3)
	local v25 = v22.raise or (v21.raise or 0.18)
	local v26 = v22.yaw or v21.yaw
	local v27 = not v26 and -0.4363323129985824 or math.rad(v26)
	local v28, v29 = p18:GetBoundingBox()
	local v30 = v28.Position + v28.LookVector * (v29.Z * v24)
	local v31 = v29.Y * v25
	local v32 = v30 + Vector3.new(0, v31, 0)
	local v33 = (CFrame.fromAxisAngle(Vector3.new(0, 1, 0), v27) * v28.LookVector).Unit
	local v34 = v29.X
	local v35 = v29.Y
	local v36 = math.max(v34, v35) / 2
	if v26 then
		local v37 = math.sin(v27)
		local v38 = math.abs(v37) * v29.Z
		local v39 = math.cos(v27)
		local v40 = (v38 + math.abs(v39) * v29.X) / 2
		local v41 = v29.Y / 2
		v36 = math.max(v40, v41)
	end
	local v42 = v36 / (v23 * 0.08748866352592401) * (v21.zoom or 1) * (v22.zoom or 1)
	local v43 = CFrame.lookAt(v32 + v33 * v42, v32)
	local v44 = (v21.nudgeRight or 0) + (v22.nudgeRight or 0)
	local v45 = (v21.nudgeUp or 0) + (v22.nudgeUp or 0)
	if v44 ~= 0 or v45 ~= 0 then
		local v46 = 2 * v42 * 0.08748866352592401
		v43 = v43 - (v43.RightVector * v44 + v43.UpVector * v45) * v46
	end
	p17.BackgroundColor3 = v_u_3
	v_u_1.Apply(p17)
	local v47 = Instance.new("Camera")
	v47.FieldOfView = 10
	v47.CFrame = v43
	v47.Parent = p17
	p17.CurrentCamera = v47
	return v47
end
return v2
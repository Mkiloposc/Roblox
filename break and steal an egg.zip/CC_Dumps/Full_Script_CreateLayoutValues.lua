local v1 = game:GetService("CorePackages")
local v2 = require(v1.Workspace.Packages.PlayerList)
local v_u_3 = require(script.Parent.Parent.TopBar.Constants)
local v_u_4 = v2.Common.CreateLayoutValues
return function(p5)
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	return v_u_4(p5, v_u_3)
end
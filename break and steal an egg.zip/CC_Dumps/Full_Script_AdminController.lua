local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Shared.AdminConchTypes)
local v_u_4 = require(v2.Shared.AdminConfig)
local v_u_5 = require(v2.Shared.Packages.conch)
local v_u_6 = require(v2.Shared.Packages.ui)
local v_u_7 = require(script.Parent.Parent.Modules.AdminRawText)
local v8 = {}
local function v_u_11(p9) -- name: waitForVerdict
	-- upvalues: (copy) v_u_4
	local v10 = p9:GetAttribute(v_u_4.Attribute)
	while v10 == nil do
		p9:GetAttributeChangedSignal(v_u_4.Attribute):Wait()
		v10 = p9:GetAttribute(v_u_4.Attribute)
	end
	return v10 == true
end
function v8.Start() -- name: Start
	-- upvalues: (copy) v_u_1, (copy) v_u_11, (copy) v_u_3, (copy) v_u_5, (copy) v_u_4, (copy) v_u_7, (copy) v_u_6
	local v_u_12 = v_u_1.LocalPlayer
	if v_u_11(v_u_12) then
		v_u_3.Register(v_u_5)
		v_u_5.initiate_default_lifecycle()
		if v_u_12:GetAttribute(v_u_4.TagOnlyAttribute) ~= true then
			v_u_5.register_default_commands()
		end
		v_u_7.Install(v_u_5)
		v_u_6.bind_to(v_u_4.Keybind)
		task.spawn(function()
			-- upvalues: (copy) v_u_12
			local v13 = v_u_12:WaitForChild("PlayerGui"):WaitForChild("Command Executor", 10)
			if v13 and v13:IsA("ScreenGui") then
				v13.ResetOnSpawn = false
				v13.IgnoreGuiInset = true
			end
		end)
		print((("[admin] console ready \226\128\148 press %* to open, or type %*cmds in chat"):format(v_u_4.Keybind.Name, v_u_4.ChatPrefix)))
	end
end
return v8
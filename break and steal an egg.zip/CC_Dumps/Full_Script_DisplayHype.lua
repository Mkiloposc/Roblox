local v_u_1 = require(script.Parent.FormatNumber)
local v_u_24 = {
	["Zones"] = nil,
	["LuckSpread"] = 6,
	["SizeExponent"] = 2.5,
	["CounterMinSweep"] = 3,
	["Zones"] = {
		{
			["LuckMult"] = 1
		},
		{
			["LuckMult"] = 8
		},
		{
			["LuckMult"] = 75
		},
		{
			["LuckMult"] = 1000
		},
		{
			["LuckMult"] = 25000
		},
		{
			["LuckMult"] = 1000000
		},
		{
			["LuckMult"] = 25000000
		},
		{
			["LuckMult"] = 500000000
		},
		{
			["LuckMult"] = 10000000000
		},
		{
			["LuckMult"] = 200000000000
		},
		{
			["LuckMult"] = 4000000000000
		},
		{
			["LuckMult"] = 80000000000000
		}
	},
	["ZoneIndexOf"] = function(p2) -- name: ZoneIndexOf
		-- upvalues: (copy) v_u_24
		if p2 then
			p2 = p2:GetAttribute("ZoneIndex")
		end
		if typeof(p2) ~= "number" then
			return 1
		end
		local v3 = math.floor(p2)
		local v4 = #v_u_24.Zones
		return math.clamp(v3, 1, v4)
	end,
	["Luck"] = function(p5, p6, p7) -- name: Luck
		-- upvalues: (copy) v_u_24
		local v8 = v_u_24.Zones
		local v9 = #v_u_24.Zones
		local v10 = v8[math.clamp(p7 or 1, 1, v9)]
		return (1 + ((p5 or 1) - 1) * v_u_24.LuckSpread) * (p6 or 1) ^ v_u_24.SizeExponent * v10.LuckMult
	end,
	["FormatLuck"] = function(p11, p12, p13) -- name: FormatLuck
		-- upvalues: (copy) v_u_24
		return v_u_24.FormatLuckValue(v_u_24.Luck(p11, p12, p13))
	end,
	["FormatLuckValue"] = function(p14) -- name: FormatLuckValue
		-- upvalues: (copy) v_u_1
		return ("x%* Luck"):format((v_u_1.Short(p14, 2)))
	end,
	["LuckCountRange"] = function(p15, p16, p17, p18) -- name: LuckCountRange
		-- upvalues: (copy) v_u_24
		local v19 = v_u_24.Luck(p15, p16 * p17, p18)
		local v20 = v_u_24.Luck(p15, p16, p18)
		local v21
		if v20 > 0 then
			v21 = v19 / v20
		else
			v21 = v_u_24.CounterMinSweep
		end
		local v22 = v_u_24.CounterMinSweep
		local v23 = math.max(v21, v22)
		return v19 / v23, v23
	end
}
return v_u_24
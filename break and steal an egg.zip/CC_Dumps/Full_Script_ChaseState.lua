local v_u_1 = {
	["ChasedAttribute"] = "BeingChased",
	["CarryingAttribute"] = "Carrying",
	["MonsterChasedAttribute"] = "PumpkinKingChased"
}
local function v_u_15(p_u_2, p3, p_u_4, p_u_5) -- name: observe
	local v_u_6 = nil
	local function v8() -- name: update
		-- upvalues: (copy) p_u_4, (copy) p_u_2, (ref) v_u_6, (copy) p_u_5
		local v7 = p_u_4(p_u_2)
		if v7 ~= v_u_6 then
			v_u_6 = v7
			p_u_5(v7)
		end
	end
	local v9 = v_u_6
	local v_u_10 = {}
	for _, v11 in p3 do
		local v12 = p_u_2:GetAttributeChangedSignal(v11)
		table.insert(v_u_10, v12:Connect(v8))
	end
	local v13 = p_u_4(p_u_2)
	if v13 ~= v9 then
		v_u_6 = v13
		p_u_5(v13)
	end
	return function()
		-- upvalues: (copy) v_u_10
		for _, v14 in v_u_10 do
			v14:Disconnect()
		end
		table.clear(v_u_10)
	end
end
function v_u_1.IsCarrying(p16) -- name: IsCarrying
	-- upvalues: (copy) v_u_1
	local v17
	if p16 == nil then
		v17 = false
	else
		v17 = p16:GetAttribute(v_u_1.CarryingAttribute) ~= nil
	end
	return v17
end
function v_u_1.IsMonsterChased(p18) -- name: IsMonsterChased
	-- upvalues: (copy) v_u_1
	local v19
	if p18 == nil then
		v19 = false
	else
		v19 = p18:GetAttribute(v_u_1.MonsterChasedAttribute) == true
	end
	return v19
end
function v_u_1.IsActive(p20) -- name: IsActive
	-- upvalues: (copy) v_u_1
	if not p20 then
		return false
	end
	local v21
	if p20:GetAttribute(v_u_1.ChasedAttribute) == nil then
		v21 = false
	else
		v21 = v_u_1.IsCarrying(p20)
	end
	return v21
end
function v_u_1.Observe(p22, p23) -- name: Observe
	-- upvalues: (copy) v_u_15, (copy) v_u_1
	return v_u_15(p22, { v_u_1.ChasedAttribute, v_u_1.CarryingAttribute }, v_u_1.IsActive, p23)
end
function v_u_1.ObserveCarrying(p24, p25) -- name: ObserveCarrying
	-- upvalues: (copy) v_u_15, (copy) v_u_1
	return v_u_15(p24, { v_u_1.CarryingAttribute }, v_u_1.IsCarrying, p25)
end
return v_u_1
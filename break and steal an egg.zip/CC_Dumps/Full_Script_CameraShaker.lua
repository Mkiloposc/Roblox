local v_u_1 = game:GetService("RunService")
local v_u_2 = require(script.CameraShakeInstance)
local v_u_3 = v_u_2.CameraShakeState
local v_u_4 = {}
v_u_4.__index = v_u_4
v_u_4.CameraShakeInstance = v_u_2
v_u_4.Presets = require(script.CameraShakePresets)
local v_u_5 = 0
function v_u_4.new(p6, p7) -- name: new
	-- upvalues: (ref) v_u_5, (copy) v_u_4
	local v8 = type(p6) == "number"
	assert(v8, "RenderPriority must be a number")
	local v9 = type(p7) == "function"
	assert(v9, "Callback must be a function")
	v_u_5 = v_u_5 + 1
	local v10 = {
		["_running"] = false,
		["_renderName"] = nil,
		["_renderPriority"] = nil,
		["_camShakeInstances"] = nil,
		["_callback"] = nil,
		["_renderName"] = ("CameraShaker_%*"):format(v_u_5),
		["_renderPriority"] = p6,
		["_camShakeInstances"] = {},
		["_callback"] = p7
	}
	local v11 = v_u_4
	return setmetatable(v10, v11)
end
function v_u_4.Start(p_u_12) -- name: Start
	-- upvalues: (copy) v_u_1
	if not p_u_12._running then
		p_u_12._running = true
		v_u_1:BindToRenderStep(p_u_12._renderName, p_u_12._renderPriority, function(p13)
			-- upvalues: (copy) p_u_12
			if #p_u_12._camShakeInstances ~= 0 then
				p_u_12._callback(p_u_12:Update(p13))
			end
		end)
	end
end
function v_u_4.Stop(p14) -- name: Stop
	-- upvalues: (copy) v_u_1
	if p14._running then
		v_u_1:UnbindFromRenderStep(p14._renderName)
		p14._running = false
	end
end
function v_u_4.Update(p15, p16) -- name: Update
	-- upvalues: (copy) v_u_3
	local v17 = p15._camShakeInstances
	local v18 = Vector3.new(0, 0, 0)
	local v19 = Vector3.new(0, 0, 0)
	for v20 = #v17, 1, -1 do
		local v21 = v17[v20]
		local v22 = v21:GetState()
		if v22 == v_u_3.Inactive and v21.DeleteOnInactive then
			table.remove(v17, v20)
		else
			if v22 == v_u_3.Inactive then
				continue
			end
			local v23 = v21:UpdateShake(p16)
			v18 = v18 + v23 * v21.PositionInfluence
			v19 = v19 + v23 * v21.RotationInfluence
		end
	end
	local v24 = CFrame.new(v18)
	local v25 = CFrame.Angles
	local v26 = v19.X
	local v27 = math.rad(v26)
	local v28 = v19.Y
	local v29 = math.rad(v28)
	local v30 = v19.Z
	return v24 * v25(v27, v29, (math.rad(v30)))
end
function v_u_4.Shake(p31, p32) -- name: Shake
	local v33 = p31._camShakeInstances
	table.insert(v33, p32)
	return p32
end
function v_u_4.ShakeSustain(p34, p35) -- name: ShakeSustain
	p35:StartFadeIn(p35.fadeInDuration)
	local v36 = p34._camShakeInstances
	table.insert(v36, p35)
	return p35
end
function v_u_4.ShakeOnce(p37, p38, p39, p40, p41, p42, p43) -- name: ShakeOnce
	-- upvalues: (copy) v_u_2
	local v44 = v_u_2.new(p38, p39, p40, p41)
	v44.PositionInfluence = typeof(p42) ~= "Vector3" and Vector3.new(0.15, 0.15, 0.15) or p42
	v44.RotationInfluence = typeof(p43) ~= "Vector3" and Vector3.new(1, 1, 1) or p43
	local v45 = p37._camShakeInstances
	table.insert(v45, v44)
	return v44
end
function v_u_4.StopSustained(p46, p47) -- name: StopSustained
	for _, v48 in p46._camShakeInstances do
		if v48.fadeOutDuration ~= 0 then
			continue
		end
		v48:StartFadeOut(p47 or v48.fadeInDuration)
	end
end
return v_u_4
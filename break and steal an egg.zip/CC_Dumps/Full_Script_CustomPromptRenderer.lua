local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ProximityPromptService")
local v_u_3 = game:GetService("TextService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = require(script.Parent.PromptThemes)
local v_u_7 = v1.LocalPlayer
local v_u_8 = v_u_7:WaitForChild("PlayerGui")
local v9 = {}
local v_u_10 = {
	[Enum.KeyCode.Backspace] = "rbxasset://textures/ui/Controls/backspace.png",
	[Enum.KeyCode.Return] = "rbxasset://textures/ui/Controls/return.png",
	[Enum.KeyCode.LeftShift] = "rbxasset://textures/ui/Controls/shift.png",
	[Enum.KeyCode.RightShift] = "rbxasset://textures/ui/Controls/shift.png",
	[Enum.KeyCode.Tab] = "rbxasset://textures/ui/Controls/tab.png"
}
local v_u_11 = {
	["\'"] = "rbxasset://textures/ui/Controls/apostrophe.png",
	[","] = "rbxasset://textures/ui/Controls/comma.png",
	["`"] = "rbxasset://textures/ui/Controls/graveaccent.png",
	["."] = "rbxasset://textures/ui/Controls/period.png",
	[" "] = "rbxasset://textures/ui/Controls/spacebar.png"
}
local v_u_12 = {
	[Enum.KeyCode.LeftControl] = "Ctrl",
	[Enum.KeyCode.RightControl] = "Ctrl",
	[Enum.KeyCode.LeftAlt] = "Alt",
	[Enum.KeyCode.RightAlt] = "Alt",
	[Enum.KeyCode.F1] = "F1",
	[Enum.KeyCode.F2] = "F2",
	[Enum.KeyCode.F3] = "F3",
	[Enum.KeyCode.F4] = "F4",
	[Enum.KeyCode.F5] = "F5",
	[Enum.KeyCode.F6] = "F6",
	[Enum.KeyCode.F7] = "F7",
	[Enum.KeyCode.F8] = "F8",
	[Enum.KeyCode.F9] = "F9",
	[Enum.KeyCode.F10] = "F10",
	[Enum.KeyCode.F11] = "F11",
	[Enum.KeyCode.F12] = "F12"
}
local v_u_13 = TweenInfo.new(0.2, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_14 = TweenInfo.new(0.06, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
local v_u_15 = TweenInfo.new(0, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)
local v_u_16 = {}
local function v_u_169(p17) -- name: buildEntry
	-- upvalues: (copy) v_u_6, (copy) v_u_4, (copy) v_u_13, (copy) v_u_14, (copy) v_u_15
	local v18 = v_u_6.Create
	local v19
	if p17 == "Default" then
		v19 = nil
	else
		v19 = p17
	end
	local v20 = v18(v19)
	local v21 = v20:FindFirstChild("PromptFrame")
	local v22 = v21:FindFirstChild("InputFrame")
	local v23 = v21:FindFirstChild("ActionText")
	local v24 = v21:FindFirstChild("ObjectText")
	local v_u_25 = {}
	local v_u_26 = {}
	local v_u_27 = {}
	local v_u_28 = {}
	local v29 = v21.BackgroundTransparency
	local v30 = v21.ImageTransparency
	v21.BackgroundTransparency = 1
	v21.ImageTransparency = 1
	local v31 = v_u_4
	local v32 = v_u_13
	local v33 = {
		["BackgroundTransparency"] = 1,
		["ImageTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(0.5, 1)
	}
	table.insert(v_u_25, v31:Create(v21, v32, v33))
	local v34 = v_u_4
	local v35 = v_u_13
	local v36 = {
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundTransparency"] = v29,
		["ImageTransparency"] = v30
	}
	table.insert(v_u_26, v34:Create(v21, v35, v36))
	local v37 = v_u_4
	local v38 = v_u_13
	local v39 = {
		["BackgroundTransparency"] = 1,
		["ImageTransparency"] = 1,
		["Size"] = nil,
		["Size"] = UDim2.fromScale(0.5, 1)
	}
	table.insert(v_u_27, v37:Create(v21, v38, v39))
	local v40 = v_u_4
	local v41 = v_u_13
	local v42 = {
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundTransparency"] = v29,
		["ImageTransparency"] = v30
	}
	table.insert(v_u_28, v40:Create(v21, v41, v42))
	local function v_u_57(p43) -- name: setupUIStrokeTweens
		-- upvalues: (copy) v_u_25, (ref) v_u_4, (ref) v_u_13, (copy) v_u_26, (copy) v_u_27, (copy) v_u_28
		local v44 = p43.Transparency
		p43.Transparency = 1
		local v45 = v_u_25
		local v46 = v_u_4
		local v47 = v_u_13
		table.insert(v45, v46:Create(p43, v47, {
			["Transparency"] = 1
		}))
		local v48 = v_u_26
		local v49 = v_u_4
		local v50 = v_u_13
		table.insert(v48, v49:Create(p43, v50, {
			["Transparency"] = v44
		}))
		local v51 = v_u_27
		local v52 = v_u_4
		local v53 = v_u_13
		table.insert(v51, v52:Create(p43, v53, {
			["Transparency"] = 1
		}))
		local v54 = v_u_28
		local v55 = v_u_4
		local v56 = v_u_13
		table.insert(v54, v55:Create(p43, v56, {
			["Transparency"] = v44
		}))
	end
	local function v_u_72(p58) -- name: setupGUIObjectTweens
		-- upvalues: (copy) v_u_25, (ref) v_u_4, (ref) v_u_13, (copy) v_u_26, (copy) v_u_27, (copy) v_u_28
		local v59 = p58.BackgroundTransparency
		p58.BackgroundTransparency = 1
		local v60 = v_u_25
		local v61 = v_u_4
		local v62 = v_u_13
		table.insert(v60, v61:Create(p58, v62, {
			["BackgroundTransparency"] = 1
		}))
		local v63 = v_u_26
		local v64 = v_u_4
		local v65 = v_u_13
		table.insert(v63, v64:Create(p58, v65, {
			["BackgroundTransparency"] = v59
		}))
		local v66 = v_u_27
		local v67 = v_u_4
		local v68 = v_u_13
		table.insert(v66, v67:Create(p58, v68, {
			["BackgroundTransparency"] = 1
		}))
		local v69 = v_u_28
		local v70 = v_u_4
		local v71 = v_u_13
		table.insert(v69, v70:Create(p58, v71, {
			["BackgroundTransparency"] = v59
		}))
	end
	local function v_u_88(p73) -- name: setupTextLabelTweens
		-- upvalues: (copy) v_u_25, (ref) v_u_4, (ref) v_u_13, (copy) v_u_26, (copy) v_u_27, (copy) v_u_28
		local v74 = p73.TextTransparency
		local v75 = p73.TextStrokeTransparency
		p73.TextTransparency = 1
		p73.TextStrokeTransparency = 1
		local v76 = v_u_25
		local v77 = v_u_4
		local v78 = v_u_13
		table.insert(v76, v77:Create(p73, v78, {
			["TextTransparency"] = 1,
			["TextStrokeTransparency"] = 1
		}))
		local v79 = v_u_26
		local v80 = v_u_4
		local v81 = v_u_13
		table.insert(v79, v80:Create(p73, v81, {
			["TextTransparency"] = v74,
			["TextStrokeTransparency"] = v75
		}))
		local v82 = v_u_27
		local v83 = v_u_4
		local v84 = v_u_13
		table.insert(v82, v83:Create(p73, v84, {
			["TextTransparency"] = 1,
			["TextStrokeTransparency"] = 1
		}))
		local v85 = v_u_28
		local v86 = v_u_4
		local v87 = v_u_13
		table.insert(v85, v86:Create(p73, v87, {
			["TextTransparency"] = v74,
			["TextStrokeTransparency"] = v75
		}))
	end
	local function v_u_103(p89) -- name: setupImageLabelTweens
		-- upvalues: (copy) v_u_25, (ref) v_u_4, (ref) v_u_13, (copy) v_u_26, (copy) v_u_27, (copy) v_u_28
		local v90 = p89.ImageTransparency
		p89.ImageTransparency = 1
		local v91 = v_u_25
		local v92 = v_u_4
		local v93 = v_u_13
		table.insert(v91, v92:Create(p89, v93, {
			["ImageTransparency"] = 1
		}))
		local v94 = v_u_26
		local v95 = v_u_4
		local v96 = v_u_13
		table.insert(v94, v95:Create(p89, v96, {
			["ImageTransparency"] = v90
		}))
		local v97 = v_u_27
		local v98 = v_u_4
		local v99 = v_u_13
		table.insert(v97, v98:Create(p89, v99, {
			["ImageTransparency"] = 1
		}))
		local v100 = v_u_28
		local v101 = v_u_4
		local v102 = v_u_13
		table.insert(v100, v101:Create(p89, v102, {
			["ImageTransparency"] = v90
		}))
	end
	local function v_u_106(p104) -- name: setupDecorationTweens
		-- upvalues: (copy) v_u_57, (copy) v_u_72, (copy) v_u_88, (copy) v_u_103, (copy) v_u_106
		if p104:IsA("UIStroke") then
			v_u_57(p104)
		elseif not p104:IsA("UIGradient") and p104:IsA("GuiObject") then
			v_u_72(p104)
			if p104:IsA("TextLabel") then
				v_u_88(p104)
			elseif p104:IsA("ImageLabel") then
				v_u_103(p104)
			end
		end
		for _, v105 in ipairs(p104:GetChildren()) do
			v_u_106(v105)
		end
	end
	local v107 = {
		[v22] = false,
		[v23] = true,
		[v24] = true
	}
	for _, v108 in ipairs(v21:GetChildren()) do
		local v109 = v107[v108]
		if v109 == nil then
			v_u_106(v108)
		else
			if v109 ~= true then
				continue
			end
			for _, v110 in ipairs(v108:GetChildren()) do
				v_u_106(v110)
			end
		end
	end
	local v111 = v22:FindFirstChild("Frame")
	local v112 = v111:FindFirstChild("UIScale")
	local v113 = v_u_4
	local v114 = v_u_13
	table.insert(v_u_26, v113:Create(v112, v114, {
		["Scale"] = 1
	}))
	v_u_88(v23)
	v_u_88(v24)
	local v115 = v111:FindFirstChild("ButtonFrame")
	local v116 = v_u_4
	local v117 = v_u_14
	table.insert(v_u_27, v116:Create(v115, v117, {
		["BackgroundTransparency"] = 1,
		["ImageTransparency"] = 1
	}))
	local v118 = v_u_4
	local v119 = v_u_14
	local v120 = {
		["BackgroundTransparency"] = v115.BackgroundTransparency,
		["ImageTransparency"] = v115.ImageTransparency
	}
	table.insert(v_u_28, v118:Create(v115, v119, v120))
	for _, v121 in ipairs(v115:GetChildren()) do
		if not v121:IsA("UIStroke") then
			continue
		end
		local v122 = v_u_4
		local v123 = v_u_14
		table.insert(v_u_27, v122:Create(v121, v123, {
			["Transparency"] = 1
		}))
		local v124 = v_u_4
		local v125 = v_u_14
		local v126 = {
			["Transparency"] = v121.Transparency
		}
		table.insert(v_u_28, v124:Create(v121, v125, v126))
	end
	local v127 = v111:FindFirstChild("ButtonImage")
	local v128 = v111:FindFirstChild("ButtonText")
	local v129 = v111:FindFirstChild("ButtonTextImage")
	local v130 = v128.TextTransparency
	local v131 = v128.TextStrokeTransparency
	local v132 = v128.BackgroundTransparency
	v128.BackgroundTransparency = 1
	v128.TextStrokeTransparency = 1
	v128.TextTransparency = 1
	local v133 = v_u_4
	local v134 = v_u_14
	table.insert(v_u_27, v133:Create(v128, v134, {
		["TextTransparency"] = 1,
		["TextStrokeTransparency"] = 1,
		["BackgroundTransparency"] = 1
	}))
	local v135 = v_u_4
	local v136 = v_u_14
	table.insert(v_u_28, v135:Create(v128, v136, {
		["TextTransparency"] = v130,
		["TextStrokeTransparency"] = v131,
		["BackgroundTransparency"] = v132
	}))
	for _, v137 in ipairs(v128:GetChildren()) do
		if not v137:IsA("UIStroke") then
			continue
		end
		local v138 = v_u_4
		local v139 = v_u_14
		table.insert(v_u_27, v138:Create(v137, v139, {
			["Transparency"] = 1
		}))
		local v140 = v_u_4
		local v141 = v_u_14
		local v142 = {
			["Transparency"] = v137.Transparency
		}
		table.insert(v_u_28, v140:Create(v137, v141, v142))
	end
	local v143 = v127.ImageTransparency
	local v144 = v127.BackgroundTransparency
	v127.BackgroundTransparency = 1
	v127.ImageTransparency = 1
	local v145 = v_u_4
	local v146 = v_u_14
	table.insert(v_u_27, v145:Create(v127, v146, {
		["ImageTransparency"] = 1,
		["BackgroundTransparency"] = 1
	}))
	local v147 = v_u_4
	local v148 = v_u_14
	table.insert(v_u_28, v147:Create(v127, v148, {
		["ImageTransparency"] = v143,
		["BackgroundTransparency"] = v144
	}))
	local v149 = v129.BackgroundTransparency
	local v150 = v129.ImageTransparency
	v129.BackgroundTransparency = 1
	v129.ImageTransparency = 1
	local v151 = v_u_4
	local v152 = v_u_14
	table.insert(v_u_27, v151:Create(v129, v152, {
		["ImageTransparency"] = 1,
		["BackgroundTransparency"] = 1
	}))
	local v153 = v_u_4
	local v154 = v_u_14
	table.insert(v_u_28, v153:Create(v129, v154, {
		["ImageTransparency"] = v150,
		["BackgroundTransparency"] = v149
	}))
	local v155 = v111:FindFirstChild("ProgressBar")
	local v156
	if v155 then
		local v_u_157 = v155:FindFirstChild("LeftGradient"):FindFirstChild("ProgressBarImage"):FindFirstChild("UIGradient")
		local v_u_158 = v155:FindFirstChild("RightGradient"):FindFirstChild("ProgressBarImage"):FindFirstChild("UIGradient")
		v156 = v155:FindFirstChild("Progress")
		v156.Changed:Connect(function(p159)
			-- upvalues: (copy) v_u_157, (copy) v_u_158
			local v160 = p159 * 360
			local v161 = math.clamp(v160, 0, 360)
			v_u_157.Rotation = math.clamp(v161, 180, 360)
			v_u_158.Rotation = math.clamp(v161, 0, 180)
		end)
	else
		v156 = nil
	end
	local v_u_162 = {
		["Gui"] = nil,
		["ThemeKey"] = nil,
		["HoldBeganTweens"] = nil,
		["HoldEndedTweens"] = nil,
		["HideTweens"] = nil,
		["ShowTweens"] = nil,
		["PromptFrame"] = nil,
		["ActionText"] = nil,
		["ObjectText"] = nil,
		["UiScale"] = nil,
		["ButtonText"] = nil,
		["ButtonImage"] = nil,
		["ButtonTextImage"] = nil,
		["HitButton"] = nil,
		["ProgressValue"] = nil,
		["AuthoredButtonTextSize"] = nil,
		["AuthoredTextVisible"] = nil,
		["AuthoredImageVisible"] = nil,
		["AuthoredIconVisible"] = nil,
		["ScaleHoldTween"] = nil,
		["ScaleHoldTarget"] = nil,
		["ProgressTween"] = nil,
		["ProgressDuration"] = nil,
		["ProgressResetTween"] = nil,
		["Prompt"] = nil,
		["Connections"] = nil,
		["Holding"] = false,
		["ClickEnabled"] = false,
		["Gui"] = v20,
		["ThemeKey"] = p17,
		["HoldBeganTweens"] = v_u_25,
		["HoldEndedTweens"] = v_u_26,
		["HideTweens"] = v_u_27,
		["ShowTweens"] = v_u_28,
		["PromptFrame"] = v21,
		["ActionText"] = v23,
		["ObjectText"] = v24,
		["UiScale"] = v112,
		["ButtonText"] = v128,
		["ButtonImage"] = v127,
		["ButtonTextImage"] = v129,
		["ProgressValue"] = v156,
		["AuthoredButtonTextSize"] = v128.TextSize,
		["AuthoredTextVisible"] = v128.Visible,
		["AuthoredImageVisible"] = v127.Visible,
		["AuthoredIconVisible"] = v129.Visible
	}
	local v163
	if v156 then
		v163 = v_u_4:Create(v156, v_u_15, {
			["Value"] = 0
		})
	else
		v163 = nil
	end
	v_u_162.ProgressResetTween = v163
	v_u_162.Connections = {}
	local v164 = v20:FindFirstChild("TextButton")
	if v164 and v164:IsA("TextButton") then
		v_u_162.HitButton = v164
		v164.InputBegan:Connect(function(p165)
			-- upvalues: (copy) v_u_162
			local v166 = v_u_162.Prompt
			if v166 and v_u_162.ClickEnabled then
				if p165.UserInputType == Enum.UserInputType.Touch or p165.UserInputType == Enum.UserInputType.MouseButton1 then
					if p165.UserInputState ~= Enum.UserInputState.Change then
						v166:InputHoldBegin()
						v_u_162.Holding = true
					end
				else
					return
				end
			else
				return
			end
		end)
		v164.InputEnded:Connect(function(p167)
			-- upvalues: (copy) v_u_162
			local v168 = v_u_162.Prompt
			if v168 and v_u_162.Holding then
				if p167.UserInputType == Enum.UserInputType.Touch or p167.UserInputType == Enum.UserInputType.MouseButton1 then
					v_u_162.Holding = false
					v168:InputHoldEnd()
				end
			else
				return
			end
		end)
	end
	return v_u_162
end
local v_u_170 = {
	["ActionText"] = true,
	["ObjectText"] = true,
	["AutoLocalize"] = true,
	["RootLocalizationTable"] = true,
	["UIOffset"] = true
}
local function v_u_179(p171, p172) -- name: getTextBoundsForLabel
	-- upvalues: (copy) v_u_3
	local v173 = Instance.new("GetTextBoundsParams")
	v173.Font = p171.FontFace
	v173.Size = p171.TextSize
	v173.Width = 1000
	local v174 = p172 or ""
	if p171.RichText then
		v174 = v174:gsub("<[^>]->", "")
	end
	v173.Text = v174
	local v175 = v_u_3.GetTextBoundsAsync
	local v176 = v_u_3
	local v177, v178 = pcall(v175, v176, v173)
	v173:Destroy()
	if v177 then
		return v178
	else
		return Vector2.new(#v174 * p171.TextSize * 0.5, p171.TextSize)
	end
end
local function v_u_226(p_u_180, p181, p182) -- name: acquirePrompt
	-- upvalues: (copy) v_u_16, (copy) v_u_169, (copy) v_u_4, (copy) v_u_13, (copy) v_u_5, (copy) v_u_10, (copy) v_u_11, (copy) v_u_12, (copy) v_u_179, (copy) v_u_170
	local v183 = p_u_180:GetAttribute("Theme")
	local v184 = typeof(v183) ~= "string" and "Default" or v183
	local v185 = v_u_16[v184]
	local v186
	if v185 then
		v186 = table.remove(v185)
	else
		v186 = nil
	end
	local v_u_187 = v186 or v_u_169(v184)
	local v_u_188 = v_u_187.Gui
	v_u_187.Prompt = p_u_180
	v_u_187.Holding = false
	v_u_187.UiScale.Scale = 1
	if v_u_187.ProgressValue then
		v_u_187.ProgressValue.Value = 0
	end
	local v189 = v_u_187.ButtonText
	local v190 = v_u_187.ButtonImage
	local v191 = v_u_187.ButtonTextImage
	v189.TextSize = v_u_187.AuthoredButtonTextSize
	v189.Visible = v_u_187.AuthoredTextVisible
	v190.Visible = v_u_187.AuthoredImageVisible
	v191.Visible = v_u_187.AuthoredIconVisible
	local v192 = p181 == Enum.ProximityPromptInputType.Touch and 1.6 or 1.33
	if v_u_187.ScaleHoldTarget ~= v192 then
		v_u_187.ScaleHoldTarget = v192
		v_u_187.ScaleHoldTween = v_u_4:Create(v_u_187.UiScale, v_u_13, {
			["Scale"] = v192
		})
	end
	if v_u_187.ProgressValue and (p_u_180.HoldDuration > 0 and v_u_187.ProgressDuration ~= p_u_180.HoldDuration) then
		v_u_187.ProgressDuration = p_u_180.HoldDuration
		v_u_187.ProgressTween = v_u_4:Create(v_u_187.ProgressValue, TweenInfo.new(p_u_180.HoldDuration, Enum.EasingStyle.Linear, Enum.EasingDirection.Out), {
			["Value"] = 1
		})
	end
	if p181 == Enum.ProximityPromptInputType.Gamepad then
		local v_u_193 = p_u_180.GamepadKeyCode
		local function v194()
			-- upvalues: (ref) v_u_5, (copy) v_u_193
			return v_u_5:GetImageForKeyCode(v_u_193)
		end
		local v195, v196 = pcall(v194)
		if not v195 or v196 == "" then
			v196 = nil
		end
		if v196 then
			v191.Image = v196
			v189.Visible = false
			v190.Visible = false
			v191.Visible = true
		end
	elseif p181 == Enum.ProximityPromptInputType.Touch then
		v190.Image = "rbxasset://textures/ui/Controls/TouchTapIcon.png"
		v189.Visible = false
		v191.Visible = false
		v190.Visible = true
	else
		v190.Visible = true
		local v197 = v_u_5:GetStringForKeyCode(p_u_180.KeyboardKeyCode)
		local v198 = v_u_10[p_u_180.KeyboardKeyCode]
		if v198 == nil then
			v198 = v_u_11[v197]
		end
		if v198 == nil then
			v197 = v_u_12[p_u_180.KeyboardKeyCode] or v197
		end
		if v198 then
			v191.Image = v198
			v189.Visible = false
			v191.Visible = true
		else
			if v197 == nil or v197 == "" then
				local v199 = warn
				local v200 = p_u_180.Name
				local v201 = p_u_180.KeyboardKeyCode
				v199((("ProximityPrompt \'%*\' has an unsupported keycode for rendering UI: %*"):format(v200, (tostring(v201)))))
				v197 = "?"
			end
			if string.len(v197) > 2 then
				local v202 = v_u_187.AuthoredButtonTextSize * 6 / 7
				v189.TextSize = math.round(v202)
			end
			v189.Text = v197
			v191.Visible = false
			v189.Visible = true
		end
	end
	v_u_187.ClickEnabled = p181 == Enum.ProximityPromptInputType.Touch and true or p_u_180.ClickablePrompt
	v_u_188.Active = v_u_187.ClickEnabled
	local v_u_203 = v_u_187.Connections
	if p_u_180.HoldDuration > 0 then
		local v204 = p_u_180.PromptButtonHoldBegan
		table.insert(v_u_203, v204:Connect(function()
			-- upvalues: (copy) v_u_187
			for _, v205 in ipairs(v_u_187.HoldBeganTweens) do
				v205:Play()
			end
			if v_u_187.ScaleHoldTween then
				v_u_187.ScaleHoldTween:Play()
			end
			if v_u_187.ProgressTween then
				v_u_187.ProgressTween:Play()
			end
		end))
		local v206 = p_u_180.PromptButtonHoldEnded
		table.insert(v_u_203, v206:Connect(function()
			-- upvalues: (copy) v_u_187
			for _, v207 in ipairs(v_u_187.HoldEndedTweens) do
				v207:Play()
			end
			if v_u_187.ProgressResetTween then
				v_u_187.ProgressResetTween:Play()
			end
		end))
	end
	local v208 = p_u_180.Triggered
	table.insert(v_u_203, v208:Connect(function()
		-- upvalues: (copy) v_u_187
		for _, v209 in ipairs(v_u_187.HideTweens) do
			v209:Play()
		end
	end))
	local v210 = p_u_180.TriggerEnded
	table.insert(v_u_203, v210:Connect(function()
		-- upvalues: (copy) v_u_187
		for _, v211 in ipairs(v_u_187.ShowTweens) do
			v211:Play()
		end
	end))
	local v_u_212 = v_u_187.ActionText
	local v_u_213 = v_u_187.ObjectText
	local function v_u_217() -- name: updateUIFromPrompt
		-- upvalues: (copy) p_u_180, (ref) v_u_179, (copy) v_u_212, (copy) v_u_213, (copy) v_u_187, (copy) v_u_188
		local v214
		if (p_u_180.ActionText == nil or p_u_180.ActionText == "") and (p_u_180.ObjectText == nil or p_u_180.ObjectText == "") then
			v214 = 72
		else
			local v215 = v_u_179(v_u_212, p_u_180.ActionText).X
			local v216 = v_u_179(v_u_213, p_u_180.ObjectText).X
			v214 = math.max(v215, v216) + 72 + 24
		end
		if v_u_187.Prompt == p_u_180 then
			v_u_212.Position = UDim2.new(0.5, 72 - v214 / 2, 0, (p_u_180.ObjectText == nil or p_u_180.ObjectText == "") and 0 or 9)
			v_u_213.Position = UDim2.new(0.5, 72 - v214 / 2, 0, -10)
			v_u_212.Text = p_u_180.ActionText
			v_u_213.Text = p_u_180.ObjectText
			v_u_212.AutoLocalize = p_u_180.AutoLocalize
			v_u_212.RootLocalizationTable = p_u_180.RootLocalizationTable
			v_u_213.AutoLocalize = p_u_180.AutoLocalize
			v_u_213.RootLocalizationTable = p_u_180.RootLocalizationTable
			v_u_188.Size = UDim2.fromOffset(v214, 72)
			v_u_188.SizeOffset = Vector2.new(p_u_180.UIOffset.X / v_u_188.Size.Width.Offset, p_u_180.UIOffset.Y / v_u_188.Size.Height.Offset)
		end
	end
	local v218 = p_u_180.Changed
	local function v220(p219)
		-- upvalues: (ref) v_u_170, (copy) v_u_217
		if v_u_170[p219] then
			v_u_217()
		end
	end
	table.insert(v_u_203, v218:Connect(v220))
	v_u_217()
	v_u_188.Adornee = p_u_180.Parent
	v_u_188.Enabled = true
	v_u_188.Parent = p182
	for _, v221 in ipairs(v_u_187.ShowTweens) do
		v221:Play()
	end
	return function()
		-- upvalues: (copy) v_u_203, (copy) v_u_187, (copy) p_u_180, (copy) v_u_188, (ref) v_u_16
		for _, v222 in ipairs(v_u_203) do
			v222:Disconnect()
		end
		table.clear(v_u_203)
		if v_u_187.ProgressTween then
			v_u_187.ProgressTween:Cancel()
		end
		if v_u_187.ScaleHoldTween then
			v_u_187.ScaleHoldTween:Cancel()
		end
		if v_u_187.Holding and p_u_180.Parent then
			p_u_180:InputHoldEnd()
		end
		v_u_187.Prompt = nil
		v_u_187.Holding = false
		for _, v223 in ipairs(v_u_187.HideTweens) do
			v223:Play()
		end
		task.wait(0.2)
		v_u_188.Enabled = false
		v_u_188.Adornee = nil
		local v224 = v_u_16[v_u_187.ThemeKey]
		if not v224 then
			v224 = {}
			v_u_16[v_u_187.ThemeKey] = v224
		end
		if #v224 < 6 then
			local v225 = v_u_187
			table.insert(v224, v225)
		else
			v_u_188:Destroy()
		end
	end
end
function v9.Start() -- name: Start
	-- upvalues: (copy) v_u_2, (copy) v_u_7, (copy) v_u_226, (copy) v_u_8
	v_u_2.PromptShown:Connect(function(p227, p228)
		-- upvalues: (ref) v_u_7, (ref) v_u_226, (ref) v_u_8
		if p227.Style == Enum.ProximityPromptStyle.Default then
			return
		else
			local v229 = p227:GetAttribute("ReservedUserId")
			local v230
			if typeof(v229) == "number" then
				v230 = v229 ~= v_u_7.UserId
			else
				v230 = false
			end
			if not v230 then
				local v_u_231 = nil
				local v_u_232 = false
				local v_u_233 = false
				local v_u_234 = nil
				local v_u_235 = nil
				local function v236() -- name: finish
					-- upvalues: (ref) v_u_232, (ref) v_u_234, (ref) v_u_235, (ref) v_u_233, (ref) v_u_231
					v_u_232 = true
					v_u_234:Disconnect()
					v_u_235:Disconnect()
					if not v_u_233 and v_u_231 then
						v_u_233 = true
						v_u_231()
					end
				end
				v_u_234 = p227.PromptHidden:Connect(v236)
				v_u_235 = p227.Destroying:Once(v236)
				local v237 = v_u_226
				local v238 = v_u_8:FindFirstChild("ProximityPrompts")
				if v238 == nil or not v238:IsA("ScreenGui") then
					v238 = Instance.new("ScreenGui")
					v238.Name = "ProximityPrompts"
					v238.ResetOnSpawn = false
					v238.Parent = v_u_8
				end
				v_u_231 = v237(p227, p228, v238)
				if v_u_232 and not v_u_233 then
					v_u_233 = true
					v_u_231()
				end
			end
		end
	end)
end
return v9
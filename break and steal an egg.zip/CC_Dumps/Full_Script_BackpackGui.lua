local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("UserInputService")
local v_u_3 = require(v1.Shared.BackpackUiConfig)
local v_u_6 = {
	["IsMobile"] = function() -- name: IsMobile
		-- upvalues: (copy) v_u_2
		local v4 = v_u_2.TouchEnabled
		if v4 then
			v4 = not v_u_2.MouseEnabled
		end
		return v4
	end,
	["Name"] = function() -- name: Name
		-- upvalues: (copy) v_u_6, (copy) v_u_3
		if v_u_6.IsMobile() then
			return v_u_3.MobileGuiName
		else
			return v_u_3.GuiName
		end
	end,
	["UnusedName"] = function() -- name: UnusedName
		-- upvalues: (copy) v_u_6, (copy) v_u_3
		if v_u_6.IsMobile() then
			return v_u_3.GuiName
		else
			return v_u_3.MobileGuiName
		end
	end,
	["IsBackpackName"] = function(p5) -- name: IsBackpackName
		-- upvalues: (copy) v_u_3
		return p5 == v_u_3.GuiName and true or p5 == v_u_3.MobileGuiName
	end
}
return v_u_6
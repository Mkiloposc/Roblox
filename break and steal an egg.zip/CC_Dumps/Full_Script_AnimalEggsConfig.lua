local v_u_1 = game:GetService("ReplicatedStorage")
local v2 = game:GetService("Workspace")
local v_u_3 = require(script.Parent.AnimalEggShape)
local v_u_4 = require(script.Parent.MergeConfig)
local v_u_8 = {
	["FolderName"] = "AnimalisticEggs",
	["FolderContainers"] = nil,
	["BodyPartName"] = "Egg",
	["FrameAttachmentName"] = "EggFrame",
	["Front"] = Vector3.new(-1, 0, 0),
	["FrontOverrides"] = nil,
	["ModelShellName"] = "Ninja egg",
	["ModelShellOverrides"] = nil,
	["ModelFront"] = Vector3.new(1, 0, 0),
	["WholeBodyEggs"] = nil,
	["GroupEggs"] = nil,
	["Overrides"] = nil,
	["FolderContainers"] = { v_u_1, v2 },
	["FrontOverrides"] = {},
	["ModelShellOverrides"] = {
		["Jax Egg"] = "Ninja egg.001",
		["John Egg"] = "Toad.001",
		["Mushroom Egg"] = "Toad.001",
		["Scarecrow Egg"] = "Toad.001",
		["Mimic Egg"] = "Cube.001",
		["Gargoyle Egg"] = "Toad.002",
		["BlackWidow Egg"] = "Toad.002",
		["Rock Crab Egg"] = "Toad.002",
		["VolcanicTurtle Egg"] = "Toad.002",
		["WizardOwl Egg"] = "Toad.002",
		["BoneBat Egg"] = "Egg",
		["BoneHydra Egg"] = "Egg"
	},
	["WholeBodyEggs"] = {
		["GoldfishEgg"] = true,
		["FangtoothFishEgg"] = true,
		["GoblinSharkEgg"] = true,
		["SharkEgg"] = true,
		["SwordfishEgg"] = true,
		["AnglerfishEgg"] = true,
		["BlobfishEgg"] = true,
		["MEGALODONEgg"] = true,
		["WhaleEgg"] = true,
		["LeafySeaDragonEgg"] = true
	},
	["GroupEggs"] = {
		{
			["Path"] = nil,
			["ShellNames"] = nil,
			["Front"] = Vector3.new(0, 0, 1),
			["Eggs"] = nil,
			["Path"] = { "EggHell", "Black" },
			["ShellNames"] = { "Egg", "Egg Template" },
			["Eggs"] = {
				["HellCroc"] = "BoarEgg",
				["HellAnky"] = "BoarEgg",
				["HellTrike"] = "ScorpionEgg",
				["HellMegalodon"] = "HoundEgg",
				["HellDinoRex"] = "HoundEgg",
				["HellTRex"] = "GolemEgg",
				["HellDragon"] = "DragonEgg",
				["HellHydra"] = "CerberusEgg"
			}
		},
		{
			["Path"] = nil,
			["ShellNames"] = nil,
			["Front"] = Vector3.new(0, 0, 1),
			["Eggs"] = nil,
			["Path"] = { "EggHell", "White" },
			["ShellNames"] = { "Egg", "Egg Template" },
			["Eggs"] = {
				["AngelCroc"] = "BoarEgg",
				["AngelAnky"] = "BoarEgg",
				["AngelTrike"] = "ScorpionEgg",
				["AngelMegalodon"] = "HoundEgg",
				["AngelTRex"] = "GolemEgg",
				["AngelDragon"] = "DragonEgg",
				["AngelHydra"] = "CerberusEgg"
			}
		},
		{
			["Path"] = nil,
			["ShellNames"] = nil,
			["Front"] = Vector3.new(0, 0, 1),
			["Eggs"] = nil,
			["Path"] = { "AnimalisticEggs" },
			["ShellNames"] = { "Egg" },
			["Eggs"] = {
				["Bug"] = "Bug Egg",
				["CrystalLizard"] = "CrystalLizard Egg",
				["CrystalBeast"] = "CrystalBeast Egg",
				["CrystalRaptor"] = "CrystalRaptor Egg",
				["CrystalDragon"] = "CrystalDragon Egg",
				["Mantis"] = "Mantis Egg",
				["AlienJellyfish"] = "AlienJellyfish Egg",
				["CrystalScorpion"] = "CrystalScorpion Egg",
				["Behemoth"] = "Behemoth Egg",
				["CrystalWolf"] = "CrystalWolf Egg",
				["CelestialBeast"] = "CelestialBeast Egg",
				["CelestialSpirit"] = "CelestialSpirit Egg"
			}
		},
		{
			["Path"] = nil,
			["ShellNames"] = nil,
			["Front"] = Vector3.new(0, 0, 1),
			["Eggs"] = nil,
			["Path"] = { "AnimalisticEggs" },
			["ShellNames"] = { "Egg" },
			["Eggs"] = {
				["Frankenblob"] = "Frankenblob Egg",
				["VampireCat"] = "VampireCat Egg",
				["ScareDog"] = "ScareDog Egg",
				["VampiricBat"] = "VampiricBat Egg",
				["PossessedChameleon"] = "PossessedChameleon Egg",
				["HauntedMantis"] = "HauntedMantis Egg",
				["GhastlyOctopus"] = "GhastlyOctopus Egg",
				["ZombieAxolotl"] = "ZombieAxolotl Egg",
				["PhantomBird"] = "PhantomBird Egg",
				["UndeadCapybara"] = "UndeadCapybara Egg",
				["VampirePorcupine"] = "VampirePorcupine Egg",
				["CursedKangaroo"] = "CursedKangaroo Egg"
			}
		},
		{
			["Path"] = nil,
			["ShellNames"] = nil,
			["Front"] = Vector3.new(0, 0, 1),
			["Eggs"] = nil,
			["Path"] = { "AnimalisticEggs" },
			["ShellNames"] = { "Egg" },
			["Eggs"] = {
				["Voidhorn"] = "Voidhorn Egg",
				["Mossbelly"] = "Mossbelly Egg",
				["Duskcoil"] = "Duskcoil Egg",
				["Hydrafang"] = "Hydrafang Egg",
				["Glacierback"] = "Glacierback Egg",
				["Stormwing"] = "Stormwing Egg",
				["Gearfang"] = "Gearfang Egg",
				["Spirewing"] = "Spirewing Egg",
				["Lilacwing"] = "Lilacwing Egg",
				["Thornmane"] = "Thornmane Egg",
				["Sandbloom"] = "Sandbloom Egg",
				["Hexhorn"] = "Hexhorn Egg",
				["Shadowgale"] = "Shadowgale Egg",
				["Cinderclub"] = "Cinderclub Egg",
				["Tidefin"] = "Tidefin Egg"
			}
		},
		{
			["Path"] = nil,
			["ShellNames"] = nil,
			["Front"] = Vector3.new(0, 0, -1),
			["Straighten"] = true,
			["HoldInFront"] = true,
			["Eggs"] = nil,
			["Path"] = { "AnimalisticEggs" },
			["ShellNames"] = { "Egg Template", "Egg" },
			["Eggs"] = {
				["CelestialLamb"] = "Celestial Cow Egg",
				["CelestialSpiritFox"] = "Celestial Fox Egg",
				["CelestialFrog"] = "Celestial Frog Egg",
				["CelestialAxolotl"] = "Axolotle Egg",
				["CelestialGorilla"] = "Celestial Gorilla Egg"
			}
		}
	},
	["Overrides"] = {
		["CHIREMA"] = "CHIMERAEgg",
		["MantisShrimp"] = "MantiShrimpEgg5",
		["SABER_TOOTHED_TIGER"] = "SaborToothTigerEgg",
		["Mamoth"] = "MammothEgg",
		["Giraffee"] = "GiraffeEgg",
		["Dullahan"] = "DullahanHorseEgg",
		["trumpet"] = "TrumpetFish Egg",
		["Moorish idol"] = "Moorish Egg",
		["John The Toad"] = "John Egg",
		["Volcano Turtle"] = "VolcanicTurtle Egg"
	},
	["GetFolder"] = function() -- name: GetFolder
		-- upvalues: (copy) v_u_8
		for _, v5 in v_u_8.FolderContainers do
			local v6 = v5:FindFirstChild(v_u_8.FolderName)
			if not v6 then
				continue
			end
			return v6
		end
		return nil
	end,
	["GetPlaceholder"] = function() -- name: GetPlaceholder
		-- upvalues: (copy) v_u_1, (copy) v_u_4
		local v7 = v_u_1:FindFirstChild(v_u_4.EggTemplateFolderName)
		if v7 then
			v7 = v7:FindFirstChild(v_u_4.EggTemplateName)
		end
		if v7 and v7:IsA("Model") then
			return v7
		else
			return nil
		end
	end
}
local function v_u_13(p9) -- name: findPath
	-- upvalues: (copy) v_u_8
	for _, v12 in v_u_8.FolderContainers do
		for _, v11 in p9 do
			if not v12 then
				continue
			end
			local v12 = v12:FindFirstChild(v11)
		end
		if not v12 then
			break
		end
		return v12
	end
	return nil
end
local function v_u_19(p14) -- name: findGroupEgg
	-- upvalues: (copy) v_u_8, (copy) v_u_13
	for _, v15 in v_u_8.GroupEggs do
		local v16 = v15.Eggs[p14]
		if not v16 then
			continue
		end
		local v17 = v_u_13(v15.Path)
		if v17 then
			v17 = v17:FindFirstChild(v16)
		end
		if v17 then
			local v18 = not v17:IsA("BasePart") and v17:IsA("Model")
			if v18 then
				v18 = v17:FindFirstChildWhichIsA("BasePart", true) ~= nil
			end
			if v18 then
				return v17, v15
			end
		end
		return nil, nil
	end
	return nil, nil
end
function v_u_8.FindOwnEgg(p20) -- name: FindOwnEgg
	-- upvalues: (copy) v_u_19, (copy) v_u_8
	local v21 = v_u_19(p20)
	if v21 then
		return v21
	end
	local v22 = v_u_8.GetFolder()
	if not v22 then
		return nil
	end
	local v23 = v_u_8.Overrides[p20]
	if v23 then
		local v24 = v22:FindFirstChild(v23)
		if v24 then
			local v25 = not v24:IsA("BasePart") and v24:IsA("Model")
			if v25 then
				v25 = v24:FindFirstChildWhichIsA("BasePart", true) ~= nil
			end
			if v25 then
				return v24
			end
		end
		return nil
	end
	local v26 = p20 .. "Egg"
	local v27 = string.lower(v26):gsub("[%s%-_]", "")
	for _, v28 in v22:GetChildren() do
		local v29 = not v28:IsA("BasePart") and v28:IsA("Model")
		if v29 then
			v29 = v28:FindFirstChildWhichIsA("BasePart", true) ~= nil
		end
		if not v29 then
			continue
		end
		local v30 = v28.Name
		if string.lower(v30):gsub("[%s%-_]", "") ~= v27 then
			continue
		end
		return v28
	end
	return nil
end
function v_u_8.UsesPlaceholder(p31) -- name: UsesPlaceholder
	-- upvalues: (copy) v_u_8
	return v_u_8.FindOwnEgg(p31) == nil
end
local function v_u_37(p32, p33, p34, p35) -- name: addFrame
	-- upvalues: (copy) v_u_8
	local v36 = Instance.new("Attachment")
	v36.Name = v_u_8.FrameAttachmentName
	v36.CFrame = CFrame.new(p33) * CFrame.lookAt(Vector3.new(0, 0, 0), p34).Rotation
	v36:SetAttribute("AuthoredFacing", p35)
	v36.Parent = p32
end
function v_u_8.CloneEgg(p38) -- name: CloneEgg
	-- upvalues: (copy) v_u_19, (copy) v_u_8, (copy) v_u_3, (copy) v_u_37
	local v39, v40 = v_u_19(p38)
	local v41 = v39 or v_u_8.FindOwnEgg(p38)
	local v42 = v41 and v_u_8.FrontOverrides[v41.Name]
	if not v42 then
		if v40 then
			v42 = v40.Front
		else
			v42 = nil
		end
	end
	local v43
	if v41 then
		v43 = v_u_8.ModelShellOverrides[v41.Name]
	else
		v43 = v41
	end
	local v_u_44
	if v40 then
		v_u_44 = v40.ShellNames
	else
		v_u_44 = { v43 or v_u_8.ModelShellName }
	end
	if v41 and v41:IsA("BasePart") then
		local v45 = Instance.new("Model")
		v45.Name = v41.Name
		local v46 = v41:Clone()
		v46.Name = v_u_8.BodyPartName
		v46.Parent = v45
		v45.PrimaryPart = v46
		local v47 = v_u_8.WholeBodyEggs[v41.Name] and Vector3.new(0, 0, 0) or v_u_3.GetBodyCenter(v41)
		local v48 = v42 or v_u_8.Front
		v_u_37(v46, v47 * v46.Size, v48, CFrame.lookAt(Vector3.new(0, 0, 0), v48).Rotation)
		return v45
	else
		if v41 and v41:IsA("Model") then
			local v_u_49 = v41:Clone()
			local function v55(p50) -- name: biggest
				-- upvalues: (copy) v_u_49, (copy) v_u_44
				local v51 = -1
				local v52 = nil
				for _, v53 in v_u_49:GetDescendants() do
					if not v53:IsA("BasePart") or p50 and not table.find(v_u_44, v53.Name) then
						continue
					end
					local v54 = v53.Size.X * v53.Size.Y * v53.Size.Z
					if v51 >= v54 then
						continue
					end
					v52 = v53
					v51 = v54
				end
				return v52
			end
			local v56 = v55(true) or v55(false)
			if v56 then
				v56.Name = v_u_8.BodyPartName
				v_u_49.PrimaryPart = v56
				local v57 = v42 or v_u_8.ModelFront
				local v58 = v56.CFrame:VectorToObjectSpace(v57)
				if v40 and v40.Straighten then
					local v59 = v58.X
					local v60 = v58.Z
					local v61 = Vector3.new(v59, 0, v60)
					if v61.Magnitude > 0.001 then
						v58 = v61.Unit
					end
				end
				v_u_37(v56, Vector3.new(0, 0, 0), v58, CFrame.lookAt(Vector3.new(0, 0, 0), v57).Rotation)
				local v62 = v40 and (v40.HoldInFront and v56:FindFirstChild(v_u_8.FrameAttachmentName))
				if v62 then
					v62:SetAttribute("HoldInFront", true)
				end
				return v_u_49
			end
			v_u_49:Destroy()
		end
		local v63 = v_u_8.GetPlaceholder()
		if v63 then
			return v63:Clone()
		else
			return nil
		end
	end
end
function v_u_8.GetEggFrame(p64) -- name: GetEggFrame
	-- upvalues: (copy) v_u_8
	local v65 = p64.PrimaryPart
	if v65 then
		v65 = v65:FindFirstChild(v_u_8.FrameAttachmentName)
	end
	if v65 and v65:IsA("Attachment") then
		return v65.WorldCFrame
	else
		return p64:GetBoundingBox()
	end
end
function v_u_8.GetFrameAttachment(p66) -- name: GetFrameAttachment
	-- upvalues: (copy) v_u_8
	local v67 = p66.PrimaryPart
	if v67 then
		v67 = v67:FindFirstChild(v_u_8.FrameAttachmentName)
	end
	if v67 and v67:IsA("Attachment") then
		return v67
	else
		return nil
	end
end
function v_u_8.AuthoredFacing(p68) -- name: AuthoredFacing
	-- upvalues: (copy) v_u_8
	local v69 = v_u_8.GetFrameAttachment(p68)
	if v69 then
		local v70 = v69:GetAttribute("AuthoredFacing")
		if typeof(v70) == "CFrame" then
			return v70.Rotation
		else
			return v69.CFrame.Rotation
		end
	else
		return CFrame.identity
	end
end
function v_u_8.PlantedFacing(p71) -- name: PlantedFacing
	-- upvalues: (copy) v_u_8
	local v72 = CFrame.lookAt(Vector3.new(0, 0, 0), v_u_8.Front).Rotation
	if p71 then
		return p71.Rotation * v72
	else
		return v72
	end
end
function v_u_8.AlignEggFrame(p73, p74) -- name: AlignEggFrame
	-- upvalues: (copy) v_u_8
	p73:PivotTo(p74 * v_u_8.GetEggFrame(p73):ToObjectSpace(p73:GetPivot()))
end
function v_u_8.PlaceOnGround(p75, p76) -- name: PlaceOnGround
	-- upvalues: (copy) v_u_8
	local v77 = p76.LookVector
	local v78 = v77.X
	local v79 = v77.Z
	local v80 = Vector3.new(v78, 0, v79)
	local v81
	if v80.Magnitude > 0.001 then
		v81 = CFrame.lookAt(Vector3.new(0, 0, 0), v80).Rotation
	else
		v81 = CFrame.identity
	end
	v_u_8.AlignEggFrame(p75, CFrame.new(p76.Position) * v81)
	local v82, v83 = p75:GetBoundingBox()
	local v84 = v82.Position.Y - v83.Y / 2
	local v85 = p75:GetPivot()
	local v86 = p76.Position.Y - v84
	p75:PivotTo(v85 + Vector3.new(0, v86, 0))
end
function v_u_8.PrepareForDisplay(p87) -- name: PrepareForDisplay
	-- upvalues: (copy) v_u_8
	local v88 = v_u_8.GetEggFrame(p87)
	p87.PrimaryPart = nil
	p87.WorldPivot = v88
	return p87
end
return v_u_8
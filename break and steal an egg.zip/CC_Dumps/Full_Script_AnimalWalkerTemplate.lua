local v1 = {}
local v_u_2 = {
	{
		["Name"] = "Torso",
		["Size"] = Vector3.new(2, 2, 1),
		["Offset"] = Vector3.new(0, 0, 0),
		["CanCollide"] = true
	},
	{
		["Name"] = "Head",
		["Size"] = Vector3.new(2, 1, 1),
		["Offset"] = Vector3.new(0, 1.5, 0),
		["CanCollide"] = true
	},
	{
		["Name"] = "Left Arm",
		["Size"] = Vector3.new(1, 2, 1),
		["Offset"] = Vector3.new(-1.5, 0, 0),
		["CanCollide"] = false
	},
	{
		["Name"] = "Right Arm",
		["Size"] = Vector3.new(1, 2, 1),
		["Offset"] = Vector3.new(1.5, 0, 0),
		["CanCollide"] = false
	},
	{
		["Name"] = "Left Leg",
		["Size"] = Vector3.new(1, 2, 1),
		["Offset"] = Vector3.new(-0.5, -2, 0),
		["CanCollide"] = false
	},
	{
		["Name"] = "Right Leg",
		["Size"] = Vector3.new(1, 2, 1),
		["Offset"] = Vector3.new(0.5, -2, 0),
		["CanCollide"] = false
	}
}
local v_u_3 = {
	{
		["Name"] = "RootJoint",
		["Part0"] = "HumanoidRootPart",
		["Part1"] = "Torso",
		["Parent"] = "HumanoidRootPart",
		["C0"] = nil,
		["C1"] = nil,
		["C0"] = CFrame.new(0, 0, 0) * CFrame.Angles(-1.5707963267948966, 0, 3.141592653589793),
		["C1"] = CFrame.new(0, 0, 0) * CFrame.Angles(-1.5707963267948966, 0, 3.141592653589793)
	},
	{
		["Name"] = "Neck",
		["Part0"] = "Torso",
		["Part1"] = "Head",
		["Parent"] = "Torso",
		["C0"] = nil,
		["C1"] = nil,
		["C0"] = CFrame.new(0, 1, 0) * CFrame.Angles(-1.5707963267948966, 0, 3.141592653589793),
		["C1"] = CFrame.new(0, -0.5, 0) * CFrame.Angles(-1.5707963267948966, 0, 3.141592653589793)
	},
	{
		["Name"] = "Right Shoulder",
		["Part0"] = "Torso",
		["Part1"] = "Right Arm",
		["Parent"] = "Torso",
		["C0"] = nil,
		["C1"] = nil,
		["C0"] = CFrame.new(1, 0.5, 0) * CFrame.Angles(0, 1.5707963267948966, 0),
		["C1"] = CFrame.new(-0.5, 0.5, 0) * CFrame.Angles(0, 1.5707963267948966, 0)
	},
	{
		["Name"] = "Left Shoulder",
		["Part0"] = "Torso",
		["Part1"] = "Left Arm",
		["Parent"] = "Torso",
		["C0"] = nil,
		["C1"] = nil,
		["C0"] = CFrame.new(-1, 0.5, 0) * CFrame.Angles(0, -1.5707963267948966, 0),
		["C1"] = CFrame.new(0.5, 0.5, 0) * CFrame.Angles(0, -1.5707963267948966, 0)
	},
	{
		["Name"] = "Right Hip",
		["Part0"] = "Torso",
		["Part1"] = "Right Leg",
		["Parent"] = "Torso",
		["C0"] = nil,
		["C1"] = nil,
		["C0"] = CFrame.new(1, -1, 0) * CFrame.Angles(0, 1.5707963267948966, 0),
		["C1"] = CFrame.new(0.5, 1, 0) * CFrame.Angles(0, 1.5707963267948966, 0)
	},
	{
		["Name"] = "Left Hip",
		["Part0"] = "Torso",
		["Part1"] = "Left Leg",
		["Parent"] = "Torso",
		["C0"] = nil,
		["C1"] = nil,
		["C0"] = CFrame.new(-1, -1, 0) * CFrame.Angles(0, -1.5707963267948966, 0),
		["C1"] = CFrame.new(-0.5, 1, 0) * CFrame.Angles(0, -1.5707963267948966, 0)
	}
}
function v1.Create() -- name: Create
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v4 = Instance.new("Model")
	v4.Name = "WalkerRig"
	local v5 = CFrame.new()
	local v6 = Instance.new("Part")
	v6.Name = "HumanoidRootPart"
	v6.Size = Vector3.new(2, 2, 1)
	v6.CFrame = v5
	v6.CanCollide = false
	v6.Anchored = false
	v6.TopSurface = Enum.SurfaceType.Smooth
	v6.BottomSurface = Enum.SurfaceType.Smooth
	v6.Transparency = 1
	v6.Anchored = true
	v6.Parent = v4
	local v7 = {
		["HumanoidRootPart"] = v6
	}
	for _, v8 in ipairs(v_u_2) do
		local v9 = v8.Name
		local v10 = v8.Size
		local v11 = CFrame.new(v8.Offset)
		local v12 = v8.CanCollide
		local v13 = Instance.new("Part")
		v13.Name = v9
		v13.Size = v10
		v13.CFrame = v11
		v13.CanCollide = v12
		v13.Anchored = false
		v13.TopSurface = Enum.SurfaceType.Smooth
		v13.BottomSurface = Enum.SurfaceType.Smooth
		v13.Parent = v4
		v7[v8.Name] = v13
	end
	for _, v14 in ipairs(v_u_3) do
		local v15 = Instance.new("Motor6D")
		v15.Name = v14.Name
		v15.Part0 = v7[v14.Part0]
		v15.Part1 = v7[v14.Part1]
		v15.C0 = v14.C0
		v15.C1 = v14.C1
		v15.Parent = v7[v14.Parent]
	end
	local v16 = Instance.new("Humanoid")
	v16.RigType = Enum.HumanoidRigType.R6
	v16.Parent = v4
	v4.PrimaryPart = v6
	return v4
end
return v1
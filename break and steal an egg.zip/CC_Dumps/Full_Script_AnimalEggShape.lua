local v_u_1 = game:GetService("Workspace")
local v_u_2 = require(script.Parent.AnimalEggCenters)
local v3 = {}
local v_u_4 = {
	["Grid"] = 17,
	["ProbeCFrame"] = nil,
	["ShellThicknessFrac"] = 0.6,
	["BodyCenterAttribute"] = "BodyCenter",
	["ProbeCFrame"] = CFrame.new(0, 5000, 0)
}
v3.Config = v_u_4
local v_u_5 = {}
local function v_u_47(p6) -- name: measure
	-- upvalues: (copy) v_u_4, (copy) v_u_1
	local v7 = p6:Clone()
	for _, v8 in v7:GetChildren() do
		v8:Destroy()
	end
	v7.Anchored = true
	v7.CanCollide = false
	v7.CanTouch = false
	v7.CanQuery = true
	v7.CFrame = v_u_4.ProbeCFrame
	v7.Parent = v_u_1
	local v_u_9 = RaycastParams.new()
	v_u_9.FilterType = Enum.RaycastFilterType.Include
	v_u_9.FilterDescendantsInstances = { v7 }
	local v_u_10 = v_u_4.ProbeCFrame
	local v_u_11 = v7.Size
	local v_u_12 = v_u_4.Grid
	local v_u_13 = {}
	local v_u_14 = 0
	local function v38()
		-- upvalues: (copy) v_u_12, (copy) v_u_11, (ref) v_u_1, (copy) v_u_10, (copy) v_u_9, (copy) v_u_13, (ref) v_u_14
		for v15 = 0, v_u_12 - 1 do
			for v16 = 0, v_u_12 - 1 do
				local v17 = (v15 / (v_u_12 - 1) - 0.5) * v_u_11.X * 0.999
				local v18 = (v16 / (v_u_12 - 1) - 0.5) * v_u_11.Z * 0.999
				local v19 = v_u_1
				local v20 = v_u_10
				local v21 = v_u_11.Y / 2 + 1
				local v22 = v20:PointToWorldSpace((Vector3.new(v17, v21, v18)))
				local v23 = -(v_u_11.Y + 2)
				local v24 = v19:Raycast(v22, Vector3.new(0, v23, 0), v_u_9)
				if not v24 then
					continue
				end
				local v25 = v_u_1
				local v26 = v_u_10
				local v27 = -v_u_11.Y / 2 - 1
				local v28 = v26:PointToWorldSpace((Vector3.new(v17, v27, v18)))
				local v29 = v_u_11.Y + 2
				local v30 = v25:Raycast(v28, Vector3.new(0, v29, 0), v_u_9)
				local v31 = v24.Position.Y - v_u_10.Y
				local v32
				if v30 then
					v32 = v30.Position.Y - v_u_10.Y
				else
					v32 = -v_u_11.Y / 2
				end
				local v33 = v31 - v32
				local v34 = math.max(v33, 0)
				if v34 <= 0 then
					continue
				end
				local v35 = v_u_13
				local v36 = Vector3.new(v17, v34, v18)
				table.insert(v35, v36)
				local v37 = v_u_14
				v_u_14 = math.max(v37, v34)
			end
		end
	end
	local v39 = pcall(v38)
	v7:Destroy()
	if not v39 or v_u_14 <= 0 then
		return Vector3.new(0, 0, 0)
	end
	local v40 = v_u_14 * v_u_4.ShellThicknessFrac
	local v41 = 0
	local v42 = 0
	local v43 = 0
	for _, v44 in v_u_13 do
		if v40 > v44.Y then
			continue
		end
		v41 = v41 + v44.Y
		v42 = v42 + v44.X * v44.Y
		v43 = v43 + v44.Z * v44.Y
	end
	if v41 <= 0 then
		return Vector3.new(0, 0, 0)
	end
	local v45 = v42 / v41 / v_u_11.X
	local v46 = v43 / v41 / v_u_11.Z
	return Vector3.new(v45, 0, v46)
end
v3.Measure = v_u_47
function v3.GetBodyCenter(p_u_48) -- name: GetBodyCenter
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_2, (copy) v_u_47
	local v49 = v_u_5[p_u_48]
	if not v49 then
		v49 = p_u_48:GetAttribute(v_u_4.BodyCenterAttribute)
		if typeof(v49) ~= "Vector3" then
			v49 = v_u_2[p_u_48.Name] or v_u_47(p_u_48)
		end
		v_u_5[p_u_48] = v49
		p_u_48.Destroying:Once(function()
			-- upvalues: (ref) v_u_5, (copy) p_u_48
			v_u_5[p_u_48] = nil
		end)
	end
	return v49
end
return v3
local v1 = {
	["Targets"] = {
		{
			["Path"] = nil,
			["Tile"] = "^Animal%d+$",
			["Display"] = "AnimalDisplay",
			["StyleOverrides"] = nil,
			["ClipTiles"] = true,
			["Path"] = {
				"Frames",
				"Shop",
				"ScrollingFrame",
				"EggsPack",
				"Inner",
				"AnimalsDisplay"
			},
			["StyleOverrides"] = {
				["LayerName"] = "AnimalDisplay"
			}
		}
	}
}
return v1
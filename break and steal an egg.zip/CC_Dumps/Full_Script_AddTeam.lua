return require(script.Parent.Parent.ActionCreator)("AddTeam", function(p1)
	return {
		["team"] = p1
	}
end)
local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("UserInputService")
local v_u_4 = require(v_u_2.Shared.AntiAfkConfig)
local v5 = {}
local v_u_6 = {
	[Enum.UserInputType.Keyboard] = true,
	[Enum.UserInputType.MouseButton1] = true,
	[Enum.UserInputType.MouseButton2] = true,
	[Enum.UserInputType.MouseButton3] = true,
	[Enum.UserInputType.Touch] = true,
	[Enum.UserInputType.Gamepad1] = true,
	[Enum.UserInputType.Gamepad2] = true,
	[Enum.UserInputType.Gamepad3] = true,
	[Enum.UserInputType.Gamepad4] = true,
	[Enum.UserInputType.Gamepad5] = true,
	[Enum.UserInputType.Gamepad6] = true,
	[Enum.UserInputType.Gamepad7] = true,
	[Enum.UserInputType.Gamepad8] = true
}
local v_u_7 = os.clock()
local v_u_8 = nil
local v_u_9 = nil
function v5.Start() -- name: Start
	-- upvalues: (copy) v_u_3, (copy) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (copy) v_u_1, (copy) v_u_2, (copy) v_u_4
	v_u_3.InputBegan:Connect(function(p10)
		-- upvalues: (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9
		if v_u_6[p10.UserInputType] then
			v_u_7 = os.clock()
			v_u_8 = nil
			v_u_9 = nil
		end
	end)
	v_u_3.InputChanged:Connect(function(p11)
		-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_9
		if p11.KeyCode == Enum.KeyCode.Thumbstick1 or p11.KeyCode == Enum.KeyCode.Thumbstick2 then
			v_u_7 = os.clock()
			v_u_8 = nil
			v_u_9 = nil
		end
	end)
	v_u_1.LocalPlayer.Idled:Connect(function(p12)
		-- upvalues: (ref) v_u_8
		local v13 = os.clock() - p12
		if v_u_8 == nil or v13 < v_u_8 then
			v_u_8 = v13
		end
	end)
	local v14 = v_u_2:WaitForChild("AntiAfkRejoinRemote")
	if not v14:IsA("RemoteEvent") then
		warn("[AntiAfkController] AntiAfkRejoinRemote is not a RemoteEvent \226\128\148 anti-AFK rejoin disabled")
		return
	end
	while true do
		repeat
			task.wait(v_u_4.CheckIntervalSeconds)
			local v15 = os.clock()
			local v16 = v15 - v_u_7
			local v17 = not v_u_8 and 0 or v15 - v_u_8
		until math.max(v16, v17) >= v_u_4.IdleSeconds and (v_u_9 == nil or os.clock() - v_u_9 >= v_u_4.RetrySeconds)
		v_u_9 = os.clock()
		v14:FireServer()
	end
end
return v5
local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(v2.Shared.ChaseState)
local v_u_6 = require(v2.Shared.PublicTreadmillConfig)
local v_u_7 = require(script.Parent.CinematicMode)
local v_u_8 = v_u_1.LocalPlayer
local v9 = {}
local v_u_10 = v_u_6.AdminSpawn
local v_u_11 = v_u_10.Cutscene
local v_u_12 = false
function v9.IsPlaying() -- name: IsPlaying
	-- upvalues: (ref) v_u_12
	return v_u_12
end
function v9.Facing(p13) -- name: Facing
	-- upvalues: (copy) v_u_6
	local v14 = p13:GetPivot().LookVector
	local v15 = v14.X
	local v16 = v14.Z
	local v17 = Vector3.new(v15, 0, v16)
	local v18 = v17.Magnitude <= 0.001 and Vector3.new(0, 0, -1) or v17.Unit
	for _, v19 in v_u_6.Treadmills do
		if v19.Model ~= p13.Name then
			continue
		end
		local v20 = p13:FindFirstChild(v19.Belt, true)
		if not (v20 and v20:IsA("BasePart")) then
			continue
		end
		local v21 = v20.CFrame:VectorToWorldSpace(v19.Facing)
		local v22 = v21.X
		local v23 = v21.Z
		local v24 = Vector3.new(v22, 0, v23)
		if v24.Magnitude > 0.001 then
			return v24.Unit
		else
			return v18
		end
	end
	return v18
end
function v9.Play(p_u_25) -- name: Play
	-- upvalues: (copy) v_u_11, (ref) v_u_12, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8, (copy) v_u_5, (copy) v_u_10, (copy) v_u_1, (copy) v_u_3
	if v_u_11.Enabled and not (v_u_12 or v_u_7.IsActive()) then
		local v_u_26 = v_u_4.CurrentCamera
		local v27 = v_u_8.Character
		if v27 then
			v27 = v27:FindFirstChild("HumanoidRootPart")
		end
		if v_u_26 and (v27 and v27:IsA("BasePart")) then
			if v_u_11.SkipWhileCarrying and (v_u_5.IsCarrying(v_u_8) or v_u_8:GetAttribute("BeingChased")) then
				return
			else
				local v_u_28 = p_u_25.FallStart
				if v_u_4:GetServerTimeNow() - v_u_28 > v_u_11.LateJoinGrace then
					return
				else
					local v_u_29 = v_u_10.DropTime
					local v_u_30 = v_u_11.Hold
					local v_u_31 = v_u_11.Return
					local v32 = p_u_25.Size
					local v33 = p_u_25.Ground
					local v34 = p_u_25.Facing
					local v35 = v34:Cross(Vector3.new(0, 1, 0))
					local v36 = v32.X
					local v37 = v32.Z
					local v38 = math.max(v36, v37) * v_u_11.Zoom
					local v_u_39 = v33 + Vector3.new(0, 1, 0) * (v32.Y * v_u_11.LookHeight)
					local v40 = v_u_11.Shots.ApproachFrom
					local v_u_41 = v33 + v35 * ((v40.Right or 0) * v38) + v34 * (((v40.Front or 0) - (v40.Back or 0)) * v38) + Vector3.new(0, 1, 0) * ((v40.Up or 0) * v38)
					local v42 = v_u_11.Shots.ApproachTo
					local v_u_43 = v33 + v35 * ((v42.Right or 0) * v38) + v34 * (((v42.Front or 0) - (v42.Back or 0)) * v38) + Vector3.new(0, 1, 0) * ((v42.Up or 0) * v38)
					local v_u_44 = RaycastParams.new()
					v_u_44.FilterType = Enum.RaycastFilterType.Exclude
					v_u_44.RespectCanCollide = true
					local function v_u_52(p45, p46) -- name: clear
						-- upvalues: (copy) p_u_25, (ref) v_u_1, (copy) v_u_44, (ref) v_u_4, (ref) v_u_11
						local v47 = { p_u_25.Model }
						for _, v48 in v_u_1:GetPlayers() do
							if not v48.Character then
								continue
							end
							local v49 = v48.Character
							table.insert(v47, v49)
						end
						v_u_44.FilterDescendantsInstances = v47
						local v50 = p45 - p46
						local v51 = v_u_4:Raycast(p46, v50, v_u_44)
						if v51 then
							return v51.Position - v50.Unit * v_u_11.WallPadding
						else
							return p45
						end
					end
					local v53 = v_u_26.CFrame.Position
					local v54 = v27.Parent
					if v54 then
						v54 = v27.Parent:FindFirstChildOfClass("Humanoid")
					end
					local v55 = not v54 and Vector3.new(0, 0, 0) or v54.CameraOffset
					local v_u_56 = v53 - (v27.Position + Vector3.new(0, 1.5, 0) + v55)
					if v_u_7.Enter(v_u_11) then
						v_u_12 = true
						local v_u_57 = v_u_26.CameraType
						v_u_26.CameraType = Enum.CameraType.Scriptable
						local v_u_58 = v_u_26.CFrame
						local v_u_59 = v_u_29 + v_u_30 + v_u_31
						local v_u_60 = false
						local function v_u_68() -- name: finish
							-- upvalues: (ref) v_u_60, (ref) v_u_3, (ref) v_u_8, (copy) v_u_26, (copy) v_u_56, (copy) v_u_57, (ref) v_u_12, (ref) v_u_7
							if not v_u_60 then
								v_u_60 = true
								v_u_3:UnbindFromRenderStep("AdminTreadmillCutscene")
								local v61 = v_u_8.Character
								if v61 then
									v61 = v_u_8.Character:FindFirstChild("HumanoidRootPart")
								end
								if v61 and v61:IsA("BasePart") then
									local v62 = v_u_26
									local v63 = v61.Parent
									if v63 then
										v63 = v61.Parent:FindFirstChildOfClass("Humanoid")
									end
									local v64 = not v63 and Vector3.new(0, 0, 0) or v63.CameraOffset
									local v65 = v61.Position + Vector3.new(0, 1.5, 0) + v64
									v62.CFrame = CFrame.lookAt(v65 + v_u_56, v65)
								end
								local v66 = v_u_26
								local v67
								if v_u_57 == Enum.CameraType.Scriptable then
									v67 = Enum.CameraType.Custom
								else
									v67 = v_u_57
								end
								v66.CameraType = v67
								v_u_12 = false
								v_u_7.Exit()
							end
						end
						local v_u_69 = v_u_26.CFrame.Position
						local v_u_70 = v_u_26.CFrame.Position + v_u_26.CFrame.LookVector * v38
						v_u_3:BindToRenderStep("AdminTreadmillCutscene", Enum.RenderPriority.Camera.Value, function(p71)
							-- upvalues: (ref) v_u_4, (copy) v_u_28, (ref) v_u_8, (copy) p_u_25, (copy) v_u_68, (copy) v_u_29, (copy) v_u_41, (copy) v_u_43, (copy) v_u_39, (ref) v_u_10, (copy) v_u_30, (copy) v_u_59, (copy) v_u_31, (copy) v_u_26, (ref) v_u_58, (copy) v_u_56, (copy) v_u_52, (ref) v_u_11, (ref) v_u_69, (ref) v_u_70
							local v72 = v_u_4:GetServerTimeNow() - v_u_28
							local v73 = v_u_8.Character
							if v73 then
								v73 = v_u_8.Character:FindFirstChild("HumanoidRootPart")
							end
							if p_u_25.Model.Parent and (v73 and v73:IsA("BasePart")) then
								local v74, v75
								if v72 < v_u_29 then
									local v76 = v_u_41
									local v77 = v_u_43
									local v78 = v72 / v_u_29
									local v79 = math.clamp(v78, 0, 1)
									v74 = v76:Lerp(v77, v79 * v79 * (3 - v79 * 2))
									local v80 = v72 / v_u_29
									local v81 = math.clamp(v80, 0, 1)
									v75 = v_u_39 + Vector3.new(0, 1, 0) * (v_u_10.DropHeight * (1 - v81 * v81))
								else
									if v72 >= v_u_29 + v_u_30 then
										if v72 < v_u_59 then
											local v82 = (v72 - v_u_29 - v_u_30) / v_u_31
											local v83 = math.clamp(v82, 0, 1)
											local v84 = v83 * v83 * (3 - v83 * 2)
											local v85 = v_u_26
											local v86 = v_u_58
											local v87 = v73.Parent
											if v87 then
												v87 = v73.Parent:FindFirstChildOfClass("Humanoid")
											end
											local v88 = not v87 and Vector3.new(0, 0, 0) or v87.CameraOffset
											local v89 = v73.Position + Vector3.new(0, 1.5, 0) + v88
											v85.CFrame = v86:Lerp(CFrame.lookAt(v89 + v_u_56, v89), v84)
										else
											v_u_68()
										end
									end
									v74 = v_u_43
									v75 = v_u_39
								end
								local v90 = v_u_52(v74, v_u_39)
								local v91 = -v_u_11.Smoothing * p71
								local v92 = 1 - math.exp(v91)
								v_u_69 = v_u_69:Lerp(v90, v92)
								v_u_70 = v_u_70:Lerp(v75, v92)
								local v93 = CFrame.lookAt(v_u_69, v_u_70)
								v_u_58 = v93
								v_u_26.CFrame = v93
							else
								v_u_68()
							end
						end)
						local v94 = task.delay
						local v95 = v_u_59 - (v_u_4:GetServerTimeNow() - v_u_28)
						v94(math.max(v95, 0) + v_u_11.SafetyGrace, v_u_68)
					end
				end
			end
		else
			return
		end
	else
		return
	end
end
return v9
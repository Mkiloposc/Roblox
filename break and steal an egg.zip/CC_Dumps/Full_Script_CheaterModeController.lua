local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = require(v2.Shared.CheaterModeConfig)
local v_u_7 = require(script.Parent.NotificationController)
local v_u_8 = v1.LocalPlayer
local v9 = {}
local v_u_10 = false
local v_u_11 = false
local v_u_12 = false
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = {}
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = nil
local function v_u_23(p19) -- name: flyDirection
	-- upvalues: (copy) v_u_4, (copy) v_u_6
	if v_u_4:GetFocusedTextBox() then
		return Vector3.new(0, 0, 0)
	end
	local v20 = p19.CFrame.LookVector
	local v21 = p19.CFrame.RightVector
	local v22 = Vector3.new(0, 0, 0)
	if v_u_4:IsKeyDown(Enum.KeyCode.W) then
		v22 = v22 + v20
	end
	if v_u_4:IsKeyDown(Enum.KeyCode.S) then
		v22 = v22 - v20
	end
	if v_u_4:IsKeyDown(Enum.KeyCode.D) then
		v22 = v22 + v21
	end
	if v_u_4:IsKeyDown(Enum.KeyCode.A) then
		v22 = v22 - v21
	end
	if v_u_4:IsKeyDown(v_u_6.FlyUpKey) then
		v22 = v22 + Vector3.new(0, 1, 0)
	end
	if v_u_4:IsKeyDown(v_u_6.FlyDownKey) then
		v22 = v22 - Vector3.new(0, 1, 0)
	end
	return v22.Magnitude <= 0 and Vector3.new(0, 0, 0) or v22.Unit
end
local function v_u_28(p24) -- name: stopFly
	-- upvalues: (ref) v_u_11, (ref) v_u_18, (ref) v_u_17, (copy) v_u_8, (copy) v_u_7
	if v_u_11 then
		v_u_11 = false
		if v_u_18 then
			v_u_18:Disconnect()
			v_u_18 = nil
		end
		for _, v25 in v_u_17 do
			v25:Destroy()
		end
		table.clear(v_u_17)
		local v26 = v_u_8.Character
		local v27
		if v26 then
			v27 = v26:FindFirstChild("HumanoidRootPart")
		else
			v27 = v26
		end
		if v26 then
			v26 = v26:FindFirstChildOfClass("Humanoid")
		end
		if not v27 or (not v27:IsA("BasePart") or (not v26 or v26.Health <= 0)) then
			v26 = nil
		end
		if v26 then
			v26.PlatformStand = false
		end
		if not p24 then
			v_u_7.ShowPreset("CheatFlyOff")
		end
	end
end
local function v_u_44() -- name: startFly
	-- upvalues: (copy) v_u_8, (ref) v_u_11, (ref) v_u_17, (ref) v_u_18, (copy) v_u_3, (copy) v_u_5, (copy) v_u_23, (ref) v_u_13, (copy) v_u_6, (ref) v_u_12, (copy) v_u_7
	local v29 = v_u_8.Character
	local v_u_30
	if v29 then
		v_u_30 = v29:FindFirstChild("HumanoidRootPart")
	else
		v_u_30 = v29
	end
	if v29 then
		v29 = v29:FindFirstChildOfClass("Humanoid")
	end
	if not v_u_30 or (not v_u_30:IsA("BasePart") or (not v29 or v29.Health <= 0)) then
		v_u_30 = nil
		v29 = nil
	end
	if not v_u_11 and (v_u_30 and v29) then
		v_u_11 = true
		local v31 = Instance.new("Attachment")
		v31.Name = "CheatFlyAttachment"
		v31.Parent = v_u_30
		local v_u_32 = Instance.new("LinearVelocity")
		v_u_32.Name = "CheatFlyVelocity"
		v_u_32.Attachment0 = v31
		v_u_32.RelativeTo = Enum.ActuatorRelativeTo.World
		v_u_32.VelocityConstraintMode = Enum.VelocityConstraintMode.Vector
		v_u_32.MaxForce = 1000000000
		v_u_32.VectorVelocity = Vector3.new(0, 0, 0)
		v_u_32.Parent = v_u_30
		local v_u_33 = Instance.new("AlignOrientation")
		v_u_33.Name = "CheatFlyOrientation"
		v_u_33.Mode = Enum.OrientationAlignmentMode.OneAttachment
		v_u_33.Attachment0 = v31
		v_u_33.RigidityEnabled = true
		v_u_33.CFrame = v_u_30.CFrame.Rotation
		v_u_33.Parent = v_u_30
		v_u_17 = { v31, v_u_32, v_u_33 }
		v29.PlatformStand = true
		v_u_18 = v_u_3.RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_5, (copy) v_u_30, (copy) v_u_32, (ref) v_u_23, (ref) v_u_13, (ref) v_u_6, (ref) v_u_12, (copy) v_u_33
			local v34 = v_u_5.CurrentCamera
			if v34 and v_u_30.Parent ~= nil then
				local v35 = v_u_32
				local v36 = v_u_23(v34)
				local v37 = v_u_13 or 16
				local v38 = v_u_6.FlyMinSpeed
				local v39 = math.max(v37, v38)
				if v_u_12 then
					v39 = v39 * v_u_6.SpeedMultiplier
				end
				v35.VectorVelocity = v36 * v39
				local v40 = v34.CFrame.LookVector
				local v41 = v40.X
				local v42 = v40.Z
				local v43 = Vector3.new(v41, 0, v42)
				if v43.Magnitude > 0.001 then
					v_u_33.CFrame = CFrame.lookAt(Vector3.new(0, 0, 0), v43)
				end
			end
		end)
		v_u_7.ShowPreset("CheatFlyOn")
	end
end
local function v_u_61(p45) -- name: teleportToScreenPoint
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_6
	local v46 = v_u_8.Character
	local v47
	if v46 then
		v47 = v46:FindFirstChild("HumanoidRootPart")
	else
		v47 = v46
	end
	local v48
	if v46 then
		v48 = v46:FindFirstChildOfClass("Humanoid")
	else
		v48 = v46
	end
	if not v47 or (not v47:IsA("BasePart") or (not v48 or v48.Health <= 0)) then
		v46 = nil
		v47 = nil
		v48 = nil
	end
	local v49 = v_u_5.CurrentCamera
	if v46 and (v47 and (v48 and v49)) then
		local v50 = v49:ViewportPointToRay(p45.X, p45.Y)
		local v51 = RaycastParams.new()
		v51.FilterType = Enum.RaycastFilterType.Exclude
		v51.FilterDescendantsInstances = { v46 }
		local v52 = v_u_5:Raycast(v50.Origin, v50.Direction * v_u_6.TeleportRange, v51)
		if v52 then
			local v53 = v52.Position
			local v54 = v48.HipHeight + v47.Size.Y * 0.5
			local v55 = v53 + Vector3.new(0, v54, 0)
			local v56 = v55 - v47.Position
			local v57 = v56.X
			local v58 = v56.Z
			local v59 = Vector3.new(v57, 0, v58)
			local v60
			if v59.Magnitude > 0.001 then
				v60 = CFrame.lookAt(v55, v55 + v59)
			else
				v60 = CFrame.new(v55) * v47.CFrame.Rotation
			end
			v47.CFrame = v60
			v47.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
		end
	else
		return
	end
end
local function v_u_79(p62) -- name: hookCharacter
	-- upvalues: (copy) v_u_16, (copy) v_u_28, (ref) v_u_14, (copy) v_u_8, (ref) v_u_10, (ref) v_u_13, (ref) v_u_12, (copy) v_u_6
	local v63 = v_u_16
	for _, v64 in v63 do
		v64:Disconnect()
	end
	table.clear(v63)
	v_u_28(true)
	v_u_14 = nil
	local v_u_65 = p62:WaitForChild("Humanoid", 10)
	if v_u_65 and (v_u_65:IsA("Humanoid") and (v_u_8.Character == p62 and v_u_10)) then
		v_u_13 = v_u_65.WalkSpeed
		local v66 = v_u_16
		local v67 = v_u_65:GetPropertyChangedSignal("WalkSpeed")
		local function v73()
			-- upvalues: (copy) v_u_65, (ref) v_u_14, (ref) v_u_13, (ref) v_u_12, (ref) v_u_6
			local v68 = v_u_65.WalkSpeed
			if v_u_14 then
				local v69 = v68 - v_u_14
				if math.abs(v69) < 0.0001 then
					return
				end
			end
			v_u_13 = v68
			if v_u_12 then
				local v70 = v_u_65
				local v71 = v_u_13 or v70.WalkSpeed
				if v_u_12 then
					v71 = v71 * v_u_6.SpeedMultiplier
				end
				local v72
				if v_u_12 then
					v72 = v71
				else
					v72 = nil
				end
				v_u_14 = v72
				if v70.WalkSpeed ~= v71 then
					v70.WalkSpeed = v71
				end
			end
		end
		table.insert(v66, v67:Connect(v73))
		local v74 = v_u_16
		local v75 = v_u_65.Died
		local function v76()
			-- upvalues: (ref) v_u_28
			v_u_28(true)
		end
		table.insert(v74, v75:Connect(v76))
		if v_u_12 then
			local v77 = v_u_13 or v_u_65.WalkSpeed
			if v_u_12 then
				v77 = v77 * v_u_6.SpeedMultiplier
			end
			local v78
			if v_u_12 then
				v78 = v77
			else
				v78 = nil
			end
			v_u_14 = v78
			if v_u_65.WalkSpeed ~= v77 then
				v_u_65.WalkSpeed = v77
			end
		end
	end
end
local function v_u_87(p80, p81) -- name: onInput
	-- upvalues: (ref) v_u_10, (copy) v_u_61, (copy) v_u_4, (copy) v_u_6, (ref) v_u_11, (copy) v_u_28, (copy) v_u_44, (ref) v_u_12, (copy) v_u_8, (ref) v_u_13, (ref) v_u_14, (copy) v_u_7
	if p81 or not v_u_10 then
		return
	elseif p80.UserInputType == Enum.UserInputType.MouseButton1 then
		v_u_61(v_u_4:GetMouseLocation())
		return
	elseif p80.KeyCode == v_u_6.FlyKey then
		if v_u_11 then
			v_u_28()
		else
			v_u_44()
		end
	else
		if p80.KeyCode == v_u_6.SpeedKey then
			local v82 = not v_u_12
			if v_u_12 == v82 then
				return
			end
			v_u_12 = v82
			local v83 = v_u_8.Character
			local v84
			if v83 then
				v84 = v83:FindFirstChild("HumanoidRootPart")
			else
				v84 = v83
			end
			if v83 then
				v83 = v83:FindFirstChildOfClass("Humanoid")
			end
			if not v84 or (not v84:IsA("BasePart") or (not v83 or v83.Health <= 0)) then
				v83 = nil
			end
			if v83 then
				local v85 = v_u_13 or v83.WalkSpeed
				if v_u_12 then
					v85 = v85 * v_u_6.SpeedMultiplier
				end
				local v86
				if v_u_12 then
					v86 = v85
				else
					v86 = nil
				end
				v_u_14 = v86
				if v83.WalkSpeed ~= v85 then
					v83.WalkSpeed = v85
				end
			end
			if v82 then
				v_u_7.ShowPreset("CheatSpeedOn", v_u_6.SpeedMultiplier)
				return
			end
			v_u_7.ShowPreset("CheatSpeedOff")
		end
		return
	end
end
local function v_u_95() -- name: arm
	-- upvalues: (ref) v_u_10, (copy) v_u_15, (copy) v_u_4, (copy) v_u_87, (copy) v_u_8, (copy) v_u_79
	if not v_u_10 then
		v_u_10 = true
		local v88 = v_u_15
		local v89 = v_u_4.InputBegan
		local v90 = v_u_87
		table.insert(v88, v89:Connect(v90))
		local v91 = v_u_15
		local v92 = v_u_8.CharacterAdded
		local function v94(p93)
			-- upvalues: (ref) v_u_79
			v_u_79(p93)
		end
		table.insert(v91, v92:Connect(v94))
		if v_u_8.Character then
			task.spawn(v_u_79, v_u_8.Character)
		end
	end
end
function v9.Start() -- name: Start
	-- upvalues: (copy) v_u_8, (copy) v_u_6, (copy) v_u_95, (ref) v_u_10, (copy) v_u_28, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (copy) v_u_15, (copy) v_u_16
	local function v104() -- name: refresh
		-- upvalues: (ref) v_u_8, (ref) v_u_6, (ref) v_u_95, (ref) v_u_10, (ref) v_u_28, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16
		if v_u_8:GetAttribute(v_u_6.Attribute) == true then
			v_u_95()
			return
		elseif v_u_10 then
			v_u_10 = false
			v_u_28(true)
			if v_u_12 ~= false then
				v_u_12 = false
				local v96 = v_u_8.Character
				local v97
				if v96 then
					v97 = v96:FindFirstChild("HumanoidRootPart")
				else
					v97 = v96
				end
				if v96 then
					v96 = v96:FindFirstChildOfClass("Humanoid")
				end
				if not v97 or (not v97:IsA("BasePart") or (not v96 or v96.Health <= 0)) then
					v96 = nil
				end
				if v96 then
					local v98 = v_u_13 or v96.WalkSpeed
					if v_u_12 then
						v98 = v98 * v_u_6.SpeedMultiplier
					end
					local v99
					if v_u_12 then
						v99 = v98
					else
						v99 = nil
					end
					v_u_14 = v99
					if v96.WalkSpeed ~= v98 then
						v96.WalkSpeed = v98
					end
				end
			end
			local v100 = v_u_15
			for _, v101 in v100 do
				v101:Disconnect()
			end
			table.clear(v100)
			local v102 = v_u_16
			for _, v103 in v102 do
				v103:Disconnect()
			end
			table.clear(v102)
			v_u_14 = nil
			v_u_13 = nil
		end
	end
	v_u_8:GetAttributeChangedSignal(v_u_6.Attribute):Connect(v104)
	if v_u_8:GetAttribute(v_u_6.Attribute) == true then
		v_u_95()
		return
	elseif v_u_10 then
		v_u_10 = false
		v_u_28(true)
		if v_u_12 ~= false then
			v_u_12 = false
			local v105 = v_u_8.Character
			local v106
			if v105 then
				v106 = v105:FindFirstChild("HumanoidRootPart")
			else
				v106 = v105
			end
			if v105 then
				v105 = v105:FindFirstChildOfClass("Humanoid")
			end
			if not v106 or (not v106:IsA("BasePart") or (not v105 or v105.Health <= 0)) then
				v105 = nil
			end
			if v105 then
				local v107 = v_u_13 or v105.WalkSpeed
				if v_u_12 then
					v107 = v107 * v_u_6.SpeedMultiplier
				end
				local v108
				if v_u_12 then
					v108 = v107
				else
					v108 = nil
				end
				v_u_14 = v108
				if v105.WalkSpeed ~= v107 then
					v105.WalkSpeed = v107
				end
			end
		end
		local v109 = v_u_15
		for _, v110 in v109 do
			v110:Disconnect()
		end
		table.clear(v109)
		local v111 = v_u_16
		for _, v112 in v111 do
			v112:Disconnect()
		end
		table.clear(v111)
		v_u_14 = nil
		v_u_13 = nil
	end
end
return v9
local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = require(script.Parent.EggPlaceBurst)
local v_u_5 = require(script.Parent.SurfaceLook)
local v_u_6 = {}
local v_u_7 = {
	["MudColor"] = nil,
	["ChunkColors"] = nil,
	["ChunkCountMin"] = 6,
	["ChunkCountMax"] = 10,
	["ChunkStagger"] = 0.015,
	["ChunkUpSeconds"] = 0.2,
	["ChunkLandSeconds"] = 0.12,
	["ChunkSettleSeconds"] = 0.08,
	["ChunkFadeDelay"] = 0.15,
	["ChunkFadeSeconds"] = 0.5,
	["DecalFadeInSeconds"] = 0.25,
	["DecalLingerMin"] = 7,
	["DecalLingerMax"] = 11,
	["DecalFadeOutSeconds"] = 1,
	["RingSeconds"] = 0.3,
	["MudColor"] = Color3.fromRGB(101, 67, 33),
	["ChunkColors"] = {
		Color3.fromRGB(101, 67, 33),
		Color3.fromRGB(92, 60, 28),
		Color3.fromRGB(110, 75, 40),
		Color3.fromRGB(85, 55, 25)
	}
}
local v_u_8 = Random.new()
local v_u_9 = nil
local function v_u_62(p10, p11, p12, p13) -- name: spawnDirtChunk
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_5, (copy) v_u_1, (copy) v_u_2
	local v_u_14 = v_u_7
	local v_u_15 = v_u_8:NextNumber(0.25, 0.45) * p12
	local v16 = v_u_15 * 0.7
	local v17 = Vector3.new(v_u_15, v16, v_u_15)
	local v18 = v_u_14.ChunkColors[v_u_8:NextInteger(1, #v_u_14.ChunkColors)]
	local v_u_19 = Instance.new("Part")
	v_u_19.Size = v17
	v_u_19.Color = v18
	v_u_19.Material = Enum.Material.SmoothPlastic
	v_u_19.Anchored = true
	v_u_19.CanCollide = false
	v_u_19.CanQuery = false
	v_u_19.CanTouch = false
	v_u_19.CastShadow = false
	local v_u_20 = v_u_5.Apply(v_u_19, p13)
	v_u_19.Position = p11 + Vector3.new(0, 0.05, 0)
	local v21 = v_u_8:NextNumber(-30, 30)
	local v22 = v_u_8:NextNumber(-180, 180)
	local v23 = v_u_8
	v_u_19.Orientation = Vector3.new(v21, v22, v23:NextNumber(-30, 30))
	v_u_19.Parent = p10
	v_u_1:AddItem(v_u_19, 3)
	local v24 = v_u_8:NextNumber(0, 360)
	local v25 = math.rad(v24)
	local v26 = v_u_8:NextNumber(0.3, 0.6) * p12
	local v27 = math.cos(v25) * v26
	local v28 = math.sin(v25) * v26
	local v29 = v27 * 0.6
	local v30 = v_u_8:NextNumber(0.5, 0.9) * p12
	local v31 = v28 * 0.6
	local v32 = p11 + Vector3.new(v29, v30, v31)
	local v33 = p12 * 0.02
	local v_u_34 = p11 + Vector3.new(v27, v33, v28)
	local v35 = p12 * -0.01
	local v_u_36 = v_u_34 + Vector3.new(0, v35, 0)
	local v37 = v_u_2
	local v38 = TweenInfo.new(v_u_14.ChunkUpSeconds, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
	local v39 = {
		["Position"] = v32
	}
	local v40 = v_u_19.Orientation
	local v41 = v_u_8:NextNumber(-45, 45)
	local v42 = v_u_8:NextNumber(-90, 90)
	local v43 = v_u_8
	v39.Orientation = v40 + Vector3.new(v41, v42, v43:NextNumber(-45, 45))
	local v44 = v37:Create(v_u_19, v38, v39)
	v44:Play()
	v44.Completed:Once(function()
		-- upvalues: (ref) v_u_2, (copy) v_u_19, (copy) v_u_14, (copy) v_u_34, (copy) v_u_15, (copy) v_u_36, (ref) v_u_5, (copy) v_u_20, (ref) v_u_1
		local v45 = v_u_2
		local v46 = v_u_19
		local v47 = TweenInfo.new(v_u_14.ChunkLandSeconds, Enum.EasingStyle.Bounce, Enum.EasingDirection.Out)
		local v48 = {
			["Position"] = v_u_34
		}
		local v49 = v_u_15 * 1.1
		local v50 = v_u_15 * 0.5
		local v51 = v_u_15 * 1.1
		v48.Size = Vector3.new(v49, v50, v51)
		local v52 = v45:Create(v46, v47, v48)
		v52:Play()
		v52.Completed:Once(function()
			-- upvalues: (ref) v_u_2, (ref) v_u_19, (ref) v_u_14, (ref) v_u_36, (ref) v_u_15, (ref) v_u_5, (ref) v_u_20, (ref) v_u_1
			local v53 = v_u_2
			local v54 = v_u_19
			local v55 = TweenInfo.new(v_u_14.ChunkSettleSeconds, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			local v56 = {
				["Position"] = v_u_36
			}
			local v57 = v_u_15
			local v58 = v_u_15 * 0.65
			local v59 = v_u_15
			v56.Size = Vector3.new(v57, v58, v59)
			local v60 = v53:Create(v54, v55, v56)
			v60:Play()
			v60.Completed:Once(function()
				-- upvalues: (ref) v_u_14, (ref) v_u_2, (ref) v_u_19, (ref) v_u_5, (ref) v_u_20, (ref) v_u_1
				task.delay(v_u_14.ChunkFadeDelay, function()
					-- upvalues: (ref) v_u_14, (ref) v_u_2, (ref) v_u_19, (ref) v_u_5, (ref) v_u_20, (ref) v_u_1
					local v61 = TweenInfo.new(v_u_14.ChunkFadeSeconds, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut)
					v_u_2:Create(v_u_19, v61, {
						["Transparency"] = 1
					}):Play()
					v_u_5.Fade(v_u_20, v61)
					v_u_1:AddItem(v_u_19, v_u_14.ChunkFadeSeconds)
				end)
			end)
		end)
	end)
end
local function v_u_70(p_u_63, p_u_64, p_u_65, p66) -- name: spawnDirtChunks
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_7, (copy) v_u_62
	local v_u_67 = p66 or v_u_5.Below(p_u_64, { p_u_63 })
	local v68 = v_u_8:NextInteger(v_u_7.ChunkCountMin, v_u_7.ChunkCountMax)
	v_u_62(p_u_63, p_u_64, p_u_65, v_u_67)
	for v69 = 2, v68 do
		task.delay((v69 - 1) * v_u_7.ChunkStagger, function()
			-- upvalues: (ref) v_u_62, (copy) p_u_63, (copy) p_u_64, (copy) p_u_65, (ref) v_u_67
			v_u_62(p_u_63, p_u_64, p_u_65, v_u_67)
		end)
	end
end
local function v_u_90(p71, p72, p73) -- name: spawnDirtDecal
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_2, (copy) v_u_1
	local v_u_74 = v_u_7
	local v_u_75 = p73 * 0.1
	local v76 = p73 * 0.8
	local v77 = p73 * 1.6
	local v_u_78 = p73 * 1.4
	local v79 = Vector3.new(v_u_75, v76, v76)
	local v80 = v_u_74.MudColor
	local v_u_81 = Instance.new("Part")
	v_u_81.Size = v79
	v_u_81.Color = v80
	v_u_81.Material = Enum.Material.SmoothPlastic
	v_u_81.Anchored = true
	v_u_81.CanCollide = false
	v_u_81.CanQuery = false
	v_u_81.CanTouch = false
	v_u_81.CastShadow = false
	v_u_81.Name = "EggPlaceDirtDecal"
	v_u_81.Shape = Enum.PartType.Cylinder
	v_u_81.Transparency = 1
	v_u_81.Position = p72 - Vector3.new(0, 0.01, 0)
	local v82 = v_u_8:NextNumber(-180, 180)
	v_u_81.Orientation = Vector3.new(0, v82, 90)
	v_u_81.Parent = p71
	v_u_2:Create(v_u_81, TweenInfo.new(v_u_74.DecalFadeInSeconds, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		["Transparency"] = 0,
		["Size"] = nil,
		["Size"] = Vector3.new(v_u_75, v77, v77)
	}):Play()
	task.delay(v_u_8:NextNumber(v_u_74.DecalLingerMin, v_u_74.DecalLingerMax), function()
		-- upvalues: (ref) v_u_2, (copy) v_u_81, (copy) v_u_74, (copy) v_u_75, (copy) v_u_78, (ref) v_u_1
		local v83 = v_u_2
		local v84 = v_u_81
		local v85 = TweenInfo.new(v_u_74.DecalFadeOutSeconds, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		local v86 = {
			["Transparency"] = 1,
			["Size"] = nil
		}
		local v87 = v_u_75
		local v88 = v_u_78
		local v89 = v_u_78
		v86.Size = Vector3.new(v87, v88, v89)
		v83:Create(v84, v85, v86):Play()
		v_u_1:AddItem(v_u_81, v_u_74.DecalFadeOutSeconds)
	end)
end
local function v_u_106(p91, p92, p93) -- name: spawnImpactRing
	-- upvalues: (copy) v_u_2, (copy) v_u_7, (copy) v_u_1
	local v94 = p93 * 0.05
	local v95 = p93 * 0.3
	local v96 = p93 * 0.3
	local v97 = Vector3.new(v94, v95, v96)
	local v98 = Color3.fromRGB(139, 90, 43)
	local v99 = Instance.new("Part")
	v99.Size = v97
	v99.Color = v98
	v99.Material = Enum.Material.SmoothPlastic
	v99.Anchored = true
	v99.CanCollide = false
	v99.CanQuery = false
	v99.CanTouch = false
	v99.CastShadow = false
	v99.Name = "EggPlaceImpactRing"
	v99.Shape = Enum.PartType.Cylinder
	v99.Transparency = 0.3
	v99.Position = p92 + Vector3.new(0, 0.02, 0)
	v99.Orientation = Vector3.new(0, 0, 90)
	v99.Parent = p91
	local v100 = v_u_2
	local v101 = TweenInfo.new(v_u_7.RingSeconds, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
	local v102 = {
		["Transparency"] = 1,
		["Size"] = nil
	}
	local v103 = p93 * 0.05
	local v104 = p93 * 1.8
	local v105 = p93 * 1.8
	v102.Size = Vector3.new(v103, v104, v105)
	v100:Create(v99, v101, v102):Play()
	v_u_1:AddItem(v99, 0.35)
end
function v_u_6.Dirt(p107, p108, p109) -- name: Dirt
	-- upvalues: (copy) v_u_70, (copy) v_u_90, (copy) v_u_106
	v_u_70(p107, p108, p109)
	v_u_90(p107, p108, p109)
	v_u_106(p107, p108, p109)
end
function v_u_6.Play(p110, p111, p112) -- name: Play
	-- upvalues: (copy) v_u_6, (ref) v_u_9, (copy) v_u_3, (copy) v_u_4
	local v113 = v_u_6.Dirt
	local v114
	if v_u_9 and v_u_9.Parent then
		v114 = v_u_9
	else
		v114 = Instance.new("Folder")
		v114.Name = "EggLandImpact_Local"
		v114.Parent = v_u_3
		v_u_9 = v114
	end
	v113(v114, p110, (math.max(p111, 0.1)))
	v_u_4.Play(p110, p112)
end
function v_u_6.Chunks(p115, p116, p117, p118) -- name: Chunks
	-- upvalues: (copy) v_u_70, (ref) v_u_9, (copy) v_u_3, (copy) v_u_4
	local v119 = v_u_70
	local v120
	if v_u_9 and v_u_9.Parent then
		v120 = v_u_9
	else
		v120 = Instance.new("Folder")
		v120.Name = "EggLandImpact_Local"
		v120.Parent = v_u_3
		v_u_9 = v120
	end
	v119(v120, p115, math.max(p116, 0.1), p118)
	v_u_4.Play(p115, p117)
end
return v_u_6
local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = require(v3.Shared.EggRewards)
local v_u_6 = require(script.Parent.SettingsState)
local v7 = {}
local v_u_8 = Color3.new(1, 1, 1)
local v_u_9 = {
	["Mythic"] = "Mythical"
}
local v_u_10 = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_11 = TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.In, 0, false, 0.55)
local v_u_12 = Random.new()
local function v_u_21(p13, p14) -- name: sampleColorSequence
	local v15 = p13.Keypoints
	if p14 <= v15[1].Time then
		return v15[1].Value
	end
	for v16 = 2, #v15 do
		local v17 = v15[v16]
		if p14 > v17.Time then
			continue
		end
		local v18 = v15[v16 - 1]
		local v19 = v17.Time - v18.Time
		local v20 = v19 <= 0 and 1 or (p14 - v18.Time) / v19
		return v18.Value:Lerp(v17.Value, v20)
	end
	return v15[#v15].Value
end
function v7.Play(p22) -- name: Play
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_9, (copy) v_u_8, (copy) v_u_5, (copy) v_u_4, (copy) v_u_10, (copy) v_u_11, (copy) v_u_21, (copy) v_u_12, (copy) v_u_1
	if v_u_6.Get("ScreenFFX") == true then
		local v23 = v_u_2.LocalPlayer:FindFirstChild("PlayerGui")
		if v23 then
			v23 = v23:FindFirstChild("MainGUI")
		end
		local v24
		if v23 then
			v24 = v23:FindFirstChild("EggRarityHatch")
		else
			v24 = v23
		end
		if v24 and v24:IsA("ImageLabel") then
			local v25 = v24:FindFirstChild("Rarities")
			local v26
			if p22 then
				v26 = v_u_9[p22] or p22
			else
				v26 = p22
			end
			local v27
			if v25 and v26 then
				v27 = v25:FindFirstChild(v26)
			else
				v27 = nil
			end
			if not (v27 and v27:IsA("UIGradient")) then
				v27 = nil
			end
			local v28
			if v27 then
				v28 = v_u_8
			else
				v28 = p22 and v_u_5.RarityColors[p22] or v_u_8
			end
			local v_u_29 = v24:Clone()
			v_u_29.Name = "EggRarityBurstFX"
			v_u_29.ImageColor3 = v28
			v_u_29.ImageTransparency = 1
			v_u_29.Visible = true
			local v30 = v_u_29:FindFirstChild("Rarities")
			if v30 then
				v30:Destroy()
			end
			if v27 then
				local v31 = v27:Clone()
				v31.Enabled = true
				v31.Parent = v_u_29
			end
			local v32 = v_u_29:FindFirstChild("Star")
			if v32 and v32:IsA("ImageLabel") then
				v32.Visible = false
			else
				v32 = nil
			end
			v_u_29.Parent = v23
			local v33 = v_u_4:Create(v_u_29, v_u_10, {
				["ImageTransparency"] = 0
			})
			v33.Completed:Once(function()
				-- upvalues: (copy) v_u_29, (ref) v_u_4, (ref) v_u_11
				if v_u_29.Parent then
					v_u_4:Create(v_u_29, v_u_11, {
						["ImageTransparency"] = 1
					}):Play()
				end
			end)
			v33:Play()
			local v34 = v_u_10.Time + v_u_11.DelayTime + v_u_11.Time
			if v32 and v32:IsA("ImageLabel") then
				local v35 = v32.Size
				for _ = 1, 12 do
					local v36 = v32:Clone()
					v36.Visible = true
					local v37
					if v27 then
						local v38, v39, v40 = v_u_21(v27.Color, v_u_12:NextNumber()):ToHSV()
						v37 = Color3.fromHSV(v38, v39, (math.max(v40, 0.75)))
					else
						v37 = v28
					end
					v36.ImageColor3 = v37
					v36.AnchorPoint = Vector2.new(0.5, 0.5)
					local v41 = v_u_12:NextNumber(0.5, 1.6)
					v36.Size = UDim2.new(v35.X.Scale * v41, v35.X.Offset * v41, v35.Y.Scale * v41, v35.Y.Offset * v41)
					local v42 = v_u_12:NextNumber(0.08, 0.92)
					local v43 = v_u_12:NextNumber(0.08, 0.92)
					v36.Position = UDim2.fromScale(v42, v43)
					v36.Rotation = v_u_12:NextNumber(0, 360)
					local v44 = v_u_12:NextNumber(0.9, 1.8)
					v34 = math.max(v34, v44)
					v36.Parent = v_u_29
					local v45 = v_u_12:NextNumber(-180, 180)
					v_u_4:Create(v36, TweenInfo.new(v44, Enum.EasingStyle.Linear), {
						["Rotation"] = v36.Rotation + v45 * v44
					}):Play()
					v_u_4:Create(v36, TweenInfo.new(v44, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["Position"] = UDim2.fromScale(v42 + v_u_12:NextNumber(-0.12, 0.12), v43 + v_u_12:NextNumber(-0.12, 0.12))
					}):Play()
					v_u_4:Create(v36, TweenInfo.new(v44, Enum.EasingStyle.Quad, Enum.EasingDirection.In), {
						["ImageTransparency"] = 1
					}):Play()
				end
			end
			v_u_1:AddItem(v_u_29, v34 + 0.2)
		end
	else
		return
	end
end
return v7
local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v3 = require(v2.Shared.AdminConfig)
local v_u_4 = require(v2.Shared.DiamondsConfig)
local v_u_5 = v1.LocalPlayer
local v_u_6 = {}
local v_u_7
if v_u_4.InfiniteInTestPlace == true then
	v_u_7 = game.PlaceId == v3.DevPlaceId
else
	v_u_7 = false
end
local v_u_8 = v_u_7 and (1 / 0) or 0
local v_u_9 = Instance.new("BindableEvent")
local v_u_10 = 0
local v_u_11 = false
local function v18() -- name: onServerChanged
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_7, (ref) v_u_11, (ref) v_u_8, (copy) v_u_9, (ref) v_u_10
	local v12 = v_u_5:GetAttribute(v_u_4.Attribute)
	if type(v12) ~= "number" then
		v12 = nil
	end
	if v_u_7 or not v12 then
		return
	elseif v_u_11 then
		if v12 < v_u_8 then
			local v13 = v12 - v_u_8
			if v13 ~= 0 then
				v_u_8 = v12
				v_u_9:Fire(v_u_8, v13)
			end
		end
		v_u_10 = v_u_10 + 1
		local v_u_14 = v_u_10
		task.delay(v_u_4.SettleDelay, function()
			-- upvalues: (ref) v_u_5, (ref) v_u_4, (copy) v_u_14, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9
			local v15 = v_u_5:GetAttribute(v_u_4.Attribute)
			if type(v15) ~= "number" then
				v15 = nil
			end
			if v_u_14 == v_u_10 and (v15 and not v_u_7) then
				local v16 = v15 - v_u_8
				if v16 == 0 then
					return
				end
				v_u_8 = v15
				v_u_9:Fire(v_u_8, v16)
			end
		end)
		return
	else
		v_u_11 = true
		local v17 = v12 - v_u_8
		if v17 ~= 0 then
			v_u_8 = v12
			v_u_9:Fire(v_u_8, v17)
		end
	end
end
function v_u_6.Get() -- name: Get
	-- upvalues: (ref) v_u_8
	return v_u_8
end
function v_u_6.CanAfford(p19) -- name: CanAfford
	-- upvalues: (copy) v_u_7, (ref) v_u_8
	return p19 < 0 or v_u_7 or p19 <= v_u_8
end
function v_u_6.Spend(p20) -- name: Spend
	-- upvalues: (copy) v_u_6, (copy) v_u_7, (ref) v_u_8, (copy) v_u_9, (ref) v_u_10, (copy) v_u_4, (copy) v_u_5
	if not v_u_6.CanAfford(p20) then
		return false
	end
	if not v_u_7 then
		local v21 = v_u_8 - p20
		local v22 = v21 - v_u_8
		if v22 ~= 0 then
			v_u_8 = v21
			v_u_9:Fire(v_u_8, v22)
		end
		v_u_10 = v_u_10 + 1
		local v_u_23 = v_u_10
		task.delay(v_u_4.SettleDelay, function()
			-- upvalues: (ref) v_u_5, (ref) v_u_4, (copy) v_u_23, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9
			local v24 = v_u_5:GetAttribute(v_u_4.Attribute)
			if type(v24) ~= "number" then
				v24 = nil
			end
			if v_u_23 == v_u_10 and (v24 and not v_u_7) then
				local v25 = v24 - v_u_8
				if v25 == 0 then
					return
				end
				v_u_8 = v24
				v_u_9:Fire(v_u_8, v25)
			end
		end)
	end
	return true
end
function v_u_6.Add(p26) -- name: Add
	-- upvalues: (copy) v_u_7, (copy) v_u_5, (copy) v_u_4, (ref) v_u_8, (copy) v_u_9, (ref) v_u_10
	if p26 > 0 and not v_u_7 then
		local v27 = v_u_5:GetAttribute(v_u_4.Attribute)
		if type(v27) ~= "number" then
			v27 = nil
		end
		local v28 = v_u_8 + p26
		if v27 then
			local v29 = v_u_8
			local v30 = math.max(v27, v29)
			v28 = math.min(v28, v30)
		end
		local v31 = v28 - v_u_8
		if v31 ~= 0 then
			v_u_8 = v28
			v_u_9:Fire(v_u_8, v31)
		end
		v_u_10 = v_u_10 + 1
		local v_u_32 = v_u_10
		task.delay(v_u_4.SettleDelay, function()
			-- upvalues: (ref) v_u_5, (ref) v_u_4, (copy) v_u_32, (ref) v_u_10, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9
			local v33 = v_u_5:GetAttribute(v_u_4.Attribute)
			if type(v33) ~= "number" then
				v33 = nil
			end
			if v_u_32 == v_u_10 and (v33 and not v_u_7) then
				local v34 = v33 - v_u_8
				if v34 == 0 then
					return
				end
				v_u_8 = v33
				v_u_9:Fire(v_u_8, v34)
			end
		end)
	end
end
function v_u_6.Observe(p35) -- name: Observe
	-- upvalues: (ref) v_u_8, (copy) v_u_9
	task.spawn(p35, v_u_8, 0)
	return v_u_9.Event:Connect(p35)
end
local v_u_36 = {
	"",
	"k",
	"M",
	"B",
	"T"
}
function v_u_6.Format(p37) -- name: Format
	-- upvalues: (copy) v_u_4, (copy) v_u_36
	if p37 == (1 / 0) then
		return v_u_4.InfiniteText
	end
	local v38 = p37 + 1e-6
	local v39 = math.floor(v38)
	if v39 < 1000 then
		return tostring(v39)
	end
	local v40 = 1
	while v39 >= 1000 and v40 < #v_u_36 do
		v39 = v39 / 1000
		v40 = v40 + 1
	end
	local v41 = string.gsub
	local v42 = string.format
	local v43 = v39 * 10
	return v41(v42("%.1f", math.floor(v43) / 10), "%.0$", "") .. v_u_36[v40]
end
v_u_5:GetAttributeChangedSignal(v_u_4.Attribute):Connect(v18)
local v44 = v_u_5:GetAttribute(v_u_4.Attribute)
if type(v44) ~= "number" then
	v44 = nil
end
if not v_u_7 and v44 then
	if v_u_11 then
		if v44 < v_u_8 then
			local v45 = v44 - v_u_8
			if v45 ~= 0 then
				v_u_8 = v44
				v_u_9:Fire(v_u_8, v45)
			end
		end
		v_u_10 = v_u_10 + 1
		local v_u_46 = v_u_10
		task.delay(v_u_4.SettleDelay, function()
			-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_46, (ref) v_u_10, (copy) v_u_7, (ref) v_u_8, (copy) v_u_9
			local v47 = v_u_5:GetAttribute(v_u_4.Attribute)
			if type(v47) ~= "number" then
				v47 = nil
			end
			if v_u_46 == v_u_10 and (v47 and not v_u_7) then
				local v48 = v47 - v_u_8
				if v48 == 0 then
					return
				end
				v_u_8 = v47
				v_u_9:Fire(v_u_8, v48)
			end
		end)
	else
		v_u_11 = true
		local v49 = v44 - v_u_8
		if v49 ~= 0 then
			v_u_8 = v44
			v_u_9:Fire(v_u_8, v49)
		end
	end
end
return v_u_6
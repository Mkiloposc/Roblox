local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.EggRewards)
local v_u_3 = require(v1.Shared.PickaxeConfig)
local v_u_4 = require(v1.Shared.TrailsConfig)
local v_u_5 = require(v1.Shared.ZonesConfig)
local v_u_9 = {
	["DebugPrint"] = true,
	["TutorialSteps"] = {
		{
			["Name"] = "Equip Pickaxe",
			["DoneAtStage"] = "BreakEgg"
		},
		{
			["Name"] = "Break Egg",
			["DoneAtStage"] = "Hatching"
		},
		{
			["Name"] = "Get Animal",
			["DoneAtStage"] = "Escape"
		},
		{
			["Name"] = "Save Animal",
			["DoneAtStage"] = "GoToPen"
		},
		{
			["Name"] = "Put Animal In Pen",
			["DoneAtStage"] = "EarnCash"
		},
		{
			["Name"] = "Upgrade Base",
			["DoneAtStage"] = "UseTreadmill"
		},
		{
			["Name"] = "Use Treadmill",
			["DoneAtStage"] = "EarnPickaxeCash"
		},
		{
			["Name"] = "Buy Better Pickaxe",
			["DoneAtStage"] = "EquipNewPickaxe"
		},
		{
			["Name"] = "Break Better Egg",
			["DoneAtStage"] = "CollectStrongerAnimal"
		},
		{
			["Name"] = "Buy Trail",
			["DoneAtStage"] = "Done"
		}
	},
	["JoinStep"] = "Join the Game",
	["Funnels"] = {
		["Zones"] = {
			["Name"] = "Zones"
		},
		["Eggs"] = {
			["Name"] = "Eggs"
		},
		["Pickaxes"] = {
			["Name"] = "Pickaxes"
		},
		["Trails"] = {
			["Name"] = "Trails"
		}
	},
	["Events"] = {
		["EggBroken"] = "Egg Broken",
		["AnimalCollected"] = "Animal Collected",
		["TrailBought"] = "Trail Bought",
		["ShopOpened"] = "Shop Opened",
		["ShopItemBought"] = "Shop Item Bought",
		["ShopRobuxSpent"] = "Shop Robux Spent"
	},
	["ShopOpenedRemoteName"] = "AnalyticsShopOpened",
	["ZoneLabel"] = function(p6) -- name: ZoneLabel
		-- upvalues: (copy) v_u_5, (copy) v_u_2
		local v7 = v_u_5.IndexOf(p6)
		if v7 then
			local v8 = v_u_2.ZoneEggs[p6]
			if v8 then
				v8 = v8.Theme
			end
			if v8 then
				return ("Zone %* (%*)"):format(v7, v8)
			else
				return ("Zone %*"):format(v7)
			end
		else
			return nil
		end
	end
}
local v_u_26 = {
	["Zones"] = function() -- name: Zones
		-- upvalues: (copy) v_u_9, (copy) v_u_5, (copy) v_u_2
		local v10 = { v_u_9.JoinStep }
		for v11, v12 in v_u_5.Zones do
			local v13 = v12.Id
			local v14 = v_u_2.ZoneEggs[v13]
			if v14 then
				v14 = v14.Theme
			end
			local v15
			if v14 then
				v15 = ("Zone %* (%*)"):format(v11, v14)
			else
				v15 = ("Zone %*"):format(v11)
			end
			table.insert(v10, v15)
		end
		return v10
	end,
	["Eggs"] = function() -- name: Eggs
		-- upvalues: (copy) v_u_9, (copy) v_u_5, (copy) v_u_2
		local v16 = { v_u_9.JoinStep }
		for _, v17 in v_u_5.Zones do
			local v18 = v_u_2.ZoneEggs[v17.Id]
			if not v18 then
				continue
			end
			for _, v19 in v18.Eggs do
				table.insert(v16, v19)
			end
		end
		return v16
	end,
	["Pickaxes"] = function() -- name: Pickaxes
		-- upvalues: (copy) v_u_9, (copy) v_u_3
		local v20 = { v_u_9.JoinStep }
		for _, v21 in v_u_3.Tiers do
			local v22 = v21.Name
			table.insert(v20, v22)
		end
		return v20
	end,
	["Trails"] = function() -- name: Trails
		-- upvalues: (copy) v_u_9, (copy) v_u_4
		local v23 = { v_u_9.JoinStep }
		for _, v24 in v_u_4.Trails do
			local v25 = v24.Name
			table.insert(v23, v25)
		end
		return v23
	end
}
local v_u_27 = {}
function v_u_9.GetSteps(p28) -- name: GetSteps
	-- upvalues: (copy) v_u_27, (copy) v_u_26
	local v29 = v_u_27[p28]
	if not v29 then
		local v30 = v_u_26[p28]
		v29 = not v30 and {} or v30()
		v_u_27[p28] = v29
	end
	return v29
end
function v_u_9.FindStep(p31, p32) -- name: FindStep
	-- upvalues: (copy) v_u_9
	if p32 then
		return table.find(v_u_9.GetSteps(p31), p32)
	else
		return nil
	end
end
return v_u_9
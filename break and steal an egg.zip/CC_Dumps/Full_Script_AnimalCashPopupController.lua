local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = require(v3.Shared.AnimalCashPopup)
local v_u_6 = require(v3.Shared.EggRewards)
local v_u_7 = require(v3.Shared.SafeZoneQuery)
local v_u_8 = require(script.Parent.Parent.Modules.LocalCharacter)
local v_u_9 = require(script.Parent.Parent.Modules.LocalModelHider)
local v10 = {}
local v_u_11 = Random.new()
local v_u_12 = v2.LocalPlayer
local v_u_13 = {}
local function v_u_23(p_u_14) -- name: track
	-- upvalues: (copy) v_u_13, (copy) v_u_12, (copy) v_u_11
	if p_u_14:IsA("Model") and not v_u_13[p_u_14] then
		local v_u_15 = {
			["Model"] = nil,
			["Hitbox"] = nil,
			["Own"] = nil,
			["Accum"] = 0,
			["NextAt"] = nil,
			["Cps"] = nil,
			["CpsConn"] = nil,
			["Scale"] = nil,
			["HeadHeight"] = nil,
			["SideReach"] = nil,
			["HeadAt"] = 0,
			["Model"] = p_u_14
		}
		local v16 = p_u_14.Parent
		local v17
		if v16 and v16.Name == "PlacedAnimals" then
			v17 = v16.Parent
			if v17 then
				v17 = v17:FindFirstChild("Hitbox")
			end
			if not (v17 and v17:IsA("BasePart")) then
				v17 = nil
			end
		else
			v17 = nil
		end
		v_u_15.Hitbox = v17
		local v18 = p_u_14:GetAttribute("OwnerUserId")
		local v19
		if typeof(v18) == "number" then
			v19 = v18 == v_u_12.UserId
		else
			v19 = nil
		end
		v_u_15.Own = v19
		v_u_15.NextAt = os.clock() + v_u_11:NextNumber(0, 1)
		local v20 = p_u_14:GetAttribute("CashPerSecond")
		if typeof(v20) ~= "number" then
			v20 = nil
		end
		v_u_15.Cps = v20
		v_u_15.CpsConn = p_u_14:GetAttributeChangedSignal("CashPerSecond"):Connect(function()
			-- upvalues: (copy) p_u_14, (copy) v_u_15
			local v21 = p_u_14:GetAttribute("CashPerSecond")
			local v22 = v_u_15
			if typeof(v21) ~= "number" then
				v21 = nil
			end
			v22.Cps = v21
		end)
		v_u_13[p_u_14] = v_u_15
	end
end
local function v_u_26(p24) -- name: untrack
	-- upvalues: (copy) v_u_13
	local v25 = p24:IsA("Model") and v_u_13[p24]
	if v25 then
		if v25.CpsConn then
			v25.CpsConn:Disconnect()
		end
		v_u_13[p24] = nil
	end
end
local function v_u_37(p27) -- name: popupScale
	-- upvalues: (copy) v_u_6
	local v28 = p27:GetAttribute("AnimalName")
	local v29 = p27:GetAttribute("WeightKg")
	local v30 = p27:GetAttribute("SizeMult")
	local v31 = p27:GetAttribute("SizeCap")
	local v32 = v_u_6.ScaleForWeight
	if typeof(v28) ~= "string" then
		v28 = nil
	end
	if typeof(v29) ~= "number" then
		v29 = nil
	end
	local v33 = typeof(v30) ~= "number" and 1 or v30
	local v34 = nil
	if typeof(v31) ~= "number" then
		v31 = nil
	end
	local v35 = v32(v28, v29, v33, v34, v31)
	local v36 = math.max(v35, 0)
	return math.sqrt(v36)
end
function v10.Start() -- name: Start
	-- upvalues: (copy) v_u_1, (copy) v_u_23, (copy) v_u_26, (copy) v_u_4, (copy) v_u_8, (copy) v_u_13, (copy) v_u_9, (copy) v_u_12, (copy) v_u_7, (copy) v_u_37, (copy) v_u_5
	for _, v38 in v_u_1:GetTagged("PlacedAnimal") do
		v_u_23(v38)
	end
	v_u_1:GetInstanceAddedSignal("PlacedAnimal"):Connect(v_u_23)
	v_u_1:GetInstanceRemovedSignal("PlacedAnimal"):Connect(v_u_26)
	local v_u_39 = {}
	local v_u_40 = 0
	local v_u_41 = 0
	v_u_4.Heartbeat:Connect(function(p42)
		-- upvalues: (ref) v_u_41, (ref) v_u_8, (copy) v_u_39, (ref) v_u_40, (ref) v_u_13, (ref) v_u_9, (ref) v_u_12, (ref) v_u_7, (ref) v_u_37, (ref) v_u_5
		v_u_41 = v_u_41 + p42
		if v_u_41 < 0.1 then
			return
		end
		local v43 = v_u_41
		v_u_41 = 0
		local v44 = v_u_8.GetPosition()
		table.clear(v_u_39)
		local v45 = os.clock()
		local v46 = v_u_40 / 10
		local v47 = math.max(1, v46)
		local v48 = 0
		for v49, v50 in v_u_13 do
			if v49.Parent then
				if v_u_9.IsHidden(v49) then
					v50.Accum = 0
					v50.NextAt = v45 + v47
				else
					local v51 = v50.Own
					if v51 == nil then
						local v52 = v49:GetAttribute("OwnerUserId")
						if typeof(v52) == "number" then
							v51 = v52 == v_u_12.UserId
						else
							v51 = nil
						end
						v50.Own = v51
					end
					if v51 == true then
						::l21::
						v48 = v48 + 1
						local v53 = v50.Cps
						if v53 == nil then
							local v54 = v49:GetAttribute("CashPerSecond")
							v53 = typeof(v54) ~= "number" and 0 or v54
						end
						v50.Accum = v50.Accum + v53 * v43
						if v45 < v50.NextAt then
							continue
						end
						v50.NextAt = v45 + v47
						if v50.Accum < 1 then
							continue
						end
						local v55 = v50.Accum
						v50.Accum = 0
						local v56 = v50.Scale
						if v56 == nil then
							v56 = v_u_37(v49)
							if typeof(v49:GetAttribute("AnimalName")) == "string" then
								v50.Scale = v56
							end
						end
						local v57 = v50.HeadHeight
						if v57 == nil or v50.HeadAt <= v45 then
							v57 = v_u_5.HeadHeight(v49)
							v50.HeadHeight = v57
							v50.SideReach = v_u_5.SideReach(v49)
							v50.HeadAt = v45 + 3
						end
						v_u_5.Play(v49, v55, {
							["SizeMult"] = v56,
							["HeadHeight"] = v57,
							["SideReach"] = v50.SideReach
						})
					else
						local v58 = v50.Hitbox
						if not (v58 and v58.Parent) then
							local v59 = v49.Parent
							if v59 and v59.Name == "PlacedAnimals" then
								v58 = v59.Parent
								if v58 then
									v58 = v58:FindFirstChild("Hitbox")
								end
								if not (v58 and v58:IsA("BasePart")) then
									v58 = nil
								end
							else
								v58 = nil
							end
							v50.Hitbox = v58
						end
						if not v58 then
							continue
						end
						local v60 = v_u_39[v58]
						if v60 == nil then
							if v44 == nil then
								v60 = false
							else
								v60 = v_u_7.IsPositionInPart(v58, v44)
							end
							v_u_39[v58] = v60
						end
						if v60 then
							goto l21
						end
						v50.Accum = 0
						v50.NextAt = v45 + v47
					end
				end
			else
				if not v49:IsA("Model") then
					continue
				end
				local v61 = v_u_13[v49]
				if not v61 then
					continue
				end
				if v61.CpsConn then
					v61.CpsConn:Disconnect()
				end
				v_u_13[v49] = nil
			end
		end
		v_u_40 = v48
	end)
end
return v10
local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = require(v1.Shared.DiamondsConfig)
local v_u_4 = require(script.Parent.Diamonds)
local v_u_5 = require(script.Parent.GuiFade)
local v_u_6 = require(script.Parent.Gui)
local v7 = v_u_3.CountTween
local v_u_8 = TweenInfo.new(v7.Duration, v7.Style, v7.Direction)
local v9 = v_u_3.PopInTween
local v_u_10 = TweenInfo.new(v9.Duration, v9.Style, v9.Direction)
local v11 = v_u_3.PopOutTween
local v_u_12 = TweenInfo.new(v11.Duration, v11.Style, v11.Direction)
local v13 = v_u_3.GainTween
local v_u_14 = TweenInfo.new(v13.Duration, v13.Style, v13.Direction)
local v15 = {}
local v_u_16 = nil
local v_u_17 = Instance.new("NumberValue")
local v_u_18 = nil
local function v_u_20() -- name: render
	-- upvalues: (ref) v_u_16, (copy) v_u_4, (copy) v_u_17
	local v19 = v_u_16
	if v19 and v19.amount.Parent then
		v19.amount.Text = v_u_4.Format(v_u_17.Value)
	end
end
local function v_u_25(p21) -- name: pop
	-- upvalues: (copy) v_u_2, (copy) v_u_10, (copy) v_u_3, (copy) v_u_12
	for _, v_u_22 in p21.pops do
		local v23 = v_u_2:Create(v_u_22, v_u_10, {
			["Scale"] = v_u_3.PopScale
		})
		v23.Completed:Once(function(p24)
			-- upvalues: (ref) v_u_2, (copy) v_u_22, (ref) v_u_12
			if p24 == Enum.PlaybackState.Completed then
				v_u_2:Create(v_u_22, v_u_12, {
					["Scale"] = 1
				}):Play()
			end
		end)
		v23:Play()
	end
end
local function v_u_37(p_u_26, p27) -- name: floatGain
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_5, (copy) v_u_2, (copy) v_u_14
	local v_u_28 = p_u_26.gain
	if v_u_28 ~= nil then
		for _, v29 in p_u_26.gainTweens do
			v29:Cancel()
		end
		table.clear(p_u_26.gainTweens)
		v_u_28.Text = (p27 > 0 and "+" or "-") .. v_u_4.Format((math.abs(p27)))
		local v30
		if p27 > 0 then
			v30 = v_u_3.EarnColor
		else
			v30 = v_u_3.SpendColor
		end
		v_u_28.TextColor3 = v30
		if p_u_26.gainGradient then
			p_u_26.gainGradient.Enabled = false
		end
		v_u_28.Position = p_u_26.gainBase
		v_u_5.Set(p_u_26.gainSnap, 0)
		v_u_28.Visible = true
		local v31 = UDim2.fromScale(0, -v_u_3.GainRise * v_u_28.Size.Y.Scale)
		local v32 = v_u_2:Create(v_u_28, v_u_14, {
			["Position"] = p_u_26.gainBase + v31
		})
		local v33 = p_u_26.gainTweens
		table.insert(v33, v32)
		for _, v34 in v_u_5.Tween(p_u_26.gainSnap, v_u_14, 1) do
			local v35 = p_u_26.gainTweens
			table.insert(v35, v34)
		end
		v32.Completed:Once(function(p36)
			-- upvalues: (copy) v_u_28, (copy) p_u_26
			if p36 == Enum.PlaybackState.Completed then
				v_u_28.Visible = false
				v_u_28.Position = p_u_26.gainBase
			end
		end)
		v32:Play()
	end
end
local function v_u_43(p38, p39) -- name: onChanged
	-- upvalues: (ref) v_u_18, (ref) v_u_16, (copy) v_u_17, (copy) v_u_4, (copy) v_u_2, (copy) v_u_8, (copy) v_u_25, (copy) v_u_3, (copy) v_u_37
	if v_u_18 then
		v_u_18:Cancel()
		v_u_18 = nil
	end
	local v40 = v_u_16
	if p39 == 0 or v40 == nil then
		v_u_17.Value = p38
		local v41 = v_u_16
		if v41 and v41.amount.Parent then
			v41.amount.Text = v_u_4.Format(v_u_17.Value)
		end
	else
		local v42 = v_u_2:Create(v_u_17, v_u_8, {
			["Value"] = p38
		})
		v_u_18 = v42
		v42:Play()
		v_u_25(v40)
		if p39 < 0 or v_u_3.ShowEarnGain then
			v_u_37(v40, p39)
		end
	end
end
local function v_u_58(p44) -- name: adopt
	-- upvalues: (ref) v_u_16, (copy) v_u_3, (copy) v_u_5, (ref) v_u_18, (copy) v_u_17, (copy) v_u_4
	v_u_16 = nil
	for _, v45 in v_u_3.DisplayPath do
		if p44 == nil then
			p44 = nil
			break
		end
		p44 = p44:FindFirstChild(v45)
	end
	local v46 = p44
	for _, v47 in v_u_3.AmountPath do
		if p44 == nil then
			p44 = nil
			break
		end
		p44 = p44:FindFirstChild(v47)
	end
	if not (v46 and (v46:IsA("GuiObject") and (p44 and p44:IsA("TextLabel")))) then
		warn((("[DiamondShop.DiamondsHud] DiamondShop.%*.%* not found"):format(table.concat(v_u_3.DisplayPath, "."), (table.concat(v_u_3.AmountPath, ".")))))
		return
	end
	local v48 = v46
	local v49 = {}
	for _, v50 in v_u_3.PopPath do
		if v46 == nil then
			v46 = nil
			break
		end
		v46 = v46:FindFirstChild(v50)
	end
	if v46 and v46:IsA("GuiObject") then
		local v51 = v46:FindFirstChild("DiamondsPop")
		if not (v51 and v51:IsA("UIScale")) then
			v51 = Instance.new("UIScale")
			v51.Name = "DiamondsPop"
			v51.Parent = v46
		end
		table.insert(v49, v51)
	end
	local v52 = p44:Clone()
	v52.Name = "DiamondsGain"
	v52.AutomaticSize = Enum.AutomaticSize.None
	v52.AnchorPoint = Vector2.new(0.5, 0.5)
	v52.Size = v_u_3.GainSize
	v52.Position = v_u_3.GainStart
	v52.Visible = false
	for _, v53 in v52:GetChildren() do
		if not v53:IsA("UIScale") then
			continue
		end
		v53:Destroy()
	end
	v52.Parent = v48
	local v54 = {
		["amount"] = p44,
		["pops"] = v49,
		["gain"] = v52
	}
	local v55
	if v52 then
		v55 = v52:FindFirstChildOfClass("UIGradient")
	else
		v55 = v52
	end
	v54.gainGradient = v55
	local v56
	if v52 then
		v56 = v52.Position
	else
		v56 = UDim2.new()
	end
	v54.gainBase = v56
	v54.gainSnap = not v52 and {} or v_u_5.Capture(v52)
	v54.gainTweens = {}
	v_u_16 = v54
	if v_u_18 then
		v_u_18:Cancel()
		v_u_18 = nil
	end
	v_u_17.Value = v_u_4.Get()
	local v57 = v_u_16
	if v57 and v57.amount.Parent then
		v57.amount.Text = v_u_4.Format(v_u_17.Value)
	end
end
function v15.Start() -- name: Start
	-- upvalues: (copy) v_u_17, (copy) v_u_4, (copy) v_u_20, (copy) v_u_6, (copy) v_u_58, (copy) v_u_43
	v_u_17.Value = v_u_4.Get()
	v_u_17.Changed:Connect(v_u_20)
	v_u_6.Observe(v_u_58)
	v_u_4.Observe(v_u_43)
end
return v15
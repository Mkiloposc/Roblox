local v_u_1 = game:GetService("Debris")
local v_u_2 = game:GetService("SoundService")
local v_u_3 = {}
local v_u_4 = {}
function v_u_3.Play(p5, p6, p7, p8) -- name: Play
	-- upvalues: (copy) v_u_4, (copy) v_u_2, (copy) v_u_1
	local v9 = p8 or "rransCustomSFX"
	local v10 = v_u_4[v9]
	if not (v10 and v10.Parent) then
		v10 = v_u_2:FindFirstChild(v9)
		v_u_4[v9] = v10
	end
	if v10 then
		v10 = v10:FindFirstChild(p5)
	end
	if v10 and v10:IsA("Sound") then
		local v_u_11 = v10:Clone()
		if p6 then
			v_u_11.Volume = p6
		end
		if p7 then
			v_u_11.PlaybackSpeed = p7
		end
		v_u_11.Parent = v_u_2
		v_u_11.Ended:Once(function()
			-- upvalues: (copy) v_u_11
			v_u_11:Destroy()
		end)
		local v12 = v_u_1
		local v13 = v_u_11.TimeLength / v_u_11.PlaybackSpeed
		v12:AddItem(v_u_11, math.max(v13, 1) + 1)
		v_u_11:Play()
	end
end
function v_u_3.PlayCue(p14) -- name: PlayCue
	-- upvalues: (copy) v_u_3
	for _, v15 in p14 do
		v_u_3.Play(v15.Name, v15.Volume, v15.Speed, v15.Folder)
	end
end
return v_u_3
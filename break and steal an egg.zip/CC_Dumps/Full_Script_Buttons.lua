local v_u_1 = {}
local v_u_2 = nil
local v_u_3 = nil
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = true
local v_u_11 = {}
function v_u_1.wire(p_u_12) -- name: wire
	-- upvalues: (copy) v_u_11, (ref) v_u_2, (ref) v_u_8, (ref) v_u_9, (ref) v_u_5, (ref) v_u_3, (ref) v_u_6, (ref) v_u_7, (ref) v_u_10, (ref) v_u_4
	if not v_u_11[p_u_12] then
		local v_u_13 = false
		local function v_u_19(p14, p15, p16, p17) -- name: juice
			-- upvalues: (ref) v_u_2, (ref) v_u_8, (copy) p_u_12, (ref) v_u_9, (ref) v_u_5, (ref) v_u_3, (ref) v_u_6, (ref) v_u_7
			if v_u_2.running then
				local v18 = v_u_8(p_u_12)
				if not v18.session then
					v_u_9(v18)
					v18.session = true
				end
				if not v18.hs then
					v18.hs = v_u_5.new(1, v_u_3.HOVER[1], v_u_3.HOVER[2])
					v18.hr = v_u_5.new(0, v_u_3.HOVER[1], v_u_3.HOVER[2])
				end
				v_u_6(v18.hs, p14, p15[1], p15[2])
				if p16 then
					v_u_6(v18.hr, p16, p15[1], p15[2])
				end
				if p17 then
					v_u_7(v18.hs, p17)
				end
				v18.live = true
			end
		end
		local v20 = {}
		if v_u_10 then
			local v21 = p_u_12.MouseEnter
			local function v22()
				-- upvalues: (ref) v_u_13, (ref) v_u_2, (copy) v_u_19, (ref) v_u_3, (ref) v_u_4
				v_u_13 = true
				if v_u_2.SFX then
					v_u_2.SFX.play("hover")
				end
				v_u_19(v_u_3.HOVER_SCALE, v_u_3.HOVER, v_u_4:NextNumber(-v_u_3.HOVER_TILT, v_u_3.HOVER_TILT))
			end
			table.insert(v20, v21:Connect(v22))
			local v23 = p_u_12.MouseLeave
			local function v24()
				-- upvalues: (ref) v_u_13, (copy) v_u_19, (ref) v_u_3
				v_u_13 = false
				v_u_19(1, v_u_3.HOVER, 0)
			end
			table.insert(v20, v23:Connect(v24))
		end
		local v25 = p_u_12.InputBegan
		local function v31(p26)
			-- upvalues: (ref) v_u_2, (ref) v_u_3, (copy) p_u_12, (ref) v_u_8, (ref) v_u_9, (ref) v_u_5, (ref) v_u_6
			local v27 = p26.UserInputType
			if v27 == Enum.UserInputType.MouseButton1 or v27 == Enum.UserInputType.Touch then
				if v_u_2.SFX then
					v_u_2.SFX.play(v_u_3.BUTTON_SFX[p_u_12.Name] or "click")
				end
				local v28 = v_u_3.PRESS_SCALE
				local v29 = v_u_3.PRESS
				if not v_u_2.running then
					return
				end
				local v30 = v_u_8(p_u_12)
				if not v30.session then
					v_u_9(v30)
					v30.session = true
				end
				if not v30.hs then
					v30.hs = v_u_5.new(1, v_u_3.HOVER[1], v_u_3.HOVER[2])
					v30.hr = v_u_5.new(0, v_u_3.HOVER[1], v_u_3.HOVER[2])
				end
				v_u_6(v30.hs, v28, v29[1], v29[2])
				v30.live = true
			end
		end
		table.insert(v20, v25:Connect(v31))
		local v32 = p_u_12.InputEnded
		local function v35(p33)
			-- upvalues: (copy) v_u_19, (ref) v_u_13, (ref) v_u_3
			local v34 = p33.UserInputType
			if v34 == Enum.UserInputType.MouseButton1 or v34 == Enum.UserInputType.Touch then
				v_u_19(v_u_13 and v_u_3.HOVER_SCALE or 1, v_u_3.RELEASE, 0, v_u_3.RELEASE_KICK)
			end
		end
		table.insert(v20, v32:Connect(v35))
		v_u_11[p_u_12] = v20
	end
end
function v_u_1.unwire(p36) -- name: unwire
	-- upvalues: (copy) v_u_11
	local v37 = v_u_11[p36]
	if v37 then
		for _, v38 in ipairs(v37) do
			v38:Disconnect()
		end
		v_u_11[p36] = nil
	end
end
function v_u_1.unwireAll() -- name: unwireAll
	-- upvalues: (copy) v_u_11, (copy) v_u_1
	for v39 in pairs(v_u_11) do
		v_u_1.unwire(v39)
	end
end
function v_u_1.init(p40) -- name: init
	-- upvalues: (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (copy) v_u_1
	v_u_2 = p40
	local v41 = v_u_2.T
	local v42 = v_u_2.rng
	local v43 = v_u_2.Spring
	v_u_3 = v41
	v_u_4 = v42
	v_u_5 = v43
	local v44 = v_u_5.to
	local v45 = v_u_5.kick
	v_u_6 = v44
	v_u_7 = v45
	local v46 = v_u_2.Actors.makeActor
	local v47 = v_u_2.Actors.refresh
	v_u_8 = v46
	v_u_9 = v47
	v_u_10 = not v_u_2.touchOnly
	for _, v48 in ipairs(v_u_2.main:GetDescendants()) do
		if not v48:IsA("GuiButton") then
			continue
		end
		v_u_1.wire(v48)
	end
end
return v_u_1
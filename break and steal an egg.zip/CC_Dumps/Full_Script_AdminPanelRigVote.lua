local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.AdminConchTypes)
local v_u_3 = require(v1.Shared.AdminConfig)
local v_u_4 = require(v1.Shared.PollConfig)
local v_u_5 = require(script.Parent.UnitTextBox)
local v6 = {}
local v_u_7 = { "Random", "Red", "Blue" }
local v_u_8 = ""
local v_u_9 = ""
local v_u_10 = 1
local v_u_11 = nil
local v_u_12 = nil
function v6.Bind(p13) -- name: Bind
	-- upvalues: (ref) v_u_11, (ref) v_u_12, (copy) v_u_3, (copy) v_u_5, (ref) v_u_8, (ref) v_u_9, (copy) v_u_7, (ref) v_u_10
	local v14 = p13:FindFirstChild("List")
	local v15
	if v14 then
		v15 = v14:FindFirstChild("Duration")
	else
		v15 = nil
	end
	local v16
	if v15 then
		v16 = v15:FindFirstChild("CCU")
	else
		v16 = nil
	end
	local v17
	if v16 then
		v17 = v16:FindFirstChild("TextBox")
	else
		v17 = nil
	end
	if v17 and v17:IsA("TextBox") then
		v17.ClearTextOnFocus = false
	else
		v17 = nil
	end
	v_u_11 = v17
	local v18
	if v15 then
		v18 = v15:FindFirstChild("Percent")
	else
		v18 = nil
	end
	local v19
	if v18 then
		v19 = v18:FindFirstChild("TextBox")
	else
		v19 = nil
	end
	if v19 and v19:IsA("TextBox") then
		v19.ClearTextOnFocus = false
	else
		v19 = nil
	end
	v_u_12 = v19
	local v_u_20
	if v15 then
		v_u_20 = v15:FindFirstChild("Winner")
	else
		v_u_20 = nil
	end
	if v_u_11 and (v_u_12 and (v_u_20 and v_u_20:IsA("GuiButton"))) then
		v_u_20:SetAttribute("HoverScale", v_u_3.PanelHoverScale)
		v_u_20:SetAttribute("PressScale", v_u_3.PanelPressScale)
		v_u_5.Bind(v_u_12, "%")
		local v_u_21 = v_u_11
		local v_u_22 = v_u_12
		v_u_21.Text = v_u_8
		v_u_22.Text = v_u_9
		v_u_21:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (ref) v_u_8, (copy) v_u_21
			v_u_8 = v_u_21.Text
		end)
		v_u_22:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (ref) v_u_9, (copy) v_u_22
			v_u_9 = v_u_22.Text
		end)
		local v_u_23 = v_u_20:FindFirstChild("Title")
		local v_u_24 = {
			["Random"] = v_u_20.BackgroundColor3
		}
		local v25
		if v14 then
			v25 = v14:FindFirstChild("Answer_1")
		else
			v25 = nil
		end
		local v26
		if v25 then
			v26 = v25:FindFirstChild("Text")
		else
			v26 = nil
		end
		local v27
		if v26 and v26:IsA("GuiObject") then
			v27 = v26.BackgroundColor3
		else
			v27 = nil
		end
		v_u_24.Red = v27 or Color3.fromRGB(200, 0, 0)
		local v28
		if v14 then
			v28 = v14:FindFirstChild("Answer_2")
		else
			v28 = nil
		end
		local v29
		if v28 then
			v29 = v28:FindFirstChild("Text")
		else
			v29 = nil
		end
		local v30
		if v29 and v29:IsA("GuiObject") then
			v30 = v29.BackgroundColor3
		else
			v30 = nil
		end
		v_u_24.Blue = v30 or Color3.fromRGB(0, 60, 200)
		local v31 = v_u_7[v_u_10]
		if v_u_23 and v_u_23:IsA("TextLabel") then
			v_u_23.Text = v31
		end
		v_u_20.BackgroundColor3 = v_u_24[v31]
		v_u_20.Activated:Connect(function()
			-- upvalues: (ref) v_u_10, (ref) v_u_7, (copy) v_u_23, (copy) v_u_20, (copy) v_u_24
			v_u_10 = v_u_10 % #v_u_7 + 1
			local v32 = v_u_7[v_u_10]
			if v_u_23 and v_u_23:IsA("TextLabel") then
				v_u_23.Text = v32
			end
			v_u_20.BackgroundColor3 = v_u_24[v32]
		end)
	else
		warn("[AdminPanelRigVote] Create a Poll needs List.Duration.CCU / Percent (TextBox) + Winner (button)")
	end
end
function v6.Get() -- name: Get
	-- upvalues: (ref) v_u_11, (ref) v_u_12, (copy) v_u_7, (ref) v_u_10, (copy) v_u_2, (copy) v_u_5, (copy) v_u_4
	local v33
	if v_u_11 then
		local v34 = v_u_11.Text
		v33 = string.gsub(string.gsub(v34, "^%s+", ""), "%s+$", "")
	else
		v33 = ""
	end
	local v35
	if v_u_12 then
		local v36 = v_u_12.Text
		v35 = string.gsub(string.gsub(v36, "^%s+", ""), "%s+$", "") ~= ""
	else
		v35 = false
	end
	if v33 == "" then
		if v35 or v_u_7[v_u_10] ~= "Random" then
			return nil, "type the CCU (e.g. 420K) to rig it, or clear Winner % and set Winner to Random"
		else
			return nil, nil
		end
	else
		local v37 = v_u_2.ParseNumber(v33)
		if not v37 or v37 < 1 then
			return nil, "type the CCU like 420K, 1.2M or 85000"
		end
		local v38
		if v_u_12 then
			local v39 = v_u_12.Text
			v38 = string.gsub(string.gsub(v39, "^%s+", ""), "%s+$", "")
		else
			v38 = ""
		end
		if v38 ~= "" then
			local v40 = v_u_5.Number(v38, "%")
			if not v40 or (v40 < v_u_4.Rig.MinShare or v_u_4.Rig.MaxShare < v40) then
				return nil, ("winner %% must be %*-%*"):format(v_u_4.Rig.MinShare, v_u_4.Rig.MaxShare)
			end
		end
		local v41 = v_u_7[v_u_10]
		return {
			["CCU"] = v33,
			["Winner"] = v41 == "Random" and "" or string.lower(v41),
			["Share"] = v38
		}, nil
	end
end
return v6
local v_u_1 = game:GetService("CollectionService")
local v_u_2 = {
	["Tag"] = "BreakableEgg",
	["DoorTag"] = "BreakableHalloweenDoor",
	["CandyPileTag"] = "BreakableCandyPile",
	["ReachBelowAttribute"] = "ReachBelow"
}
local v_u_3 = nil
local function v_u_10() -- name: tagSet
	-- upvalues: (ref) v_u_3, (copy) v_u_2, (copy) v_u_1
	local v4 = v_u_3
	if v4 then
		return v4
	end
	local v_u_5 = {}
	v_u_3 = v_u_5
	for _, v6 in { v_u_2.Tag, v_u_2.DoorTag, v_u_2.CandyPileTag } do
		for _, v7 in v_u_1:GetTagged(v6) do
			if not v7:IsA("BasePart") then
				continue
			end
			v_u_5[v7] = true
		end
		v_u_1:GetInstanceAddedSignal(v6):Connect(function(p8)
			-- upvalues: (ref) v_u_5
			if p8:IsA("BasePart") then
				v_u_5[p8] = true
			end
		end)
		v_u_1:GetInstanceRemovedSignal(v6):Connect(function(p9)
			-- upvalues: (ref) v_u_5
			v_u_5[p9] = nil
		end)
	end
	return v_u_5
end
function v_u_2.IsLive(p11) -- name: IsLive
	local v12 = p11 ~= nil and p11.Parent ~= nil and not (p11:GetAttribute("Broken") or p11:GetAttribute("Hatching"))
	if v12 then
		v12 = not p11:GetAttribute("Despawning")
	end
	return v12
end
function v_u_2.SurfaceDistance(p13, p14) -- name: SurfaceDistance
	-- upvalues: (copy) v_u_2
	local v15 = p13.Size
	if p13:GetAttribute("TargetShape") == "Box" then
		local v16 = p13.CFrame:PointToObjectSpace(p14)
		local v17 = v15 * 0.5
		local v18 = v16.X
		local v19 = math.abs(v18) - v17.X
		local v20 = math.max(v19, 0)
		local v21 = v16.Y
		local v22 = math.abs(v21) - v17.Y
		local v23 = math.max(v22, 0)
		local v24 = v16.Z
		local v25 = math.abs(v24) - v17.Z
		local v26 = math.max(v25, 0)
		return Vector3.new(v20, v23, v26).Magnitude
	end
	local v27 = v15.X
	local v28 = v15.Z
	local v29 = math.max(v27, v28) / 2
	local v30 = p14 - p13.Position
	local v31 = v30.X
	local v32 = v30.Z
	local v33 = Vector3.new(v31, 0, v32).Magnitude - v29
	local v34 = math.max(v33, 0)
	local v35 = v15.Y / 2
	local v36 = v30.Y
	local v37 = math.abs(v36) - v35
	local v38 = math.max(v37, 0)
	if v38 > 0 and v30.Y < 0 then
		local v39 = p13:GetAttribute(v_u_2.ReachBelowAttribute)
		if type(v39) == "number" and v39 > 0 then
			local v40 = -v30.Y - v35 - v39
			v38 = math.max(v40, 0)
		end
	end
	local v41 = v34 * v34 + v38 * v38
	return math.sqrt(v41)
end
function v_u_2.Nearest(p42, p43) -- name: Nearest
	-- upvalues: (copy) v_u_10, (copy) v_u_2
	local v44 = nil
	for v45 in v_u_10() do
		if v45.Parent == nil then
			continue
		end
		local v46 = v_u_2.SurfaceDistance(v45, p42)
		if v46 > p43 or (v45:GetAttribute("Broken") or (v45:GetAttribute("Hatching") or v45:GetAttribute("Despawning"))) then
			continue
		end
		v44 = v45
		p43 = v46
	end
	return v44
end
function v_u_2.Pick(p47, p48, p49, p50) -- name: Pick
	-- upvalues: (copy) v_u_10, (copy) v_u_2
	if p49 and (v_u_10()[p49] and (v_u_2.IsLive(p49) and v_u_2.SurfaceDistance(p49, p47) <= (p50 or p48))) then
		return p49
	else
		return v_u_2.Nearest(p47, p48)
	end
end
return v_u_2
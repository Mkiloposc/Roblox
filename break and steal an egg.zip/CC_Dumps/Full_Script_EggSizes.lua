local v_u_1 = require(script.Parent.EggConfig)
local function v_u_37(p_u_2) -- name: buildCurve
	local v_u_3 = 1 - p_u_2.BigChance
	local v_u_4 = p_u_2.TailExponent or 1
	local v_u_5 = (1 / (p_u_2.MaxOneIn * p_u_2.BigChance)) ^ (1 / (p_u_2.MaxMult - 1) ^ v_u_4)
	local v_u_6 = p_u_2.MinMult < 1
	local v_u_7
	if v_u_6 then
		local v8 = 1 / (p_u_2.MinOneIn * v_u_3)
		local v9 = math.log(v8)
		local v10 = p_u_2.MinMult
		v_u_7 = v9 / math.log(v10)
	else
		v_u_7 = 0
	end
	local v11 = v_u_5 < 1
	assert(v11, "[EggSizes] MaxOneIn * BigChance must be > 1 so bigger rolls are rarer")
	local v12 = not v_u_6 or v_u_7 > 0
	assert(v12, "[EggSizes] MinOneIn * (1 - BigChance) must be > 1 so smaller rolls are rarer")
	local v_u_13 = 10 ^ p_u_2.Decimals
	local v_u_36 = {
		["ChanceAtLeast"] = function(p14, p15) -- name: ChanceAtLeast
			-- upvalues: (copy) v_u_36, (copy) p_u_2, (copy) v_u_5, (copy) v_u_4
			if p14 < 1 then
				return 1 - v_u_36.ChanceAtMost(p14, p15)
			end
			local v16 = p_u_2.BigChance
			local v17 = v_u_5
			local v18 = p14 - 1
			local v19 = p_u_2.LuckBend
			return v16 * v17 ^ (v18 / ((not v19 or (not p15 or p15 <= 1)) and 1 or 1 + math.log(p15) * v19)) ^ v_u_4
		end,
		["ChanceAtMost"] = function(p20, p21) -- name: ChanceAtMost
			-- upvalues: (copy) v_u_36, (copy) v_u_6, (copy) p_u_2, (copy) v_u_3, (copy) v_u_7
			if p20 >= 1 then
				return 1 - v_u_36.ChanceAtLeast(p20, p21)
			else
				return (not v_u_6 or p20 < p_u_2.MinMult) and 0 or v_u_3 * p20 ^ v_u_7
			end
		end,
		["OneIn"] = function(p22, p23) -- name: OneIn
			-- upvalues: (copy) v_u_36
			local v24
			if p22 >= 1 then
				v24 = v_u_36.ChanceAtLeast(p22, p23)
			else
				v24 = v_u_36.ChanceAtMost(p22, p23)
			end
			if v24 <= 0 then
				return (1 / 0)
			end
			local v25 = 1 / v24 + 0.5
			local v26 = math.floor(v25)
			return math.max(v26, 1)
		end,
		["Roll"] = function(p27, p28) -- name: Roll
			-- upvalues: (copy) p_u_2, (copy) v_u_5, (copy) v_u_4, (copy) v_u_6, (copy) v_u_7, (copy) v_u_13
			local v29 = p27:NextNumber()
			local v30
			if p27:NextNumber() < p_u_2.BigChance then
				local v31 = p_u_2.LuckBend
				local v32 = v_u_5
				v30 = 1 + ((not v31 or (not p28 or p28 <= 1)) and 1 or 1 + math.log(p28) * v31) * (math.log(v29) / math.log(v32)) ^ (1 / v_u_4)
			elseif v_u_6 then
				local v33 = v29 ^ (1 / v_u_7)
				local v34 = p_u_2.MinMult
				v30 = math.max(v33, v34)
			else
				v30 = 1
			end
			local v35 = v30 * v_u_13 + 0.5
			return math.floor(v35) / v_u_13
		end
	}
	return v_u_36
end
local v_u_38 = {
	["Spawn"] = v_u_37(v_u_1.Size.Spawn),
	["Hatch"] = v_u_37(v_u_1.Size.Hatch)
}
local v_u_39 = {}
function v_u_38.ForZone(p40) -- name: ForZone
	-- upvalues: (copy) v_u_1, (copy) v_u_38, (copy) v_u_39, (copy) v_u_37
	local v41
	if p40 then
		v41 = (v_u_1.Size.ZoneCaps or {})[p40]
	else
		v41 = nil
	end
	if not v41 then
		return v_u_38
	end
	local v42 = v_u_39[p40]
	if not v42 then
		v42 = {}
		local v43 = v_u_37
		local v44 = v_u_1.Size.Spawn
		local v45 = v41.SpawnMax
		if v45 and v45 ~= v44.MaxMult then
			v44 = table.clone(v44)
			v44.MaxMult = v45
		end
		v42.Spawn = v43(v44)
		local v46 = v_u_37
		local v47 = v_u_1.Size.Hatch
		local v48 = v41.HatchMax
		if v48 and v48 ~= v47.MaxMult then
			v47 = table.clone(v47)
			v47.MaxMult = v48
		end
		v42.Hatch = v46(v47)
		v_u_39[p40] = v42
	end
	return v42
end
function v_u_38.AnimalWeightLuck(p49, p50) -- name: AnimalWeightLuck
	-- upvalues: (copy) v_u_1
	local v51 = v_u_1.Size.AnimalWeightLuck
	if not v51 or (not p49 or (not p50 or (p49 <= 0 or p50 <= 0))) then
		return 1
	end
	local v52 = (p49 / p50) ^ (v51.Exponent or 1)
	local v53 = v51.MaxLuck or (1 / 0)
	return math.clamp(v52, 1, v53)
end
function v_u_38.BracketForChance(p54, p55) -- name: BracketForChance
	-- upvalues: (copy) v_u_1
	for _, v56 in v_u_1.Size.Brackets do
		local v57
		if p55 then
			v57 = (v_u_1.Size.ZoneBracketMults or {})[p55]
		else
			v57 = nil
		end
		if v57 then
			v57 = v57[v56.Label]
		end
		local v58
		if v57 then
			v58 = v56.Chance * v57
		else
			v58 = v56.Chance
		end
		if p54 > v58 then
			continue
		end
		return v56.Label
	end
	return ""
end
function v_u_38.Bracket(p59, p60) -- name: Bracket
	-- upvalues: (copy) v_u_38
	return v_u_38.BracketForChance(v_u_38.ForZone(p60).Hatch.ChanceAtLeast(p59), p60)
end
function v_u_38.MinHatchForChance(p61, p62) -- name: MinHatchForChance
	-- upvalues: (copy) v_u_1
	for _, v63 in v_u_1.Size.Brackets do
		local v64
		if p62 then
			v64 = (v_u_1.Size.ZoneBracketMults or {})[p62]
		else
			v64 = nil
		end
		if v64 then
			v64 = v64[v63.Label]
		end
		local v65
		if v64 then
			v65 = v63.Chance * v64
		else
			v65 = v63.Chance
		end
		if p61 > v65 then
			continue
		end
		return v63.MinHatchMult or 1
	end
	return 1
end
return v_u_38
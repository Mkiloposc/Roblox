local v1 = script:FindFirstAncestor("Chrome")
local v2 = game:GetService("CorePackages")
if not require(v2.Workspace.Packages.Chrome).Enabled() then
	return nil
end
local v_u_3 = require(v1.Service)
local v_u_4 = require(v1.Integrations.Party.Constants)
local v_u_5 = require(v1.Integrations.Connect.isConnectUnibarEnabled)
local v_u_6 = require(v2.Workspace.Packages.SharedExperimentDefinition).isInExperienceUIVREnabled
local v7 = require(v1.ChromeShared.Shortcuts.ConfigureShortcuts)
local v_u_8 = require(v1.ChromeShared.Unibar.buildMenuOrder)
local v9 = require(v2.Workspace.Packages.SharedFlags)
local v_u_10 = v9.GetFFlagDebugEnableUnibarDummyIntegrations
local v11 = v9.FFlagEnableConsoleExpControls
local v_u_12 = v9.FFlagAppNavMyStatsTab
local v_u_13 = require(v2.Workspace.Packages.SocialExperiments).ArgoPartyExperimentation
local v_u_14 = require(v2.Workspace.Packages.AppCommonLib).isSpatial
local function v20() -- name: configureUnibar
	-- upvalues: (copy) v_u_8, (copy) v_u_10, (copy) v_u_5, (copy) v_u_13, (copy) v_u_4, (copy) v_u_12, (copy) v_u_6, (copy) v_u_14, (copy) v_u_3
	local v15 = v_u_8()
	local v16 = { "nine_dot", "chat", "toggle_mic_mute" }
	table.insert(v16, 3, "join_voice")
	if v_u_10() then
		table.insert(v16, "dummy_window")
		table.insert(v16, "dummy_window_2")
	end
	if v_u_5() then
		local v17 = v_u_13.getIsRenameEnabled() and "party_entrypoint" or "connect_unibar"
		table.insert(v16, v17)
	end
	local v18 = table.find(v16, "toggle_mic_mute")
	if v18 then
		local v19 = v_u_4.TOGGLE_MIC_INTEGRATION_ID
		table.insert(v16, v18, v19)
	end
	if v_u_12 then
		table.insert(v16, "assistant_build")
	end
	if v_u_6 and v_u_14() then
		v_u_3:configureMenu({
			{ "vr_toggle_button", "vr_safety_bubble" },
			v16
		})
	else
		v_u_3:configureMenu({ v16 })
	end
	v_u_3:configureSubMenu("nine_dot", v15)
end
require(v1.Integrations)
if v11 then
	v7()
end
v20()
return nil
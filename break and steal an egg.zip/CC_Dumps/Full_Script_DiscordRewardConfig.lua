local v_u_9 = {
	["Animal"] = "SABER_TOOTHED_TIGER",
	["RewardName"] = "Sabertooth Egg",
	["CardPath"] = nil,
	["TextBoxPath"] = nil,
	["VerifyButtonPath"] = nil,
	["VerifyTitleName"] = "Title",
	["VerifyText"] = "Verify",
	["ClaimedText"] = "Claimed!",
	["LockedTint"] = nil,
	["DeniedClaimedText"] = "Already claimed!",
	["DeniedEmptyText"] = "Type your Roblox @Username first!",
	["JoinAskText"] = "Join our Community server through the game page, then press Verify again!",
	["TryAgainText"] = "Try again in {seconds} seconds!",
	["SuccessText"] = "You got a {name}!",
	["JoinWaitSeconds"] = 30,
	["PressDebounce"] = 1,
	["ServerPressDebounce"] = 0.6,
	["AskDebounce"] = 2,
	["RemoteName"] = "DiscordRewardRemote",
	["CardPath"] = {
		"Frames",
		"Shop",
		"ScrollingFrame",
		"CommunityReward",
		"Inner"
	},
	["TextBoxPath"] = { "UserNameVerify", "TextBox" },
	["VerifyButtonPath"] = { "ButtonList", "Verify" },
	["LockedTint"] = Color3.fromRGB(140, 140, 140),
	["CleanName"] = function(p1) -- name: CleanName
		return string.gsub(string.gsub(p1, "%s", ""), "^@+", "")
	end,
	["TryAgain"] = function(p2) -- name: TryAgain
		-- upvalues: (copy) v_u_9
		local v3 = v_u_9.TryAgainText
		local v4 = math.ceil(p2)
		local v5 = math.max(v4, 1)
		return v3:gsub("{seconds}", (tostring(v5)))
	end,
	["InputDenial"] = function(p6, p7) -- name: InputDenial
		-- upvalues: (copy) v_u_9
		if p6.Claimed then
			return v_u_9.DeniedClaimedText
		elseif v_u_9.CleanName(p7) == "" then
			return v_u_9.DeniedEmptyText
		else
			return nil
		end
	end,
	["LadderDenial"] = function(p8) -- name: LadderDenial
		-- upvalues: (copy) v_u_9
		if p8.Asked then
			if p8.Wait > 0 then
				return v_u_9.TryAgain(p8.Wait)
			else
				return nil
			end
		else
			return v_u_9.JoinAskText
		end
	end
}
return v_u_9
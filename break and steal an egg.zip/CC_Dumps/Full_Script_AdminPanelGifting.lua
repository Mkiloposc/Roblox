local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = require(v_u_1.Shared.AdminConfig)
local v_u_4 = require(v_u_1.Shared.EggRarity)
local v_u_5 = require(v_u_1.Shared.EggRewards)
local v_u_6 = require(v_u_1.Shared.PotionConfig)
local v_u_7 = require(v_u_1.Shared.CountingNumber)
local v_u_8 = require(v_u_1.Shared.FormatNumber)
local v_u_9 = require(script.Parent.AdminEditDropdown)
local v_u_10 = require(script.Parent.RichWordTyper)
local v_u_11 = require(script.Parent.UnitTextBox)
local v_u_12 = require(script.Parent.AnimalTileStyle)
local v_u_13 = require(script.Parent.Parent.Controllers.NotificationController)
local v14 = {}
local v_u_15 = v_u_3.Gift
local v_u_16 = TweenInfo.new(0.3, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local function v_u_27(p17, p18) -- name: stripUnit
	local v19 = string.lower(p18)
	local v20 = string.gsub(string.gsub(p17, "^%s+", ""), "%s+$", "")
	local v21 = string.lower
	local v22 = -#p18
	if v21((string.sub(v20, v22))) == v19 then
		local v23 = #v20 - #p18
		v20 = string.sub(v20, 1, v23)
	end
	local v24 = string.lower
	local v25 = #p18
	if v24((string.sub(v20, 1, v25))) == v19 then
		local v26 = #p18 + 1
		v20 = string.sub(v20, v26)
	end
	return string.gsub(string.gsub(v20, "^%s+", ""), "%s+$", "")
end
local function v_u_33(p_u_28, p_u_29) -- name: unitBox
	-- upvalues: (copy) v_u_27
	if p_u_28 then
		p_u_28.Focused:Connect(function()
			-- upvalues: (copy) p_u_28, (ref) v_u_27, (copy) p_u_29
			p_u_28.Text = v_u_27(p_u_28.Text, p_u_29)
		end)
		p_u_28.FocusLost:Connect(function()
			-- upvalues: (ref) v_u_27, (copy) p_u_28, (copy) p_u_29
			local v30 = v_u_27(p_u_28.Text, p_u_29)
			local v31 = tonumber(v30) ~= nil and true or string.match(v30, "^%-?%d*%.?%d+%a%a?$") ~= nil
			local v32 = p_u_28
			if v30 ~= "" and v31 then
				v30 = v30 .. p_u_29
			end
			v32.Text = v30
		end)
	end
end
local function v_u_36(p34) -- name: pop
	-- upvalues: (copy) v_u_2, (copy) v_u_16
	local v35 = p34:FindFirstChild("GiftPopScale")
	if not (v35 and v35:IsA("UIScale")) then
		v35 = Instance.new("UIScale")
		v35.Name = "GiftPopScale"
		v35.Parent = p34
	end
	v35.Scale = 0.94
	v_u_2:Create(v35, v_u_16, {
		["Scale"] = 1
	}):Play()
end
local v_u_37 = {
	["k"] = 1000,
	["m"] = 1000000,
	["b"] = 1000000000,
	["t"] = 1000000000000
}
local v_u_38 = Color3.new(1, 1, 1)
local v_u_39 = Color3.new(0, 0, 0)
local function v_u_44(p40) -- name: potionColor
	-- upvalues: (copy) v_u_6
	if p40 == "all" then
		return Color3.fromHex(v_u_6.AllPotionsColor)
	end
	local v41 = v_u_6.ById(p40)
	local v42 = Color3.fromHex
	local v43
	if v41 then
		v43 = v41.Color
	else
		v43 = v_u_6.HoverMultiplierColor
	end
	return v42(v43)
end
local function v_u_62(p45, p46, p47) -- name: reshade
	-- upvalues: (copy) v_u_38, (copy) v_u_39
	local v48 = p45.Keypoints
	local v49 = 0
	for _, v50 in v48 do
		local v51 = v50.Value
		v49 = v49 + (0.299 * v51.R + 0.587 * v51.G + 0.114 * v51.B)
	end
	local v52 = v49 / #v48
	local v53 = table.create(#v48)
	for _, v54 in v48 do
		local v55 = v54.Value
		local v56 = (0.299 * v55.R + 0.587 * v55.G + 0.114 * v55.B - v52) * p47
		local v57
		if v56 >= 0 then
			v57 = p46:Lerp(v_u_38, (math.clamp(v56, 0, 0.6)))
		else
			local v58 = v_u_39
			local v59 = -v56
			v57 = p46:Lerp(v58, (math.clamp(v59, 0, 0.6)))
		end
		local v60 = ColorSequenceKeypoint.new
		local v61 = v54.Time
		table.insert(v53, v60(v61, v57))
	end
	return ColorSequence.new(v53)
end
local function v_u_71(p63, p64) -- name: copyStyle
	p64.BackgroundColor3 = p63.BackgroundColor3
	for _, v65 in p63:GetChildren() do
		local v66 = p64:FindFirstChild(v65.Name)
		if v65:IsA("UIGradient") and (v66 and v66:IsA("UIGradient")) then
			v66.Color = v65.Color
		else
			if not (v65:IsA("UIStroke") and (v66 and v66:IsA("UIStroke"))) then
				continue
			end
			v66.Color = v65.Color
			local v67 = v65:FindFirstChildWhichIsA("UIGradient")
			local v68 = v66:FindFirstChildWhichIsA("UIGradient")
			if not (v67 and v68) then
				continue
			end
			v68.Color = v67.Color
		end
	end
	local v69 = p63:FindFirstChild("Title")
	local v70 = p64:FindFirstChild("Title")
	if v69 then
		v69 = v69:FindFirstChildWhichIsA("UIStroke")
	end
	if v70 then
		v70 = v70:FindFirstChildWhichIsA("UIStroke")
	end
	if v69 and v70 then
		v70.Color = v69.Color
	end
end
local function v_u_79(p72, p73) -- name: paintButton
	-- upvalues: (copy) v_u_38, (copy) v_u_62, (copy) v_u_39
	p72.BackgroundColor3 = v_u_38
	for _, v74 in p72:GetChildren() do
		if v74:IsA("UIGradient") then
			v74.Color = v_u_62(v74.Color, p73, 1.6)
		else
			if not v74:IsA("UIStroke") then
				continue
			end
			local v75
			if v74.Name == "Inner" then
				v75 = p73:Lerp(v_u_38, 0.45)
			else
				v75 = p73:Lerp(v_u_39, 0.6)
			end
			v74.Color = v75
			local v76 = v74:FindFirstChildWhichIsA("UIGradient")
			if not v76 then
				continue
			end
			v76.Color = v_u_62(v76.Color, v75, 1.2)
		end
	end
	local v77 = p72:FindFirstChild("Title")
	if v77 and v77:IsA("TextLabel") then
		v77.RichText = true
		local v78 = v77:FindFirstChildWhichIsA("UIStroke")
		if v78 then
			v78.Color = p73:Lerp(v_u_39, 0.7)
		end
	end
end
function v14.Bind(p_u_80, p81, p_u_82) -- name: Bind
	-- upvalues: (copy) v_u_15, (copy) v_u_71, (copy) v_u_3, (copy) v_u_36, (copy) v_u_9, (copy) v_u_6, (copy) v_u_79, (copy) v_u_44, (copy) v_u_38, (copy) v_u_12, (copy) v_u_5, (copy) v_u_4, (copy) v_u_1, (copy) v_u_13, (copy) v_u_11, (copy) v_u_33, (copy) v_u_7, (copy) v_u_8, (copy) v_u_27, (copy) v_u_37, (copy) v_u_10
	local v83 = {
		["Dropdowns"] = {},
		["Reset"] = function() -- name: Reset end
	}
	local function v_u_95(p84) -- name: styleSource
		-- upvalues: (ref) v_u_15, (copy) p_u_82
		local v85 = v_u_15.StyleSources[p84]
		if v85 then
			local v86 = p_u_82
			local v87
			if v86 then
				v87 = v86:FindFirstChild("CommandsList")
			else
				v87 = nil
			end
			local v88 = v85[1]
			local v89
			if v87 then
				v89 = v87:FindFirstChild(v88)
			else
				v89 = nil
			end
			local v90
			if v89 then
				v90 = v89:FindFirstChild("Container")
			else
				v90 = nil
			end
			local v91
			if v90 then
				v91 = v90:FindFirstChild("EditList")
			else
				v91 = nil
			end
			local v92 = v85[2]
			local v93
			if v91 then
				v93 = v91:FindFirstChild(v92)
			else
				v93 = nil
			end
			local v94
			if v93 then
				v94 = v93:FindFirstChild("Button")
			else
				v94 = nil
			end
			if v94 and v94:IsA("GuiObject") then
				return v94
			else
				return nil
			end
		else
			return nil
		end
	end
	local v96 = v_u_15.Sections.Potions
	local v97
	if p81 then
		v97 = p81:FindFirstChild(v96)
	else
		v97 = nil
	end
	local v98 = v_u_15.Sections.Animals
	local v99
	if p81 then
		v99 = p81:FindFirstChild(v98)
	else
		v99 = nil
	end
	local v100
	if p81 then
		v100 = p81:FindFirstChild("GiftType")
	else
		v100 = nil
	end
	local v101
	if v97 then
		v101 = v97:FindFirstChild("Edit")
	else
		v101 = nil
	end
	local v102
	if p81 then
		v102 = p81:FindFirstChild("PotionEdit")
	else
		v102 = nil
	end
	local v103
	if v99 then
		v103 = v99:FindFirstChild("AnimalSelect")
	else
		v103 = nil
	end
	local v_u_104
	if p_u_82 then
		v_u_104 = p_u_82:FindFirstChild("CommandsList")
	else
		v_u_104 = nil
	end
	local v_u_105
	if p_u_82 then
		v_u_105 = p_u_82:FindFirstChild("AnimalSelectionList")
	else
		v_u_105 = nil
	end
	local v106 = {}
	local v107
	if v97 then
		v107 = v97:FindFirstChild("Send")
	else
		v107 = nil
	end
	local v108
	if v99 then
		v108 = v99:FindFirstChild("Send")
	else
		v108 = nil
	end
	__set_list(v106, 1, {v100, v101, v103, v107, v108})
	for _, v109 in v106 do
		if not (v109 and v109:IsA("GuiButton")) then
			continue
		end
		v109:SetAttribute("HoverScale", v_u_3.PanelHoverScale)
		v109:SetAttribute("PressScale", v_u_3.PanelPressScale)
	end
	local v_u_110 = {}
	for v111, v112 in v_u_15.Sections do
		local v113
		if p81 then
			v113 = p81:FindFirstChild(v112)
		else
			v113 = nil
		end
		if not (v113 and v113:IsA("GuiObject")) then
			continue
		end
		v_u_110[v111] = v113
	end
	local v_u_114 = v_u_15.DefaultType
	local function v_u_115() end
	local function v_u_116() end
	local function v_u_121(p117, p118) -- name: showSection
		-- upvalues: (ref) v_u_114, (copy) p_u_80, (ref) v_u_115, (ref) v_u_116, (copy) v_u_110, (ref) v_u_36
		v_u_114 = p117
		p_u_80:SetAttribute("GiftType", p117)
		v_u_115()
		v_u_116(p118)
		for v119, v120 in v_u_110 do
			v120.Visible = v119 == p117
			if v119 ~= p117 or not p118 then
				continue
			end
			v_u_36(v120)
		end
	end
	v_u_121(v_u_114, false)
	if v100 and v100:IsA("GuiButton") then
		local v122
		if p81 then
			v122 = p81:FindFirstChild("EditList")
		else
			v122 = nil
		end
		local v123 = v_u_9.Bind
		local v124 = v_u_114
		local function v126(p125)
			-- upvalues: (copy) v_u_110, (ref) v_u_114, (copy) v_u_121
			if v_u_110[p125] and p125 ~= v_u_114 then
				v_u_121(p125, true)
			end
		end
		local v127 = {
			["Toggle"] = v100
		}
		if not (v122 and v122:IsA("GuiObject")) then
			v122 = nil
		end
		v127.List = v122
		local v128 = v123(p81, v124, v126, v127)
		if v128 then
			local v129 = v83.Dropdowns
			table.insert(v129, v128)
		end
	end
	local v_u_130 = nil
	local v_u_131
	if v102 and (v101 and (v101:IsA("GuiButton") and v102:IsA("GuiObject"))) then
		local v132 = v102:FindFirstChild("Template")
		if v132 and v132:IsA("GuiObject") then
			v132.Visible = false
			v_u_131 = v_u_114
			local v133 = {}
			for _, v134 in v_u_6.Potions do
				local v135 = v134.Id
				table.insert(v133, v135)
			end
			table.insert(v133, "all")
			for v136, v137 in v133 do
				if v102:FindFirstChild(v137) then
					continue
				end
				local v138 = v132:Clone()
				v138.Name = v137
				v138.LayoutOrder = v132.LayoutOrder + v136
				v138.Visible = true
				local v139 = v138:FindFirstChild("Button")
				local v140, v141, v142, v143, v144, v145, v146, v147, v148
				if v139 and v139:IsA("GuiObject") then
					local v149 = v_u_15.PotionStyles[v137]
					local v150, v151
					if v149 then
						local v152 = v_u_95(v149)
						local v153
						if v152 then
							v_u_71(v152, v139)
							v153 = true
						else
							v153 = false
						end
						if v153 then
							v150 = v139:FindFirstChild("Title")
							if v150 and v150:IsA("TextLabel") then
								v150.RichText = true
							end
						else
							v151 = v_u_95("Green")
							if v151 then
								v_u_71(v151, v139)
							end
							v_u_79(v139, v_u_44(v137))
							v150 = v139:FindFirstChild("Title")
							if v150 and v150:IsA("TextLabel") then
								v150.RichText = true
							end
						end
					else
						v151 = v_u_95("Green")
						if v151 then
							v_u_71(v151, v139)
						end
						v_u_79(v139, v_u_44(v137))
						v150 = v139:FindFirstChild("Title")
						if v150 and v150:IsA("TextLabel") then
							v150.RichText = true
						end
					end
					if v137 == "all" then
						v140 = "All"
						v141 = "Potions"
					else
						v142 = v_u_6.ById(v137)
						if v142 then
							v140 = v142.HoverMultiplier
							v141 = v142.HoverName
						else
							v141 = v137
							v140 = ""
						end
					end
					if v137 == "all" then
						v143 = Color3.fromHex(v_u_6.AllPotionsColor)
					else
						v144 = v_u_6.ById(v137)
						v145 = Color3.fromHex
						if v144 then
							v146 = v144.Color
						else
							v146 = v_u_6.HoverMultiplierColor
						end
						v143 = v145(v146)
					end
					v147 = ("<font color=\"#%*\">%*</font> %*"):format(v143:Lerp(v_u_38, 0.6):ToHex(), v140, v141)
					if v139 then
						v148 = v139:FindFirstChild("Title")
					else
						v148 = nil
					end
					if v148 and v148:IsA("TextLabel") then
						v148.Text = v147
					end
					v138.Parent = v102
				else
					if v137 == "all" then
						v140 = "All"
						v141 = "Potions"
					else
						v142 = v_u_6.ById(v137)
						if v142 then
							v140 = v142.HoverMultiplier
							v141 = v142.HoverName
						else
							v141 = v137
							v140 = ""
						end
					end
					if v137 == "all" then
						v143 = Color3.fromHex(v_u_6.AllPotionsColor)
					else
						v144 = v_u_6.ById(v137)
						v145 = Color3.fromHex
						if v144 then
							v146 = v144.Color
						else
							v146 = v_u_6.HoverMultiplierColor
						end
						v143 = v145(v146)
					end
					v147 = ("<font color=\"#%*\">%*</font> %*"):format(v143:Lerp(v_u_38, 0.6):ToHex(), v140, v141)
					if v139 then
						v148 = v139:FindFirstChild("Title")
					else
						v148 = nil
					end
					if v148 and v148:IsA("TextLabel") then
						v148.Text = v147
					end
					v138.Parent = v102
				end
			end
		else
			v_u_131 = v_u_114
		end
		local v155 = v_u_9.Bind(p81, "", function(p154)
			-- upvalues: (ref) v_u_130, (ref) v_u_116
			v_u_130 = p154
			v_u_116(true)
		end, {
			["Toggle"] = nil,
			["List"] = nil,
			["Setting"] = false,
			["Direction"] = "Up",
			["Toggle"] = v101,
			["List"] = v102
		})
		if v155 then
			local v156 = v83.Dropdowns
			table.insert(v156, v155)
		end
	else
		v_u_131 = v_u_114
	end
	local v_u_157 = nil
	local v_u_158 = false
	local function v_u_159() end
	local function v_u_172() -- name: buildTiles
		-- upvalues: (ref) v_u_158, (copy) v_u_105, (ref) v_u_12, (ref) v_u_5, (ref) v_u_4, (ref) v_u_157, (copy) v_u_104, (ref) v_u_36, (ref) v_u_159, (ref) v_u_116
		if v_u_158 or not v_u_105 then
			return
		else
			v_u_158 = true
			local v160 = v_u_105:FindFirstChild("Template")
			if v160 and v160:IsA("GuiObject") then
				v160.Visible = false
				if v_u_105:IsA("ScrollingFrame") then
					v_u_12.SetupGrid(v_u_105)
				end
				local v161 = table.clone(v_u_5.Pool)
				table.sort(v161, function(p162, p163)
					-- upvalues: (ref) v_u_4
					local v164 = v_u_4.IndexOf(p162.Rarity) or 0
					local v165 = v_u_4.IndexOf(p163.Rarity) or 0
					if v164 == v165 then
						return p162.Name < p163.Name
					else
						return v164 < v165
					end
				end)
				for v166, v_u_167 in v161 do
					local v168 = v160:Clone()
					v168.Name = v_u_167.Name
					v168.LayoutOrder = v166
					v168.Visible = true
					local v169 = v168:FindFirstChild("Inner")
					local v170
					if v169 then
						v170 = v169:FindFirstChild("Name")
					else
						v170 = nil
					end
					if v170 and v170:IsA("TextLabel") then
						v170.Text = v_u_5.DisplayName(v_u_167.Name)
					end
					local v171
					if v169 then
						v171 = v169:FindFirstChild("AnimalDisplay")
					else
						v171 = nil
					end
					v_u_12.SetRender(v171, v_u_167.Name)
					if v169 and v169:IsA("GuiObject") then
						v_u_12.PaintBackground(v169, v_u_167.Rarity)
						v_u_12.Prepare(v169, v171)
					end
					if v169 and v169:IsA("GuiButton") then
						v169.Activated:Connect(function()
							-- upvalues: (copy) v_u_167, (ref) v_u_157, (ref) v_u_105, (ref) v_u_104, (ref) v_u_36, (ref) v_u_159, (ref) v_u_116
							v_u_157 = v_u_167.Name
							if v_u_105 and v_u_105:IsA("GuiObject") then
								v_u_105.Visible = false
							end
							if v_u_104 and v_u_104:IsA("GuiObject") then
								v_u_104.Visible = true
								v_u_36(v_u_104)
							end
							v_u_159(true)
							v_u_116(true)
						end)
					end
					v168.Parent = v_u_105
				end
			end
		end
	end
	if v103 and (v103:IsA("GuiButton") and (v_u_105 and v_u_105:IsA("GuiObject"))) then
		v103.Activated:Connect(function()
			-- upvalues: (copy) v_u_172, (copy) v_u_104, (copy) v_u_105, (ref) v_u_36
			v_u_172()
			if v_u_104 and v_u_104:IsA("GuiObject") then
				v_u_104.Visible = false
			end
			if v_u_105:IsA("ScrollingFrame") then
				v_u_105.CanvasPosition = Vector2.zero
			end
			v_u_105.Visible = true
			v_u_36(v_u_105)
		end)
	end
	local v_u_173 = v_u_15.DefaultGlobal
	local v_u_174 = p81:FindFirstChild(v_u_15.GlobalToggleName, true)
	if not (v_u_174 and v_u_174:IsA("GuiButton")) then
		v_u_174 = nil
	end
	local v_u_175
	if v_u_174 then
		v_u_175 = v_u_174:FindFirstChild("State")
	else
		v_u_175 = nil
	end
	if v_u_174 then
		if v_u_174 and v_u_174:IsA("GuiButton") then
			v_u_174:SetAttribute("HoverScale", v_u_3.PanelHoverScale)
			v_u_174:SetAttribute("PressScale", v_u_3.PanelPressScale)
		end
		local v176
		if v_u_174 then
			v176 = v_u_174:FindFirstChild("Title")
		else
			v176 = nil
		end
		if v176 and v176:IsA("TextLabel") then
			v176.Text = "Global"
		end
		if v_u_174 then
			local v177
			if v_u_173 then
				v177 = v_u_15.GlobalOnStyle
			else
				v177 = v_u_15.GlobalOffStyle
			end
			local v178 = v_u_95(v177)
			if v178 then
				v_u_71(v178, v_u_174)
			end
		end
		if v_u_175 and v_u_175:IsA("TextLabel") then
			local v179
			if v_u_173 then
				v179 = v_u_15.GlobalOnText
			else
				v179 = v_u_15.GlobalOffText
			end
			v_u_175.Text = v179
		end
		v_u_174.Activated:Connect(function()
			-- upvalues: (ref) v_u_173, (copy) p_u_80, (copy) v_u_174, (ref) v_u_15, (copy) v_u_95, (ref) v_u_71, (copy) v_u_175
			v_u_173 = not v_u_173
			p_u_80:SetAttribute("GiftGlobal", v_u_173)
			if v_u_174 then
				local v180 = v_u_174
				local v181
				if v_u_173 then
					v181 = v_u_15.GlobalOnStyle
				else
					v181 = v_u_15.GlobalOffStyle
				end
				local v182 = v_u_95(v181)
				if v182 then
					v_u_71(v182, v180)
				end
			end
			if v_u_175 and v_u_175:IsA("TextLabel") then
				local v183 = v_u_175
				local v184
				if v_u_173 then
					v184 = v_u_15.GlobalOnText
				else
					v184 = v_u_15.GlobalOffText
				end
				v183.Text = v184
			end
		end)
	end
	p_u_80:SetAttribute("GiftGlobal", v_u_173)
	v_u_115 = function()
		-- upvalues: (copy) v_u_174, (ref) v_u_15, (ref) v_u_131
		if v_u_174 then
			v_u_174.Visible = v_u_15.GlobalTypes[v_u_131] == true
		end
	end
	v_u_115()
	local v_u_185 = false
	local function v_u_193(p_u_186) -- name: send
		-- upvalues: (ref) v_u_185, (ref) v_u_1, (ref) v_u_3, (ref) v_u_13, (ref) v_u_173, (ref) v_u_15, (ref) v_u_131
		if v_u_185 then
			return
		else
			local v_u_187 = v_u_1:FindFirstChild(v_u_3.PanelRemotes.Gift)
			if v_u_187 and v_u_187:IsA("RemoteFunction") then
				local v188 = v_u_173
				if v188 then
					v188 = v_u_15.GlobalTypes[v_u_131] == true
				end
				p_u_186.Global = v188
				v_u_185 = true
				local v189, v190, v191 = pcall(function()
					-- upvalues: (copy) v_u_187, (copy) p_u_186
					return v_u_187:InvokeServer(p_u_186)
				end)
				v_u_185 = false
				if v189 and v190 == true then
					v_u_13.Show(type(v191) ~= "string" and "{Gift} sent!" or v191, "Success")
				else
					local v192 = (not v189 or type(v191) ~= "string") and "couldn\'t send the gift" or v191
					v_u_13.Show(("Gift failed: %*"):format(v192), "Error")
				end
			else
				v_u_13.Show("Gifting isn\'t ready yet", "Error")
				return
			end
		end
	end
	local v194
	if v97 then
		v194 = v97:FindFirstChild("Username")
	else
		v194 = nil
	end
	local v_u_195
	if v194 then
		v_u_195 = v194:FindFirstChild("TextBox")
	else
		v_u_195 = nil
	end
	if v_u_195 and v_u_195:IsA("TextBox") then
		v_u_195.ClearTextOnFocus = false
	else
		v_u_195 = nil
	end
	local v196
	if v97 then
		v196 = v97:FindFirstChild("Duration")
	else
		v196 = nil
	end
	local v_u_197
	if v196 then
		v_u_197 = v196:FindFirstChild("TextBox")
	else
		v_u_197 = nil
	end
	if v_u_197 and v_u_197:IsA("TextBox") then
		v_u_197.ClearTextOnFocus = false
	else
		v_u_197 = nil
	end
	v_u_11.Bind(v_u_197, v_u_15.MinutesSuffix)
	local v198
	if v97 then
		v198 = v97:FindFirstChild("Send")
	else
		v198 = nil
	end
	if v198 and v198:IsA("GuiButton") then
		v198.Activated:Connect(function()
			-- upvalues: (ref) v_u_130, (ref) v_u_13, (copy) v_u_193, (copy) v_u_195, (copy) v_u_197
			if v_u_130 then
				task.spawn(v_u_193, {
					["Kind"] = "Potion",
					["Target"] = nil,
					["Duration"] = nil,
					["Potion"] = nil,
					["Target"] = not v_u_195 and "" or v_u_195.Text,
					["Duration"] = not v_u_197 and "" or v_u_197.Text,
					["Potion"] = v_u_130
				})
			else
				v_u_13.Show("Pick a potion first (Edit)", "Error")
			end
		end)
	end
	local v199
	if v99 then
		v199 = v99:FindFirstChild("PlayerName")
	else
		v199 = nil
	end
	local v_u_200
	if v199 then
		v_u_200 = v199:FindFirstChild("TextBox")
	else
		v_u_200 = nil
	end
	if v_u_200 and v_u_200:IsA("TextBox") then
		v_u_200.ClearTextOnFocus = false
	else
		v_u_200 = nil
	end
	local v201
	if v99 then
		v201 = v99:FindFirstChild("AnimalWeight")
	else
		v201 = nil
	end
	local v_u_202
	if v201 then
		v_u_202 = v201:FindFirstChild("TextBox")
	else
		v_u_202 = nil
	end
	if v_u_202 and v_u_202:IsA("TextBox") then
		v_u_202.ClearTextOnFocus = false
	else
		v_u_202 = nil
	end
	local v203
	if v99 then
		v203 = v99:FindFirstChild("Amount")
	else
		v203 = nil
	end
	local v_u_204
	if v203 then
		v_u_204 = v203:FindFirstChild("TextBox")
	else
		v_u_204 = nil
	end
	if v_u_204 and v_u_204:IsA("TextBox") then
		v_u_204.ClearTextOnFocus = false
	else
		v_u_204 = nil
	end
	v_u_33(v_u_202, v_u_15.KgSuffix)
	v_u_33(v_u_204, v_u_15.AmountSuffix)
	local v_u_205
	if v99 then
		v_u_205 = v99:FindFirstChild("Template")
	else
		v_u_205 = nil
	end
	local v_u_206
	if v_u_205 then
		v_u_206 = v_u_205:FindFirstChild("Inner")
	else
		v_u_206 = nil
	end
	local v_u_207
	if v_u_206 then
		v_u_207 = v_u_206:FindFirstChild("AnimalDisplay")
	else
		v_u_207 = nil
	end
	local v_u_208
	if v_u_206 then
		v_u_208 = v_u_206:FindFirstChild("AnimalEarnings")
	else
		v_u_208 = nil
	end
	if not (v_u_208 and v_u_208:IsA("TextLabel")) then
		v_u_208 = nil
	end
	if v_u_206 and v_u_206:IsA("GuiObject") then
		v_u_12.Prepare(v_u_206, v_u_207)
	end
	local v_u_213 = v_u_7.new(function(p209)
		-- upvalues: (copy) v_u_208, (ref) v_u_8
		if v_u_208 then
			local v210 = v_u_208
			local v211 = v_u_8.Short
			local v212 = p209 + 0.5
			v210.Text = ("$%*/s"):format((v211((math.floor(v212)))))
		end
	end)
	v_u_213:Snap(0)
	local function v_u_221(p214) -- name: previewKg
		-- upvalues: (copy) v_u_202, (ref) v_u_27, (ref) v_u_15, (ref) v_u_37, (ref) v_u_5
		local v215 = not v_u_202 and "" or v_u_27(v_u_202.Text, v_u_15.KgSuffix)
		local v216 = tonumber(v215)
		if not v216 then
			local v217, v218 = string.match(string.lower(v215), "^(%d*%.?%d+)(%a+)$")
			local v219 = v_u_37[v218 or ""]
			if v217 and v219 then
				v216 = tonumber(v217) * v219
			else
				v216 = nil
			end
		end
		if v216 and v216 > 0 then
			return v216
		end
		local v220 = p214.Zone
		if v220 then
			v220 = v_u_5.ZoneEggs[("Zone%*"):format(p214.Zone)]
		end
		if v220 then
			v220 = v220.Eggs[1]
		end
		return v_u_5.KgForSize(v_u_5.EggBaseKgFor(v220, p214.Rarity), 1)
	end
	local v_u_222 = nil
	v_u_159 = function(p223)
		-- upvalues: (ref) v_u_157, (ref) v_u_5, (copy) v_u_205, (copy) v_u_213, (ref) v_u_222, (ref) v_u_12, (copy) v_u_207, (copy) v_u_206, (ref) v_u_36, (copy) v_u_221, (copy) v_u_204, (ref) v_u_27, (ref) v_u_15
		local v226
		if v_u_157 then
			local v225 = v_u_157
			for _, v226 in v_u_5.Pool do
				if v226.Name ~= v225 then
					continue
				end
			end
			v226 = nil
		else
			v226 = nil
		end
		if v_u_205 and v_u_205:IsA("GuiObject") then
			v_u_205.Visible = v226 ~= nil
		end
		if v226 then
			if v226.Name ~= v_u_222 then
				v_u_222 = v226.Name
				v_u_12.SetRender(v_u_207, v226.Name)
				if v_u_206 and v_u_206:IsA("GuiObject") then
					v_u_12.PaintBackground(v_u_206, v226.Rarity)
				end
				if p223 and (v_u_205 and v_u_205:IsA("GuiObject")) then
					v_u_36(v_u_205)
				end
			end
			local v227 = v_u_5.PlacedCashPerSecond(v226.Name, nil, nil, v_u_221(v226))
			local v228 = v_u_213
			local v229 = not v_u_204 and "" or v_u_27(v_u_204.Text, v_u_15.AmountSuffix)
			local v230 = tonumber(v229)
			local v231
			if v230 and v230 >= 1 then
				local v232 = math.floor(v230)
				local v233 = v_u_15.MaxAnimalAmount
				v231 = math.min(v232, v233)
			else
				v231 = 1
			end
			v228:Set(v227 * v231)
		else
			v_u_213:Snap(0)
		end
	end
	local v_u_234 = v_u_157
	local v_u_235 = v_u_159
	for _, v236 in { v_u_202, v_u_204 } do
		if not v236 then
			continue
		end
		v236:GetPropertyChangedSignal("Text"):Connect(function()
			-- upvalues: (ref) v_u_235
			v_u_235(false)
		end)
	end
	v_u_235(false)
	local v_u_237
	if p81 then
		v_u_237 = p81:FindFirstChild("ItemSelected")
	else
		v_u_237 = nil
	end
	local v_u_238
	if v_u_237 and v_u_237:IsA("TextLabel") then
		v_u_238 = v_u_10.new(v_u_237)
	else
		v_u_238 = nil
	end
	local v_u_239 = v_u_15.AnimalColor
	v_u_116 = function(p240)
		-- upvalues: (copy) v_u_237, (copy) v_u_238, (copy) v_u_239, (ref) v_u_131, (ref) v_u_234, (ref) v_u_5, (ref) v_u_130, (ref) v_u_6, (ref) v_u_38, (ref) v_u_36
		if v_u_237 and (v_u_237:IsA("TextLabel") and v_u_238) then
			local v241 = nil
			local v242 = v_u_239
			if v_u_131 == "Animals" and v_u_234 then
				v241 = v_u_5.DisplayName(v_u_234)
			elseif v_u_131 == "Potions" and v_u_130 then
				v241 = v_u_130
				local v243
				if v241 == "all" then
					v243 = "All"
					v241 = "Potions"
				else
					local v244 = v_u_6.ById(v241)
					if v244 then
						v243 = v244.HoverMultiplier
						v241 = v244.HoverName
					else
						v243 = ""
					end
				end
				if v243 ~= "" then
					v241 = ("%* %*"):format(v243, v241)
				end
				local v245 = v_u_130
				local v246
				if v245 == "all" then
					v246 = Color3.fromHex(v_u_6.AllPotionsColor)
				else
					local v247 = v_u_6.ById(v245)
					local v248 = Color3.fromHex
					local v249
					if v247 then
						v249 = v247.Color
					else
						v249 = v_u_6.HoverMultiplierColor
					end
					v246 = v248(v249)
				end
				v242 = v246:Lerp(v_u_38, 0.15)
			end
			if v241 then
				if v_u_237.Visible then
					v_u_238:Set(v241, v242, not p240)
				else
					v_u_238:Set(v241, v242, true)
					v_u_237.Visible = true
					if p240 then
						v_u_36(v_u_237)
						return
					end
				end
			else
				v_u_237.Visible = false
			end
		else
			return
		end
	end
	v_u_116(false)
	local v250
	if v99 then
		v250 = v99:FindFirstChild("Send")
	else
		v250 = nil
	end
	if v250 and v250:IsA("GuiButton") then
		v250.Activated:Connect(function()
			-- upvalues: (ref) v_u_234, (ref) v_u_13, (copy) v_u_193, (copy) v_u_200, (copy) v_u_202, (ref) v_u_27, (ref) v_u_15, (copy) v_u_204
			if v_u_234 then
				task.spawn(v_u_193, {
					["Kind"] = "Animal",
					["Target"] = nil,
					["Animal"] = nil,
					["Kg"] = nil,
					["Amount"] = nil,
					["Target"] = not v_u_200 and "" or v_u_200.Text,
					["Animal"] = v_u_234,
					["Kg"] = not v_u_202 and "" or v_u_27(v_u_202.Text, v_u_15.KgSuffix),
					["Amount"] = not v_u_204 and "" or v_u_27(v_u_204.Text, v_u_15.AmountSuffix)
				})
			else
				v_u_13.Show("Select an animal first", "Error")
			end
		end)
	end
	function v83.Reset()
		-- upvalues: (copy) v_u_105, (copy) v_u_104
		if v_u_105 and v_u_105:IsA("GuiObject") then
			v_u_105.Visible = false
		end
		if v_u_104 and v_u_104:IsA("GuiObject") then
			v_u_104.Visible = true
		end
	end
	return v83
end
return v14
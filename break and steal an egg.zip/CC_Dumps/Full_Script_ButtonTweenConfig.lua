local v1 = {
	["HoverScale"] = 1.1,
	["PressScale"] = 0.9,
	["TweenDuration"] = 0.1,
	["TweenEasingStyle"] = nil,
	["TweenEasingDirection"] = nil,
	["HoverBlockerTag"] = "ButtonTweenHoverBlocker",
	["IgnoreScreenGuis"] = nil,
	["TweenEasingStyle"] = Enum.EasingStyle.Quart,
	["TweenEasingDirection"] = Enum.EasingDirection.InOut,
	["IgnoreScreenGuis"] = {
		["Scatchel"] = nil,
		["MobileScatchel"] = nil,
		["BackpackGui"] = true,
		["TopbarStandard"] = true,
		["TopbarCentre"] = true,
		["TopbarPlus"] = true,
		["ProximityPrompts"] = true,
		["Scatchel"] = {
			["Sell"] = true,
			["Cancel"] = true
		},
		["MobileScatchel"] = {
			["Sell"] = true,
			["Cancel"] = true
		}
	}
}
return v1
local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = require(script.Parent.BillboardAssets)
local v_u_5 = require(script.Parent.FormatNumber)
local v_u_6 = {
	["TemplateName"] = "AnimalCashGainPopup",
	["HolderName"] = "AnimalCashPopups",
	["AmountNames"] = {
		"Amount",
		"Cash",
		"CashGain",
		"Gain",
		"Text",
		"Label"
	},
	["MinScale"] = 0.85,
	["MaxScale"] = 2.2
}
local v_u_7 = TweenInfo.new(0.32, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_8 = TweenInfo.new(1.1, Enum.EasingStyle.Quart, Enum.EasingDirection.Out)
local v_u_9 = TweenInfo.new(0.4)
v_u_6.HeightAboveHead = 1
v_u_6.Lanes = { -1, 0, 1 }
v_u_6.SideGap = 0.6
v_u_6.SideHeightMin = 0.55
v_u_6.SideHeightMax = 0.85
local v_u_10 = Random.new()
local v_u_11 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_12 = v2.LocalPlayer
local function v_u_16() -- name: getHolder
	-- upvalues: (copy) v_u_12, (copy) v_u_6
	if not v_u_12 then
		return nil
	end
	local v13 = v_u_12:FindFirstChildOfClass("PlayerGui")
	if not v13 then
		return nil
	end
	local v14 = v13:FindFirstChild(v_u_6.HolderName)
	if v14 and v14:IsA("ScreenGui") then
		return v14
	end
	local v15 = Instance.new("ScreenGui")
	v15.Name = v_u_6.HolderName
	v15.ResetOnSpawn = false
	v15.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	v15.Parent = v13
	return v15
end
local function v_u_20(p17) -- name: findAmountLabel
	-- upvalues: (copy) v_u_6
	for _, v18 in v_u_6.AmountNames do
		local v19 = p17:FindFirstChild(v18, true)
		if not (v19 and v19:IsA("TextLabel")) then
			continue
		end
		return v19
	end
	return p17:FindFirstChildWhichIsA("TextLabel", true)
end
local function v_u_24(p21) -- name: collectFadeTargets
	local v22 = {}
	for _, v23 in p21:GetDescendants() do
		if v23:IsA("TextLabel") or v23:IsA("TextButton") then
			table.insert(v22, {
				["Instance"] = nil,
				["Property"] = "TextTransparency",
				["Instance"] = v23
			})
			if v23.BackgroundTransparency >= 1 then
				continue
			end
			table.insert(v22, {
				["Instance"] = nil,
				["Property"] = "BackgroundTransparency",
				["Instance"] = v23
			})
		elseif v23:IsA("ImageLabel") or v23:IsA("ImageButton") then
			table.insert(v22, {
				["Instance"] = nil,
				["Property"] = "ImageTransparency",
				["Instance"] = v23
			})
			if v23.BackgroundTransparency >= 1 then
				continue
			end
			table.insert(v22, {
				["Instance"] = nil,
				["Property"] = "BackgroundTransparency",
				["Instance"] = v23
			})
		elseif v23:IsA("UIStroke") then
			table.insert(v22, {
				["Instance"] = nil,
				["Property"] = "Transparency",
				["Instance"] = v23
			})
		else
			if not v23:IsA("Frame") or v23.BackgroundTransparency >= 1 then
				continue
			end
			table.insert(v22, {
				["Instance"] = nil,
				["Property"] = "BackgroundTransparency",
				["Instance"] = v23
			})
		end
	end
	return v22
end
function v_u_6.HeadHeight(p25, p26) -- name: HeadHeight
	local v27 = p26 or (p25.PrimaryPart or p25:FindFirstChildWhichIsA("BasePart", true))
	if not v27 then
		return 0
	end
	local v28, v29 = p25:GetBoundingBox()
	local v30 = v28.RightVector.Y
	local v31 = math.abs(v30) * v29.X
	local v32 = v28.UpVector.Y
	local v33 = v31 + math.abs(v32) * v29.Y
	local v34 = v28.LookVector.Y
	local v35 = (v33 + math.abs(v34) * v29.Z) / 2
	local v36 = v28.Position.Y + v35 - v27.Position.Y
	return math.max(v36, 0)
end
function v_u_6.SideReach(p37) -- name: SideReach
	local v38, v39 = p37:GetBoundingBox()
	local v40 = v38.RightVector
	local v41 = v38.UpVector
	local v42 = v38.LookVector
	local v43 = v40.X
	local v44 = math.abs(v43) * v39.X
	local v45 = v41.X
	local v46 = v44 + math.abs(v45) * v39.Y
	local v47 = v42.X
	local v48 = v46 + math.abs(v47) * v39.Z
	local v49 = v40.Z
	local v50 = math.abs(v49) * v39.X
	local v51 = v41.Z
	local v52 = v50 + math.abs(v51) * v39.Y
	local v53 = v42.Z
	local v54 = v52 + math.abs(v53) * v39.Z
	return math.max(v48, v54) / 2
end
local function v_u_61(p55) -- name: pickLane
	-- upvalues: (copy) v_u_6, (copy) v_u_11, (copy) v_u_10
	local v56 = v_u_6.Lanes
	local v57 = v_u_11[p55]
	local v58 = {}
	for _, v59 in v56 do
		if v59 == v57 then
			continue
		end
		table.insert(v58, v59)
	end
	if #v58 ~= 0 then
		v56 = v58
	end
	local v60 = v56[v_u_10:NextInteger(1, #v56)]
	v_u_11[p55] = v60
	return v60
end
function v_u_6.Play(p62, p63, p64) -- name: Play
	-- upvalues: (copy) v_u_4, (copy) v_u_6, (copy) v_u_16, (copy) v_u_20, (copy) v_u_5, (copy) v_u_61, (copy) v_u_10, (copy) v_u_3, (copy) v_u_7, (copy) v_u_8, (copy) v_u_24, (copy) v_u_9, (copy) v_u_1
	if p63 <= 0 or not p62.Parent then
		return nil
	end
	local v65 = p62.PrimaryPart or p62:FindFirstChildWhichIsA("BasePart", true)
	if not v65 then
		return nil
	end
	local v66 = v_u_4.Get(v_u_6.TemplateName)
	local v67 = v_u_16()
	if not (v66 and v67) then
		return nil
	end
	local v68 = p64 or {}
	local v_u_69 = v66:Clone()
	v_u_69.Name = "AnimalCashGain"
	v_u_69.Adornee = v65
	v_u_69.Enabled = true
	local v70 = v_u_20(v_u_69)
	if v70 then
		local v71 = v68.Prefix or "+"
		local v72 = v_u_5.Short
		local v73 = math.round(p63)
		v70.Text = ("%*$%*"):format(v71, (v72((math.max(v73, 1)))))
		if v68.Color then
			v70.TextColor3 = v68.Color
		end
	end
	local v74 = v68.SizeMult or 1
	local v75 = v_u_6.MinScale
	local v76 = v_u_6.MaxScale
	local v77 = math.clamp(v74, v75, v76)
	if v77 ~= 1 then
		v_u_69.Size = UDim2.new(v_u_69.Size.X.Scale * v77, v_u_69.Size.X.Offset * v77, v_u_69.Size.Y.Scale * v77, v_u_69.Size.Y.Offset * v77)
	end
	local v78 = v_u_69.StudsOffsetWorldSpace
	local v79 = v68.HeadHeight or v_u_6.HeadHeight(p62, v65)
	local v80 = v_u_61(p62)
	local v81
	if v80 == 0 then
		v81 = v79 + v_u_6.HeightAboveHead
	else
		v81 = v79 * v_u_10:NextNumber(v_u_6.SideHeightMin, v_u_6.SideHeightMax)
	end
	local v82 = v78.X
	local v83 = v78.Z
	local v84 = Vector3.new(v82, v81, v83)
	v_u_69.StudsOffsetWorldSpace = v84
	local v85 = v68.SideReach or v_u_6.SideReach(p62)
	local v86 = v_u_69.StudsOffset
	local v87 = v80 * (v85 + v_u_6.SideGap)
	v_u_69.StudsOffset = v86 + Vector3.new(v87, 0, 0)
	local v88 = v_u_10:NextNumber(2.6, 4.2)
	local v89 = v84 + Vector3.new(0, v88, 0)
	local v90
	if v80 == 0 then
		v90 = v_u_10:NextNumber(-0.9, 0.9)
	else
		v90 = v80 * v_u_10:NextNumber(0, 0.9)
	end
	local v91 = v_u_69.StudsOffset + Vector3.new(v90, 0, 0)
	local v92 = v_u_69:FindFirstChildWhichIsA("GuiObject")
	local v93 = v90 * 10
	local v94 = math.clamp(v93, -9, 9)
	local v95 = v_u_69:FindFirstChildOfClass("UIScale")
	if not v95 then
		if v92 then
			v95 = v92:FindFirstChildOfClass("UIScale")
		else
			v95 = v92
		end
	end
	if not v95 then
		if v92 then
			v95 = Instance.new("UIScale")
			v95.Parent = v92
		else
			v95 = nil
		end
	end
	local v96 = not v95 and 1 or v95.Scale
	if v95 then
		v95.Scale = 0
	end
	v_u_69.Parent = v67
	if v95 then
		v_u_3:Create(v95, v_u_7, {
			["Scale"] = v96
		}):Play()
	end
	v_u_3:Create(v_u_69, v_u_8, {
		["StudsOffsetWorldSpace"] = v89,
		["StudsOffset"] = v91
	}):Play()
	if v92 then
		v_u_3:Create(v92, v_u_8, {
			["Rotation"] = v92.Rotation + v94
		}):Play()
	end
	local v_u_97 = v_u_24(v_u_69)
	task.delay(0.8700000000000001, function()
		-- upvalues: (copy) v_u_69, (copy) v_u_97, (ref) v_u_3, (ref) v_u_9
		if v_u_69.Parent ~= nil then
			for _, v98 in v_u_97 do
				v_u_3:Create(v98.Instance, v_u_9, {
					[v98.Property] = 1
				}):Play()
			end
		end
	end)
	v_u_1:AddItem(v_u_69, 1.37)
	return v_u_69
end
function v_u_6.Duration() -- name: Duration
	return 1.27
end
return v_u_6
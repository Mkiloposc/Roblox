local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(script.Parent.AnimalEggsConfig)
local v_u_3 = require(script.Parent.EggRewards)
local v_u_4 = {
	["Attribute"] = "EggType",
	["TemplateFolder"] = "Eggs",
	["AnimMaxDistance"] = 140,
	["AnimCheckInterval"] = 0.5,
	["DisabledNoticeDelay"] = 6
}
local v5 = {
	["Demon"] = {
		["DisplayName"] = "Demon Egg",
		["Template"] = "Demon Egg",
		["Body"] = "Demon Egg.014",
		["Front"] = Vector3.new(0, 0, 1),
		["BodyCenter"] = Vector3.new(0, 0.03, 0.14),
		["HoldForward"] = 0.21,
		["HoldLift"] = 0.1,
		["GroundSink"] = 0.11,
		["GrowthSeconds"] = 60,
		["Rarity"] = "Inferno",
		["Icon"] = "rbxassetid://76560393633139",
		["HatchPool"] = nil,
		["HatchWeights"] = nil,
		["GrowByWeight"] = true,
		["VariantChance"] = nil,
		["HatchPool"] = {
			"HellAnky",
			"HellTrike",
			"HellMegalodon",
			"HellTRex",
			"HellDragon",
			"HellHydra"
		},
		["HatchWeights"] = {
			["HellAnky"] = 50,
			["HellTrike"] = 32,
			["HellMegalodon"] = 14.4,
			["HellTRex"] = 3,
			["HellDragon"] = 0.5,
			["HellHydra"] = 0.1
		},
		["VariantChance"] = {
			["Gold"] = 0.05,
			["Diamond"] = 0.01
		}
	},
	["Haunted"] = {
		["DisplayName"] = "Super Haunted Egg",
		["Template"] = "Super Haunted Egg",
		["Body"] = "Plane.004",
		["Front"] = Vector3.new(0, 0, 1),
		["BodyCenter"] = Vector3.new(0, 0, 0),
		["HoldForward"] = 0.42,
		["HoldLift"] = 0,
		["GrowthSeconds"] = 60,
		["Rarity"] = "Inferno",
		["Icon"] = "rbxassetid://121815550962423",
		["HatchPool"] = nil,
		["HatchWeights"] = nil,
		["GrowByWeight"] = true,
		["HatchPool"] = {
			"HauntedWolf",
			"HauntedKitsune",
			"HauntedGriffin",
			"HauntedCerberus",
			"PenguinKing",
			"WitchSpider"
		},
		["HatchWeights"] = {
			["HauntedWolf"] = 70,
			["HauntedKitsune"] = 18,
			["HauntedGriffin"] = 9.9,
			["HauntedCerberus"] = 1,
			["PenguinKing"] = 1,
			["WitchSpider"] = 0.1
		}
	},
	["FallenAngel"] = {
		["DisplayName"] = "Fallen Angel Egg",
		["Template"] = "Angel Egg",
		["Body"] = "Demon Egg.014",
		["Front"] = Vector3.new(0, 0, 1),
		["BodyCenter"] = Vector3.new(0, 0.03, 0.14),
		["HoldForward"] = 0.21,
		["HoldLift"] = 0.1,
		["GroundSink"] = 0.11,
		["GrowthSeconds"] = 60,
		["Rarity"] = "Celestial",
		["Icon"] = "rbxassetid://83525826842415",
		["HatchPool"] = nil,
		["HatchWeights"] = nil,
		["Renames"] = nil,
		["GrowByWeight"] = true,
		["VariantChance"] = nil,
		["HatchPool"] = {
			"AngelAnky",
			"AngelTrike",
			"AngelMegalodon",
			"AngelTRex",
			"AngelDragon",
			"AngelHydra"
		},
		["HatchWeights"] = {
			["AngelAnky"] = 70,
			["AngelTrike"] = 18,
			["AngelMegalodon"] = 9.9,
			["AngelTRex"] = 1,
			["AngelDragon"] = 1,
			["AngelHydra"] = 0.1
		},
		["Renames"] = {
			["AngelCroc"] = "AngelAnky",
			["HellCroc"] = "AngelAnky",
			["HellAnky"] = "AngelAnky",
			["HellTrike"] = "AngelTrike",
			["HellMegalodon"] = "AngelMegalodon",
			["HellTRex"] = "AngelTRex",
			["HellDragon"] = "AngelDragon",
			["HellHydra"] = "AngelHydra"
		},
		["VariantChance"] = {
			["Gold"] = 0.05,
			["Diamond"] = 0.01
		}
	},
	["Celestial"] = {
		["DisplayName"] = "Celestial Egg",
		["Template"] = "Celestial Egg",
		["Body"] = "Egg",
		["Front"] = Vector3.new(0, 0, 1),
		["BodyCenter"] = Vector3.new(0, 0, 0),
		["HoldForward"] = 0.37,
		["HoldLift"] = 0,
		["GrowthSeconds"] = 60,
		["Rarity"] = "Celestial",
		["Icon"] = "rbxassetid://128356870637903",
		["HatchPool"] = nil,
		["HatchWeights"] = nil,
		["GrowByWeight"] = true,
		["HatchPool"] = {
			"CelestialLamb",
			"CelestialSpiritFox",
			"CelestialFrog",
			"CelestialAxolotl",
			"CelestialGorilla"
		},
		["HatchWeights"] = {
			["CelestialLamb"] = 50,
			["CelestialSpiritFox"] = 30,
			["CelestialFrog"] = 17.25,
			["CelestialAxolotl"] = 2.5,
			["CelestialGorilla"] = 0.25
		}
	},
	["HalloweenEgg1"] = {
		["DisplayName"] = "Pumpkin Patch Egg",
		["Template"] = "Halloween Egg 1",
		["Body"] = "Sphere.010",
		["Front"] = Vector3.new(0, 0, -1),
		["BodyCenter"] = Vector3.new(0, 0, 0),
		["HoldForward"] = 0.37,
		["HoldLift"] = 0,
		["GrowthSeconds"] = 60,
		["Rarity"] = "Celestial",
		["Icon"] = "rbxassetid://92202503250727",
		["HatchPool"] = nil,
		["HatchWeights"] = nil,
		["GrowByWeight"] = true,
		["VariantChance"] = nil,
		["HatchPool"] = {
			"CandleCat",
			"CandleWolf",
			"LanternDeer",
			"BoneBat",
			"BoneHydra"
		},
		["HatchWeights"] = {
			["CandleCat"] = 50,
			["CandleWolf"] = 30,
			["LanternDeer"] = 12,
			["BoneBat"] = 6,
			["BoneHydra"] = 2
		},
		["VariantChance"] = {
			["Gold"] = 0.05,
			["Diamond"] = 0.01
		}
	},
	["HalloweenEgg2"] = {
		["DisplayName"] = "Scarecrow Egg",
		["Template"] = "Halloween Egg 2",
		["Body"] = "Sphere.002",
		["Front"] = Vector3.new(0, 0, -1),
		["BodyCenter"] = Vector3.new(0, 0, 0),
		["HoldForward"] = 0.37,
		["HoldLift"] = 0,
		["GrowthSeconds"] = 60,
		["Rarity"] = "Inferno",
		["Icon"] = "rbxassetid://87153328609813",
		["HatchPool"] = nil,
		["HatchWeights"] = nil,
		["GrowByWeight"] = true,
		["VariantChance"] = nil,
		["HatchPool"] = {
			"ScarecrowTurkey",
			"ScarecrowOwl",
			"ScarecrowRhino",
			"ScarecrowLion",
			"ScarecrowHorse"
		},
		["HatchWeights"] = {
			["ScarecrowTurkey"] = 50,
			["ScarecrowOwl"] = 30,
			["ScarecrowRhino"] = 12,
			["ScarecrowLion"] = 6,
			["ScarecrowHorse"] = 2
		},
		["VariantChance"] = {
			["Gold"] = 0.05,
			["Diamond"] = 0.01
		}
	},
	["HalloweenEgg3"] = {
		["DisplayName"] = "Bone Crypt Egg",
		["Template"] = "Halloween Egg 3",
		["Body"] = "Sphere.008",
		["Front"] = Vector3.new(0, 0, -1),
		["BodyCenter"] = Vector3.new(0, 0, 0),
		["HoldForward"] = 0.37,
		["HoldLift"] = 0,
		["GrowthSeconds"] = 60,
		["Rarity"] = "Void",
		["Icon"] = "rbxassetid://120063992013066",
		["HatchPool"] = nil,
		["HatchWeights"] = nil,
		["GrowByWeight"] = true,
		["VariantChance"] = nil,
		["HatchPool"] = {
			"BoneGuineaPig",
			"BoneRat",
			"BoneHorse",
			"BoneLion",
			"BoneMammoth"
		},
		["HatchWeights"] = {
			["BoneGuineaPig"] = 50,
			["BoneRat"] = 30,
			["BoneHorse"] = 12,
			["BoneLion"] = 6,
			["BoneMammoth"] = 2
		},
		["VariantChance"] = {
			["Gold"] = 0.05,
			["Diamond"] = 0.01
		}
	}
}
v_u_4.Types = v5
function v_u_4.Get(p6) -- name: Get
	-- upvalues: (copy) v_u_4
	if typeof(p6) == "string" then
		return v_u_4.Types[p6]
	else
		return nil
	end
end
function v_u_4.IsDisabled(p7) -- name: IsDisabled
	-- upvalues: (copy) v_u_4
	local v8 = v_u_4.Get(p7)
	local v9
	if v8 == nil then
		v9 = false
	else
		v9 = v8.Disabled == true
	end
	return v9
end
function v_u_4.GrowsByWeight(p10) -- name: GrowsByWeight
	-- upvalues: (copy) v_u_4
	local v11 = v_u_4.Get(p10)
	local v12
	if v11 == nil then
		v12 = false
	else
		v12 = v11.GrowByWeight == true and true or v11.WeightLuck ~= nil
	end
	return v12
end
function v_u_4.RollAnimal(p13, p14) -- name: RollAnimal
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v15 = v_u_4.Get(p13)
	if v15 then
		local v16 = p14 or Random.new()
		local v17 = v15.HatchPool
		if v17 and #v17 > 0 then
			local v18 = v15.HatchWeights
			if not v18 then
				return v17[v16:NextInteger(1, #v17)]
			end
			local v19 = 0
			for _, v20 in v17 do
				local v21 = v18[v20] or 1
				v19 = v19 + math.max(v21, 0)
			end
			local v22 = v16:NextNumber() * v19
			for _, v23 in v17 do
				local v24 = v18[v23] or 1
				v22 = v22 - math.max(v24, 0)
				if v22 > 0 then
					continue
				end
				return v23
			end
			return v17[#v17]
		else
			local v25 = {}
			for _, v26 in v_u_3.Pool do
				if not v26.Zone then
					continue
				end
				local v27 = v26.Name
				table.insert(v25, v27)
			end
			if #v25 == 0 then
				return nil
			else
				return v25[v16:NextInteger(1, #v25)]
			end
		end
	else
		return nil
	end
end
function v_u_4.HatchOdds(p28) -- name: HatchOdds
	-- upvalues: (copy) v_u_4
	local v29 = v_u_4.Get(p28)
	local v30
	if v29 then
		v30 = v29.HatchPool
	else
		v30 = v29
	end
	local v31 = {}
	if not v29 or (not v30 or #v30 <= 0) then
		return v31
	end
	local v32 = v29.HatchWeights
	local v33 = 0
	for _, v34 in v30 do
		local v35
		if v32 then
			local v36 = v32[v34] or 1
			v35 = math.max(v36, 0)
		else
			v35 = 1
		end
		v33 = v33 + v35
	end
	for _, v37 in v30 do
		local v38
		if v32 then
			local v39 = v32[v37] or 1
			v38 = math.max(v39, 0)
		else
			v38 = 1
		end
		v31[v37] = v33 <= 0 and 0 or v38 / v33 * 100
	end
	return v31
end
function v_u_4.FormatChance(p40) -- name: FormatChance
	local v41 = p40 * 1000
	local v42 = math.round(v41) / 1000
	return string.format("%g%%", v42)
end
local v_u_43 = { "Diamond", "Gold" }
function v_u_4.RollVariant(p44, p45) -- name: RollVariant
	-- upvalues: (copy) v_u_4, (copy) v_u_43
	local v46 = v_u_4.Get(p44)
	if v46 then
		v46 = v46.VariantChance
	end
	if not v46 then
		return nil
	end
	local v47 = p45 or Random.new()
	for _, v48 in v_u_43 do
		if v47:NextNumber() >= (v46[v48] or 0) then
			continue
		end
		return v48
	end
	return nil
end
function v_u_4.RollLuckKg(p49, p50) -- name: RollLuckKg
	-- upvalues: (copy) v_u_4
	local v51 = v_u_4.Get(p49)
	if v51 then
		v51 = v51.WeightLuck
	end
	if not v51 or #v51 == 0 then
		return nil, nil
	end
	local v52 = p50 or Random.new()
	local v53 = 0
	for _, v54 in v51 do
		v53 = v53 + v54.Chance
	end
	local v55 = v52:NextNumber() * v53
	local v56 = v51[#v51]
	for _, v57 in v51 do
		v55 = v55 - v57.Chance
		if v55 > 0 then
			continue
		end
		v56 = v57
	end
	local v58 = v56.MinKg
	local v59 = math.log(v58)
	local v60 = v56.MaxKg
	local v61 = v56.MinKg
	local v62 = math.max(v60, v61)
	local v63 = v59 + (math.log(v62) - v59) * v52:NextNumber()
	local v64 = math.exp(v63) + 0.5
	return math.floor(v64), v56.Label
end
function v_u_4.CloneModel(p65) -- name: CloneModel
	-- upvalues: (copy) v_u_4, (copy) v_u_1, (copy) v_u_2
	local v66 = v_u_4.Get(p65)
	if not v66 then
		return nil
	end
	local v67 = v_u_1:FindFirstChild(v_u_4.TemplateFolder)
	if v67 then
		v67 = v67:FindFirstChild(v66.Template)
	end
	if not (v67 and v67:IsA("Model")) then
		v67 = v_u_1:FindFirstChild(v66.Template)
	end
	if not (v67 and v67:IsA("Model")) then
		warn((("[EggTypeConfig] %*: ReplicatedStorage.%*.%* (Model) not found"):format(p65, v_u_4.TemplateFolder, v66.Template)))
		return nil
	end
	local v68 = v67:Clone()
	for _, v69 in v68:GetDescendants() do
		if not (v69:IsA("LuaSourceContainer") or v69:IsA("ProximityPrompt")) then
			continue
		end
		v69:Destroy()
	end
	for _, v70 in { "AnimSaves", "InitialPoses" } do
		local v71 = v68:FindFirstChild(v70)
		if not v71 then
			continue
		end
		v71:Destroy()
	end
	local v72
	if v66.Body then
		v72 = v68:FindFirstChild(v66.Body, true)
	else
		v72 = nil
	end
	if not (v72 and v72:IsA("BasePart")) then
		v72 = v68.PrimaryPart or v68:FindFirstChildWhichIsA("BasePart", true)
	end
	if not v72 then
		v68:Destroy()
		return nil
	end
	v68.PrimaryPart = v72
	v72.PivotOffset = CFrame.identity
	local v73 = v72:FindFirstChild(v_u_2.FrameAttachmentName)
	if v73 then
		v73:Destroy()
	end
	local v74 = Instance.new("Attachment")
	v74.Name = v_u_2.FrameAttachmentName
	v74.CFrame = CFrame.new(v66.BodyCenter or Vector3.new(0, 0, 0)) * CFrame.lookAt(Vector3.new(0, 0, 0), v66.Front)
	v74:SetAttribute("AuthoredFacing", CFrame.lookAt(Vector3.new(0, 0, 0), v66.Front).Rotation)
	v74.Parent = v72
	return v68
end
function v_u_4.DisplayName(p75, p76) -- name: DisplayName
	-- upvalues: (copy) v_u_4, (copy) v_u_3
	local v77 = v_u_4.Get(p75)
	if v77 then
		return v77.DisplayName
	else
		return ("%* Egg"):format((v_u_3.DisplayName(p76)))
	end
end
return v_u_4
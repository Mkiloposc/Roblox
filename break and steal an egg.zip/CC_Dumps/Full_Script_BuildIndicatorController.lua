local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = require(v_u_3.Shared.MergeConfig)
local v_u_7 = require(script.Parent.OwnBase)
local v8 = {}
local v_u_9 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_10 = Color3.fromRGB(255, 60, 50)
local v_u_11 = v2.LocalPlayer
local v_u_12 = nil
local v_u_13 = 0
local v_u_14 = nil
local v_u_15 = v_u_7.Get
local v_u_16 = v_u_7.Hitbox
local function v_u_19() -- name: holdingPlaceableTool
	-- upvalues: (copy) v_u_11, (copy) v_u_1, (copy) v_u_6
	local v17 = v_u_11.Character
	if not v17 then
		return nil
	end
	for _, v18 in v17:GetChildren() do
		if not v18:IsA("Tool") then
			continue
		end
		if v_u_1:HasTag(v18, "AnimalTool") then
			return "animal"
		end
		if not v_u_1:HasTag(v18, v_u_6.EggToolTag) then
			continue
		end
		return "egg"
	end
	return nil
end
local function v_u_26() -- name: updateColor
	-- upvalues: (ref) v_u_12, (ref) v_u_14, (copy) v_u_19, (copy) v_u_15, (copy) v_u_10
	if v_u_12 and (v_u_12.Parent and v_u_14) then
		local v20
		if v_u_19() == "animal" then
			local v21 = v_u_15()
			if v21 then
				local v22 = v21:GetAttribute("AnimalsPlaced") or 0
				local v23 = v21:GetAttribute("MaxAnimals")
				if typeof(v23) == "number" then
					v20 = v23 <= v22
				else
					v20 = false
				end
			else
				v20 = false
			end
		else
			v20 = false
		end
		local v24 = v_u_12
		local v25
		if v20 then
			v25 = v_u_10
		else
			v25 = v_u_14
		end
		v24.Color = v25
	end
end
local function v_u_32(p27, p28) -- name: applyFootprint
	local v29 = p28.Size.X - 0.15
	local v30 = p27.Size.Y
	local v31 = p28.Size.Z - 0.15
	p27.Size = Vector3.new(v29, v30, v31)
	p27.CFrame = p28.CFrame * CFrame.new(0, -p28.Size.Y / 2 + p27.Size.Y / 2, 0)
end
local function v_u_34() -- name: refit
	-- upvalues: (copy) v_u_16, (ref) v_u_12, (copy) v_u_32
	local v33 = v_u_16()
	if v_u_12 and (v_u_12.Parent and v33) then
		v_u_32(v_u_12, v33)
	end
end
local function v_u_38() -- name: ensureIndicator
	-- upvalues: (ref) v_u_12, (copy) v_u_16, (copy) v_u_3, (ref) v_u_13, (ref) v_u_14, (copy) v_u_32, (copy) v_u_5
	if v_u_12 and v_u_12.Parent then
		return v_u_12
	end
	local v35 = v_u_16()
	local v36 = v_u_3:FindFirstChild("BuildIndicator")
	if not (v35 and (v36 and v36:IsA("BasePart"))) then
		return nil
	end
	local v37 = v36:Clone()
	v_u_13 = v37.Transparency
	v_u_14 = v37.Color
	v_u_32(v37, v35)
	v37.Transparency = 1
	v37.Anchored = true
	v37.CanCollide = false
	v37.CanQuery = false
	v37.CanTouch = false
	v37.Parent = v_u_5
	v_u_12 = v37
	return v37
end
local function v_u_46() -- name: show
	-- upvalues: (copy) v_u_38, (ref) v_u_12, (ref) v_u_14, (copy) v_u_19, (copy) v_u_15, (copy) v_u_10, (copy) v_u_4, (copy) v_u_9, (ref) v_u_13
	local v39 = v_u_38()
	if v39 then
		if v_u_12 and (v_u_12.Parent and v_u_14) then
			local v40
			if v_u_19() == "animal" then
				local v41 = v_u_15()
				if v41 then
					local v42 = v41:GetAttribute("AnimalsPlaced") or 0
					local v43 = v41:GetAttribute("MaxAnimals")
					if typeof(v43) == "number" then
						v40 = v43 <= v42
					else
						v40 = false
					end
				else
					v40 = false
				end
			else
				v40 = false
			end
			local v44 = v_u_12
			local v45
			if v40 then
				v45 = v_u_10
			else
				v45 = v_u_14
			end
			v44.Color = v45
		end
		v_u_4:Create(v39, v_u_9, {
			["Transparency"] = v_u_13
		}):Play()
	end
end
local function v_u_47() -- name: refresh
	-- upvalues: (copy) v_u_19, (copy) v_u_46, (ref) v_u_12, (copy) v_u_4, (copy) v_u_9
	if v_u_19() == nil then
		if v_u_12 and v_u_12.Parent then
			v_u_4:Create(v_u_12, v_u_9, {
				["Transparency"] = 1
			}):Play()
		end
	else
		v_u_46()
	end
end
function v8.Start() -- name: Start
	-- upvalues: (copy) v_u_47, (copy) v_u_19, (copy) v_u_46, (ref) v_u_12, (copy) v_u_4, (copy) v_u_9, (copy) v_u_11, (copy) v_u_7, (copy) v_u_26, (copy) v_u_34, (copy) v_u_16, (copy) v_u_32
	local v_u_48 = {}
	local function v59(p49) -- name: hookCharacter
		-- upvalues: (copy) v_u_48, (ref) v_u_47, (ref) v_u_19, (ref) v_u_46, (ref) v_u_12, (ref) v_u_4, (ref) v_u_9
		for _, v50 in v_u_48 do
			v50:Disconnect()
		end
		table.clear(v_u_48)
		local v51 = v_u_48
		local v52 = p49.ChildAdded
		local function v54(p53)
			-- upvalues: (ref) v_u_47
			if p53:IsA("Tool") then
				task.defer(v_u_47)
			end
		end
		table.insert(v51, v52:Connect(v54))
		local v55 = v_u_48
		local v56 = p49.ChildRemoved
		local function v58(p57)
			-- upvalues: (ref) v_u_47
			if p57:IsA("Tool") then
				task.defer(v_u_47)
			end
		end
		table.insert(v55, v56:Connect(v58))
		if v_u_19() == nil then
			if v_u_12 and v_u_12.Parent then
				v_u_4:Create(v_u_12, v_u_9, {
					["Transparency"] = 1
				}):Play()
			end
		else
			v_u_46()
		end
	end
	if v_u_11.Character then
		v59(v_u_11.Character)
	end
	v_u_11.CharacterAdded:Connect(v59)
	v_u_11.CharacterRemoving:Connect(function()
		-- upvalues: (copy) v_u_48, (ref) v_u_12, (ref) v_u_4, (ref) v_u_9
		for _, v60 in v_u_48 do
			v60:Disconnect()
		end
		table.clear(v_u_48)
		if v_u_12 and v_u_12.Parent then
			v_u_4:Create(v_u_12, v_u_9, {
				["Transparency"] = 1
			}):Play()
		end
	end)
	local v_u_61 = {}
	local v_u_62 = nil
	v_u_7.Observe(function(p63)
		-- upvalues: (ref) v_u_62, (copy) v_u_61, (ref) v_u_26, (ref) v_u_34, (ref) v_u_16, (ref) v_u_12, (ref) v_u_32, (ref) v_u_19, (ref) v_u_46, (ref) v_u_4, (ref) v_u_9
		v_u_62 = p63
		for _, v64 in v_u_61 do
			v64:Disconnect()
		end
		table.clear(v_u_61)
		local v65 = v_u_61
		local v66 = p63:GetAttributeChangedSignal("AnimalsPlaced")
		local v67 = v_u_26
		table.insert(v65, v66:Connect(v67))
		local v68 = v_u_61
		local v69 = p63:GetAttributeChangedSignal("MaxAnimals")
		local v70 = v_u_26
		table.insert(v68, v69:Connect(v70))
		local v71 = p63:WaitForChild("Hitbox", 10)
		if v_u_62 == p63 then
			if v71 and v71:IsA("BasePart") then
				local v72 = v_u_61
				local v73 = v71:GetPropertyChangedSignal("Size")
				local v74 = v_u_34
				table.insert(v72, v73:Connect(v74))
				local v75 = v_u_61
				local v76 = v71:GetPropertyChangedSignal("CFrame")
				local v77 = v_u_34
				table.insert(v75, v76:Connect(v77))
			end
			local v78 = v_u_16()
			if v_u_12 and (v_u_12.Parent and v78) then
				v_u_32(v_u_12, v78)
			end
			if v_u_19() == nil then
				if v_u_12 and v_u_12.Parent then
					v_u_4:Create(v_u_12, v_u_9, {
						["Transparency"] = 1
					}):Play()
				end
			else
				v_u_46()
			end
		else
			return
		end
	end)
end
return v8
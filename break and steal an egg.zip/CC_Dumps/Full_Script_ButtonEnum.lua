return {
	["SkipButton"] = "SkipButton",
	["NextButton"] = "NextButton"
}
local v_u_1 = { 0.05, 0.1, 0.2 }
local v2 = {}
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Chat")
v_u_4:WaitForChild("ClientChatModules")
local v5 = script.Parent
local v6 = v_u_4:WaitForChild("ClientChatModules")
local v_u_7 = {
	["ChatColor"] = require(v6:WaitForChild("ChatSettings")).ErrorMessageTextColor or Color3.fromRGB(245, 50, 50)
}
local v_u_8 = require(v6:WaitForChild("ChatConstants"))
local v_u_9 = require(v5:WaitForChild("ChatChannel"))
local v_u_10 = require(v5:WaitForChild("Speaker"))
local v_u_11 = require(v5:WaitForChild("Util"))
local v_u_12 = nil
pcall(function()
	-- upvalues: (ref) v_u_12
	v_u_12 = require(game:GetService("Chat").ClientChatModules.ChatLocalization)
end)
v_u_12 = v_u_12 or {}
if not (v_u_12.FormatMessageToSend and v_u_12.LocalizeFormattedMessage) then
	function v_u_12.FormatMessageToSend(_, _, p13) -- name: FormatMessageToSend
		return p13
	end
end
local v_u_14 = {}
v_u_14.__index = v_u_14
function v_u_14.AddChannel(p_u_15, p_u_16, p17) -- name: AddChannel
	-- upvalues: (ref) v_u_12, (copy) v_u_9, (copy) v_u_8
	if p_u_15.ChatChannels[p_u_16:lower()] then
		error(string.format("Channel %q alrady exists.", p_u_16))
	end
	local function v22(p18, p19) -- name: DefaultChannelCommands
		-- upvalues: (copy) p_u_15, (copy) p_u_16, (ref) v_u_12
		if p19:lower() ~= "/leave" then
			return false
		end
		local v20 = p_u_15:GetChannel(p_u_16)
		local v21 = p_u_15:GetSpeaker(p18)
		if v20 and v21 then
			if v20.Leavable then
				v21:LeaveChannel(p_u_16)
				v21:SendSystemMessage(v_u_12:FormatMessageToSend("GameChat_ChatService_YouHaveLeftChannel", string.format("You have left channel \'%s\'", p_u_16), "RBX_NAME", p_u_16), "System")
			else
				v21:SendSystemMessage(v_u_12:FormatMessageToSend("GameChat_ChatService_CannotLeaveChannel", "You cannot leave this channel."), p_u_16)
			end
		end
		return true
	end
	local v23 = v_u_9.new(p_u_15, p_u_16)
	p_u_15.ChatChannels[p_u_16:lower()] = v23
	v23:RegisterProcessCommandsFunction("default_commands", v22, v_u_8.HighPriority)
	local v24, v25 = pcall(function()
		-- upvalues: (copy) p_u_15, (copy) p_u_16
		p_u_15.eChannelAdded:Fire(p_u_16)
	end)
	if not v24 and v25 then
		print("Error addding channel: " .. v25)
	end
	if p17 ~= nil then
		v23.AutoJoin = p17
		if p17 then
			for _, v26 in pairs(p_u_15.Speakers) do
				v26:JoinChannel(p_u_16)
			end
		end
	end
	return v23
end
function v_u_14.RemoveChannel(p_u_27, p28) -- name: RemoveChannel
	if p_u_27.ChatChannels[p28:lower()] then
		local v_u_29 = p_u_27.ChatChannels[p28:lower()].Name
		p_u_27.ChatChannels[p28:lower()]:InternalDestroy()
		p_u_27.ChatChannels[p28:lower()] = nil
		local v30, v31 = pcall(function()
			-- upvalues: (copy) p_u_27, (copy) v_u_29
			p_u_27.eChannelRemoved:Fire(v_u_29)
		end)
		if not v30 and v31 then
			print("Error removing channel: " .. v31)
			return
		end
	else
		warn(string.format("Channel %q does not exist.", p28))
	end
end
function v_u_14.GetChannel(p32, p33) -- name: GetChannel
	return p32.ChatChannels[p33:lower()]
end
function v_u_14.AddSpeaker(p_u_34, p_u_35) -- name: AddSpeaker
	-- upvalues: (copy) v_u_10
	if p_u_34.Speakers[p_u_35:lower()] then
		error("Speaker \"" .. p_u_35 .. "\" already exists!")
	end
	local v36 = v_u_10.new(p_u_34, p_u_35)
	p_u_34.Speakers[p_u_35:lower()] = v36
	local v37, v38 = pcall(function()
		-- upvalues: (copy) p_u_34, (copy) p_u_35
		p_u_34.eSpeakerAdded:Fire(p_u_35)
	end)
	if not v37 and v38 then
		print("Error adding speaker: " .. v38)
	end
	return v36
end
function v_u_14.InternalUnmuteSpeaker(p39, p40) -- name: InternalUnmuteSpeaker
	for _, v41 in pairs(p39.ChatChannels) do
		if not v41:IsSpeakerMuted(p40) then
			continue
		end
		v41:UnmuteSpeaker(p40)
	end
end
function v_u_14.RemoveSpeaker(p_u_42, p43) -- name: RemoveSpeaker
	if p_u_42.Speakers[p43:lower()] then
		local v_u_44 = p_u_42.Speakers[p43:lower()].Name
		p_u_42:InternalUnmuteSpeaker(v_u_44)
		p_u_42.Speakers[p43:lower()]:InternalDestroy()
		p_u_42.Speakers[p43:lower()] = nil
		local v45, v46 = pcall(function()
			-- upvalues: (copy) p_u_42, (copy) v_u_44
			p_u_42.eSpeakerRemoved:Fire(v_u_44)
		end)
		if not v45 and v46 then
			print("Error removing speaker: " .. v46)
			return
		end
	else
		warn("Speaker \"" .. p43 .. "\" does not exist!")
	end
end
function v_u_14.GetSpeaker(p47, p48) -- name: GetSpeaker
	return p47.Speakers[p48:lower()]
end
function v_u_14.GetSpeakerByUserOrDisplayName(p49, p50) -- name: GetSpeakerByUserOrDisplayName
	local v51 = p49.Speakers[p50:lower()]
	if v51 then
		return v51
	end
	for _, v52 in pairs(p49.Speakers) do
		local v53 = v52:GetPlayer()
		if not v53 or v53.DisplayName:lower() ~= p50:lower() then
			continue
		end
		return v52
	end
end
function v_u_14.GetChannelList(p54) -- name: GetChannelList
	local v55 = {}
	for _, v56 in pairs(p54.ChatChannels) do
		if v56.Private then
			continue
		end
		local v57 = v56.Name
		table.insert(v55, v57)
	end
	return v55
end
function v_u_14.GetAutoJoinChannelList(p58) -- name: GetAutoJoinChannelList
	local v59 = {}
	for _, v60 in pairs(p58.ChatChannels) do
		if not v60.AutoJoin then
			continue
		end
		table.insert(v59, v60)
	end
	return v59
end
function v_u_14.GetSpeakerList(p61) -- name: GetSpeakerList
	local v62 = {}
	for _, v63 in pairs(p61.Speakers) do
		local v64 = v63.Name
		table.insert(v62, v64)
	end
	return v62
end
function v_u_14.SendGlobalSystemMessage(p65, p66) -- name: SendGlobalSystemMessage
	for _, v67 in pairs(p65.Speakers) do
		v67:SendSystemMessage(p66, nil)
	end
end
function v_u_14.RegisterFilterMessageFunction(p68, p69, p70, p71) -- name: RegisterFilterMessageFunction
	if p68.FilterMessageFunctions:HasFunction(p69) then
		error(string.format("FilterMessageFunction \'%s\' already exists", p69))
	end
	p68.FilterMessageFunctions:AddFunction(p69, p70, p71)
end
function v_u_14.FilterMessageFunctionExists(p72, p73) -- name: FilterMessageFunctionExists
	return p72.FilterMessageFunctions:HasFunction(p73)
end
function v_u_14.UnregisterFilterMessageFunction(p74, p75) -- name: UnregisterFilterMessageFunction
	if not p74.FilterMessageFunctions:HasFunction(p75) then
		error(string.format("FilterMessageFunction \'%s\' does not exists", p75))
	end
	p74.FilterMessageFunctions:RemoveFunction(p75)
end
function v_u_14.RegisterProcessCommandsFunction(p76, p77, p78, p79) -- name: RegisterProcessCommandsFunction
	if p76.ProcessCommandsFunctions:HasFunction(p77) then
		error(string.format("ProcessCommandsFunction \'%s\' already exists", p77))
	end
	p76.ProcessCommandsFunctions:AddFunction(p77, p78, p79)
end
function v_u_14.ProcessCommandsFunctionExists(p80, p81) -- name: ProcessCommandsFunctionExists
	return p80.ProcessCommandsFunctions:HasFunction(p81)
end
function v_u_14.UnregisterProcessCommandsFunction(p82, p83) -- name: UnregisterProcessCommandsFunction
	if not p82.ProcessCommandsFunctions:HasFunction(p83) then
		error(string.format("ProcessCommandsFunction \'%s\' does not exist", p83))
	end
	p82.ProcessCommandsFunctions:RemoveFunction(p83)
end
local v_u_84 = 0
local v_u_85 = 0
local v_u_86 = 0
function v_u_14.InternalNotifyFilterIssue(p87) -- name: InternalNotifyFilterIssue
	-- upvalues: (ref) v_u_85, (ref) v_u_86, (ref) v_u_84, (ref) v_u_12, (copy) v_u_7
	if tick() - v_u_85 > 60 then
		v_u_86 = 0
	end
	v_u_86 = v_u_86 + 1
	v_u_85 = tick()
	if v_u_86 >= 3 and tick() - v_u_84 > 60 then
		v_u_84 = tick()
		local v88 = p87:GetChannel("System")
		if v88 then
			v88:SendSystemMessage(v_u_12:FormatMessageToSend("GameChat_ChatService_ChatFilterIssues", "The chat filter is currently experiencing issues and messages may be slow to appear."), v_u_7)
		end
	end
end
local v_u_89 = {}
function v_u_14.InternalApplyRobloxFilter(p90, p91, p_u_92, p_u_93) -- name: InternalApplyRobloxFilter
	-- upvalues: (copy) v_u_3, (copy) v_u_4, (copy) v_u_1, (copy) v_u_89
	if not v_u_3:IsServer() or v_u_3:IsStudio() then
		if not v_u_89[p_u_92] then
			v_u_89[p_u_92] = true
			wait()
		end
		return p_u_92
	end
	local v94 = p90:GetSpeaker(p91)
	if p_u_93 then
		p_u_93 = p90:GetSpeaker(p_u_93)
	end
	if v94 == nil then
		return nil
	end
	local v_u_95 = v94:GetPlayer()
	if p_u_93 then
		p_u_93 = p_u_93:GetPlayer()
	end
	if v_u_95 == nil then
		return p_u_92
	end
	local v96 = string.gsub(p_u_92, " ", "")
	if string.len(v96) == 0 then
		return p_u_92
	end
	local v97 = tick()
	local v98 = 0
	while true do
		local v99, v100 = pcall(function()
			-- upvalues: (copy) p_u_93, (ref) v_u_4, (copy) p_u_92, (copy) v_u_95
			if p_u_93 then
				return v_u_4:FilterStringAsync(p_u_92, v_u_95, p_u_93)
			else
				return v_u_4:FilterStringForBroadcast(p_u_92, v_u_95)
			end
		end)
		if v99 then
			break
		end
		warn("Error filtering message:", v100)
		v98 = v98 + 1
		if v98 > 3 or tick() - v97 > 60 then
			p90:InternalNotifyFilterIssue()
			return nil
		end
		local v101 = v_u_1
		local v102 = #v_u_1
		local v103 = v101[math.min(v102, v98)]
		local v104 = v103 + (math.random() * 2 - 1) * v103
		wait(v104)
	end
	return v100
end
function v_u_14.InternalApplyRobloxFilterAndTranslate(p105, p106, p_u_107, p_u_108, p_u_109) -- name: InternalApplyRobloxFilterAndTranslate
	-- upvalues: (copy) v_u_3
	local v110 = v_u_3:IsServer()
	if v110 then
		v110 = not v_u_3:IsStudio()
	end
	if not v110 then
		wait()
		return true, false, p_u_108
	end
	local v111 = p105:GetSpeaker(p106)
	if v111 == nil then
		return false, nil, nil
	end
	local v_u_112 = v111:GetPlayer()
	if v_u_112 == nil then
		return true, false, p_u_108
	end
	local v113 = string.gsub(p_u_108, " ", "")
	if string.len(v113) == 0 then
		return true, false, p_u_108
	end
	local v114, v115 = pcall(function()
		-- upvalues: (copy) p_u_108, (copy) v_u_112, (copy) p_u_107, (copy) p_u_109
		return game:GetService("TextService"):FilterAndTranslateStringAsync(p_u_108, v_u_112.UserId, p_u_107, p_u_109)
	end)
	if v114 then
		return true, true, v115
	end
	warn("Error filtering and translating message", p_u_108, v115)
	p105:InternalNotifyFilterIssue()
	return false, nil, nil
end
function v_u_14.InternalApplyRobloxFilterNewAPI(p116, p117, p_u_118, p_u_119) -- name: InternalApplyRobloxFilterNewAPI
	-- upvalues: (copy) v_u_3
	local v120 = v_u_3:IsServer()
	if v120 then
		v120 = not v_u_3:IsStudio()
	end
	if not v120 then
		wait()
		return true, false, p_u_118
	end
	local v121 = p116:GetSpeaker(p117)
	if v121 == nil then
		return false, nil, nil
	end
	local v_u_122 = v121:GetPlayer()
	if v_u_122 == nil then
		return true, false, p_u_118
	end
	local v123 = string.gsub(p_u_118, " ", "")
	if string.len(v123) == 0 then
		return true, false, p_u_118
	end
	local v124, v125 = pcall(function()
		-- upvalues: (copy) p_u_118, (copy) v_u_122, (copy) p_u_119
		return game:GetService("TextService"):FilterStringAsync(p_u_118, v_u_122.UserId, p_u_119)
	end)
	if v124 then
		return true, true, v125
	end
	warn("Error filtering message:", p_u_118, v125)
	p116:InternalNotifyFilterIssue()
	return false, nil, nil
end
function v_u_14.InternalDoMessageFilter(p126, p_u_127, p_u_128, p_u_129) -- name: InternalDoMessageFilter
	for v130, v_u_131, _ in p126.FilterMessageFunctions:GetIterator() do
		local v132, v133 = pcall(function()
			-- upvalues: (copy) v_u_131, (copy) p_u_127, (copy) p_u_128, (copy) p_u_129
			v_u_131(p_u_127, p_u_128, p_u_129)
		end)
		if v132 then
			continue
		end
		warn(string.format("DoMessageFilter Function \'%s\' failed for reason: %s", v130, v133))
	end
end
function v_u_14.InternalDoProcessCommands(p134, p_u_135, p_u_136, p_u_137) -- name: InternalDoProcessCommands
	for v138, v_u_139, _ in p134.ProcessCommandsFunctions:GetIterator() do
		local v141, v142 = pcall(function()
			-- upvalues: (copy) v_u_139, (copy) p_u_135, (copy) p_u_136, (copy) p_u_137
			local v140 = v_u_139(p_u_135, p_u_136, p_u_137)
			if type(v140) ~= "boolean" then
				error("Process command functions must return a bool")
			end
			return v140
		end)
		if v141 then
			if not v142 then
				continue
			end
			return true
		end
		warn(string.format("DoProcessCommands Function \'%s\' failed for reason: %s", v138, v142))
	end
	return false
end
function v_u_14.InternalGetUniqueMessageId(p143) -- name: InternalGetUniqueMessageId
	local v144 = p143.MessageIdCounter
	p143.MessageIdCounter = v144 + 1
	return v144
end
function v_u_14.InternalAddSpeakerWithPlayerObject(p_u_145, p_u_146, p147, p148) -- name: InternalAddSpeakerWithPlayerObject
	-- upvalues: (copy) v_u_10
	if p_u_145.Speakers[p_u_146:lower()] then
		error("Speaker \"" .. p_u_146 .. "\" already exists!")
	end
	local v149 = v_u_10.new(p_u_145, p_u_146)
	v149:InternalAssignPlayerObject(p147)
	p_u_145.Speakers[p_u_146:lower()] = v149
	if p148 then
		local v150, v151 = pcall(function()
			-- upvalues: (copy) p_u_145, (copy) p_u_146
			p_u_145.eSpeakerAdded:Fire(p_u_146)
		end)
		if not v150 and v151 then
			print("Error adding speaker: " .. v151)
		end
	end
	return v149
end
function v_u_14.InternalFireSpeakerAdded(p_u_152, p_u_153) -- name: InternalFireSpeakerAdded
	local v154, v155 = pcall(function()
		-- upvalues: (copy) p_u_152, (copy) p_u_153
		p_u_152.eSpeakerAdded:Fire(p_u_153)
	end)
	if not v154 and v155 then
		print("Error firing speaker added: " .. v155)
	end
end
function v2.new() -- name: new
	-- upvalues: (copy) v_u_14, (copy) v_u_11
	local v156 = v_u_14
	local v157 = setmetatable({}, v156)
	v157.MessageIdCounter = 0
	v157.ChatChannels = {}
	v157.Speakers = {}
	v157.FilterMessageFunctions = v_u_11:NewSortedFunctionContainer()
	v157.ProcessCommandsFunctions = v_u_11:NewSortedFunctionContainer()
	v157.eChannelAdded = Instance.new("BindableEvent")
	v157.eChannelRemoved = Instance.new("BindableEvent")
	v157.eSpeakerAdded = Instance.new("BindableEvent")
	v157.eSpeakerRemoved = Instance.new("BindableEvent")
	v157.ChannelAdded = v157.eChannelAdded.Event
	v157.ChannelRemoved = v157.eChannelRemoved.Event
	v157.SpeakerAdded = v157.eSpeakerAdded.Event
	v157.SpeakerRemoved = v157.eSpeakerRemoved.Event
	v157.ChatServiceMajorVersion = 0
	v157.ChatServiceMinorVersion = 5
	return v157
end
return v2.new()
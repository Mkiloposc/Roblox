return {
	["Attribute"] = "CheaterMode",
	["FlyKey"] = nil,
	["SpeedKey"] = nil,
	["FlyUpKey"] = nil,
	["FlyDownKey"] = nil,
	["SpeedMultiplier"] = 3,
	["FlyMinSpeed"] = 30,
	["TeleportRange"] = 2000,
	["ForgivenNotifyCooldownSeconds"] = 1,
	["FlyKey"] = Enum.KeyCode.F,
	["SpeedKey"] = Enum.KeyCode.Q,
	["FlyUpKey"] = Enum.KeyCode.Space,
	["FlyDownKey"] = Enum.KeyCode.LeftControl
}
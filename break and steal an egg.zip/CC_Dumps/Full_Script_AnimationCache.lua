local v_u_1 = game:GetService("ContentProvider")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(v3.Shared.AnimationAssets)
local v_u_5 = require(v3.Shared.WaitFor)
local v_u_6 = {}
local v_u_7 = v2.LocalPlayer
local v_u_8 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_9 = false
local v_u_10 = false
function v_u_6.WarmAssets() -- name: WarmAssets
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (copy) v_u_5, (copy) v_u_4, (copy) v_u_1
	if v_u_9 then
		return
	elseif v_u_10 then
		v_u_5.Until(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_10
			return v_u_9 or not v_u_10
		end, 60)
	else
		v_u_10 = true
		local v11 = v_u_4.PreloadList()
		if #v11 > 0 then
			local v12 = v_u_1.PreloadAsync
			local v13 = v_u_1
			pcall(v12, v13, v11)
		end
		v_u_9 = true
		v_u_10 = false
	end
end
local function v_u_17(p14) -- name: getAnimator
	local v15 = p14:FindFirstChildOfClass("Humanoid") or p14:WaitForChild("Humanoid", 10)
	if v15 and v15:IsA("Humanoid") then
		local v16 = v15:FindFirstChildOfClass("Animator") or v15:WaitForChild("Animator", 10)
		if v16 and v16:IsA("Animator") then
			return v16
		else
			return nil
		end
	else
		return nil
	end
end
local function v_u_27(p18, p19, p20, p21) -- name: loadTrack
	-- upvalues: (copy) v_u_17, (copy) v_u_4
	local v22 = v_u_17(p18)
	if not v22 or p18.Parent == nil then
		return nil
	end
	local v23 = v22.LoadAnimation
	local v24 = v_u_4.Get
	local v25, v26 = pcall(v23, v22, v24(p19))
	if not (v25 and v26) then
		warn((("[AnimationCache] couldn\'t load %*: %*"):format(p19, v26)))
		return nil
	end
	v26.Looped = p21 ~= false
	v26.Priority = p20 or Enum.AnimationPriority.Action
	return v26
end
function v_u_6.Track(p28, p29, p30, p31) -- name: Track
	-- upvalues: (copy) v_u_8, (copy) v_u_27
	if p28 == nil or (p29 == nil or p29 == "") then
		return nil
	else
		local v32 = v_u_8[p28]
		if v32 == nil then
			v32 = {}
			v_u_8[p28] = v32
		end
		local v33 = v32[p29]
		if v33 == nil then
			local v34 = v_u_27(p28, p29, p30, p31)
			local v35 = v32[p29]
			if v35 == nil then
				if v34 then
					v32[p29] = v34
				end
				return v34
			else
				if v34 and v34 ~= v35 then
					v34:Destroy()
				end
				return v35
			end
		else
			return v33
		end
	end
end
function v_u_6.Warm(p_u_36, p37, p38, p39) -- name: Warm
	-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_8
	local v_u_40 = v_u_6.Track(p_u_36, p37, p38, p39)
	if v_u_40 == nil or (p_u_36 == nil or p37 == nil) then
		return v_u_40
	end
	for v41 = 1, 2 do
		local v_u_42 = false
		v_u_5.Until(function()
			-- upvalues: (copy) p_u_36, (ref) v_u_42, (ref) v_u_40
			if p_u_36.Parent ~= nil then
				return v_u_40.Length > 0
			end
			v_u_42 = true
			return true
		end, 4)
		if v_u_42 then
			return nil
		end
		if v_u_40.Length > 0 or v41 == 2 then
			break
		end
		v_u_6.WarmAssets()
		local v43 = v_u_8[p_u_36]
		if v43 then
			v43[p37] = nil
		end
		local v44 = v_u_6.Track(p_u_36, p37, p38, p39)
		if v44 == nil then
			return nil
		end
		local v45 = v44
		v_u_40 = v45
	end
	return v_u_40
end
function v_u_6.WarmCharacter(p46) -- name: WarmCharacter
	-- upvalues: (copy) v_u_6, (copy) v_u_4
	v_u_6.WarmAssets()
	for _, v47 in v_u_4.Character do
		if p46.Parent == nil then
			return
		end
		v_u_6.Warm(p46, v47.Id, v47.Priority, v47.Looped)
	end
end
function v_u_6.Start() -- name: Start
	-- upvalues: (copy) v_u_6, (copy) v_u_7
	task.spawn(v_u_6.WarmAssets)
	v_u_7.CharacterAdded:Connect(function(p48)
		-- upvalues: (ref) v_u_6
		task.spawn(v_u_6.WarmCharacter, p48)
	end)
	if v_u_7.Character then
		task.spawn(v_u_6.WarmCharacter, v_u_7.Character)
	end
end
return v_u_6
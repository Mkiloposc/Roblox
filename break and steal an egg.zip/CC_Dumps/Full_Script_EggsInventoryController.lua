local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = require(v_u_3.Shared.AnimalRenders)
local v_u_6 = require(v_u_3.Shared.ChaseState)
local v_u_7 = require(v_u_3.Shared.EggTypeConfig)
local v_u_8 = require(v_u_3.Shared.MergeConfig)
local v_u_9 = require(script.Parent.UiFrames)
local v_u_10 = require(script.Parent.Parent.Modules.MainGui)
local v_u_11 = require(script.Parent.Parent.Modules.EggGrowthBoostText)
local v12 = {}
local v_u_13 = v2.LocalPlayer
local v_u_14 = {}
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = nil
local function v_u_21(p19, ...) -- name: fireRemote
	-- upvalues: (copy) v_u_3, (copy) v_u_8
	local v20 = v_u_3:FindFirstChild(v_u_8.RemoteName)
	if v20 and v20:IsA("RemoteEvent") then
		v20:FireServer(p19, ...)
	end
end
local function v_u_34() -- name: resortRows
	-- upvalues: (copy) v_u_14
	local v22 = {}
	for _, v23 in v_u_14 do
		table.insert(v22, v23)
	end
	table.sort(v22, function(p24, p25)
		local v26 = p24.Model:GetAttribute("Ready") == true
		if v26 ~= (p25.Model:GetAttribute("Ready") == true) then
			return v26
		end
		local v27 = p24.Model:GetAttribute("ReadyAtServerTime") or 0
		local v28 = p25.Model:GetAttribute("ReadyAtServerTime") or 0
		if v27 ~= v28 then
			return v27 < v28
		end
		local v29 = p24.Model
		local v30 = tostring(v29:GetAttribute("EggId"))
		local v31 = p25.Model
		return v30 < tostring(v31:GetAttribute("EggId"))
	end)
	for v32, v33 in v22 do
		v33.Frame.LayoutOrder = v32
	end
end
local function v_u_49(p35) -- name: updateRow
	-- upvalues: (copy) v_u_8, (copy) v_u_11
	local v36 = p35.Model
	local v37, v38 = v_u_8.RemainingSeconds(v36)
	local v39 = v36:GetAttribute("Ready") == true
	local v40 = p35.Ready ~= v39
	if v40 then
		p35.Ready = v39
		if p35.Open then
			p35.Open.Visible = v39
		end
		if p35.Timer then
			p35.Timer.Visible = not v39
		end
		if p35.Skip then
			p35.Skip.Visible = not v39
		end
	end
	if v39 then
		return v40
	end
	local v41 = p35.TimerTitle
	if v41 then
		local v42 = math.ceil(v37)
		local v43 = math.max(v42, 0)
		local v44 = v_u_11.MultiplierFor(p35.Model)
		if v43 ~= p35.TextSeconds or v44 ~= p35.TextMultiplier then
			p35.TextSeconds = v43
			p35.TextMultiplier = v44
			local v45 = v_u_11.Decorate(v41, p35.Model, string.lower(v_u_8.FormatDuration(v37)))
			if v45 ~= p35.Text then
				p35.Text = v45
				v41.Text = v45
			end
		end
	end
	if p35.Bar and p35.BarY then
		local v46
		if v38 > 0 then
			local v47 = 1 - v37 / v38
			v46 = math.clamp(v47, 0, 1)
		else
			v46 = 1
		end
		local v48 = v46 - (p35.LastProgress or -1)
		if math.abs(v48) > 0.001 then
			p35.LastProgress = v46
			p35.Bar.Position = UDim2.new(v46, 0, p35.BarY.Scale, p35.BarY.Offset)
		end
	end
	return v40
end
local function v_u_53(p50) -- name: removeRow
	-- upvalues: (copy) v_u_14
	local v51 = v_u_14[p50]
	if v51 then
		v_u_14[p50] = nil
		for _, v52 in v51.Connections do
			v52:Disconnect()
		end
		v51.Frame:Destroy()
	end
end
local function v_u_83(p_u_54) -- name: addRow
	-- upvalues: (ref) v_u_17, (ref) v_u_18, (copy) v_u_14, (copy) v_u_13, (copy) v_u_7, (copy) v_u_5, (copy) v_u_21, (copy) v_u_49, (copy) v_u_34
	local v55 = v_u_17
	local v56 = v_u_18
	if v55 and (v56 and not v_u_14[p_u_54]) then
		local v57 = p_u_54:IsA("Model")
		if v57 then
			v57 = p_u_54:GetAttribute("OwnerUserId") == v_u_13.UserId
		end
		if v57 then
			local v58 = p_u_54:GetAttribute("AnimalName")
			if typeof(v58) == "string" then
				local v59 = v56:Clone()
				v59.Name = "Entry"
				v59.Visible = true
				local v60 = UDim2.new
				local v61 = v55.AbsoluteWindowSize.Y * v56.Size.Y.Scale
				local v62 = math.floor(v61)
				v59.Size = v60(1, 0, 0, (math.max(v62, 1)))
				local v63 = v59:FindFirstChild("Container")
				local v64 = v_u_7.Get(p_u_54:GetAttribute(v_u_7.Attribute))
				local v65
				if v64 and v64.Icon then
					v65 = v64.Icon
				else
					v65 = v_u_5.GetEggImage(v58)
				end
				if v65 == "" then
					v65 = v_u_5.GetImage(v58)
				end
				local v66
				if v63 then
					v66 = v63:FindFirstChild("EggDisplay")
				else
					v66 = v63
				end
				if v66 and v66:IsA("ImageLabel") then
					v66.Image = v65
					local v67 = v66:FindFirstChild("Inner")
					if v67 and v67:IsA("ImageLabel") then
						v67.Image = v65
					end
				end
				local v68
				if v63 then
					v68 = v63:FindFirstChild("Timer")
				else
					v68 = v63
				end
				local v69
				if v68 then
					v69 = v68:FindFirstChild("Title")
				else
					v69 = v68
				end
				local v70
				if v68 then
					v70 = v68:FindFirstChild("Bar")
				else
					v70 = v68
				end
				local v71
				if v63 then
					v71 = v63:FindFirstChild("Open")
				else
					v71 = v63
				end
				if v63 then
					v63 = v63:FindFirstChild("Skip")
				end
				local v_u_72 = {
					["Model"] = nil,
					["Frame"] = nil,
					["Timer"] = nil,
					["TimerTitle"] = nil,
					["Bar"] = nil,
					["BarY"] = nil,
					["Open"] = nil,
					["Skip"] = nil,
					["Ready"] = nil,
					["Text"] = nil,
					["OpeningUntil"] = 0,
					["Connections"] = nil,
					["Model"] = p_u_54,
					["Frame"] = v59
				}
				if not (v68 and v68:IsA("GuiObject")) then
					v68 = nil
				end
				v_u_72.Timer = v68
				if not (v69 and v69:IsA("TextLabel")) then
					v69 = nil
				end
				v_u_72.TimerTitle = v69
				local v73
				if v70 and v70:IsA("GuiObject") then
					v73 = v70
				else
					v73 = nil
				end
				v_u_72.Bar = v73
				local v74
				if v70 and v70:IsA("GuiObject") then
					v74 = v70.Position.Y
				else
					v74 = nil
				end
				v_u_72.BarY = v74
				local v75
				if v71 and v71:IsA("GuiObject") then
					v75 = v71
				else
					v75 = nil
				end
				v_u_72.Open = v75
				local v76
				if v63 and v63:IsA("GuiObject") then
					v76 = v63
				else
					v76 = nil
				end
				v_u_72.Skip = v76
				v_u_72.Connections = {}
				if v71 and v71:IsA("GuiButton") then
					v71.Activated:Connect(function()
						-- upvalues: (copy) v_u_72, (ref) v_u_21, (copy) p_u_54
						local v77 = os.clock()
						if v_u_72.Ready and v_u_72.OpeningUntil <= v77 then
							v_u_72.OpeningUntil = v77 + 2
							v_u_21("HatchEgg", p_u_54:GetAttribute("EggId"))
						end
					end)
				end
				if v63 and v63:IsA("GuiButton") then
					v63.Activated:Connect(function()
						-- upvalues: (copy) v_u_72, (ref) v_u_21, (copy) p_u_54
						if not v_u_72.Ready then
							v_u_21("SkipEgg", p_u_54:GetAttribute("EggId"))
						end
					end)
				end
				local function v78() -- name: onStateChanged
					-- upvalues: (ref) v_u_49, (copy) v_u_72, (ref) v_u_34
					v_u_49(v_u_72)
					v_u_34()
				end
				local v79 = v_u_72.Connections
				local v80 = p_u_54:GetAttributeChangedSignal("Ready")
				table.insert(v79, v80:Connect(v78))
				local v81 = v_u_72.Connections
				local v82 = p_u_54:GetAttributeChangedSignal("ReadyAtServerTime")
				table.insert(v81, v82:Connect(v78))
				v_u_14[p_u_54] = v_u_72
				v_u_49(v_u_72)
				v59.Parent = v55
				v_u_34()
			end
		end
	end
end
local function v_u_89() -- name: clearRows
	-- upvalues: (copy) v_u_14
	local v84 = {}
	for v85 in v_u_14 do
		table.insert(v84, v85)
	end
	for _, v86 in v84 do
		local v87 = v_u_14[v86]
		if not v87 then
			continue
		end
		v_u_14[v86] = nil
		for _, v88 in v87.Connections do
			v88:Disconnect()
		end
		v87.Frame:Destroy()
	end
end
local function v_u_105(p90) -- name: adopt
	-- upvalues: (copy) v_u_89, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_18, (copy) v_u_9, (copy) v_u_6, (copy) v_u_13, (copy) v_u_14, (copy) v_u_49, (copy) v_u_34, (copy) v_u_21, (copy) v_u_1, (copy) v_u_8, (copy) v_u_83
	v_u_89()
	v_u_15 = nil
	v_u_16 = nil
	v_u_17 = nil
	v_u_18 = nil
	local v_u_91 = p90:WaitForChild("RightHUD", 10)
	local v_u_92 = p90:WaitForChild("Frames", 10)
	local v93
	if v_u_91 then
		v93 = v_u_91:FindFirstChild("Eggs")
	else
		v93 = v_u_91
	end
	if v_u_92 then
		v_u_92 = v_u_92:FindFirstChild("EggsInventory")
	end
	if v_u_91 and (v_u_91:IsA("GuiObject") and (v_u_92 and v_u_92:IsA("GuiObject"))) then
		local v_u_94 = v_u_92:FindFirstChild("ScrollingFrame", true)
		local v_u_95
		if v_u_94 then
			v_u_95 = v_u_94:FindFirstChild("Template")
		else
			v_u_95 = v_u_94
		end
		if v_u_94 and (v_u_94:IsA("ScrollingFrame") and (v_u_95 and v_u_95:IsA("Frame"))) then
			v_u_95.Visible = false
			v_u_92.Visible = false
			v_u_15 = v_u_92
			v_u_16 = v_u_91
			v_u_17 = v_u_94
			v_u_18 = v_u_95
			v_u_9.Observe(v_u_92, function(p96)
				-- upvalues: (ref) v_u_6, (ref) v_u_13, (copy) v_u_91, (ref) v_u_14, (ref) v_u_49, (ref) v_u_34
				if not v_u_6.IsActive(v_u_13) then
					v_u_91.Visible = not p96
				end
				if p96 then
					for _, v97 in v_u_14 do
						v_u_49(v97)
					end
					v_u_34()
				end
			end)
			if v93 and v93:IsA("GuiButton") then
				v93.Activated:Connect(function()
					-- upvalues: (ref) v_u_9, (copy) v_u_92
					v_u_9.Open(v_u_92)
				end)
			end
			local v98 = v_u_92:FindFirstChild("TopBar")
			if v98 then
				v98 = v98:FindFirstChild("GrowAll") or v98:FindFirstChild("PurchaseMoreEquipped")
			end
			if v98 and v98:IsA("GuiButton") then
				v98.Activated:Connect(function()
					-- upvalues: (ref) v_u_21
					v_u_21("SkipAll")
				end)
			end
			v_u_94:GetPropertyChangedSignal("AbsoluteWindowSize"):Connect(function()
				-- upvalues: (copy) v_u_94, (copy) v_u_95, (ref) v_u_14
				local v99 = v_u_95
				local v100 = v_u_94.AbsoluteWindowSize.Y * v99.Size.Y.Scale
				local v101 = math.floor(v100)
				local v102 = math.max(v101, 1)
				for _, v103 in v_u_14 do
					v103.Frame.Size = UDim2.new(1, 0, 0, v102)
				end
			end)
			v_u_89()
			for _, v104 in v_u_1:GetTagged(v_u_8.PlacedEggTag) do
				v_u_83(v104)
			end
		end
	else
		return
	end
end
function v12.Start() -- name: Start
	-- upvalues: (copy) v_u_1, (copy) v_u_8, (copy) v_u_83, (copy) v_u_53, (copy) v_u_4, (ref) v_u_15, (copy) v_u_9, (copy) v_u_14, (copy) v_u_49, (copy) v_u_34, (copy) v_u_6, (copy) v_u_13, (ref) v_u_16, (copy) v_u_10, (copy) v_u_105
	v_u_1:GetInstanceAddedSignal(v_u_8.PlacedEggTag):Connect(v_u_83)
	v_u_1:GetInstanceRemovedSignal(v_u_8.PlacedEggTag):Connect(v_u_53)
	v_u_4.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_15, (ref) v_u_9, (ref) v_u_14, (ref) v_u_49, (ref) v_u_34
		local v106 = v_u_15
		if v106 and v_u_9.IsOpen(v106) then
			local v107 = false
			for v108, v109 in v_u_14 do
				if v108.Parent == nil then
					local v110 = v_u_14[v108]
					if not v110 then
						continue
					end
					v_u_14[v108] = nil
					for _, v111 in v110.Connections do
						v111:Disconnect()
					end
					v110.Frame:Destroy()
				else
					if not v_u_49(v109) then
						continue
					end
					v107 = true
				end
			end
			if v107 then
				v_u_34()
			end
		end
	end)
	v_u_6.Observe(v_u_13, function(p112)
		-- upvalues: (ref) v_u_16, (ref) v_u_15, (ref) v_u_6, (ref) v_u_13, (ref) v_u_9
		if not p112 then
			task.defer(task.defer, function()
				-- upvalues: (ref) v_u_16, (ref) v_u_15, (ref) v_u_6, (ref) v_u_13, (ref) v_u_9
				local v113 = v_u_16
				local v114 = v_u_15
				if v113 and (v114 and (not v_u_6.IsActive(v_u_13) and v_u_9.IsOpen(v114))) then
					v113.Visible = false
				end
			end)
		end
	end)
	v_u_10.Observe(v_u_105)
end
return v12
return require(script.Parent.Parent.Action)("ActionBindingsUpdateSearchFilter", function(p1)
	return {
		["searchTerm"] = p1
	}
end)
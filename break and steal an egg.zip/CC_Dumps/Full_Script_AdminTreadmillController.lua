local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("Workspace")
local v7 = require(v3.Shared.PublicTreadmillConfig)
local v_u_8 = require(v3.Shared.RranBossConfig)
local v9 = script.Parent.Parent.Modules
local v_u_10 = require(v9.AdminTreadmillCutscene)
local v_u_11 = require(v9.CameraShaker)
local v_u_12 = require(v9.EggLandImpact)
local v_u_13 = require(v9.SpatialSfx)
local v_u_14 = require(v9.VFXBurst)
local v_u_15 = v2.LocalPlayer
local v16 = {}
local v_u_17 = v7.AdminSpawn
local v_u_18 = nil
local function v_u_26(p19) -- name: shake
	-- upvalues: (copy) v_u_15, (copy) v_u_10, (copy) v_u_17, (ref) v_u_18, (copy) v_u_11, (copy) v_u_6
	local v20 = v_u_15.Character
	if v20 then
		v20 = v20:FindFirstChild("HumanoidRootPart")
	end
	if v20 and v20:IsA("BasePart") then
		local v21 = (v20.Position - p19).Magnitude
		local v22 = v_u_10.IsPlaying()
		if v_u_17.ShakeRadius > v21 or v22 then
			if not v_u_18 then
				v_u_18 = v_u_11.new(Enum.RenderPriority.Camera.Value + 1, function(p23)
					-- upvalues: (ref) v_u_6
					local v24 = v_u_6.CurrentCamera
					if v24 then
						v24.CFrame = v24.CFrame * p23
					end
				end)
				v_u_18:Start()
			end
			local v25
			if v22 then
				v25 = v_u_17.Cutscene.ShakeScale
			else
				v25 = 1 - v21 / v_u_17.ShakeRadius
			end
			v_u_18:ShakeOnce(v_u_17.ShakeMagnitude * v25, 12, 0.03, 1.1)
		end
	else
		return
	end
end
local function v_u_31(p27, p28) -- name: fallSound
	-- upvalues: (copy) v_u_13, (copy) v_u_8, (copy) v_u_17, (copy) v_u_6, (copy) v_u_5, (copy) v_u_1
	local v_u_29 = v_u_13.Play(v_u_8.Sfx.Folder, v_u_17.FallSound, {
		["At"] = p27,
		["Range"] = v_u_17.SlamRange,
		["MinRange"] = v_u_17.SlamRange * 0.15,
		["RollOffMode"] = Enum.RollOffMode.Linear
	})
	if not v_u_29 then
		return function() end
	end
	local v30 = (p28 - v_u_6:GetServerTimeNow()) * v_u_29.PlaybackSpeed
	if v30 < v_u_29.TimeLength then
		v_u_29.TimePosition = v_u_29.TimeLength - v30
	end
	return function()
		-- upvalues: (copy) v_u_29, (ref) v_u_5, (ref) v_u_17, (ref) v_u_1
		if v_u_29.Parent then
			v_u_5:Create(v_u_29, TweenInfo.new(v_u_17.FallSoundFadeOut), {
				["Volume"] = 0
			}):Play()
			v_u_1:AddItem(v_u_29, v_u_17.FallSoundFadeOut + 0.05)
		end
	end
end
local function v_u_44(p32, p33) -- name: slam
	-- upvalues: (copy) v_u_14, (copy) v_u_17, (copy) v_u_12, (copy) v_u_13, (copy) v_u_8, (copy) v_u_26
	v_u_14.Play(v_u_17.LandBlastName, CFrame.new(p32), v_u_17.LandBlastScale)
	v_u_14.Play(v_u_17.SmokeName, CFrame.new(p32), v_u_17.SmokeScale)
	local v34 = p33.X * 0.55
	local v35 = p33.Z * 0.55
	for v36 = 1, v_u_17.FlameRingCount do
		local v37 = v36 / v_u_17.FlameRingCount * 3.141592653589793 * 2
		local v38 = math.cos(v37) * v34
		local v39 = math.sin(v37) * v35
		local v40 = p32 + Vector3.new(v38, 0, v39)
		task.delay(v36 * 0.02, v_u_14.Play, v_u_17.LandBlastName, CFrame.new(v40), v_u_17.FlameRingScale)
	end
	local v41 = v_u_12.Chunks
	local v42 = p33.X
	local v43 = p33.Z
	v41(p32, math.max(v42, v43) * 0.25, p33.Y)
	v_u_13.Play(v_u_8.Sfx.Folder, v_u_17.SlamSound, {
		["At"] = p32,
		["Range"] = v_u_17.SlamRange,
		["MinRange"] = v_u_17.SlamRange * 0.15,
		["RollOffMode"] = Enum.RollOffMode.Linear
	})
	v_u_26(p32)
end
local function v_u_80(p_u_45) -- name: drop
	-- upvalues: (copy) v_u_17, (copy) v_u_6, (copy) v_u_10, (copy) v_u_31, (copy) v_u_4, (copy) v_u_44
	local v46 = p_u_45:GetAttribute(v_u_17.LandAtAttribute)
	if type(v46) == "number" and v46 > v_u_6:GetServerTimeNow() then
		local v_u_47 = v46 - v_u_17.DropTime
		local v_u_48 = {}
		local v_u_49 = {}
		local v_u_50 = {}
		local function v55(p51) -- name: addPart
			-- upvalues: (copy) v_u_50, (copy) v_u_48, (copy) v_u_49
			if p51:IsA("BasePart") and not v_u_50[p51] then
				v_u_50[p51] = true
				local v52 = v_u_48
				table.insert(v52, p51)
				local v53 = v_u_49
				local v54 = p51.CFrame
				table.insert(v53, v54)
			end
		end
		for _, v56 in p_u_45:GetDescendants() do
			if not v56:IsA("BasePart") or v_u_50[v56] then
				continue
			end
			v_u_50[v56] = true
			table.insert(v_u_48, v56)
			local v57 = v56.CFrame
			table.insert(v_u_49, v57)
		end
		local v_u_58 = p_u_45.DescendantAdded:Connect(v55)
		local v59, v_u_60 = p_u_45:GetBoundingBox()
		local v61 = v59.Position
		local v62 = v_u_60.Y / 2
		local v_u_63 = v61 - Vector3.new(0, v62, 0)
		local v64 = v_u_10.Facing(p_u_45)
		local v65 = v_u_17.DropHeight
		local v66 = Vector3.new(0, v65, 0)
		local v_u_67 = {}
		for v68, v69 in v_u_49 do
			v_u_67[v68] = v69 + v66
		end
		v_u_6:BulkMoveTo(v_u_48, v_u_67, Enum.BulkMoveMode.FireCFrameChanged)
		local v_u_70 = not v_u_48[1] and function() end or v_u_31(v_u_48[1], v46)
		task.spawn(v_u_10.Play, {
			["Model"] = p_u_45,
			["Ground"] = v_u_63,
			["Size"] = v_u_60,
			["Facing"] = v64,
			["FallStart"] = v_u_47
		})
		local v_u_71 = nil
		v_u_71 = v_u_4.RenderStepped:Connect(function()
			-- upvalues: (copy) p_u_45, (ref) v_u_71, (copy) v_u_58, (copy) v_u_70, (ref) v_u_6, (copy) v_u_47, (ref) v_u_17, (copy) v_u_49, (copy) v_u_67, (copy) v_u_48, (ref) v_u_44, (copy) v_u_63, (copy) v_u_60
			if p_u_45.Parent then
				local v72 = (v_u_6:GetServerTimeNow() - v_u_47) / v_u_17.DropTime
				local v73 = math.clamp(v72, 0, 1)
				local v74 = v_u_17.DropHeight * (1 - v73 * v73)
				local v75 = Vector3.new(0, v74, 0)
				for v76, v77 in v_u_49 do
					v_u_67[v76] = v77 + v75
				end
				v_u_6:BulkMoveTo(v_u_48, v_u_67, Enum.BulkMoveMode.FireCFrameChanged)
				if v73 >= 1 then
					v_u_71:Disconnect()
					v_u_58:Disconnect()
					for v78, v79 in v_u_49 do
						v_u_67[v78] = v79 + Vector3.new(0, 0, 0)
					end
					v_u_6:BulkMoveTo(v_u_48, v_u_67, Enum.BulkMoveMode.FireCFrameChanged)
					v_u_70()
					v_u_44(v_u_63, v_u_60)
				end
			else
				v_u_71:Disconnect()
				v_u_58:Disconnect()
				v_u_70()
			end
		end)
	end
end
local function v_u_82(p81) -- name: watch
	-- upvalues: (copy) v_u_17, (copy) v_u_80
	if p81:IsA("Model") and p81.Name == v_u_17.Model then
		v_u_80(p81)
	end
end
function v16.Start() -- name: Start
	-- upvalues: (copy) v_u_6, (copy) v_u_82
	for _, v83 in v_u_6:GetChildren() do
		task.spawn(v_u_82, v83)
	end
	v_u_6.ChildAdded:Connect(v_u_82)
end
return v16
local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v_u_1.Shared.DiscordRewardConfig)
local v_u_3 = require(script.Parent.NotificationController)
local v_u_4 = require(script.Parent.Parent.Modules.MainGui)
local v5 = {}
local v_u_6 = nil
local v_u_7 = {
	["Claimed"] = false,
	["Asked"] = false,
	["Wait"] = 0
}
local v_u_8 = (-1 / 0)
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = Color3.new(1, 1, 1)
local v_u_13 = (-1 / 0)
local function v_u_17() -- name: verify
	-- upvalues: (ref) v_u_13, (copy) v_u_2, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (copy) v_u_3, (ref) v_u_6
	local v14 = os.clock()
	if v14 - v_u_13 < v_u_2.PressDebounce then
		return
	elseif v_u_7.Claimed or (not v_u_7.Asked or v14 - v_u_8 >= v_u_2.AskDebounce) then
		v_u_13 = v14
		local v15 = not v_u_9 and "" or v_u_9.Text
		local v16 = v_u_2.InputDenial(v_u_7, v15)
		if v16 then
			v_u_3.Show(v16, "Error")
		elseif v_u_6 then
			v_u_6:FireServer("Verify", v15)
		end
	else
		return
	end
end
local function v_u_29(p18) -- name: adopt
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (copy) v_u_2, (copy) v_u_17, (ref) v_u_12, (ref) v_u_7
	v_u_9 = nil
	v_u_10 = nil
	v_u_11 = nil
	for _, v19 in v_u_2.CardPath do
		if not p18 then
			continue
		end
		p18 = p18:FindFirstChild(v19)
	end
	if p18 then
		local v20 = p18
		for _, v21 in v_u_2.TextBoxPath do
			if not p18 then
				continue
			end
			p18 = p18:FindFirstChild(v21)
		end
		if not (p18 and p18:IsA("TextBox")) then
			p18 = v20:FindFirstChildWhichIsA("TextBox", true)
		end
		if p18 and p18:IsA("TextBox") then
			v_u_9 = p18
			p18.FocusLost:Connect(function(p22)
				-- upvalues: (ref) v_u_17
				if p22 then
					v_u_17()
				end
			end)
		end
		for _, v23 in v_u_2.VerifyButtonPath do
			if not v20 then
				continue
			end
			v20 = v20:FindFirstChild(v23)
		end
		if v20 and v20:IsA("GuiButton") then
			v_u_10 = v20
			v_u_12 = v20.BackgroundColor3
			local v24 = v20:FindFirstChild(v_u_2.VerifyTitleName)
			if v24 and v24:IsA("TextLabel") then
				v_u_11 = v24
			end
			v20.Activated:Connect(v_u_17)
		end
		if v_u_10 then
			v_u_10.Active = true
			v_u_10.AutoButtonColor = not v_u_7.Claimed
			local v25 = v_u_10
			local v26
			if v_u_7.Claimed then
				v26 = v_u_2.LockedTint
			else
				v26 = v_u_12
			end
			v25.BackgroundColor3 = v26
		end
		if v_u_11 then
			local v27 = v_u_11
			local v28
			if v_u_7.Claimed then
				v28 = v_u_2.ClaimedText
			else
				v28 = v_u_2.VerifyText
			end
			v27.Text = v28
		end
	end
end
function v5.Start() -- name: Start
	-- upvalues: (copy) v_u_4, (copy) v_u_29, (copy) v_u_1, (copy) v_u_2, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_10, (ref) v_u_12, (ref) v_u_11
	v_u_4.Observe(v_u_29)
	local v30 = v_u_1:WaitForChild(v_u_2.RemoteName, 30)
	if v30 and v30:IsA("RemoteEvent") then
		v_u_6 = v30
		v30.OnClientEvent:Connect(function(p31, p32)
			-- upvalues: (ref) v_u_7, (ref) v_u_8, (ref) v_u_10, (ref) v_u_2, (ref) v_u_12, (ref) v_u_11
			if p31 == "State" and typeof(p32) == "table" then
				local v33 = v_u_7.Asked
				local v34 = {
					["Claimed"] = p32.Claimed == true,
					["Asked"] = p32.Asked == true
				}
				local v35 = p32.Wait
				local v36
				if typeof(v35) == "number" then
					local v37 = p32.Wait
					v36 = math.max(v37, 0)
				else
					v36 = 0
				end
				v34.Wait = v36
				v_u_7 = v34
				if v_u_7.Asked and not v33 then
					v_u_8 = os.clock()
				end
				if v_u_10 then
					v_u_10.Active = true
					v_u_10.AutoButtonColor = not v_u_7.Claimed
					local v38 = v_u_10
					local v39
					if v_u_7.Claimed then
						v39 = v_u_2.LockedTint
					else
						v39 = v_u_12
					end
					v38.BackgroundColor3 = v39
				end
				if v_u_11 then
					local v40 = v_u_11
					local v41
					if v_u_7.Claimed then
						v41 = v_u_2.ClaimedText
					else
						v41 = v_u_2.VerifyText
					end
					v40.Text = v41
				end
			end
		end)
		v30:FireServer("Get")
	end
end
return v5
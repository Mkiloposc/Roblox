local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("GuiService")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("UserInputService")
local v7 = require(v3.Shared.AdminConfig)
local v_u_8 = require(v3.Shared.ButtonTweenConfig)
local v_u_9 = require(script.Parent.RichWordTyper)
local v10 = {}
local v_u_11 = TweenInfo.new(0.7, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
local v_u_12 = TweenInfo.new(0.38, Enum.EasingStyle.Back, Enum.EasingDirection.Out)
local v_u_13 = TweenInfo.new(0.35, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
local v_u_14 = TweenInfo.new(0.3, Enum.EasingStyle.Quint, Enum.EasingDirection.In)
local v_u_15 = v7.PanelHoverScale
local v_u_16 = v7.PanelPressScale
local v_u_17 = {
	["Client"] = Color3.fromRGB(255, 60, 60),
	["Server"] = Color3.fromRGB(0, 255, 0),
	["Global"] = Color3.fromRGB(0, 170, 255)
}
local v_u_18 = Color3.new(1, 1, 1)
local function v_u_26(p19, p20) -- name: evalSequence
	local v21 = p19.Keypoints
	for v22 = 1, #v21 - 1 do
		local v23 = v21[v22]
		local v24 = v21[v22 + 1]
		if p20 > v24.Time then
			continue
		end
		local v25 = v24.Time - v23.Time
		if v25 > 0 then
			return v23.Value:Lerp(v24.Value, (p20 - v23.Time) / v25)
		else
			return v24.Value
		end
	end
	return v21[#v21].Value
end
local function v_u_36(p27, p28) -- name: optionColor
	-- upvalues: (copy) v_u_26, (copy) v_u_17, (copy) v_u_18
	local v29 = p28:FindFirstChildWhichIsA("UIGradient")
	if v29 then
		local v30 = v_u_26(v29.Color, 0.5)
		local v31 = p28.BackgroundColor3
		local v32 = Color3.new(v30.R * v31.R, v30.G * v31.G, v30.B * v31.B)
		local _, v33, v34 = v32:ToHSV()
		if v33 >= 0.25 and v34 >= 0.3 then
			local v35 = v32:ToHSV()
			return Color3.fromHSV(v35, v33, 1)
		end
	end
	return v_u_17[p27] or v_u_18
end
local function v_u_44(p37, p38) -- name: reanchor
	local v39 = p37.AnchorPoint
	if v39 ~= p38 then
		local v40 = p37.Size
		local v41 = p37.Position
		local v42 = p38.X - v39.X
		local v43 = p38.Y - v39.Y
		p37.AnchorPoint = p38
		p37.Position = UDim2.new(v41.X.Scale + v40.X.Scale * v42, v41.X.Offset + v40.X.Offset * v42, v41.Y.Scale + v40.Y.Scale * v43, v41.Y.Offset + v40.Y.Offset * v43)
	end
end
function v10.Bind(p45, p_u_46, p_u_47, p48) -- name: Bind
	-- upvalues: (copy) v_u_9, (copy) v_u_44, (copy) v_u_15, (copy) v_u_16, (copy) v_u_5, (copy) v_u_4, (copy) v_u_36, (copy) v_u_17, (copy) v_u_18, (copy) v_u_1, (copy) v_u_8, (copy) v_u_11, (copy) v_u_13, (copy) v_u_12, (copy) v_u_14, (copy) v_u_6, (copy) v_u_2
	local v_u_49
	if p48 and p48.Toggle then
		v_u_49 = p48.Toggle
	else
		v_u_49 = p45:FindFirstChild("Edit")
	end
	local v_u_50
	if p48 and p48.List then
		v_u_50 = p48.List
	else
		v_u_50 = p45:FindFirstChild("EditList")
	end
	if not (v_u_49 and (v_u_49:IsA("GuiButton") and (v_u_50 and v_u_50:IsA("GuiObject")))) then
		return nil
	end
	local v_u_51
	if v_u_50:IsA("ScrollingFrame") then
		v_u_51 = v_u_50
	else
		v_u_51 = nil
	end
	local v52
	if p48 and p48.Setting ~= nil then
		local v53 = p48.Setting
		if typeof(v53) == "Instance" then
			v52 = p48.Setting
		else
			v52 = nil
		end
	else
		v52 = p45:FindFirstChild("Setting")
	end
	local v_u_54
	if v52 and v52:IsA("TextLabel") then
		v_u_54 = v_u_9.new(v52)
	else
		v_u_54 = nil
	end
	local v_u_55
	if p48 == nil then
		v_u_55 = false
	else
		v_u_55 = p48.Direction == "Up"
	end
	v_u_44(v_u_50, Vector2.new(0.5, v_u_55 and 1 or 0))
	local v_u_56 = v_u_50.Position
	local v_u_57 = v_u_50.Size
	local v_u_58 = UDim2.new(v_u_57.X.Scale, v_u_57.X.Offset, 0, 0)
	local v_u_59
	if v_u_51 then
		v_u_59 = v_u_51.CanvasSize
	else
		v_u_59 = nil
	end
	local v_u_60 = not v_u_51 and 0 or v_u_51.ScrollBarThickness
	local v_u_61 = v_u_49:FindFirstChild("Icon")
	if not (v_u_61 and v_u_61:IsA("GuiObject")) then
		v_u_61 = nil
	end
	local v_u_62 = not v_u_61 and 0 or v_u_61.Rotation
	local v_u_63 = {}
	for _, v64 in v_u_50:GetChildren() do
		local v65 = v64:FindFirstChild("Button")
		if v64.Name == "Template" or not (v64:IsA("GuiObject") and (v65 and v65:IsA("GuiButton"))) then
			continue
		end
		local v66 = {
			["Frame"] = v64,
			["Button"] = v65,
			["Size"] = v64.Size
		}
		table.insert(v_u_63, v66)
		v65:SetAttribute("HoverScale", v_u_15)
		v65:SetAttribute("PressScale", v_u_16)
		v65:SetAttribute("ButtonTweenSelf", true)
		v64:SetAttribute("HoverScale", nil)
		v64:SetAttribute("PressScale", nil)
	end
	table.sort(v_u_63, function(p67, p68)
		if p67.Frame.LayoutOrder == p68.Frame.LayoutOrder then
			return p67.Frame.Name < p68.Frame.Name
		else
			return p67.Frame.LayoutOrder < p68.Frame.LayoutOrder
		end
	end)
	local v_u_69 = false
	local v_u_70 = 0
	local v_u_71 = {}
	local v_u_72 = {}
	local v_u_73 = false
	local function v_u_77() -- name: pinRows
		-- upvalues: (ref) v_u_73, (copy) v_u_63, (copy) v_u_51, (copy) v_u_59
		if not v_u_73 then
			v_u_73 = true
			for _, v74 in v_u_63 do
				local v75 = v74.Frame.AbsoluteSize.Y
				local v76 = v74.Size
				v74.Frame.Size = UDim2.new(v76.X.Scale, v76.X.Offset, 0, v75)
			end
			if v_u_51 and v_u_59 then
				v_u_51.CanvasSize = UDim2.new(v_u_59.X.Scale, v_u_59.X.Offset, 0, v_u_51.AbsoluteCanvasSize.Y)
				v_u_51.ScrollBarThickness = 0
			end
		end
	end
	local v78 = nil
	local v79 = 0
	local v_u_80 = v_u_73
	local v_u_81 = v78
	local v_u_82 = v79
	local v_u_83 = {}
	for _, v84 in v_u_63 do
		v_u_83[v84.Frame.Name] = v_u_36(v84.Frame.Name, v84.Button)
	end
	local function v_u_88() -- name: resetClosed
		-- upvalues: (copy) v_u_71, (copy) v_u_50, (copy) v_u_56, (copy) v_u_57, (ref) v_u_81, (copy) v_u_51, (ref) v_u_80, (copy) v_u_63, (copy) v_u_59, (copy) v_u_60, (copy) v_u_61, (copy) v_u_62, (ref) v_u_1, (ref) v_u_8
		for _, v85 in v_u_71 do
			v85:Cancel()
		end
		table.clear(v_u_71)
		v_u_50.Visible = false
		v_u_50.Position = v_u_56
		v_u_50.Size = v_u_57
		if v_u_81 then
			v_u_81:Disconnect()
			v_u_81 = nil
		end
		if v_u_51 then
			v_u_51.CanvasPosition = Vector2.zero
		end
		v_u_80 = false
		for _, v86 in v_u_63 do
			v86.Frame.Size = v86.Size
		end
		if v_u_51 and v_u_59 then
			v_u_51.CanvasSize = v_u_59
			v_u_51.ScrollBarThickness = v_u_60
		end
		if v_u_51 then
			v_u_51.CanvasPosition = Vector2.zero
		end
		for _, v87 in v_u_63 do
			v87.Button.Visible = true
			if not v87.Rest then
				continue
			end
			v87.Button.Position = v87.Rest
		end
		if v_u_61 then
			v_u_61.Rotation = v_u_62
		end
		v_u_1:RemoveTag(v_u_50, v_u_8.HoverBlockerTag)
	end
	local v_u_149 = {
		["IsOpen"] = function() -- name: IsOpen
			-- upvalues: (ref) v_u_69
			return v_u_69
		end,
		["GetValue"] = function() -- name: GetValue
			-- upvalues: (ref) p_u_46
			return p_u_46
		end,
		["SetValue"] = function(p89) -- name: SetValue
			-- upvalues: (ref) p_u_46, (copy) v_u_54, (copy) v_u_83, (ref) v_u_17, (ref) v_u_18
			p_u_46 = p89
			if v_u_54 then
				v_u_54:Set(p_u_46, v_u_83[p_u_46] or (v_u_17[p_u_46] or v_u_18), nil)
			end
		end,
		["Open"] = function() -- name: Open
			-- upvalues: (ref) v_u_69, (ref) v_u_70, (copy) v_u_71, (copy) v_u_63, (copy) v_u_50, (copy) v_u_57, (copy) v_u_51, (copy) v_u_77, (copy) v_u_55, (copy) v_u_58, (copy) v_u_56, (ref) v_u_82, (ref) v_u_81, (ref) v_u_4, (ref) v_u_1, (ref) v_u_8, (ref) v_u_11, (ref) v_u_5, (copy) v_u_61, (ref) v_u_13, (copy) v_u_62, (ref) v_u_12, (ref) v_u_80, (copy) v_u_59, (copy) v_u_60
			if not v_u_69 then
				v_u_69 = true
				v_u_70 = v_u_70 + 1
				local v_u_90 = v_u_70
				for _, v91 in v_u_71 do
					v91:Cancel()
				end
				table.clear(v_u_71)
				for _, v92 in v_u_63 do
					if v92.Rest ~= nil then
						continue
					end
					v92.Rest = v92.Button.Position
				end
				v_u_50.Size = v_u_57
				local v93 = v_u_50.AbsoluteSize.Y
				local v94 = math.max(v93, 1)
				local v95 = v_u_50.AbsolutePosition.Y
				local v96 = not v_u_51 and 0 or v_u_51.CanvasPosition.Y
				v_u_77()
				if v_u_51 then
					v_u_51.CanvasPosition = Vector2.zero
				end
				local v_u_97 = {}
				for v98, v99 in v_u_63 do
					local v100 = v99.Frame.AbsolutePosition.Y - v95 + v96
					local v101 = v99.Frame.AbsoluteSize.Y
					local v102
					if v94 <= v100 then
						v102 = 1
					elseif v_u_55 then
						v102 = 1 - (v100 + v101 * 0.7) / v94
					else
						v102 = (v100 + v101 * 0.3) / v94
					end
					v_u_97[v98] = (1 - (1 - math.clamp(v102, 0, 1)) ^ 0.2) * 0.7
				end
				local v103 = {}
				for v104 in v_u_63 do
					table.insert(v103, v104)
				end
				table.sort(v103, function(p105, p106)
					-- upvalues: (copy) v_u_97, (ref) v_u_55
					if v_u_97[p105] == v_u_97[p106] then
						if v_u_55 then
							return p106 < p105
						else
							return p105 < p106
						end
					else
						return v_u_97[p105] < v_u_97[p106]
					end
				end)
				local v107 = (-1 / 0)
				local v108 = {}
				for _, v109 in v103 do
					local v110 = v_u_97[v109]
					local v111 = v107 + 0.08
					v107 = math.max(v110, v111)
					v108[v109] = v107
				end
				local v112 = v_u_55 and 16 or -16
				for _, v113 in v_u_63 do
					v113.Button.Visible = false
					local v114 = v113.Button
					local v115 = v113.Rest
					v114.Position = UDim2.new(v115.X.Scale, v115.X.Offset + 0, v115.Y.Scale, v115.Y.Offset + v112)
				end
				v_u_50.Size = v_u_58
				v_u_50.Position = v_u_56
				v_u_82 = v94
				if not v_u_81 and (v_u_55 and v_u_51) then
					local v_u_116 = v_u_51
					v_u_81 = v_u_4.RenderStepped:Connect(function()
						-- upvalues: (copy) v_u_116, (ref) v_u_82
						local v117 = v_u_116.Parent
						local v118 = not (v117 and v117:IsA("GuiObject")) and 0 or v117.AbsoluteSize.Y
						local v119 = v_u_116.Size
						local v120 = v119.Y.Scale * v118 + v119.Y.Offset
						local v121 = v_u_116
						local v122 = Vector2.new
						local v123 = v_u_82 - v120
						v121.CanvasPosition = v122(0, (math.max(v123, 0)))
					end)
				end
				v_u_50.Visible = true
				v_u_1:AddTag(v_u_50, v_u_8.HoverBlockerTag)
				local v124 = v_u_5:Create(v_u_50, v_u_11, {
					["Size"] = v_u_57
				})
				v124:Play()
				local v125 = v_u_71
				table.insert(v125, v124)
				if v_u_61 then
					local v126 = v_u_5:Create(v_u_61, v_u_13, {
						["Rotation"] = v_u_62 + -14
					})
					v126:Play()
					local v127 = v_u_71
					table.insert(v127, v126)
				end
				for v128, v_u_129 in v_u_63 do
					task.delay(v108[v128], function()
						-- upvalues: (ref) v_u_70, (copy) v_u_90, (ref) v_u_69, (copy) v_u_129, (ref) v_u_12, (ref) v_u_5, (ref) v_u_71
						if v_u_70 == v_u_90 and v_u_69 then
							v_u_129.Button.Visible = true
							local v130 = v_u_5:Create(v_u_129.Button, v_u_12, {
								["Position"] = v_u_129.Rest
							})
							v130:Play()
							local v131 = v_u_71
							table.insert(v131, v130)
						end
					end)
				end
				task.delay(0.7, function()
					-- upvalues: (ref) v_u_70, (copy) v_u_90, (ref) v_u_69, (ref) v_u_81, (ref) v_u_51, (ref) v_u_80, (ref) v_u_63, (ref) v_u_59, (ref) v_u_60
					if v_u_70 == v_u_90 and v_u_69 then
						if v_u_81 then
							v_u_81:Disconnect()
							v_u_81 = nil
						end
						if v_u_51 then
							v_u_51.CanvasPosition = Vector2.zero
						end
						v_u_80 = false
						for _, v132 in v_u_63 do
							v132.Frame.Size = v132.Size
						end
						if v_u_51 and v_u_59 then
							v_u_51.CanvasSize = v_u_59
							v_u_51.ScrollBarThickness = v_u_60
						end
					end
				end)
			end
		end,
		["Close"] = function(p133) -- name: Close
			-- upvalues: (ref) v_u_69, (copy) v_u_88, (ref) v_u_70, (copy) v_u_71, (ref) v_u_81, (copy) v_u_50, (ref) v_u_82, (copy) v_u_55, (copy) v_u_51, (ref) v_u_4, (copy) v_u_77, (ref) v_u_14, (copy) v_u_58, (ref) v_u_5, (copy) v_u_61, (ref) v_u_13, (copy) v_u_62
			if v_u_69 then
				v_u_69 = false
				v_u_70 = v_u_70 + 1
				local v_u_134 = v_u_70
				for _, v135 in v_u_71 do
					v135:Cancel()
				end
				table.clear(v_u_71)
				if p133 then
					v_u_88()
				else
					if not v_u_81 then
						local v136 = v_u_50.AbsoluteSize.Y
						v_u_82 = math.max(v136, 1)
						if not v_u_81 and (v_u_55 and v_u_51) then
							local v_u_137 = v_u_51
							v_u_81 = v_u_4.RenderStepped:Connect(function()
								-- upvalues: (copy) v_u_137, (ref) v_u_82
								local v138 = v_u_137.Parent
								local v139 = not (v138 and v138:IsA("GuiObject")) and 0 or v138.AbsoluteSize.Y
								local v140 = v_u_137.Size
								local v141 = v140.Y.Scale * v139 + v140.Y.Offset
								local v142 = v_u_137
								local v143 = Vector2.new
								local v144 = v_u_82 - v141
								v142.CanvasPosition = v143(0, (math.max(v144, 0)))
							end)
						end
					end
					v_u_77()
					local v145 = v_u_5:Create(v_u_50, v_u_14, {
						["Size"] = v_u_58
					})
					v145:Play()
					local v146 = v_u_71
					table.insert(v146, v145)
					if v_u_61 then
						local v147 = v_u_5:Create(v_u_61, v_u_13, {
							["Rotation"] = v_u_62
						})
						v147:Play()
						local v148 = v_u_71
						table.insert(v148, v147)
					end
					task.delay(v_u_14.Time, function()
						-- upvalues: (ref) v_u_70, (copy) v_u_134, (ref) v_u_69, (ref) v_u_88
						if v_u_70 == v_u_134 and not v_u_69 then
							v_u_88()
						end
					end)
				end
			else
				if p133 then
					v_u_88()
				end
				return
			end
		end
	}
	local v_u_150 = (-1 / 0)
	function v_u_149.Toggle() -- name: Toggle
		-- upvalues: (ref) v_u_69, (copy) v_u_149, (ref) v_u_150
		if v_u_69 then
			v_u_149.Close()
		elseif os.clock() - v_u_150 > 0.25 then
			v_u_149.Open()
		end
	end
	function v_u_149.Destroy() -- name: Destroy
		-- upvalues: (copy) v_u_72, (copy) v_u_71, (ref) v_u_69, (ref) v_u_70, (ref) v_u_81
		for _, v151 in v_u_72 do
			v151:Disconnect()
		end
		table.clear(v_u_72)
		for _, v152 in v_u_71 do
			v152:Cancel()
		end
		table.clear(v_u_71)
		v_u_69 = false
		v_u_70 = v_u_70 + 1
		if v_u_81 then
			v_u_81:Disconnect()
			v_u_81 = nil
		end
	end
	local v153 = v_u_49.Activated
	local v154 = v_u_149.Toggle
	table.insert(v_u_72, v153:Connect(v154))
	local v_u_155 = v_u_150
	for _, v_u_156 in v_u_63 do
		local v157 = v_u_156.Button.Activated
		local function v158()
			-- upvalues: (ref) p_u_46, (copy) v_u_156, (copy) v_u_54, (copy) v_u_83, (ref) v_u_17, (ref) v_u_18, (copy) p_u_47, (ref) v_u_69, (copy) v_u_149
			p_u_46 = v_u_156.Frame.Name
			if v_u_54 then
				v_u_54:Set(p_u_46, v_u_83[p_u_46] or (v_u_17[p_u_46] or v_u_18), nil)
			end
			if p_u_47 then
				task.spawn(p_u_47, p_u_46)
			end
			task.delay(0.1, function()
				-- upvalues: (ref) v_u_69, (ref) v_u_149
				if v_u_69 then
					v_u_149.Close()
				end
			end)
		end
		table.insert(v_u_72, v157:Connect(v158))
	end
	local v159 = v_u_6.InputBegan
	local function v173(p160)
		-- upvalues: (ref) v_u_69, (copy) v_u_50, (ref) v_u_2, (copy) v_u_49, (ref) v_u_155, (copy) v_u_149
		if v_u_69 then
			local v161 = p160.UserInputType
			if v161 == Enum.UserInputType.MouseButton1 or v161 == Enum.UserInputType.Touch then
				local v162 = v_u_50
				local v163 = Vector2.new(p160.Position.X, p160.Position.Y)
				local v164 = v162:FindFirstAncestorWhichIsA("ScreenGui")
				if v164 and v164.IgnoreGuiInset then
					v163 = v163 + v_u_2:GetGuiInset()
				end
				local v165 = v_u_50
				local v166 = v165.AbsolutePosition
				local v167 = v166 + v165.AbsoluteSize
				local v168
				if v163.X >= v166.X and (v163.X <= v167.X and v163.Y >= v166.Y) then
					v168 = v163.Y <= v167.Y
				else
					v168 = false
				end
				if not v168 then
					local v169 = v_u_49
					local v170 = v169.AbsolutePosition
					local v171 = v170 + v169.AbsoluteSize
					local v172
					if v163.X >= v170.X and (v163.X <= v171.X and v163.Y >= v170.Y) then
						v172 = v163.Y <= v171.Y
					else
						v172 = false
					end
					if not v172 then
						v_u_155 = os.clock()
						v_u_149.Close()
						return
					end
				end
			end
		else
			return
		end
	end
	table.insert(v_u_72, v159:Connect(v173))
	local v174 = v_u_50.Destroying
	table.insert(v_u_72, v174:Connect(function()
		-- upvalues: (copy) v_u_149
		v_u_149.Destroy()
	end))
	v_u_88()
	if v_u_54 then
		v_u_54:Set(p_u_46, v_u_83[p_u_46] or (v_u_17[p_u_46] or v_u_18), true)
	end
	return v_u_149
end
return v10
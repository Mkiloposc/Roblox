local v_u_1 = {}
local v_u_2 = nil
local v_u_3 = nil
local v_u_4 = nil
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
local v_u_8 = nil
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local v_u_12 = nil
local v_u_13 = {}
local v_u_14 = {}
v_u_1.map = v_u_13
v_u_1.list = v_u_14
v_u_1.count = 0
v_u_1.noFade = {}
v_u_1.FADE_PROPS = {
	["ImageLabel"] = { "ImageTransparency", "BackgroundTransparency" },
	["ImageButton"] = { "ImageTransparency", "BackgroundTransparency" },
	["TextLabel"] = { "TextTransparency", "TextStrokeTransparency", "BackgroundTransparency" },
	["TextButton"] = { "TextTransparency", "TextStrokeTransparency", "BackgroundTransparency" },
	["TextBox"] = { "TextTransparency", "TextStrokeTransparency", "BackgroundTransparency" },
	["Frame"] = { "BackgroundTransparency" },
	["CanvasGroup"] = { "GroupTransparency", "BackgroundTransparency" },
	["ScrollingFrame"] = { "ScrollBarImageTransparency", "BackgroundTransparency" },
	["ViewportFrame"] = { "ImageTransparency", "BackgroundTransparency" },
	["UIStroke"] = { "Transparency" },
	["UIShadow"] = { "Transparency" }
}
local v_u_15 = v_u_1.FADE_PROPS
function v_u_1.chainVisible(p16) -- name: chainVisible
	-- upvalues: (ref) v_u_7
	while p16 and p16 ~= v_u_7 do
		if p16:IsA("GuiObject") and not p16.Visible then
			return false
		end
		p16 = p16.Parent
	end
	return p16 == v_u_7
end
local v_u_17 = v_u_1.noFade
function v_u_1.makeActor(p18, p19) -- name: makeActor
	-- upvalues: (copy) v_u_13, (ref) v_u_6, (ref) v_u_2, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (copy) v_u_1, (copy) v_u_14
	local v20 = v_u_13[p18]
	if v20 then
		return v20
	end
	local v21 = p18:FindFirstChildOfClass("UIScale")
	if not (v21 or p19) then
		v21 = Instance.new("UIScale")
		v21.Name = v_u_6.SCALE_NAME
		v21.Parent = p18
	end
	local v22 = p18.Position
	local v23 = {
		["inst"] = p18,
		["scaleObj"] = v21,
		["hxS"] = v22.X.Scale,
		["hxO"] = v22.X.Offset,
		["hyS"] = v22.Y.Scale,
		["hyO"] = v22.Y.Offset,
		["hRot"] = p18.Rotation,
		["hScale"] = v21 and v21.Scale or 1,
		["ox"] = v_u_2.new(0, 3, 1),
		["oy"] = v_u_2.new(0, 3, 1),
		["rot"] = v_u_2.new(0, 3, 1),
		["sc"] = v_u_2.new(1, 3, 1),
		["a"] = v_u_2.new(0, v_u_6.ALPHA_IN, 1),
		["hs"] = nil,
		["hr"] = nil,
		["ix"] = 0,
		["iy"] = 0,
		["ir"] = 0,
		["is"] = 1,
		["wx"] = 0,
		["wy"] = 0,
		["wr"] = 0,
		["ws"] = 1,
		["wa"] = 0,
		["eP"] = v_u_9,
		["eR"] = v_u_10,
		["eS"] = v_u_11,
		["fades"] = false,
		["fI"] = {},
		["fP"] = {},
		["fB"] = {},
		["fN"] = 0,
		["pX"] = 0,
		["pY"] = 0,
		["pR"] = 0,
		["pS"] = 1,
		["pA"] = 0,
		["inAt"] = 0,
		["inF"] = 3,
		["inD"] = 0.6,
		["aInF"] = v_u_6.ALPHA_IN,
		["outAt"] = 0,
		["outF"] = 4,
		["outD"] = 1,
		["aOutF"] = v_u_6.ALPHA_OUT,
		["outKick"] = 0,
		["pend"] = 0,
		["pendAt"] = 0,
		["idle"] = 0,
		["idleAt"] = (1 / 0),
		["idleDelay"] = 0.35,
		["live"] = false,
		["session"] = false,
		["index"] = 0
	}
	local v24 = v_u_1.count + 1
	v_u_1.count = v24
	v_u_14[v24] = v23
	v23.index = v24
	v_u_13[p18] = v23
	return v23
end
function v_u_1.removeActor(p25) -- name: removeActor
	-- upvalues: (copy) v_u_13, (copy) v_u_1, (copy) v_u_14
	local v26 = v_u_13[p25]
	if v26 then
		v_u_13[p25] = nil
		local v27 = v_u_1.count
		local v28 = v_u_14[v27]
		v_u_14[v26.index] = v28
		v28.index = v26.index
		v_u_14[v27] = nil
		v_u_1.count = v27 - 1
	end
end
local function v_u_47(p29) -- name: buildFade
	-- upvalues: (copy) v_u_15, (copy) v_u_17, (copy) v_u_13, (ref) v_u_8
	local v_u_30 = p29.fI
	local v_u_31 = p29.fP
	local v_u_32 = p29.fB
	local v_u_33 = 0
	local function v_u_38(p34) -- name: add
		-- upvalues: (ref) v_u_15, (ref) v_u_17, (ref) v_u_33, (copy) v_u_30, (copy) v_u_31, (copy) v_u_32
		local v35 = v_u_15[p34.ClassName]
		if v35 and not v_u_17[p34] then
			for _, v36 in ipairs(v35) do
				local v37 = p34[v36]
				if v37 >= 1 then
					continue
				end
				v_u_33 = v_u_33 + 1
				v_u_30[v_u_33] = p34
				v_u_31[v_u_33] = v36
				v_u_32[v_u_33] = v37
			end
		end
	end
	local function v_u_44(p39) -- name: walk
		-- upvalues: (copy) v_u_38, (ref) v_u_13, (ref) v_u_8, (copy) v_u_44
		v_u_38(p39)
		for _, v40 in ipairs(p39:GetChildren()) do
			local v41 = v_u_13[v40]
			if v40:IsA("GuiObject") then
				if not v40.Visible then
					continue
				end
				for _, v42 in ipairs(v_u_8) do
					if v40.Parent ~= v42 then
						continue
					end
					v43 = true
				end
				local v43 = false
				if v43 or v41 and v41.entrance then
					break
				end
			end
			v_u_44(v40)
		end
	end
	v_u_44(p29.inst)
	local v45 = v_u_33
	for v46 = v_u_33 + 1, p29.fN do
		v_u_30[v46] = nil
		v_u_31[v46] = nil
		v_u_32[v46] = nil
	end
	p29.fN = v45
end
local function v_u_55(p48, p49) -- name: writeFade
	local v50 = p48.fI
	local v51 = p48.fP
	local v52 = p48.fB
	for v53 = 1, p48.fN do
		local v54 = v52[v53]
		v50[v53][v51[v53]] = v54 + (1 - v54) * p49
	end
end
function v_u_1.writeActor(p56) -- name: writeActor
	-- upvalues: (ref) v_u_12, (copy) v_u_55
	local v57 = p56.ox.x + p56.ix
	local v58 = p56.oy.x + p56.iy
	local v59 = v57 - p56.wx
	local v60 = v58 - p56.wy
	local v61 = p56.eP
	if v61 < v59 or (v59 < -v61 or (v61 < v60 or v60 < -v61)) then
		p56.wx = v57
		p56.wy = v58
		p56.inst.Position = UDim2.new(p56.hxS + v57, p56.hxO, p56.hyS + v58, p56.hyO)
	end
	local v62 = p56.rot.x + p56.ir
	local v63 = p56.hr
	if v63 then
		v62 = v62 + v63.x
	end
	local v64 = v62 - p56.wr
	local v65 = p56.eR
	if v65 < v64 or v64 < -v65 then
		p56.wr = v62
		p56.inst.Rotation = p56.hRot + v62
	end
	local v66 = p56.sc.x * p56.is
	local v67 = p56.hs
	if v67 then
		v66 = v66 * v67.x
	end
	local v68 = v66 < 0 and 0 or v66
	local v69 = v68 - p56.ws
	local v70 = p56.eS
	if (v70 < v69 or v69 < -v70) and p56.scaleObj then
		p56.ws = v68
		p56.scaleObj.Scale = p56.hScale * v68
	end
	if p56.fN > 0 then
		local v71 = p56.a.x
		local v72 = v71 < 0 and 0 or (v71 > 1 and 1 or v71)
		local v73 = v72 - p56.wa
		if v73 ~= 0 and (v_u_12 < v73 or (v73 < -v_u_12 or (v72 == 0 or v72 == 1))) then
			p56.wa = v72
			v_u_55(p56, v72)
		end
	end
end
local function v_u_82(p74) -- name: forceWrite
	-- upvalues: (copy) v_u_55
	local v75 = p74.ox.x + p74.ix
	local v76 = p74.oy.x + p74.iy
	if v75 ~= p74.wx or v76 ~= p74.wy then
		p74.wx = v75
		p74.wy = v76
		p74.inst.Position = UDim2.new(p74.hxS + v75, p74.hxO, p74.hyS + v76, p74.hyO)
	end
	local v77 = p74.rot.x + p74.ir + (p74.hr and (p74.hr.x or 0) or 0)
	if v77 ~= p74.wr then
		p74.wr = v77
		p74.inst.Rotation = p74.hRot + v77
	end
	local v78 = p74.sc.x * p74.is * (p74.hs and (p74.hs.x or 1) or 1)
	local v79 = math.max(v78, 0)
	if v79 ~= p74.ws and p74.scaleObj then
		p74.ws = v79
		p74.scaleObj.Scale = p74.hScale * v79
	end
	local v80 = p74.a.x
	local v81 = math.clamp(v80, 0, 1)
	if v81 ~= p74.wa then
		p74.wa = v81
		v_u_55(p74, v81)
	end
end
v_u_1.forceWrite = v_u_82
function v_u_1.refresh(p83) -- name: refresh
	-- upvalues: (copy) v_u_1, (ref) v_u_6, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (copy) v_u_47
	local v84 = p83.inst.Position
	local v85 = v84.X.Scale
	local v86 = v84.X.Offset
	local v87 = v84.Y.Scale
	local v88 = v84.Y.Offset
	p83.hxS = v85
	p83.hxO = v86
	p83.hyS = v87
	p83.hyO = v88
	p83.hRot = p83.inst.Rotation
	p83.hScale = p83.scaleObj and (p83.scaleObj.Scale or 1) or 1
	local v89 = p83.inst.Parent
	local v90 = v_u_1.panel.screen
	local v91 = p83.eKey ~= v90 and p83.inst.AbsoluteSize or Vector2.zero
	if v91.X > 0 and (v91.Y > 0 and (v89 and v89:IsA("GuiBase2d"))) then
		p83.eKey = v90
		local v92 = v_u_6.WRITE_PX
		local v93 = v89.AbsoluteSize
		local v94 = v_u_9
		local v95 = v93.X
		local v96 = v93.Y
		local v97 = v92 / math.max(v95, v96, 1)
		p83.eP = math.max(v94, v97)
		local v98 = v_u_10
		local v99 = v92 * 360 / (3.141592653589793 * v91.Magnitude)
		p83.eR = math.max(v98, v99)
		local v100 = v_u_11
		local v101 = v91.X
		local v102 = v91.Y
		local v103 = v92 / math.max(v101, v102)
		p83.eS = math.max(v100, v103)
	end
	if p83.fades then
		v_u_47(p83)
	elseif p83.customFade then
		p83.customFade(p83)
	end
end
function v_u_1.park(p104) -- name: park
	-- upvalues: (ref) v_u_3, (copy) v_u_82
	v_u_3(p104.ox, p104.pX)
	v_u_3(p104.oy, p104.pY)
	v_u_3(p104.rot, p104.pR)
	v_u_3(p104.sc, p104.pS)
	v_u_3(p104.a, p104.pA)
	p104.ix = 0
	p104.iy = 0
	p104.ir = 0
	p104.is = 1
	if p104.spinA then
		p104.spinA = 0
	end
	p104.idleAt = (1 / 0)
	p104.session = true
	v_u_82(p104)
end
function v_u_1.toRest(p105) -- name: toRest
	-- upvalues: (ref) v_u_3, (copy) v_u_82
	v_u_3(p105.ox, 0)
	v_u_3(p105.oy, 0)
	v_u_3(p105.rot, 0)
	v_u_3(p105.sc, 1)
	v_u_3(p105.a, 0)
	if p105.hs then
		v_u_3(p105.hs, 1)
		v_u_3(p105.hr, 0)
	end
	p105.ix = 0
	p105.iy = 0
	p105.ir = 0
	p105.is = 1
	if p105.spinA then
		p105.spinA = 0
	end
	p105.pend = 0
	p105.idleAt = (1 / 0)
	p105.live = false
	p105.session = false
	v_u_82(p105)
end
function v_u_1.goIn(p106, p107) -- name: goIn
	-- upvalues: (ref) v_u_4
	v_u_4(p106.ox, 0, p106.inF, p106.inD)
	v_u_4(p106.oy, 0, p106.inF, p106.inD)
	v_u_4(p106.rot, 0, p106.inF, p106.inD)
	v_u_4(p106.sc, 1, p106.inF, p106.inD)
	v_u_4(p106.a, 0, p106.aInF, 1)
	p106.idleAt = p107 + p106.idleDelay
	p106.live = true
end
function v_u_1.goOut(p108) -- name: goOut
	-- upvalues: (ref) v_u_4, (ref) v_u_5
	v_u_4(p108.ox, p108.pX, p108.outF, p108.outD)
	v_u_4(p108.oy, p108.qY or p108.pY, p108.outF, p108.outD)
	v_u_4(p108.rot, p108.pR, p108.outF, p108.outD)
	v_u_4(p108.sc, p108.qS or p108.pS, p108.outF, p108.outD)
	v_u_4(p108.a, p108.pA, p108.aOutF, 1)
	if p108.outKick ~= 0 then
		v_u_5(p108.sc, p108.outKick)
	end
	p108.live = true
end
function v_u_1.define(p109, p110) -- name: define
	-- upvalues: (copy) v_u_1, (ref) v_u_6
	if not p109 then
		return nil
	end
	local v111 = v_u_1.makeActor(p109, p110.noScale)
	local v112 = p110.park
	local v113 = v112[1]
	local v114 = v112[2]
	local v115 = v112[3]
	local v116 = v112[4]
	local v117 = v112[5]
	v111.pX = v113
	v111.pY = v114
	v111.pR = v115
	v111.pS = v116
	v111.pA = v117
	v111.inAt = p110.inAt
	local v118 = p110.inSpring[1]
	local v119 = p110.inSpring[2]
	v111.inF = v118
	v111.inD = v119
	v111.outAt = p110.outAt
	local v120 = p110.outSpring[1]
	local v121 = p110.outSpring[2]
	v111.outF = v120
	v111.outD = v121
	v111.aInF = p110.alphaIn or v_u_6.ALPHA_IN
	v111.aOutF = p110.alphaOut or v_u_6.ALPHA_OUT
	v111.outKick = p110.outKick or 0
	v111.fades = p110.fades ~= false
	v111.tabAt = p110.tabAt or 0
	v111.entrance = true
	return v111
end
function v_u_1.init(p122) -- name: init
	-- upvalues: (ref) v_u_2, (ref) v_u_3, (ref) v_u_4, (ref) v_u_5, (ref) v_u_6, (ref) v_u_7, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (ref) v_u_12
	v_u_2 = p122.Spring
	local v123 = v_u_2.snap
	local v124 = v_u_2.to
	local v125 = v_u_2.kick
	v_u_3 = v123
	v_u_4 = v124
	v_u_5 = v125
	v_u_6 = p122.T
	local v126 = p122.gui
	local v127 = p122.grids
	v_u_7 = v126
	v_u_8 = v127
	local v128 = v_u_6.POS_EPS
	local v129 = v_u_6.ROT_EPS
	local v130 = v_u_6.SCALE_EPS
	local v131 = v_u_6.ALPHA_EPS
	v_u_9 = v128
	v_u_10 = v129
	v_u_11 = v130
	v_u_12 = v131
end
function v_u_1.clear() -- name: clear
	-- upvalues: (copy) v_u_17, (copy) v_u_13, (copy) v_u_14, (copy) v_u_1
	table.clear(v_u_17)
	table.clear(v_u_13)
	table.clear(v_u_14)
	v_u_1.count = 0
end
return v_u_1
local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(v2.Shared.EggConfig)
local v_u_5 = require(v2.Shared.LuckyEggConfig)
local v_u_6 = require(script.Parent.Parent.Modules.EggCullQuality)
local v_u_7 = require(script.Parent.Parent.Modules.EggViewFrustum)
local v8 = {}
local function v_u_10(p9) -- name: isCullable
	return p9:IsA("ParticleEmitter") or (p9:IsA("Trail") or p9:IsA("Beam")) or (p9:IsA("Light") or p9:IsA("Fire") or (p9:IsA("Smoke") or p9:IsA("Sparkles")))
end
local v_u_11 = {}
local v_u_12 = {}
local function v_u_18(p13) -- name: applyState
	for v14, v17 in p13.effects do
		if v14.Parent then
			local v16
			if p13.near == true then
				if v17 then
					local v17 = p13.offView
				end
				v16 = not v17
			else
				v16 = false
			end
			if v14.Enabled == v16 then
				continue
			end
			v14.Enabled = v16
		else
			p13.effects[v14] = nil
		end
	end
end
local function v_u_22(p19) -- name: untrack
	-- upvalues: (copy) v_u_11, (copy) v_u_12
	local v20 = v_u_11[p19]
	if v20 then
		v_u_11[p19] = nil
		v_u_12[p19] = nil
		for _, v21 in v20.connections do
			v21:Disconnect()
		end
	end
end
local function v_u_52(p_u_23) -- name: track
	-- upvalues: (copy) v_u_11, (copy) v_u_10, (copy) v_u_12, (copy) v_u_18
	if p_u_23:IsA("BasePart") and not v_u_11[p_u_23] then
		if not (p_u_23:GetAttribute("Hatching") or p_u_23:GetAttribute("Broken")) then
			local v24 = p_u_23:FindFirstAncestorOfClass("Model")
			if not v24 or v24.PrimaryPart ~= p_u_23 then
				v24 = p_u_23
			end
			local v_u_25 = {
				["root"] = nil,
				["effects"] = nil,
				["connections"] = nil,
				["near"] = nil,
				["offView"] = false,
				["offscreenSince"] = nil,
				["root"] = v24,
				["effects"] = {},
				["connections"] = {}
			}
			v_u_11[p_u_23] = v_u_25
			local function v30(p26) -- name: register
				-- upvalues: (ref) v_u_10, (copy) v_u_25
				if v_u_10(p26) and p26.Enabled then
					local v27 = p26:IsA("ParticleEmitter") or p26:IsA("Fire") or (p26:IsA("Smoke") or p26:IsA("Sparkles"))
					v_u_25.effects[p26] = v27
					if v_u_25.near ~= nil then
						local v28 = v_u_25
						local v29
						if v28.near == true then
							if v27 then
								v27 = v28.offView
							end
							v29 = not v27
						else
							v29 = false
						end
						if not v29 then
							p26.Enabled = false
						end
					end
				end
			end
			for _, v31 in v24:GetDescendants() do
				if not v_u_10(v31) then
					continue
				end
				if not v31.Enabled then
					continue
				end
				local v32 = v31:IsA("ParticleEmitter") or v31:IsA("Fire") or (v31:IsA("Smoke") or v31:IsA("Sparkles"))
				v_u_25.effects[v31] = v32
				if v_u_25.near == nil then
					continue
				end
				local v33
				if v_u_25.near == true then
					if v32 then
						v32 = v_u_25.offView
					end
					v33 = not v32
				else
					v33 = false
				end
				if v33 then
					continue
				end
				v31.Enabled = false
			end
			local v34 = v_u_25.connections
			local v35 = v24.DescendantAdded
			table.insert(v34, v35:Connect(v30))
			local v36 = v_u_25.connections
			local v37 = p_u_23:GetAttributeChangedSignal("Hatching")
			local function v43()
				-- upvalues: (copy) p_u_23, (copy) v_u_25, (ref) v_u_12, (ref) v_u_18, (ref) v_u_11
				if p_u_23:GetAttribute("Hatching") then
					if v_u_25.offView then
						local v38 = p_u_23
						local v39 = v_u_25
						v39.offView = false
						v39.offscreenSince = nil
						v_u_12[v38] = nil
						v_u_18(v39)
					end
					local v40 = p_u_23
					local v41 = v_u_11[v40]
					if not v41 then
						return
					end
					v_u_11[v40] = nil
					v_u_12[v40] = nil
					for _, v42 in v41.connections do
						v42:Disconnect()
					end
				end
			end
			table.insert(v36, v37:Connect(v43))
			local v44 = v_u_25.connections
			local v45 = p_u_23:GetAttributeChangedSignal("Broken")
			local function v51()
				-- upvalues: (copy) p_u_23, (copy) v_u_25, (ref) v_u_12, (ref) v_u_18, (ref) v_u_11
				if p_u_23:GetAttribute("Broken") then
					if v_u_25.offView then
						local v46 = p_u_23
						local v47 = v_u_25
						v47.offView = false
						v47.offscreenSince = nil
						v_u_12[v46] = nil
						v_u_18(v47)
					end
					local v48 = p_u_23
					local v49 = v_u_11[v48]
					if not v49 then
						return
					end
					v_u_11[v48] = nil
					v_u_12[v48] = nil
					for _, v50 in v49.connections do
						v50:Disconnect()
					end
				end
			end
			table.insert(v44, v45:Connect(v51))
		end
	else
		return
	end
end
function v8.Start() -- name: Start
	-- upvalues: (copy) v_u_1, (copy) v_u_52, (copy) v_u_22, (copy) v_u_4, (copy) v_u_3, (copy) v_u_7, (copy) v_u_12, (copy) v_u_11, (copy) v_u_18, (copy) v_u_6, (copy) v_u_5
	for _, v53 in v_u_1:GetTagged("BreakableEgg") do
		v_u_52(v53)
	end
	v_u_1:GetInstanceAddedSignal("BreakableEgg"):Connect(v_u_52)
	v_u_1:GetInstanceRemovedSignal("BreakableEgg"):Connect(v_u_22)
	local v_u_54 = v_u_4.AmbientCull
	local v_u_55 = v_u_4.ViewCull
	local v_u_56 = v_u_55.PauseEggVFX == true
	if v_u_56 then
		v_u_3:BindToRenderStep("EggVFXCullView", v_u_7.RENDER_PRIORITY_AFTER, function()
			-- upvalues: (ref) v_u_12, (ref) v_u_11, (ref) v_u_7, (ref) v_u_18
			for v57, v58 in v_u_12 do
				if v57.Parent then
					if not v_u_7.IsEggVisible(v57) then
						continue
					end
					v58.offView = false
					v58.offscreenSince = nil
					v_u_12[v57] = nil
					v_u_18(v58)
				else
					local v59 = v_u_11[v57]
					if not v59 then
						continue
					end
					v_u_11[v57] = nil
					v_u_12[v57] = nil
					for _, v60 in v59.connections do
						v60:Disconnect()
					end
				end
			end
		end)
	end
	local v_u_61 = 0
	v_u_3.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_61, (copy) v_u_54, (ref) v_u_11, (ref) v_u_12, (ref) v_u_6, (ref) v_u_5, (copy) v_u_55, (ref) v_u_18, (copy) v_u_56, (ref) v_u_7
		local v62 = os.clock()
		if v62 < v_u_61 then
			return
		else
			v_u_61 = v62 + v_u_54.CheckInterval
			local v63 = workspace.CurrentCamera
			if v63 then
				local v64 = v63.CFrame.Position
				for v65, v66 in v_u_11 do
					if v65.Parent then
						local v67 = v65.Position
						local v68 = v67 - v64
						local v69 = v68:Dot(v68)
						local v70 = v65:GetAttribute("Lucky") == true
						local v71 = v_u_6.EggDistance
						local v72
						if v70 then
							v72 = v_u_5.AuraViewDistance
						else
							v72 = v_u_54.Distance
						end
						local v73 = v71(v72, v65)
						local v74 = v73 * v73
						local v75 = (v73 + v_u_54.Hysteresis) ^ 2
						local v76 = v_u_6.EggHideDelay(v_u_55.HideDelay, v65)
						if v66.near == nil then
							v66.near = v69 <= v75
							v_u_18(v66)
						elseif v66.near and v75 <= v69 then
							v66.near = false
							v_u_18(v66)
						elseif not v66.near and v69 <= v74 then
							v66.near = true
							v_u_18(v66)
						end
						if not v_u_56 or v66.offView then
							continue
						end
						if v66.near and not v_u_7.IsVisible(v67, v65.Size) then
							if v66.offscreenSince then
								if v76 > v62 - v66.offscreenSince then
									continue
								end
								v66.offView = true
								v66.offscreenSince = nil
								v_u_12[v65] = v66
								v_u_18(v66)
							else
								v66.offscreenSince = v62
							end
						else
							v66.offscreenSince = nil
						end
					else
						local v77 = v_u_11[v65]
						if not v77 then
							continue
						end
						v_u_11[v65] = nil
						v_u_12[v65] = nil
						for _, v78 in v77.connections do
							v78:Disconnect()
						end
					end
				end
			end
		end
	end)
end
return v8
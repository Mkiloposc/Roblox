local v_u_1 = game:GetService("LocalizationService")
local v_u_2 = game:GetService("Chat")
local v_u_3 = {
	["System"] = "InGame.Chat.Label.SystemMessagePrefix",
	["Team"] = "InGame.Chat.Label.TeamMessagePrefix"
}
local v_u_4 = {
	["From(%s.+)"] = {
		["English"] = "From",
		["LocalizationKey"] = "InGame.Chat.Label.From"
	},
	["To(%s.+)"] = {
		["English"] = "To",
		["LocalizationKey"] = "InGame.Chat.Label.To"
	}
}
return {
	["_hasFetchedLocalization"] = false,
	["_getTranslator"] = function(p_u_5) -- name: _getTranslator
		-- upvalues: (copy) v_u_2, (copy) v_u_1
		if not (p_u_5._translator or p_u_5._hasFetchedLocalization) then
			p_u_5._hasFetchedLocalization = true
			local v6 = v_u_2:WaitForChild("ChatLocalization", 4)
			if v6 then
				p_u_5._translator = v6:GetTranslator(v_u_1.RobloxLocaleId)
				v_u_1:GetPropertyChangedSignal("RobloxLocaleId"):Connect(function()
					-- upvalues: (copy) p_u_5
					p_u_5._hasFetchedLocalization = false
					p_u_5._translator = nil
				end)
			else
				warn("Missing ChatLocalization. Chat interface will not be localized.")
			end
		end
		return p_u_5._translator
	end,
	["Get"] = function(p_u_7, p_u_8, p9, p_u_10) -- name: Get
		local v_u_11 = p9
		pcall(function()
			-- upvalues: (copy) p_u_7, (ref) v_u_11, (copy) p_u_8, (copy) p_u_10
			local v12 = p_u_7:_getTranslator()
			if v12 then
				v_u_11 = v12:FormatByKey(p_u_8, p_u_10)
			else
				warn("Missing Translator. Used default for", p_u_8)
			end
		end)
		return v_u_11
	end,
	["LocalizeFormattedMessage"] = function(p13, p14) -- name: LocalizeFormattedMessage
		local v15, v16 = string.find(p14, "{RBX_LOCALIZATION_KEY}")
		if not v15 then
			return p14
		end
		local v17, v18 = string.find(p14, "{RBX_LOCALIZATION_DEFAULT}")
		if not v17 then
			return p14
		end
		local v19, v20 = string.find(p14, "{RBX_LOCALIZATION_PARAMS}")
		local v21 = v16 + 1
		local v22 = v17 - 1
		local v23 = string.sub(p14, v21, v22)
		if not v19 then
			local v24 = v18 + 1
			return p13:Get(v23, (string.sub(p14, v24)))
		end
		local v25 = v18 + 1
		local v26 = v19 - 1
		local v27 = string.sub(p14, v25, v26)
		local v28 = v20 + 1
		local v29 = string.sub(p14, v28)
		local v30 = {}
		for v31, v32 in string.gmatch(v29, "([^%s]+)=([^%s]+)") do
			v30[v31] = v32
		end
		return p13:Get(v23, v27, v30)
	end,
	["FormatMessageToSend"] = function(_, p33, p34, p35, p36) -- name: FormatMessageToSend
		if p35 and p36 then
			return "{RBX_LOCALIZATION_KEY}" .. p33 .. "{RBX_LOCALIZATION_DEFAULT}" .. p34 .. "{RBX_LOCALIZATION_PARAMS}" .. p35 .. "=" .. p36
		else
			return "{RBX_LOCALIZATION_KEY}" .. p33 .. "{RBX_LOCALIZATION_DEFAULT}" .. p34
		end
	end,
	["tryLocalize"] = function(p37, p38) -- name: tryLocalize
		-- upvalues: (copy) v_u_3, (copy) v_u_4
		if v_u_3[p38] then
			return p37:Get(v_u_3[p38], p38)
		end
		for v39, v40 in pairs(v_u_3) do
			if not string.find(p38, v39) then
				continue
			end
			local v41 = p37:Get(v40, v39)
			return string.gsub(p38, v39, v41, 1)
		end
		for v42, v43 in pairs(v_u_4) do
			local v44 = string.find(p38, v42)
			local v45 = string.match(p38, v42)
			if not (v44 and v45) then
				continue
			end
			local v46 = p37:Get(v43.LocalizationKey, v43.English)
			return (v44 <= 1 and "" or p38:sub(1, v44 - 1)) .. v46 .. v45
		end
		return p38
	end
}
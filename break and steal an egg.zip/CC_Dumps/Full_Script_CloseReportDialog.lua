local v1 = game:GetService("CorePackages")
return require(v1.Packages.Rodux).makeActionCreator("CLOSE_REPORT_DIALOG", function()
	return {}
end)
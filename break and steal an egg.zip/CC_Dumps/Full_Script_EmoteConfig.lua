return {
	["Emotes"] = {
		{
			["Name"] = "BatSwing",
			["AnimationId"] = 522635514,
			["Slot"] = 8
		}
	}
}
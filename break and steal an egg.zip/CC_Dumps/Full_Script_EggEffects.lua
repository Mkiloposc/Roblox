local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("ContentProvider")
local v_u_3 = game:GetService("Debris")
local v_u_4 = game:GetService("Players")
local v_u_5 = game:GetService("ReplicatedStorage")
local v_u_6 = game:GetService("RunService")
local v_u_7 = game:GetService("SoundService")
local v_u_8 = game:GetService("TweenService")
local v_u_9 = require(v_u_5.Shared.DisplayHype)
local v_u_10 = require(v_u_5.Shared.EggConfig)
local v_u_11 = require(v_u_5.Shared.EggInfoUi)
local v_u_12 = require(v_u_5.Shared.EggRewards)
local v_u_13 = require(v_u_5.Shared.HatchVFX)
local v_u_14 = require(v_u_5.Shared.ModelScaler)
local v_u_15 = require(v_u_5.Shared.TitanicEggConfig)
local v_u_16 = require(v_u_5.Shared.ZoneHitboxLookup)
local v_u_17 = require(script.Parent.EggLocalHits)
local v_u_18 = require(script.Parent.Parent.Modules.EggCullQuality)
local v_u_19 = require(script.Parent.Parent.Modules.EggRarityBurst)
local v_u_20 = require(script.Parent.Parent.Modules.EggViewFrustum)
local v_u_21 = require(script.Parent.Parent.Modules.SfxBudget)
local v22 = {}
local v_u_23 = {}
local v_u_24 = {}
local v_u_25 = v_u_4.LocalPlayer
local v_u_26 = {}
local v_u_27 = {}
local function v_u_46(p28) -- name: preloadVariantSkins
	-- upvalues: (copy) v_u_27, (copy) v_u_12, (copy) v_u_2
	local v_u_29 = p28:GetAttribute("Variant")
	local v_u_30 = p28:GetAttribute("EggType")
	if typeof(v_u_29) == "string" and (v_u_29 ~= "" and typeof(v_u_30) == "string") then
		local v_u_31 = p28:GetAttribute("HatchAnimal")
		if typeof(v_u_31) ~= "string" or v_u_31 == "" then
			v_u_31 = nil
		end
		local v32
		if v_u_31 then
			v32 = ("%*:%*"):format(v_u_29, v_u_31)
		else
			v32 = ("%*:%*"):format(v_u_29, v_u_30)
		end
		if not v_u_27[v32] then
			v_u_27[v32] = true
			task.spawn(function()
				-- upvalues: (ref) v_u_31, (ref) v_u_12, (copy) v_u_29, (copy) v_u_30, (ref) v_u_2
				local v33 = {}
				local v34 = v_u_31 and v_u_12.FindAnimalTemplate(v_u_31, v_u_29)
				if v34 then
					table.insert(v33, v34)
				end
				if #v33 == 0 then
					local v35 = v_u_12.RosterZoneOf(v_u_12.ZoneOfEggType(v_u_30))
					for _, v36 in v_u_12.Pool do
						if v36.Zone == nil or v36.Zone ~= v35 then
							continue
						end
						local v37 = v_u_12.FindAnimalTemplate(v36.Name, v_u_29)
						if not v37 then
							continue
						end
						table.insert(v33, v37)
					end
				end
				local v38 = {}
				local v39 = {}
				for _, v40 in v33 do
					for _, v41 in v40:GetDescendants() do
						if not v41:IsA("SurfaceAppearance") or (v41.ColorMap == "" or v38[v41.ColorMap]) then
							continue
						end
						v38[v41.ColorMap] = true
						local v42 = Instance.new("Decal")
						v42.Texture = v41.ColorMap
						table.insert(v39, v42)
					end
				end
				if #v39 > 0 then
					local v43 = v_u_2.PreloadAsync
					local v44 = v_u_2
					pcall(v43, v44, v39)
					for _, v45 in v39 do
						v45:Destroy()
					end
				end
			end)
		end
	else
		return
	end
end
local function v_u_60(p47) -- name: attachHitVfx
	-- upvalues: (copy) v_u_10, (copy) v_u_5, (copy) v_u_13
	local v48 = v_u_10.Hit.VFXName or "EggHit"
	local v49 = v_u_5:FindFirstChild("VFX")
	if v49 then
		v49 = v49:FindFirstChild(v48)
	end
	if not (v49 and v49:IsA("Attachment")) then
		v49 = nil
	end
	if not v49 then
		return nil
	end
	local v50 = v49:Clone()
	v50.Name = "HitVFX"
	v50.Position = Vector3.new(0, 0, 0)
	local v51 = v_u_10.VFXScaleForWidth
	local v52 = p47.Size.X
	local v53 = p47.Size.Z
	local v54 = v51((math.min(v52, v53)))
	local v55 = {}
	for _, v56 in v50:GetDescendants() do
		if not v56:IsA("ParticleEmitter") then
			continue
		end
		v56.Enabled = false
		if v54 ~= 1 then
			v_u_13.ScaleParticle(v56, v54)
		end
		local v57 = {
			["emitter"] = v56
		}
		local v58 = (v56:GetAttribute("EmitCount") or v56.Rate) * v54
		local v59 = math.ceil(v58)
		v57.count = math.max(v59, 1)
		table.insert(v55, v57)
	end
	v50.Parent = p47
	return {
		["attachment"] = v50,
		["emitters"] = v55
	}
end
local function v_u_63(p61) -- name: emitHitVfx
	if p61 and p61.attachment.Parent then
		for _, v62 in p61.emitters do
			v62.emitter:Emit(v62.count)
		end
	end
end
local v_u_64 = 0
local v_u_65 = nil
local function v_u_84(p_u_66, p_u_67, p68) -- name: screenShake
	-- upvalues: (ref) v_u_64, (ref) v_u_65, (copy) v_u_25, (copy) v_u_6
	v_u_64 = v_u_64 + 1
	local v_u_69 = v_u_64
	if v_u_65 then
		v_u_65()
		v_u_65 = nil
	end
	local v_u_70 = v_u_25.Character
	if v_u_70 then
		v_u_70 = v_u_70:FindFirstChildOfClass("Humanoid")
	end
	if v_u_70 then
		local v_u_71 = v_u_70.CameraOffset
		local function v_u_72() -- name: restore
			-- upvalues: (copy) v_u_70, (copy) v_u_71, (ref) v_u_65, (ref) v_u_72
			if v_u_70.Parent then
				v_u_70.CameraOffset = v_u_71
			end
			if v_u_65 == v_u_72 then
				v_u_65 = nil
			end
		end
		v_u_65 = v_u_72
		local v_u_73 = os.clock()
		local v_u_74 = 10 / math.max(p68, 0.05)
		local v_u_75 = nil
		v_u_75 = v_u_6.RenderStepped:Connect(function()
			-- upvalues: (copy) v_u_73, (copy) v_u_69, (ref) v_u_64, (copy) p_u_66, (copy) v_u_70, (ref) v_u_75, (ref) v_u_72, (copy) v_u_74, (copy) v_u_71, (copy) p_u_67
			local v76 = os.clock() - v_u_73
			if v_u_69 == v_u_64 and (p_u_66 > v76 and v_u_70.Parent) then
				local v77 = (p_u_66 - v76) / (p_u_66 * 0.25)
				local v78 = math.clamp(v77, 0, 1)
				local v79 = v76 * v_u_74
				local v80 = v_u_70
				local v81 = v_u_71
				local v82 = math.noise(v79, 7.3) * 2 * p_u_67 * v78
				local v83 = math.noise(v79, 17.9) * 2 * p_u_67 * v78
				v80.CameraOffset = v81 + Vector3.new(v82, v83, 0)
			else
				v_u_75:Disconnect()
				if v_u_69 == v_u_64 then
					v_u_72()
				end
			end
		end)
	end
end
local v_u_85 = {}
local function v_u_99(p86, p87, p88, p89, p90) -- name: playSfx
	-- upvalues: (copy) v_u_85, (copy) v_u_7, (copy) v_u_3
	local v91 = p89 or "SFX"
	local v92 = v_u_85[v91]
	if not (v92 and v92.Parent) then
		v92 = v_u_7:FindFirstChild(v91)
		v_u_85[v91] = v92
	end
	if v92 then
		v92 = v92:FindFirstChild(p86)
	end
	if not (v92 and v92:IsA("Sound")) then
		v92 = nil
	end
	if v92 then
		if p88 and p87 then
			local v93 = workspace.CurrentCamera
			local v94
			if p87:IsA("BasePart") then
				v94 = p87.Position
			elseif p87:IsA("Attachment") then
				v94 = p87.WorldPosition
			else
				v94 = nil
			end
			if v93 and (v94 and p88 < (v93.CFrame.Position - v94).Magnitude) then
				return
			end
		end
		local v_u_95 = v92:Clone()
		if p88 then
			v_u_95.RollOffMode = Enum.RollOffMode.LinearSquare
			local v96 = p88 / 2
			v_u_95.RollOffMinDistance = math.min(10, v96)
			v_u_95.RollOffMaxDistance = p88
		end
		if p90 then
			v_u_95.PlaybackSpeed = p90
		end
		v_u_95.Parent = p87 or v_u_7
		v_u_95.Ended:Once(function()
			-- upvalues: (copy) v_u_95
			v_u_95:Destroy()
		end)
		local v97 = v_u_3
		local v98 = v_u_95.TimeLength
		v97:AddItem(v_u_95, math.max(v98, 1) + 1)
		v_u_95:Play()
	end
end
local function v_u_112(p100, p101, p102, p103, p104, p_u_105) -- name: playLoopedSfx
	-- upvalues: (copy) v_u_85, (copy) v_u_7, (copy) v_u_8, (copy) v_u_3
	local v106 = p103 or "SFX"
	local v107 = v_u_85[v106]
	if not (v107 and v107.Parent) then
		v107 = v_u_7:FindFirstChild(v106)
		v_u_85[v106] = v107
	end
	if v107 then
		v107 = v107:FindFirstChild(p100)
	end
	if not (v107 and v107:IsA("Sound")) then
		v107 = nil
	end
	if not v107 then
		return function() end
	end
	local v_u_108 = v107:Clone()
	v_u_108.Looped = true
	if p104 then
		v_u_108.Volume = p104
	end
	v_u_108.RollOffMode = Enum.RollOffMode.LinearSquare
	local v109 = p102 / 2
	v_u_108.RollOffMinDistance = math.min(10, v109)
	v_u_108.RollOffMaxDistance = p102
	v_u_108.Parent = p101
	v_u_108:Play()
	local v_u_110 = false
	return function()
		-- upvalues: (ref) v_u_110, (copy) p_u_105, (copy) v_u_108, (ref) v_u_8, (ref) v_u_3
		if v_u_110 then
			return
		else
			v_u_110 = true
			local v111 = p_u_105 or 0
			if v111 > 0 and v_u_108.Parent then
				v_u_8:Create(v_u_108, TweenInfo.new(v111, Enum.EasingStyle.Linear), {
					["Volume"] = 0
				}):Play()
				v_u_3:AddItem(v_u_108, v111 + 0.1)
			else
				v_u_108:Destroy()
			end
		end
	end
end
local function v_u_117(p113) -- name: nestFullyReplicated
	local v114 = p113:GetAttribute("NestParts") or 0
	if v114 <= 0 then
		return true
	end
	local v115 = 0
	for _, v116 in p113:GetDescendants() do
		if not v116:IsA("BasePart") then
			continue
		end
		v115 = v115 + 1
	end
	return v114 <= v115
end
local function v_u_541(p_u_118) -- name: setupEgg
	-- upvalues: (copy) v_u_10, (copy) v_u_14, (copy) v_u_60, (copy) v_u_8, (copy) v_u_99, (copy) v_u_15, (copy) v_u_63, (copy) v_u_6, (copy) v_u_18, (copy) v_u_20, (copy) v_u_25, (copy) v_u_16, (copy) v_u_12, (copy) v_u_11, (copy) v_u_9, (copy) v_u_84, (copy) v_u_21, (copy) v_u_112, (copy) v_u_23, (copy) v_u_24, (copy) v_u_13, (copy) v_u_117, (copy) v_u_19, (copy) v_u_4, (copy) v_u_46, (copy) v_u_26, (copy) v_u_17
	if p_u_118:IsA("BasePart") and not p_u_118:GetAttribute("_EffectsHooked") then
		p_u_118:SetAttribute("_EffectsHooked", true)
		local v_u_119 = p_u_118.Size
		local v_u_120 = p_u_118.CFrame
		local v121 = v_u_10.VFXScaleForWidth
		local v122 = v_u_119.X
		local v123 = v_u_119.Z
		local v_u_124 = v121((math.min(v122, v123)))
		local v_u_125 = p_u_118:FindFirstAncestorOfClass("Model")
		if not v_u_125 or v_u_125.PrimaryPart ~= p_u_118 then
			v_u_125 = nil
		end
		local v_u_126 = nil
		local v_u_127 = false
		local v_u_128 = 0
		local function v_u_133() -- name: ensureEggRig
			-- upvalues: (ref) v_u_126, (copy) v_u_125, (copy) p_u_118, (ref) v_u_128, (ref) v_u_14
			if v_u_126 then
				return true
			end
			local v129 = v_u_125
			if not v129 then
				return true
			end
			local v130 = p_u_118:GetAttribute("EggParts") or 0
			if v130 > 0 then
				if os.clock() < v_u_128 then
					return false
				end
				local v131 = 0
				for _, v132 in v129:GetDescendants() do
					if not v132:IsA("BasePart") then
						continue
					end
					v131 = v131 + 1
				end
				if v131 < v130 then
					v_u_128 = os.clock() + 0.25
					return false
				end
			end
			v_u_126 = v_u_14.Capture(v129, p_u_118.CFrame)
			return true
		end
		local function v_u_139(p134, p135) -- name: applyTransform
			-- upvalues: (ref) v_u_127, (copy) v_u_133, (copy) v_u_125, (ref) v_u_126, (ref) v_u_14, (copy) p_u_118, (copy) v_u_119
			local v136 = not v_u_127
			if v136 then
				v136 = v_u_133()
			end
			local v137 = not v136 and 1 or p134
			if v_u_125 and v_u_125.Parent then
				local v138 = v_u_126
				if v138 then
					v_u_14.Apply(v138, math.max(v137, 0.001), p135)
				else
					v_u_125:SetPrimaryPartCFrame(p135)
				end
			else
				p_u_118.Size = v_u_119 * v137
				p_u_118.CFrame = p135
				return
			end
		end
		local function v_u_141() -- name: waitForWholeEgg
			-- upvalues: (copy) p_u_118, (copy) v_u_133
			local v140 = os.clock() + 2
			while p_u_118.Parent do
				if v_u_133() then
					return true
				end
				if v140 <= os.clock() then
					break
				end
				task.wait()
			end
			return false
		end
		local v_u_142 = Instance.new("Highlight")
		v_u_142.Name = "HitHighlight"
		v_u_142.FillColor = Color3.fromRGB(255, 255, 255)
		v_u_142.FillTransparency = 1
		v_u_142.OutlineTransparency = 1
		v_u_142.DepthMode = Enum.HighlightDepthMode.Occluded
		v_u_142.Enabled = false
		local v_u_143 = v_u_60(p_u_118)
		local v_u_144 = {}
		local v_u_145 = 0
		local v_u_146 = false
		local v_u_147 = false
		local v_u_148 = 0
		local function v_u_152() -- name: cancelActiveTweens
			-- upvalues: (ref) v_u_145, (copy) v_u_144, (copy) v_u_142, (ref) v_u_146, (ref) v_u_147, (copy) v_u_119, (copy) v_u_120, (copy) v_u_139
			v_u_145 = v_u_145 + 1
			for _, v149 in v_u_144 do
				v149:Cancel()
			end
			table.clear(v_u_144)
			v_u_142.Enabled = false
			v_u_142.Adornee = nil
			v_u_142.Parent = nil
			v_u_142.FillColor = Color3.new(1, 1, 1)
			if not (v_u_146 or v_u_147) then
				local v150 = v_u_120
				local v151 = ((v_u_119 * 1).Y - v_u_119.Y) / 2
				v_u_139(1, v150 + Vector3.new(0, v151, 0))
			end
		end
		local v_u_153 = v_u_8:Create(v_u_142, TweenInfo.new(v_u_10.Hit.FlashTime, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
			["FillTransparency"] = 1
		})
		v_u_153.Completed:Connect(function(p154)
			-- upvalues: (copy) v_u_142
			if p154 == Enum.PlaybackState.Completed then
				v_u_142.Enabled = false
				v_u_142.Adornee = nil
				v_u_142.Parent = nil
			end
		end)
		local function v_u_179(p155) -- name: playHitEffect
			-- upvalues: (copy) v_u_152, (ref) v_u_10, (ref) v_u_99, (copy) p_u_118, (ref) v_u_15, (ref) v_u_63, (copy) v_u_143, (ref) v_u_145, (copy) v_u_142, (copy) v_u_125, (copy) v_u_144, (copy) v_u_153, (ref) v_u_148, (ref) v_u_8, (ref) v_u_127, (copy) v_u_133, (copy) v_u_119, (copy) v_u_120, (copy) v_u_139, (ref) v_u_6, (ref) v_u_146
			v_u_152()
			if p155 or not v_u_10.Hit.SoundLocalOnly then
				local v156 = v_u_99
				local v157 = v_u_10.Hit.SoundName
				local v158 = p_u_118
				local v159 = p_u_118
				local v160 = v_u_10.Hit.SoundRange
				if v159:GetAttribute("Titanic") then
					v160 = v160 * (v_u_15.SoundRangeMult or 1)
				end
				v156(v157, v158, v160, v_u_10.Hit.SoundFolder)
			end
			v_u_63(v_u_143)
			local v_u_161 = v_u_10.Hit
			local v_u_162 = v_u_145
			v_u_142.FillTransparency = 0
			v_u_142.Adornee = v_u_125 or p_u_118
			v_u_142.Parent = p_u_118
			v_u_142.Enabled = true
			local v163 = v_u_144
			local v164 = v_u_153
			table.insert(v163, v164)
			v_u_153:Play()
			local v_u_165 = v_u_161.ShrinkTime + v_u_161.RecoverTime
			v_u_148 = os.clock() + v_u_165 + 0.1
			local v_u_166 = os.clock()
			local v_u_167 = 1
			task.spawn(function()
				-- upvalues: (copy) v_u_162, (ref) v_u_145, (copy) v_u_166, (copy) v_u_165, (copy) v_u_161, (ref) v_u_8, (ref) v_u_167, (ref) v_u_127, (ref) v_u_133, (ref) v_u_119, (ref) v_u_120, (ref) v_u_139, (ref) v_u_6, (ref) v_u_146
				while v_u_162 == v_u_145 do
					local v168 = os.clock() - v_u_166
					if v_u_165 <= v168 then
						break
					end
					local v169
					if v168 < v_u_161.ShrinkTime then
						local v170 = v_u_8:GetValue(v168 / v_u_161.ShrinkTime, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
						v169 = 1 + (v_u_161.ShrinkScale - 1) * v170
					else
						local v171 = v_u_8:GetValue((v168 - v_u_161.ShrinkTime) / v_u_161.RecoverTime, Enum.EasingStyle.Elastic, Enum.EasingDirection.Out)
						v169 = v_u_161.ShrinkScale + (1 - v_u_161.ShrinkScale) * v171
					end
					local v172 = v169 - v_u_167
					if math.abs(v172) >= v_u_167 * 0.015 then
						v_u_167 = v169
						local v173
						if (v169 or 1) == 1 then
							v173 = 1
						else
							local v174 = not v_u_127
							if v174 then
								v174 = v_u_133()
							end
							v173 = not v174 and 1 or v169
						end
						local v175 = v_u_120
						local v176 = ((v_u_119 * v173).Y - v_u_119.Y) / 2
						v_u_139(v169, v175 + Vector3.new(0, v176, 0))
					end
					v_u_6.RenderStepped:Wait()
				end
				if v_u_162 == v_u_145 and not v_u_146 then
					local v177 = v_u_120
					local v178 = ((v_u_119 * 1).Y - v_u_119.Y) / 2
					v_u_139(1, v177 + Vector3.new(0, v178, 0))
				end
			end)
		end
		local function v_u_195(p180) -- name: playIdleWiggle
			-- upvalues: (ref) v_u_145, (copy) v_u_119, (copy) v_u_120, (ref) v_u_146, (ref) v_u_147, (copy) v_u_139, (ref) v_u_6
			local v181 = v_u_145
			local v182 = math.random() * 6.283185307179586
			local v183 = p180.WiggleAngle
			local v184 = math.rad(v183)
			local v185 = math.cos(v182)
			local v186 = math.sin(v182)
			local v187 = v_u_120
			local v188 = ((v_u_119 * 1).Y - v_u_119.Y) / 2
			local v189 = v187 + Vector3.new(0, v188, 0)
			local v190 = os.clock()
			while v181 == v_u_145 and not (v_u_146 or v_u_147) do
				local v191 = os.clock() - v190
				local v192 = v191 / p180.WiggleTime
				if v192 >= 1 then
					break
				end
				local v193 = 6.283185307179586 * p180.WiggleRate * v191
				local v194 = v184 * math.sin(v193) * (1 - v192)
				v_u_139(1, v189 * CFrame.fromOrientation(v185 * v194, 0, v186 * v194))
				v_u_6.RenderStepped:Wait()
			end
			if v181 == v_u_145 and not (v_u_146 or v_u_147) then
				v_u_139(1, v189)
			end
		end
		local function v_u_207(p196) -- name: playIdleHop
			-- upvalues: (ref) v_u_145, (copy) v_u_119, (copy) v_u_120, (ref) v_u_146, (ref) v_u_147, (copy) v_u_139, (ref) v_u_6
			local v197 = v_u_145
			local v198 = v_u_119.Y * p196.HopHeightFrac
			local v199 = v_u_120
			local v200 = ((v_u_119 * 1).Y - v_u_119.Y) / 2
			local v201 = v199 + Vector3.new(0, v200, 0)
			local v202 = os.clock()
			while v197 == v_u_145 and not (v_u_146 or v_u_147) do
				local v203 = (os.clock() - v202) / p196.HopTime
				if v203 >= 1 then
					break
				end
				local v204 = v_u_139
				local v205 = 3.141592653589793 * v203
				local v206 = math.sin(v205) * v198
				v204(1, v201 + Vector3.new(0, v206, 0))
				v_u_6.RenderStepped:Wait()
			end
			if v197 == v_u_145 and not (v_u_146 or v_u_147) then
				v_u_139(1, v201)
			end
		end
		task.spawn(function()
			-- upvalues: (ref) v_u_10, (copy) p_u_118, (ref) v_u_146, (ref) v_u_147, (ref) v_u_148, (copy) v_u_120, (ref) v_u_18, (ref) v_u_20, (copy) v_u_119, (copy) v_u_207, (copy) v_u_195
			local v208 = v_u_10.Idle
			while p_u_118.Parent do
				task.wait(v208.MinDelay + math.random() * (v208.MaxDelay - v208.MinDelay))
				if v_u_146 or v_u_147 then
					break
				end
				if not p_u_118.Parent or v_u_148 > os.clock() then
					continue
				end
				local v209 = workspace.CurrentCamera
				local v210
				if v209 == nil or (v209.CFrame.Position - v_u_120.Position).Magnitude >= v_u_18.EggDistance(v_u_10.AmbientCull.Distance, p_u_118) then
					v210 = false
				else
					v210 = v_u_20.IsVisible(v_u_120.Position, v_u_119)
				end
				if not v210 then
					continue
				end
				if math.random() < v208.HopChance then
					v_u_207(v208)
				else
					v_u_195(v208)
				end
			end
		end)
		local function v_u_214() -- name: isInEggZone
			-- upvalues: (ref) v_u_25, (ref) v_u_16, (copy) p_u_118, (copy) v_u_120
			local v211 = v_u_25.Character
			if v211 then
				v211 = v211:FindFirstChild("HumanoidRootPart")
			end
			if not v211 then
				return false
			end
			local v212 = v_u_16.GetZoneIndexAt(v211.Position)
			if not v212 then
				return false
			end
			local v213 = p_u_118:GetAttribute("ZoneIndex")
			if typeof(v213) ~= "number" then
				v213 = v_u_16.GetZoneIndexAt(v_u_120.Position)
			end
			return v212 == v213
		end
		local v_u_215 = v_u_12.HatchSequence.SpinIntroDuration
		local function v_u_231() -- name: playSpinIntro
			-- upvalues: (copy) v_u_142, (copy) v_u_125, (copy) p_u_118, (ref) v_u_8, (copy) v_u_215, (copy) v_u_119, (copy) v_u_120, (copy) v_u_139, (ref) v_u_18, (ref) v_u_10, (ref) v_u_20, (ref) v_u_6
			v_u_142.FillTransparency = 1
			v_u_142.Adornee = v_u_125 or p_u_118
			v_u_142.Parent = p_u_118
			v_u_142.Enabled = true
			v_u_8:Create(v_u_142, TweenInfo.new(v_u_215, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["FillTransparency"] = 0
			}):Play()
			local v216 = v_u_120
			local v217 = ((v_u_119 * 1).Y - v_u_119.Y) / 2
			local v218 = v216 + Vector3.new(0, v217, 0)
			local v219 = os.clock()
			while true do
				while true do
					if not p_u_118.Parent then
						v_u_139(1, v218)
						return
					end
					local v220 = (os.clock() - v219) / v_u_215
					local v221 = math.clamp(v220, 0, 1)
					local v222 = v_u_139
					local v223 = 1
					local v224 = CFrame.Angles
					local v225 = 0
					local v226 = 18.84955592153876
					local v227
					if v221 < 0.4 then
						v227 = v221 * 1.4285714285714286
					else
						local v228 = v221 - 0.4
						v227 = (v228 - v228 * v228 / 1.2) * 1.4285714285714286 + 0.5714285714285715
					end
					v222(v223, v218 * v224(v225, v226 * v227, 0))
					if v221 >= 1 then
						break
					end
					if not p_u_118:GetAttribute("Titanic") then
						break
					end
					v_u_6.RenderStepped:Wait()
				end
				local v229 = workspace.CurrentCamera
				local v230
				if v229 == nil or (v229.CFrame.Position - v_u_120.Position).Magnitude >= v_u_18.EggDistance(v_u_10.AmbientCull.Distance, p_u_118) then
					v230 = false
				else
					v230 = v_u_20.IsVisible(v_u_120.Position, v_u_119)
				end
				if v230 then
					v_u_6.RenderStepped:Wait()
				else
					task.wait(0.1)
				end
			end
		end
		local v232 = v_u_119.X
		local v233 = v_u_119.Z
		local v_u_234 = math.min(v232, v233)
		local v_u_235 = nil
		local function v_u_240() -- name: scaleInfoUi
			-- upvalues: (ref) v_u_11, (copy) p_u_118, (ref) v_u_235, (copy) v_u_234
			local v236 = v_u_11.Find(p_u_118)
			if v236 then
				local v237 = v_u_234 <= 0 and 1 or v_u_11.Footprint(p_u_118) / v_u_234
				local v238 = v_u_11.GrowScale(v_u_234, v237, v_u_11.MaxScaleFor(p_u_118))
				if v_u_235 then
					local v239 = v238 - v_u_235
					if math.abs(v239) < 0.01 then
						return
					end
				end
				v_u_235 = v238
				v_u_11.ApplyScale(v236, v238, p_u_118)
			else
				v_u_235 = nil
			end
		end
		local v_u_241 = nil
		local function v_u_252(p242) -- name: showLuckCounter
			-- upvalues: (ref) v_u_11, (copy) p_u_118, (ref) v_u_241, (ref) v_u_9
			local v243 = v_u_11.Find(p_u_118)
			if not v243 then
				return false
			end
			local v244 = nil
			for _, v245 in v243:GetChildren() do
				if not v245:IsA("GuiObject") then
					continue
				end
				local v246 = v245.Name == "LuckMultiList"
				v245.Visible = v246
				if not v246 then
					continue
				end
				v244 = v245
			end
			if v244 then
				local v247 = v_u_241
				if not (v247 and v247.Parent) then
					local v248 = v_u_11.Find(p_u_118)
					if v248 then
						v248 = v248:FindFirstChild("LuckMulti", true)
					end
					if not (v248 and v248:IsA("TextLabel")) then
						v248 = nil
					end
					v_u_241 = v248
					v247 = v_u_241
				end
				if v247 then
					local v249 = v_u_241
					if not (v249 and v249.Parent) then
						local v250 = v_u_11.Find(p_u_118)
						if v250 then
							v250 = v250:FindFirstChild("LuckMulti", true)
						end
						if not (v250 and v250:IsA("TextLabel")) then
							v250 = nil
						end
						v_u_241 = v250
						v249 = v_u_241
					end
					if v249 then
						local v251 = v_u_9.FormatLuckValue(p242)
						if v249.Text ~= v251 then
							v249.Text = v251
						end
					end
					v243.Enabled = true
					return true
				end
			end
			return false
		end
		local function v_u_332(p_u_253) -- name: playShakeGrow
			-- upvalues: (copy) p_u_118, (ref) v_u_25, (copy) v_u_120, (ref) v_u_84, (ref) v_u_146, (ref) v_u_9, (copy) v_u_252, (copy) v_u_240, (ref) v_u_21, (ref) v_u_10, (ref) v_u_112, (ref) v_u_15, (ref) v_u_99, (ref) v_u_127, (copy) v_u_133, (copy) v_u_119, (copy) v_u_139, (ref) v_u_241, (ref) v_u_11, (ref) v_u_18, (ref) v_u_20, (ref) v_u_6
			local v_u_254 = p_u_253.Grow
			local v255 = p_u_118:GetAttribute("SpawnSizeMult") or 1
			local v256 = p_u_118:GetAttribute("HatchSizeMult") or 1
			local v257 = math.max(v256, 1)
			local v258 = v_u_254.Duration
			local v259 = v257 - 1
			local v260 = v_u_254.ScreenShakePerMult * v259
			local v261 = v_u_254.JitterPerMult * v259
			local v262 = v_u_254.JitterMax
			local v263 = math.min(v261, v262)
			local v264 = p_u_118:GetAttribute("WeightBracket") == "TITANIC"
			if v260 > 0 then
				local v265 = p_u_253.ScreenShakeDistance
				local v266 = v_u_25.Character
				if v266 then
					v266 = v266:FindFirstChild("HumanoidRootPart")
				end
				local v267
				if v266 == nil then
					v267 = false
				else
					v267 = (v266.Position - v_u_120.Position).Magnitude < v265
				end
				if v267 then
					v_u_84(v258 + p_u_253.ScreenShakeDurationBuffer, v260, 0.5)
				end
			end
			if v264 then
				task.delay(v_u_254.AuraDelayFrac * v258, function()
					-- upvalues: (ref) v_u_146, (copy) p_u_253, (ref) v_u_25, (ref) v_u_120, (ref) v_u_84, (copy) v_u_254
					if v_u_146 then
						local v268 = p_u_253.ScreenShakeDistance
						local v269 = v_u_25.Character
						if v269 then
							v269 = v269:FindFirstChild("HumanoidRootPart")
						end
						local v270
						if v269 == nil then
							v270 = false
						else
							v270 = (v269.Position - v_u_120.Position).Magnitude < v268
						end
						if v270 then
							v_u_84(v_u_254.AuraShakeDuration, v_u_254.AuraShakeMagnitude, 0.1)
						end
					end
				end)
			end
			local v271 = p_u_118:GetAttribute("Luck") or 1
			local v272, v273 = v_u_9.LuckCountRange(v271, v255, v257, v_u_9.ZoneIndexOf(p_u_118))
			local v274 = v_u_252(v272)
			v_u_240()
			local v275 = 1 + v_u_254.RattleSpeedPerMult * v259
			local v276 = p_u_253.ShakePreDuration
			local v277 = v258 * 0.5
			local v278 = math.min(v276, v277)
			local v279 = p_u_253.ShakeTiltMagnitude or 8
			local v280 = math.rad(v279)
			local v281 = p_u_253.ShakeTiltRate or 6
			local v282 = math.random() * 100
			local v283 = v_u_254.MinVisualMult or 1
			local v284 = math.max(v257, v283)
			local v285 = v_u_254.Tick
			local v286 = 0
			local v287 = 1
			local v288
			if p_u_118:GetAttribute("SilentHatch") then
				v288 = nil
			else
				v288 = v_u_21.TryAcquire("HatchAudio", v_u_10.HatchAudio.MaxConcurrent)
			end
			if not v288 then
				v285 = nil
			end
			local v289
			if v288 then
				v289 = v_u_254.Rumble
			else
				v289 = nil
			end
			local v290
			if v289 then
				local v291 = v_u_112
				local v292 = v289.SoundName
				local v293 = p_u_118
				local v294 = p_u_118
				local v295 = p_u_253.OpenSoundRange
				if v294:GetAttribute("Titanic") then
					v295 = v295 * (v_u_15.SoundRangeMult or 1)
				end
				v290 = v291(v292, v293, v295, v289.SoundFolder, v289.Volume, v289.FadeOutTime)
			else
				v290 = nil
			end
			local v296 = os.clock()
			while true do
				while true do
					if not p_u_118.Parent then
						local v297
						if (v284 or 1) == 1 then
							v297 = 1
						else
							local v298 = not v_u_127
							if v298 then
								v298 = v_u_133()
							end
							v297 = not v298 and 1 or v284
						end
						local v299 = v_u_120
						local v300 = ((v_u_119 * v297).Y - v_u_119.Y) / 2
						v_u_139(v284, v299 + Vector3.new(0, v300, 0))
						if v290 then
							v290()
						end
						if v288 then
							v288()
						end
						return v284
					end
					local v301 = os.clock() - v296
					local v302 = v301 / v258
					local v303 = math.clamp(v302, 0, 1)
					if v285 and v286 <= v301 then
						local v304 = v285.StartPitch + (v285.EndPitch - v285.StartPitch) * v303
						local v305 = v_u_99
						local v306 = v285.SoundName
						local v307 = p_u_118
						local v308 = p_u_118
						local v309 = p_u_253.OpenSoundRange
						if v308:GetAttribute("Titanic") then
							v309 = v309 * (v_u_15.SoundRangeMult or 1)
						end
						v305(v306, v307, v309, "rransCustomSFX", v304)
						v286 = v301 + v285.StartInterval + (v285.EndInterval - v285.StartInterval) * v303
					end
					local v310 = v301 / v278
					local v311 = math.clamp(v310, 0, 1)
					local v312 = 1 - (1 - v311) * (1 - v311)
					local v313 = v301 * v281 * v275 * (v303 + 1)
					local v314 = math.noise(v313, v282) * 2 * v280 * v312
					local v315 = math.noise(v282, v313) * 2 * v280 * v312
					local v316 = v284 ^ v303
					if v316 < v287 * 1.01 then
						v316 = v287
					else
						v287 = v316
					end
					local v317
					if (v287 or 1) == 1 then
						v317 = 1
					else
						local v318 = not v_u_127
						if v318 then
							v318 = v_u_133()
						end
						v317 = not v318 and 1 or v287
					end
					local v319 = v_u_120
					local v320 = ((v_u_119 * v317).Y - v_u_119.Y) / 2
					local v321 = v319 + Vector3.new(0, v320, 0)
					if v263 > 0 then
						local v322 = math.noise(v303 * v_u_254.ShakeRate, -v260, v260)
						local v323 = math.noise
						local v324 = -v303 * v_u_254.ShakeRate
						local v325 = -v260
						v321 = v321 + Vector3.new(v322, 0, v323(v324, v325, v260)) * v263
					end
					v_u_139(v287, v321 * CFrame.fromOrientation(v314, 0, v315))
					if v274 then
						local v326 = v272 * v273 ^ v303
						local v327 = v_u_241
						if not (v327 and v327.Parent) then
							local v328 = v_u_11.Find(p_u_118)
							if v328 then
								v328 = v328:FindFirstChild("LuckMulti", true)
							end
							if not (v328 and v328:IsA("TextLabel")) then
								v328 = nil
							end
							v_u_241 = v328
							v327 = v_u_241
						end
						if v327 then
							local v329 = v_u_9.FormatLuckValue(v326)
							if v327.Text ~= v329 then
								v327.Text = v329
							end
						end
					else
						v274 = v_u_252(v272 * v273 ^ v303)
					end
					v_u_240()
					if v303 >= 1 then
						break
					end
					if not p_u_118:GetAttribute("Titanic") then
						break
					end
					v_u_6.RenderStepped:Wait()
					v287 = v316
				end
				local v330 = workspace.CurrentCamera
				local v331
				if v330 == nil or (v330.CFrame.Position - v_u_120.Position).Magnitude >= v_u_18.EggDistance(v_u_10.AmbientCull.Distance, p_u_118) then
					v331 = false
				else
					v331 = v_u_20.IsVisible(v_u_120.Position, v_u_119)
				end
				if v331 then
					v_u_6.RenderStepped:Wait()
					v287 = v316
				else
					task.wait(0.1)
					v287 = v316
				end
			end
		end
		local function v_u_346() -- name: findHatchedPickup
			-- upvalues: (copy) p_u_118, (ref) v_u_23, (ref) v_u_24, (copy) v_u_120
			local v333 = p_u_118:GetAttribute("HatchId")
			for v334 in v_u_23 do
				if not v334:GetAttribute("Hatched") or v_u_24[v334] then
					continue
				end
				local v335 = v334:GetAttribute("HatchId")
				if v333 ~= nil and v335 ~= nil then
					if v335 ~= v333 then
						continue
					end
					v_u_24[v334] = true
					return v334
				end
				local v336 = v334:GetPivot().Position
				local v337 = v336.X - v_u_120.Position.X
				local v338 = v336.Z - v_u_120.Position.Z
				if v337 * v337 + v338 * v338 >= 22500 then
					continue
				end
				local v339, v340 = v334:GetBoundingBox()
				local v341 = v339.Position.X - v_u_120.Position.X
				local v342 = v339.Position.Z - v_u_120.Position.Z
				local v343 = v340.X
				local v344 = v340.Z
				local v345 = math.max(v343, v344) / 2 + 6
				if v341 * v341 + v342 * v342 >= v345 * v345 then
					continue
				end
				v_u_24[v334] = true
				return v334
			end
			return nil
		end
		local function v_u_349(p347) -- name: stopBakedVfx
			for _, v348 in p347:GetDescendants() do
				if v348:IsA("ParticleEmitter") then
					v348.Enabled = false
					v348:Clear()
				elseif v348:IsA("Trail") then
					v348.Enabled = false
					v348:Clear()
				elseif v348:IsA("Beam") or v348:IsA("Light") then
					v348.Enabled = false
				else
					if not (v348:IsA("Fire") or (v348:IsA("Smoke") or v348:IsA("Sparkles"))) then
						continue
					end
					v348:Destroy()
				end
			end
		end
		local function v_u_388(p350, p351, p352) -- name: playExplode
			-- upvalues: (ref) v_u_11, (copy) p_u_118, (copy) v_u_234, (ref) v_u_235, (copy) v_u_125, (copy) v_u_349, (ref) v_u_13, (copy) v_u_124, (copy) v_u_120, (copy) v_u_119, (ref) v_u_25, (ref) v_u_84, (ref) v_u_127, (copy) v_u_133, (copy) v_u_139, (copy) v_u_346, (ref) v_u_18, (ref) v_u_10, (ref) v_u_20, (ref) v_u_6, (copy) v_u_142
			local v353 = v_u_11.Find(p_u_118)
			if v353 then
				v353.Enabled = false
				v_u_11.ApplyScale(v353, v_u_11.ScaleFor(v_u_234, v_u_11.MaxScaleFor(p_u_118)), p_u_118)
				v_u_235 = nil
			end
			local v354 = {}
			if v_u_125 then
				for _, v355 in v_u_125:GetDescendants() do
					if not v355:IsA("BasePart") then
						continue
					end
					table.insert(v354, v355)
				end
			else
				local v356 = p_u_118
				table.insert(v354, v356)
			end
			for _, v357 in v354 do
				if v357:IsA("MeshPart") then
					v357.TextureID = ""
				end
				local v358 = v357:FindFirstChildOfClass("SurfaceAppearance")
				if v358 then
					v358:Destroy()
				end
				v357.Color = Color3.new(1, 1, 1)
				v357.Material = Enum.Material.SmoothPlastic
			end
			local v359 = v_u_125 or p_u_118
			v_u_349(v359)
			for _, v360 in v359:GetDescendants() do
				if not (v360:IsA("Decal") or v360:IsA("Texture")) then
					continue
				end
				v360.Transparency = 1
			end
			if not p_u_118:GetAttribute("NoPickup") then
				v_u_13.Emit("Explode", p_u_118.Position, {
					["Scale"] = nil,
					["LifetimeMult"] = 1.5,
					["Scale"] = p351 * v_u_124
				})
			end
			if p_u_118:GetAttribute("WeightBracket") == "TITANIC" then
				local v361 = {
					["Scale"] = nil,
					["LifetimeMult"] = 1.5,
					["Scale"] = v_u_124
				}
				v_u_13.Emit("TitanicExplode", p_u_118.Position, v361)
				local v362 = v_u_13.EnableFor
				local v363 = v_u_120.Position
				local v364 = v_u_119.Y / 2
				v362("TitanicExplodeAOE", v363 - Vector3.new(0, v364, 0), 7)
				local v365 = p350.ScreenShakeDistance
				local v366 = v_u_25.Character
				if v366 then
					v366 = v366:FindFirstChild("HumanoidRootPart")
				end
				local v367
				if v366 == nil then
					v367 = false
				else
					v367 = (v366.Position - v_u_120.Position).Magnitude < v365
				end
				if v367 then
					v_u_84(2.5, 1, 0.5)
				end
			end
			local v368 = p351 * p350.ExplodeUpscaleSize
			local v369 = os.clock()
			local v370 = p351
			local v371 = nil
			while true do
				while true do
					if not p_u_118.Parent then
						for _, v372 in v354 do
							v372.Transparency = 1
						end
						v_u_142.Enabled = false
						v_u_142.Adornee = nil
						v_u_142.Parent = nil
						if not (v371 or p_u_118:GetAttribute("NoPickup")) then
							local v373 = os.clock() + 2
							while os.clock() < v373 do
								local v374 = v_u_346()
								if v374 then
									for _, v375 in v374:GetDescendants() do
										if not v375:IsA("BasePart") then
											continue
										end
										v375.LocalTransparencyModifier = 1
									end
									task.spawn(p352, v374)
									return
								end
								task.wait(0.05)
							end
						end
						return
					end
					local v376 = (os.clock() - v369) / p350.ExplodeDuration
					local v377 = math.clamp(v376, 0, 1)
					local v378 = v377 >= 1 and 1 or 1 - 2 ^ (v377 * -10)
					local v379 = p351 + (v368 - p351) * v378
					if v379 < v370 * 1.01 then
						v379 = v370
					else
						v370 = v379
					end
					local v380
					if (v370 or 1) == 1 then
						v380 = 1
					else
						local v381 = not v_u_127
						if v381 then
							v381 = v_u_133()
						end
						v380 = not v381 and 1 or v370
					end
					local v382 = v_u_120
					local v383 = ((v_u_119 * v380).Y - v_u_119.Y) / 2
					v_u_139(v370, v382 + Vector3.new(0, v383, 0))
					for _, v384 in v354 do
						v384.Transparency = v378
					end
					if not (v371 or p_u_118:GetAttribute("NoPickup")) then
						v371 = v_u_346()
						if v371 then
							for _, v385 in v371:GetDescendants() do
								if not v385:IsA("BasePart") then
									continue
								end
								v385.LocalTransparencyModifier = 1
							end
							task.spawn(p352, v371)
						end
					end
					if v377 >= 1 then
						break
					end
					if not p_u_118:GetAttribute("Titanic") then
						break
					end
					v_u_6.RenderStepped:Wait()
					v370 = v379
				end
				local v386 = workspace.CurrentCamera
				local v387
				if v386 == nil or (v386.CFrame.Position - v_u_120.Position).Magnitude >= v_u_18.EggDistance(v_u_10.AmbientCull.Distance, p_u_118) then
					v387 = false
				else
					v387 = v_u_20.IsVisible(v_u_120.Position, v_u_119)
				end
				if v387 then
					v_u_6.RenderStepped:Wait()
					v370 = v379
				else
					task.wait(0.1)
					v370 = v379
				end
			end
		end
		local function v_u_392(p389) -- name: playRevealHighlight
			-- upvalues: (ref) v_u_8
			local v_u_390 = Instance.new("Highlight")
			v_u_390.Name = "RevealHighlight"
			v_u_390.Adornee = p389
			v_u_390.FillColor = Color3.fromRGB(255, 255, 255)
			v_u_390.OutlineColor = Color3.fromRGB(255, 255, 255)
			v_u_390.FillTransparency = 0
			v_u_390.OutlineTransparency = 0
			v_u_390.DepthMode = Enum.HighlightDepthMode.Occluded
			v_u_390.Enabled = true
			v_u_390.Parent = p389
			v_u_8:Create(v_u_390, TweenInfo.new(0.6, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["FillTransparency"] = 1
			}):Play()
			task.delay(3, function()
				-- upvalues: (copy) v_u_390, (ref) v_u_8
				if v_u_390.Parent then
					local v391 = v_u_8:Create(v_u_390, TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
						["OutlineTransparency"] = 1
					})
					v391.Completed:Once(function()
						-- upvalues: (ref) v_u_390
						v_u_390:Destroy()
					end)
					v391:Play()
				end
			end)
		end
		local function v_u_403(p393) -- name: waitForFullRig
			local v394 = p393:GetAttribute("RigCount") or 0
			if v394 <= 0 then
				return true
			end
			local v_u_395 = {}
			local v_u_396 = 0
			local function v398(p397) -- name: addPiece
				-- upvalues: (copy) v_u_395, (ref) v_u_396
				if (p397:IsA("BasePart") or p397:IsA("Bone")) and not v_u_395[p397] then
					v_u_395[p397] = true
					v_u_396 = v_u_396 + 1
				end
			end
			local v399 = p393.DescendantAdded:Connect(v398)
			local v400 = v_u_396
			for _, v401 in p393:GetDescendants() do
				if not (v401:IsA("BasePart") or v401:IsA("Bone")) or v_u_395[v401] then
					continue
				end
				v_u_395[v401] = true
				v_u_396 = v400 + 1
				v400 = v_u_396
			end
			local v402 = os.clock() + 2
			while p393.Parent and os.clock() < v402 do
				if v394 <= v400 then
					v399:Disconnect()
					return true
				end
				task.wait()
			end
			v399:Disconnect()
			return false
		end
		local function v_u_419() -- name: playNestPopAway
			-- upvalues: (copy) p_u_118, (ref) v_u_10, (ref) v_u_117, (ref) v_u_14, (copy) v_u_120, (ref) v_u_18, (ref) v_u_20, (copy) v_u_119, (ref) v_u_6
			local v404 = p_u_118:FindFirstChild("Nest")
			local v405
			if v404 and v404:IsA("ObjectValue") then
				v405 = v404.Value
			else
				v405 = nil
			end
			if not (v405 and (v405:IsA("Model") and v405.Parent)) then
				return
			end
			local v406 = v_u_10.NestPop
			if not v_u_117(v405) then
				return
			end
			local v407 = v_u_14.Capture(v405)
			local v408 = v406.PopTime + v406.ShrinkTime
			local v409 = os.clock()
			while true do
				while true do
					if not v405.Parent then
						if v405.Parent then
							for _, v410 in v405:GetDescendants() do
								if not v410:IsA("BasePart") then
									continue
								end
								v410.LocalTransparencyModifier = 1
							end
						end
						return
					end
					local v411 = os.clock() - v409
					local v412
					if v411 < v406.PopTime then
						local v413 = v406.PopScale - 1
						local v414 = v411 / v406.PopTime
						v412 = 1 + v413 * (1 - (1 - v414) * (1 - v414))
					else
						local v415 = (v411 - v406.PopTime) / v406.ShrinkTime
						local v416 = math.clamp(v415, 0, 1)
						v412 = v406.PopScale * (1 - v416 * v416)
					end
					v_u_14.Apply(v407, (math.max(v412, 0.01)))
					if v408 <= v411 then
						break
					end
					if not p_u_118:GetAttribute("Titanic") then
						break
					end
					v_u_6.RenderStepped:Wait()
				end
				local v417 = workspace.CurrentCamera
				local v418
				if v417 == nil or (v417.CFrame.Position - v_u_120.Position).Magnitude >= v_u_18.EggDistance(v_u_10.AmbientCull.Distance, p_u_118) then
					v418 = false
				else
					v418 = v_u_20.IsVisible(v_u_120.Position, v_u_119)
				end
				if v418 then
					v_u_6.RenderStepped:Wait()
				else
					task.wait(0.1)
				end
			end
		end
		local function v_u_486(p420, p_u_421, p422) -- name: playPetIntro
			-- upvalues: (copy) v_u_403, (copy) p_u_118, (ref) v_u_25, (copy) v_u_214, (ref) v_u_19, (ref) v_u_12, (ref) v_u_15, (ref) v_u_99, (copy) v_u_392, (copy) v_u_419, (ref) v_u_4, (ref) v_u_127, (copy) v_u_133, (copy) v_u_119, (copy) v_u_120, (ref) v_u_14, (ref) v_u_18, (ref) v_u_10, (ref) v_u_20, (ref) v_u_6, (ref) v_u_13
			if not (p_u_421 and p_u_421.Parent) then
				return
			end
			local v423 = v_u_403(p_u_421)
			if not p_u_421.Parent then
				return
			end
			local function v425() -- name: playRarityBurst
				-- upvalues: (ref) p_u_118, (ref) v_u_25, (ref) v_u_214, (copy) p_u_421, (ref) v_u_19, (ref) v_u_12
				if p_u_118:GetAttribute("HatchBreakerUserId") == v_u_25.UserId then
					if v_u_214() then
						local v424 = p_u_118:GetAttribute("HatchAnimal")
						if typeof(v424) ~= "string" or v424 == "" then
							v424 = p_u_421.Name
						end
						v_u_19.Play(v_u_12.RarityOf(v424))
					end
				else
					return
				end
			end
			if not v423 then
				for _, v426 in p_u_421:GetDescendants() do
					if not v426:IsA("BasePart") then
						continue
					end
					v426.LocalTransparencyModifier = 0
				end
				local v427 = p_u_118
				local v428 = p420.OpenSoundRange
				if v427:GetAttribute("Titanic") then
					v428 = v428 * (v_u_15.SoundRangeMult or 1)
				end
				v_u_99("Egg Open", p_u_118, v428)
				v_u_99("Confetti", p_u_118, v428, "rransCustomSFX")
				v_u_99("Reveal", p_u_118, v428, "rransCustomSFX")
				v_u_392(p_u_421)
				v425()
				task.spawn(v_u_419)
				return
			end
			for _, v429 in p_u_421:GetDescendants() do
				if not v429:IsA("BasePart") then
					continue
				end
				v429.LocalTransparencyModifier = 1
			end
			local v_u_430 = p_u_421:GetPivot()
			local v_u_431 = v_u_4:GetPlayerByUserId(p_u_118:GetAttribute("HatchBreakerUserId") or 0)
			local function v439(p432) -- name: faceBreaker
				-- upvalues: (copy) v_u_430, (copy) v_u_431
				local v433 = CFrame.new(p432) * v_u_430.Rotation
				local v434 = v_u_431
				if v434 then
					v434 = v_u_431.Character
				end
				if v434 then
					v434 = v434:FindFirstChild("HumanoidRootPart")
				end
				if v434 and v434:IsA("BasePart") then
					local v435 = v434.Position.X
					local v436 = p432.Y
					local v437 = v434.Position.Z
					local v438 = Vector3.new(v435, v436, v437)
					if (v438 - p432).Magnitude > 0.001 then
						v433 = CFrame.lookAt(p432, v438)
					end
				end
				return v433
			end
			local v440
			if (p422 or 1) == 1 then
				v440 = 1
			else
				local v441 = not v_u_127
				if v441 then
					v441 = v_u_133()
				end
				v440 = not v441 and 1 or p422
			end
			local v442 = v_u_120
			local v443 = ((v_u_119 * v440).Y - v_u_119.Y) / 2
			local v444 = (v442 + Vector3.new(0, v443, 0)).Position.Y - v_u_430.Position.Y
			local v445 = math.max(v444, 3)
			local v446 = v_u_14.Capture(p_u_421, v_u_430)
			local v447 = v439(v_u_430.Position)
			v_u_14.Apply(v446, 0.01, v447)
			for _, v448 in p_u_421:GetDescendants() do
				if not v448:IsA("BasePart") then
					continue
				end
				v448.LocalTransparencyModifier = 0
			end
			local v449 = p_u_118
			local v450 = p420.OpenSoundRange
			if v449:GetAttribute("Titanic") then
				v450 = v450 * (v_u_15.SoundRangeMult or 1)
			end
			v_u_99("Egg Open", p_u_118, v450)
			v_u_99("Confetti", p_u_118, v450, "rransCustomSFX")
			v_u_99("Reveal", p_u_118, v450, "rransCustomSFX")
			v_u_392(p_u_421)
			v425()
			task.spawn(v_u_419)
			local v451 = os.clock()
			while true do
				local v452 = (os.clock() - v451) / 0.6
				local v453 = math.clamp(v452, 0, 1)
				local v454 = v453 - 1
				local v455 = v454 * 2.70158 * v454 * v454 + 1 + v454 * 1.70158 * v454
				local v456 = 18.84955592153876 * (1 - (1 - v453) ^ 5)
				local v457 = v_u_430.Position
				local v458 = v445 * v455
				local v459 = v439(v457 + Vector3.new(0, v458, 0)) * CFrame.Angles(0, v456, 0)
				v_u_14.Apply(v446, math.max(v455, 0.01), v459)
				if v453 >= 1 or not p_u_421.Parent then
					break
				end
				if p_u_118:GetAttribute("Titanic") then
					v_u_6.RenderStepped:Wait()
				else
					local v460 = workspace.CurrentCamera
					local v461
					if v460 == nil or (v460.CFrame.Position - v_u_120.Position).Magnitude >= v_u_18.EggDistance(v_u_10.AmbientCull.Distance, p_u_118) then
						v461 = false
					else
						v461 = v_u_20.IsVisible(v_u_120.Position, v_u_119)
					end
					if v461 then
						v_u_6.RenderStepped:Wait()
					else
						task.wait(0.1)
					end
				end
			end
			if not p_u_421.Parent then
				return
			end
			local v462 = v439(v_u_430.Position + Vector3.new(0, v445, 0))
			v_u_14.Apply(v446, 1, v462)
			local v463 = os.clock()
			while true do
				local v464 = (os.clock() - v463) / 0.55
				local v465 = math.clamp(v464, 0, 1)
				local v466
				if v465 < 0.36363636363636365 then
					v466 = v465 * 7.5625 * v465
				elseif v465 < 0.7272727272727273 then
					local v467 = v465 - 0.5454545454545454
					v466 = v467 * 7.5625 * v467 + 0.75
				elseif v465 < 0.9090909090909091 then
					local v468 = v465 - 0.8181818181818182
					v466 = v468 * 7.5625 * v468 + 0.9375
				else
					local v469 = v465 - 0.9545454545454546
					v466 = v469 * 7.5625 * v469 + 0.984375
				end
				local v470 = v445 * (1 - v466)
				p_u_421:PivotTo((v439(v_u_430.Position + Vector3.new(0, v470, 0))))
				if v465 >= 1 or not p_u_421.Parent then
					break
				end
				if p_u_118:GetAttribute("Titanic") then
					v_u_6.RenderStepped:Wait()
				else
					local v471 = workspace.CurrentCamera
					local v472
					if v471 == nil or (v471.CFrame.Position - v_u_120.Position).Magnitude >= v_u_18.EggDistance(v_u_10.AmbientCull.Distance, p_u_118) then
						v472 = false
					else
						v472 = v_u_20.IsVisible(v_u_120.Position, v_u_119)
					end
					if v472 then
						v_u_6.RenderStepped:Wait()
					else
						task.wait(0.1)
					end
				end
			end
			local _, v473 = p_u_421:GetBoundingBox()
			local v474 = v_u_13.Emit
			local v475 = v_u_430.Position
			local v476 = v473.Y / 2
			v474("Impact", v475 - Vector3.new(0, v476, 0), {
				["LifetimeMult"] = 0.5
			})
			local v477 = os.clock()
			while true do
				while true do
					local v478 = os.clock() - v477
					if p420.PetLookDuration <= v478 or not p_u_421.Parent then
						if p_u_421.Parent then
							p_u_421:PivotTo((v439(v_u_430.Position)))
						end
						return
					end
					local v479 = (p420.PetLookDuration - v478) / 0.5
					local v480 = math.clamp(v479, 0, 1)
					local v481 = 6.283185307179586 * v478 * p420.PetFloatRate
					local v482 = math.sin(v481)
					local v483 = math.abs(v482) * p420.PetFloatHeight * v480
					p_u_421:PivotTo((v439(v_u_430.Position + Vector3.new(0, v483, 0))))
					if p_u_118:GetAttribute("Titanic") then
						break
					end
					local v484 = workspace.CurrentCamera
					local v485
					if v484 == nil or (v484.CFrame.Position - v_u_120.Position).Magnitude >= v_u_18.EggDistance(v_u_10.AmbientCull.Distance, p_u_118) then
						v485 = false
					else
						v485 = v_u_20.IsVisible(v_u_120.Position, v_u_119)
					end
					if v485 then
						v_u_6.RenderStepped:Wait()
					else
						task.wait(0.1)
					end
				end
				v_u_6.RenderStepped:Wait()
			end
		end
		local function v_u_496() -- name: playHatchSequence
			-- upvalues: (ref) v_u_146, (copy) v_u_152, (copy) v_u_142, (ref) v_u_46, (copy) p_u_118, (copy) v_u_141, (ref) v_u_127, (ref) v_u_12, (copy) v_u_231, (copy) v_u_332, (copy) v_u_388, (copy) v_u_486
			v_u_146 = true
			v_u_152()
			v_u_142.Enabled = false
			v_u_142.Adornee = nil
			v_u_142.Parent = nil
			v_u_46(p_u_118)
			if not v_u_141() then
				v_u_127 = true
			end
			local v_u_487 = v_u_12.HatchSequence
			v_u_231()
			local v_u_488 = v_u_332(v_u_487)
			v_u_388(v_u_487, v_u_488, function(p489)
				-- upvalues: (ref) v_u_486, (copy) v_u_487, (copy) v_u_488
				local v490 = v_u_486
				local v491 = v_u_487
				local v492 = v_u_488
				local v493, v494 = pcall(v490, v491, p489, v492)
				if not v493 then
					if p489.Parent then
						for _, v495 in p489:GetDescendants() do
							if not v495:IsA("BasePart") then
								continue
							end
							v495.LocalTransparencyModifier = 0
						end
					end
					warn((("[EggEffects] pet intro failed for %*: %*"):format(p489.Name, v494)))
				end
			end)
		end
		local function v_u_502() -- name: pinNest
			-- upvalues: (copy) p_u_118, (ref) v_u_117, (ref) v_u_14
			local v497 = p_u_118:FindFirstChild("Nest")
			local v498
			if v497 and v497:IsA("ObjectValue") then
				v498 = v497.Value
			else
				v498 = nil
			end
			if not (v498 and (v498:IsA("Model") and v498.Parent)) then
				v498 = nil
			end
			if not v498 then
				return nil
			end
			if not v_u_117(v498) then
				return nil
			end
			local v499 = v498:GetPivot()
			local v500, v501 = v498:GetBoundingBox()
			return {
				["nest"] = v498,
				["rig"] = v_u_14.Capture(v498, v499),
				["pivot"] = v499,
				["bottomY"] = v500.Position.Y - v501.Y / 2
			}
		end
		local function v_u_513(p503, p504, p505) -- name: scaleUnit
			-- upvalues: (ref) v_u_127, (copy) v_u_133, (copy) v_u_119, (copy) v_u_120, (copy) v_u_139, (ref) v_u_14
			local v506 = math.max(p504, 0.01)
			local v507 = p505 or 0
			local v508
			if (v506 or 1) == 1 then
				v508 = 1
			else
				local v509 = not v_u_127
				if v509 then
					v509 = v_u_133()
				end
				v508 = not v509 and 1 or v506
			end
			local v510 = v_u_120
			local v511 = ((v_u_119 * v508).Y - v_u_119.Y) / 2
			v_u_139(v506, v510 + Vector3.new(0, v511, 0) + Vector3.new(0, v507, 0))
			if p503 and p503.nest.Parent then
				local v512 = p503.bottomY + (p503.pivot.Position.Y - p503.bottomY) * v506 + v507
				v_u_14.Apply(p503.rig, v506, CFrame.new(p503.pivot.Position.X, v512, p503.pivot.Position.Z) * p503.pivot.Rotation)
			end
		end
		local function v522() -- name: playSpawnRise
			-- upvalues: (copy) v_u_141, (copy) p_u_118, (ref) v_u_146, (ref) v_u_147, (ref) v_u_10, (copy) v_u_502, (ref) v_u_148, (copy) v_u_513, (copy) v_u_120, (ref) v_u_18, (ref) v_u_20, (copy) v_u_119, (ref) v_u_6
			local v514 = v_u_141()
			if not p_u_118.Parent or (v_u_146 or v_u_147) then
				return
			end
			if not v514 then
				return
			end
			local v515 = v_u_10.SpawnRise
			local v516 = v_u_502()
			v_u_148 = os.clock() + v515.Duration + 0.1
			local v517 = os.clock()
			while true do
				while true do
					if not p_u_118.Parent or (v_u_146 or v_u_147) then
						if p_u_118.Parent and not (v_u_146 or v_u_147) then
							v_u_513(v516, 1)
						end
						return
					end
					local v518 = (os.clock() - v517) / v515.Duration
					local v519 = math.clamp(v518, 0, 1)
					v_u_513(v516, 1 - (1 - v519) * (1 - v519))
					if v519 >= 1 then
						break
					end
					if not p_u_118:GetAttribute("Titanic") then
						break
					end
					v_u_6.RenderStepped:Wait()
				end
				local v520 = workspace.CurrentCamera
				local v521
				if v520 == nil or (v520.CFrame.Position - v_u_120.Position).Magnitude >= v_u_18.EggDistance(v_u_10.AmbientCull.Distance, p_u_118) then
					v521 = false
				else
					v521 = v_u_20.IsVisible(v_u_120.Position, v_u_119)
				end
				if v521 then
					v_u_6.RenderStepped:Wait()
				else
					task.wait(0.1)
				end
			end
		end
		local function v_u_535() -- name: playDespawnShrink
			-- upvalues: (ref) v_u_147, (copy) v_u_152, (ref) v_u_10, (copy) v_u_502, (copy) p_u_118, (copy) v_u_513, (copy) v_u_120, (ref) v_u_18, (ref) v_u_20, (copy) v_u_119, (ref) v_u_6, (copy) v_u_349, (copy) v_u_125
			if v_u_147 then
				return
			end
			v_u_147 = true
			v_u_152()
			local v523 = v_u_10.DespawnSink
			local v524 = v_u_502()
			local v525 = os.clock()
			while true do
				while true do
					if not p_u_118.Parent then
						v_u_349(v_u_125 or p_u_118)
						local v526 = {}
						local v527
						if v_u_125 then
							v527 = v_u_125
						else
							v527 = p_u_118
						end
						__set_list(v526, 1, {v527})
						if v524 then
							local v528 = v524.nest
							table.insert(v526, v528)
						end
						for _, v529 in v526 do
							if not v529.Parent then
								continue
							end
							if v529:IsA("BasePart") then
								v529.LocalTransparencyModifier = 1
							end
							for _, v530 in v529:GetDescendants() do
								if not v530:IsA("BasePart") then
									continue
								end
								v530.LocalTransparencyModifier = 1
							end
						end
						return
					end
					local v531 = (os.clock() - v525) / v523.Duration
					local v532 = math.clamp(v531, 0, 1)
					v_u_513(v524, 1 - v532 * v532)
					if v532 >= 1 then
						break
					end
					if not p_u_118:GetAttribute("Titanic") then
						break
					end
					v_u_6.RenderStepped:Wait()
				end
				local v533 = workspace.CurrentCamera
				local v534
				if v533 == nil or (v533.CFrame.Position - v_u_120.Position).Magnitude >= v_u_18.EggDistance(v_u_10.AmbientCull.Distance, p_u_118) then
					v534 = false
				else
					v534 = v_u_20.IsVisible(v_u_120.Position, v_u_119)
				end
				if v534 then
					v_u_6.RenderStepped:Wait()
				else
					task.wait(0.1)
				end
			end
		end
		local v536 = p_u_118:GetAttribute("SpawnedAt")
		if v536 and workspace:GetServerTimeNow() - v536 < v_u_10.SpawnRise.MaxAge then
			task.spawn(v522)
		end
		p_u_118:GetAttributeChangedSignal("Despawning"):Connect(function()
			-- upvalues: (copy) p_u_118, (ref) v_u_146, (copy) v_u_535
			if p_u_118:GetAttribute("Despawning") and not v_u_146 then
				task.spawn(v_u_535)
			end
		end)
		if p_u_118:GetAttribute("Despawning") then
			task.spawn(v_u_535)
		end
		v_u_26[p_u_118] = function()
			-- upvalues: (ref) v_u_146, (copy) p_u_118, (copy) v_u_179
			if not (v_u_146 or p_u_118:GetAttribute("Broken")) then
				v_u_179(true)
			end
		end
		p_u_118.Destroying:Connect(function()
			-- upvalues: (ref) v_u_26, (copy) p_u_118, (ref) v_u_17, (copy) v_u_142
			v_u_26[p_u_118] = nil
			v_u_17.Forget(p_u_118)
			v_u_142:Destroy()
		end)
		local v_u_537 = p_u_118:GetAttribute("Health") or 0
		p_u_118:GetAttributeChangedSignal("Health"):Connect(function()
			-- upvalues: (copy) p_u_118, (ref) v_u_537, (ref) v_u_146, (ref) v_u_17, (copy) v_u_120, (ref) v_u_18, (ref) v_u_10, (ref) v_u_20, (copy) v_u_119, (copy) v_u_179
			local v538 = p_u_118:GetAttribute("Health") or 0
			if v538 < v_u_537 and not (v_u_146 or v_u_17.ConsumeConfirm(p_u_118)) then
				local v539 = workspace.CurrentCamera
				local v540
				if v539 == nil or (v539.CFrame.Position - v_u_120.Position).Magnitude >= v_u_18.EggDistance(v_u_10.AmbientCull.Distance, p_u_118) then
					v540 = false
				else
					v540 = v_u_20.IsVisible(v_u_120.Position, v_u_119)
				end
				if v540 then
					v_u_179(false)
				end
			end
			v_u_537 = v538
		end)
		p_u_118:GetAttributeChangedSignal("Hatching"):Connect(function()
			-- upvalues: (copy) p_u_118, (ref) v_u_146, (ref) v_u_26, (ref) v_u_17, (copy) v_u_496
			if p_u_118:GetAttribute("Hatching") and not v_u_146 then
				v_u_26[p_u_118] = nil
				v_u_17.Forget(p_u_118)
				task.spawn(v_u_496)
			end
		end)
	end
end
function v22.Start() -- name: Start
	-- upvalues: (copy) v_u_1, (copy) v_u_23, (copy) v_u_24, (copy) v_u_541, (copy) v_u_17, (copy) v_u_26
	for _, v542 in v_u_1:GetTagged("AnimalPickup") do
		v_u_23[v542] = true
	end
	v_u_1:GetInstanceAddedSignal("AnimalPickup"):Connect(function(p543)
		-- upvalues: (ref) v_u_23
		v_u_23[p543] = true
	end)
	v_u_1:GetInstanceRemovedSignal("AnimalPickup"):Connect(function(p544)
		-- upvalues: (ref) v_u_23, (ref) v_u_24
		v_u_23[p544] = nil
		v_u_24[p544] = nil
	end)
	for _, v545 in v_u_1:GetTagged("BreakableEgg") do
		v_u_541(v545)
	end
	v_u_1:GetInstanceAddedSignal("BreakableEgg"):Connect(v_u_541)
	v_u_17.OnHit(function(p546)
		-- upvalues: (ref) v_u_26
		local v547 = v_u_26[p546]
		if v547 then
			v547()
		end
	end)
end
return v22
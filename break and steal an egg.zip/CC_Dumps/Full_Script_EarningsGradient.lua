local v_u_1 = require(script.Parent.PrettyGradient)
local v_u_2 = {}
local v_u_3 = {
	{ 0, Color3.fromRGB(206, 240, 206) },
	{ 1, Color3.fromRGB(88, 214, 96) },
	{ 2, Color3.fromRGB(54, 214, 172) },
	{ 3, Color3.fromRGB(64, 170, 255) },
	{ 4, Color3.fromRGB(142, 120, 255) },
	{ 5, Color3.fromRGB(198, 96, 255) },
	{ 6, Color3.fromRGB(255, 92, 196) },
	{ 7, Color3.fromRGB(255, 84, 84) },
	{ 8, Color3.fromRGB(255, 140, 44) },
	{ 9, Color3.fromRGB(255, 198, 60) },
	{ 10, Color3.fromRGB(255, 240, 110) },
	{ 12, Color3.fromRGB(166, 255, 77) }
}
local v_u_4 = v_u_3[1][1]
local v_u_5 = v_u_3[#v_u_3][1]
function v_u_2.Decade(p6) -- name: Decade
	-- upvalues: (copy) v_u_4, (copy) v_u_5
	if p6 ~= p6 or p6 <= 1 then
		return v_u_4
	end
	local v7 = math.log10(p6)
	local v8 = v_u_4
	local v9 = v_u_5
	return math.clamp(v7, v8, v9)
end
function v_u_2.Color(p10) -- name: Color
	-- upvalues: (copy) v_u_2, (copy) v_u_3
	local v11 = v_u_2.Decade(p10)
	for v12 = 1, #v_u_3 - 1 do
		local v13 = v_u_3[v12][1]
		local v14 = v_u_3[v12][2]
		local v15 = v_u_3[v12 + 1][1]
		local v16 = v_u_3[v12 + 1][2]
		if v11 > v15 then
			continue
		end
		local v17 = (v11 - v13) / (v15 - v13)
		return v14:Lerp(v16, (math.clamp(v17, 0, 1)))
	end
	return v_u_3[#v_u_3][2]
end
function v_u_2.ApplyToLabel(p18, p19) -- name: ApplyToLabel
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	return v_u_1.ApplyToLabel(p18, v_u_2.Color(p19))
end
return v_u_2
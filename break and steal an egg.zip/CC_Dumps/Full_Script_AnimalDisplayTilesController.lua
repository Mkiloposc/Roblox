local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.AnimalDisplayTilesConfig)
local v_u_3 = require(v1.Shared.FloatingIconConfig)
local v_u_4 = require(script.Parent.Parent.Modules.FloatingIconFX)
local v_u_5 = require(script.Parent.Parent.Modules.MainGui)
local v6 = {}
local function v_u_11(p7, p8, p9) -- name: bindTile
	-- upvalues: (copy) v_u_4
	p7:SetAttribute("HoverScale", 1)
	p7:SetAttribute("PressScale", 1)
	if p8.ClipTiles then
		p7.ClipsDescendants = true
	end
	local v10 = p7:FindFirstChild(p8.Display)
	if v10 and v10:IsA("GuiObject") then
		v_u_4.Attach(v10, p9, p7)
	end
end
local function v_u_20(p12) -- name: bind
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_11
	for _, v13 in v_u_2.Targets do
		local v14 = p12
		for _, v15 in v13.Path do
			if not p12 then
				continue
			end
			p12 = p12:FindFirstChild(v15)
		end
		if p12 then
			local v16 = table.clone(v_u_3.Styles.AnimalTile)
			for v17, v18 in v13.StyleOverrides do
				v16[v17] = v18
			end
			for _, v19 in p12:GetChildren() do
				if not (v19:IsA("GuiButton") and string.match(v19.Name, v13.Tile)) then
					continue
				end
				v_u_11(v19, v13, v16)
			end
			p12 = v14
		else
			warn((("[AnimalDisplayTilesController] missing MainGUI.%*"):format((table.concat(v13.Path, ".")))))
			p12 = v14
		end
	end
end
function v6.Start() -- name: Start
	-- upvalues: (copy) v_u_5, (copy) v_u_20
	v_u_5.Observe(v_u_20)
end
return v6
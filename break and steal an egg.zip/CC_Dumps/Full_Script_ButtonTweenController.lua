local v_u_1 = game:GetService("CollectionService")
local v_u_2 = game:GetService("GuiService")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("UserInputService")
local v5 = game:GetService("ReplicatedStorage")
local v_u_6 = game:GetService("TweenService")
local v_u_7 = require(v5.Shared.ButtonTweenConfig)
local v8 = require(script.Parent.Parent.Modules.UiSounds)
local v_u_9 = require(script.Parent.Parent.Modules.FloatingIconFX)
local v_u_10 = require(script.Parent.Parent.Modules.ListLayoutFreeze)
local v_u_11 = v3.LocalPlayer
local v12 = {}
local v_u_13 = Vector2.new(0.5, 0.5)
local v_u_14 = TweenInfo.new(v_u_7.TweenDuration, v_u_7.TweenEasingStyle, v_u_7.TweenEasingDirection)
local v_u_15 = {}
local function v_u_32(p16) -- name: tweenInfoFor
	-- upvalues: (copy) v_u_14, (copy) v_u_15, (copy) v_u_7
	if not p16 then
		return v_u_14
	end
	local v17 = p16:GetAttribute("TweenDuration")
	local v_u_18 = p16:GetAttribute("TweenEasingStyle")
	local v_u_19 = p16:GetAttribute("TweenEasingDirection")
	if v17 == nil and (v_u_18 == nil and v_u_19 == nil) then
		return v_u_14
	end
	local v20 = ("%*|%*|%*"):format(v17, v_u_18, v_u_19)
	local v21 = v_u_15[v20]
	if v21 then
		return v21
	end
	local v22 = TweenInfo.new
	if typeof(v17) ~= "number" then
		v17 = v_u_7.TweenDuration
	end
	local v_u_23 = Enum.EasingStyle
	local v24 = v_u_7.TweenEasingStyle
	if typeof(v_u_18) == "string" then
		local v25, v26 = pcall(function()
			-- upvalues: (copy) v_u_23, (copy) v_u_18
			return v_u_23[v_u_18]
		end)
		if v25 and typeof(v26) == "EnumItem" then
			v24 = v26
		end
	end
	local v_u_27 = Enum.EasingDirection
	local v28 = v_u_7.TweenEasingDirection
	if typeof(v_u_19) == "string" then
		local v29, v30 = pcall(function()
			-- upvalues: (copy) v_u_27, (copy) v_u_19
			return v_u_27[v_u_19]
		end)
		if v29 and typeof(v30) == "EnumItem" then
			v28 = v30
		end
	end
	local v31 = v22(v17, v24, v28)
	v_u_15[v20] = v31
	return v31
end
local v_u_33 = {}
local v_u_34 = {}
local v_u_35 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_46(p36) -- name: recenterAnchor
	-- upvalues: (copy) v_u_35, (copy) v_u_10, (copy) v_u_13
	local v37 = p36.Parent
	local v_u_38
	if v37 == nil then
		v_u_38 = nil
	else
		v_u_38 = v37:FindFirstChildWhichIsA("UIGridStyleLayout")
	end
	if v_u_38 == nil then
		local v39 = p36.AnchorPoint
		if v39 ~= v_u_13 then
			local v40 = p36.Position
			local v41 = p36.Size
			local v42 = 0.5 - v39.X
			local v43 = 0.5 - v39.Y
			p36.Position = UDim2.new(v40.X.Scale + v41.X.Scale * v42, v40.X.Offset + v41.X.Offset * v42, v40.Y.Scale + v41.Y.Scale * v43, v40.Y.Offset + v41.Y.Offset * v43)
			p36.AnchorPoint = v_u_13
		end
	else
		local v_u_44 = p36.Parent
		if v_u_38:IsA("UIListLayout") and not v_u_44:IsA("ScrollingFrame") then
			if not v_u_35[v_u_44] then
				v_u_35[v_u_44] = true
				task.spawn(function()
					-- upvalues: (copy) v_u_44, (copy) v_u_38, (ref) v_u_35, (ref) v_u_10
					local v45 = os.clock() + 5
					while (v_u_44.AbsoluteSize.X <= 0 or v_u_44.AbsoluteSize.Y <= 0) and (os.clock() < v45 and v_u_44.Parent ~= nil) do
						task.wait()
					end
					if v_u_44.Parent == nil or v_u_38.Parent == nil then
						return
					elseif v_u_44.AbsoluteSize.X <= 0 or v_u_44.AbsoluteSize.Y <= 0 then
						v_u_35[v_u_44] = nil
					else
						v_u_10.Freeze(v_u_44, v_u_38)
					end
				end)
			end
		else
			p36.AnchorPoint = v_u_13
			return
		end
	end
end
local v_u_47 = v8.Click
local v_u_48 = v8.Hover
local function v_u_54(p_u_49) -- name: getTargetState
	-- upvalues: (copy) v_u_33, (copy) v_u_46
	local v50 = v_u_33[p_u_49]
	if v50 == nil then
		v_u_46(p_u_49)
		local v51 = {
			["uiScale"] = nil,
			["mouseInside"] = false,
			["selected"] = false,
			["pressed"] = false,
			["watching"] = false,
			["tween"] = nil
		}
		local v52 = p_u_49:FindFirstChild("ButtonTweenScale")
		if v52 == nil or not v52:IsA("UIScale") then
			v52 = Instance.new("UIScale")
			v52.Name = "ButtonTweenScale"
			v52.Scale = 1
			v52.Parent = p_u_49
		end
		v51.uiScale = v52
		local v_u_53 = v51
		v_u_33[p_u_49] = v_u_53
		p_u_49.Destroying:Connect(function()
			-- upvalues: (ref) v_u_53, (ref) v_u_33, (copy) p_u_49
			if v_u_53.tween ~= nil then
				v_u_53.tween:Cancel()
			end
			v_u_33[p_u_49] = nil
		end)
		v50 = v_u_53
	end
	return v50
end
local function v_u_59(p55) -- name: applyState
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (copy) v_u_32
	local v56 = p55.uiScale.Parent
	local v57 = 1
	if p55.pressed then
		if v56 then
			v57 = v56:GetAttribute("PressScale")
		else
			v57 = v56
		end
		if typeof(v57) ~= "number" then
			v57 = v_u_7.PressScale
		end
	elseif p55.mouseInside or p55.selected then
		if v56 then
			v57 = v56:GetAttribute("HoverScale")
		else
			v57 = v56
		end
		if typeof(v57) ~= "number" then
			v57 = v_u_7.HoverScale
		end
	end
	if p55.tween ~= nil then
		p55.tween:Cancel()
	end
	local v58 = v_u_6:Create(p55.uiScale, v_u_32(v56), {
		["Scale"] = v57
	})
	p55.tween = v58
	v58:Play()
end
local function v_u_67(p60) -- name: isMouseOver
	-- upvalues: (copy) v_u_2, (copy) v_u_4
	local v61 = p60
	while p60 ~= nil do
		if p60:IsA("ScreenGui") then
			if not p60.Enabled then
				return false
			end
			break
		end
		if p60:IsA("GuiObject") and not p60.Visible then
			return false
		end
		p60 = p60.Parent
	end
	if p60 == nil then
		return false
	end
	local v62 = v_u_2:GetGuiInset()
	local v63 = v_u_4:GetMouseLocation() - v62
	local v64 = v61.AbsolutePosition
	local v65 = v61.AbsoluteSize
	local v66
	if v63.X >= v64.X and (v63.X <= v64.X + v65.X and v63.Y >= v64.Y) then
		v66 = v63.Y <= v64.Y + v65.Y
	else
		v66 = false
	end
	return v66
end
local function v_u_70(p68) -- name: isHoverBlocked
	-- upvalues: (copy) v_u_1, (copy) v_u_7, (copy) v_u_67
	for _, v69 in v_u_1:GetTagged(v_u_7.HoverBlockerTag) do
		if not v69:IsA("GuiObject") or (v69 == p68 or (p68:IsDescendantOf(v69) or not v_u_67(v69))) then
			continue
		end
		return true
	end
	return false
end
local function v_u_79(p_u_71) -- name: hookButton
	-- upvalues: (copy) v_u_34, (copy) v_u_9, (copy) v_u_7, (copy) v_u_54, (copy) v_u_59, (copy) v_u_70, (copy) v_u_48, (copy) v_u_67, (copy) v_u_47
	if v_u_34[p_u_71] then
		return
	elseif p_u_71:GetAttribute("NoButtonTween") == true then
		return
	elseif v_u_9.IsConfiguredTarget(p_u_71) then
		return
	else
		local v72 = p_u_71:FindFirstAncestorOfClass("ScreenGui")
		if v72 then
			v72 = v_u_7.IgnoreScreenGuis[v72.Name]
		end
		if v72 ~= true and (type(v72) ~= "table" or v72[p_u_71.Name]) then
			v_u_34[p_u_71] = true
			local v_u_73 = p_u_71.Parent
			if p_u_71:GetAttribute("ButtonTweenSelf") == true then
				v_u_73 = p_u_71
			elseif p_u_71.Name ~= "Button" and p_u_71:GetAttribute("ButtonTweenParent") ~= true or (v_u_73 == nil or not v_u_73:IsA("GuiObject")) then
				v_u_73 = p_u_71
			end
			local v_u_74 = v_u_54(v_u_73)
			p_u_71:GetAttributeChangedSignal("ButtonTweenSelf"):Connect(function()
				-- upvalues: (copy) p_u_71, (ref) v_u_73, (ref) v_u_74, (ref) v_u_59, (ref) v_u_54
				local v75 = p_u_71
				local v76 = v75.Parent
				if v75:GetAttribute("ButtonTweenSelf") ~= true then
					if (v75.Name == "Button" or v75:GetAttribute("ButtonTweenParent") == true) and (v76 ~= nil and v76:IsA("GuiObject")) then
						v75 = v76
					end
				end
				if v75 ~= v_u_73 then
					v_u_74.mouseInside = false
					v_u_74.selected = false
					v_u_74.pressed = false
					v_u_59(v_u_74)
					v_u_73 = v75
					v_u_74 = v_u_54(v75)
				end
			end)
			p_u_71.MouseEnter:Connect(function()
				-- upvalues: (ref) v_u_70, (ref) v_u_73, (ref) v_u_74, (ref) v_u_48, (ref) v_u_59, (ref) v_u_67
				if v_u_70(v_u_73) then
					return
				else
					if not v_u_74.mouseInside then
						v_u_74.mouseInside = true
						v_u_48()
						v_u_59(v_u_74)
					end
					local v_u_77 = v_u_73
					local v_u_78 = v_u_74
					if not v_u_78.watching then
						v_u_78.watching = true
						task.spawn(function()
							-- upvalues: (copy) v_u_78, (copy) v_u_77, (ref) v_u_67, (ref) v_u_70, (ref) v_u_59
							while v_u_78.mouseInside and v_u_77.Parent ~= nil do
								if not v_u_67(v_u_77) or v_u_70(v_u_77) then
									v_u_78.mouseInside = false
									v_u_78.pressed = false
									v_u_59(v_u_78)
									break
								end
								task.wait(0.1)
							end
							v_u_78.watching = false
						end)
					end
				end
			end)
			p_u_71.MouseLeave:Connect(function()
				-- upvalues: (ref) v_u_74, (ref) v_u_59
				v_u_74.mouseInside = false
				v_u_74.pressed = false
				v_u_59(v_u_74)
			end)
			p_u_71.SelectionGained:Connect(function()
				-- upvalues: (ref) v_u_74, (ref) v_u_48, (ref) v_u_59
				if not v_u_74.selected then
					v_u_74.selected = true
					v_u_48()
					v_u_59(v_u_74)
				end
			end)
			p_u_71.SelectionLost:Connect(function()
				-- upvalues: (ref) v_u_74, (ref) v_u_59
				v_u_74.selected = false
				v_u_74.pressed = false
				v_u_59(v_u_74)
			end)
			p_u_71.MouseButton1Down:Connect(function()
				-- upvalues: (ref) v_u_70, (ref) v_u_73, (ref) v_u_74, (ref) v_u_59
				if not v_u_70(v_u_73) then
					v_u_74.pressed = true
					v_u_59(v_u_74)
				end
			end)
			p_u_71.MouseButton1Up:Connect(function()
				-- upvalues: (ref) v_u_74, (ref) v_u_59
				v_u_74.pressed = false
				v_u_59(v_u_74)
			end)
			p_u_71.Activated:Connect(v_u_47)
			p_u_71.Destroying:Connect(function()
				-- upvalues: (ref) v_u_34, (copy) p_u_71
				v_u_34[p_u_71] = nil
			end)
		end
	end
end
function v12.Start() -- name: Start
	-- upvalues: (copy) v_u_11, (copy) v_u_79
	local v80 = v_u_11:WaitForChild("PlayerGui")
	for _, v81 in v80:GetDescendants() do
		if not v81:IsA("GuiButton") then
			continue
		end
		v_u_79(v81)
	end
	v80.DescendantAdded:Connect(function(p82)
		-- upvalues: (ref) v_u_79
		if p82:IsA("GuiButton") then
			v_u_79(p82)
		end
	end)
end
return v12
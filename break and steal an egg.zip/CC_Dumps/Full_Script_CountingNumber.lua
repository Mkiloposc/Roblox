local v_u_1 = game:GetService("RunService")
local v_u_2 = {}
v_u_2.__index = v_u_2
function v_u_2.new(p3, p4) -- name: new
	-- upvalues: (copy) v_u_2
	local v5 = v_u_2
	return setmetatable({
		["_apply"] = nil,
		["_onStep"] = nil,
		["_value"] = 0,
		["_target"] = 0,
		["_shown"] = nil,
		["_connection"] = nil,
		["_apply"] = p3,
		["_onStep"] = p4
	}, v5)
end
function v_u_2._stop(p6) -- name: _stop
	if p6._connection ~= nil then
		p6._connection:Disconnect()
		p6._connection = nil
	end
end
function v_u_2._applyIfChanged(p7, p8) -- name: _applyIfChanged
	local v9 = p8 * 2
	local v10 = math.floor(v9)
	if v10 ~= p7._shown then
		p7._shown = v10
		p7._apply(p8)
	end
end
function v_u_2.Snap(p11, p12) -- name: Snap
	p11:_stop()
	p11._target = p12
	p11._value = p12
	p11:_applyIfChanged(p12)
	if p11._onStep then
		p11._onStep(p12)
	end
end
function v_u_2.Value(p13) -- name: Value
	return p13._value
end
function v_u_2.Set(p_u_14, p15) -- name: Set
	-- upvalues: (copy) v_u_1
	p_u_14._target = p15
	local v16 = p15 - p_u_14._value
	local v17 = math.abs(v16)
	if v17 == v17 and v17 ~= (1 / 0) then
		local v18 = math.abs(p15) * 1e-9
		if v17 > math.max(0.5, v18) then
			if p_u_14._connection == nil then
				p_u_14._connection = v_u_1.Heartbeat:Connect(function(p19)
					-- upvalues: (copy) p_u_14
					local v20 = p_u_14._target - p_u_14._value
					local v21 = math.abs(v20)
					local v22 = p_u_14._target
					local v23 = math.abs(v22) * 1e-9
					if v21 <= math.max(0.5, v23) then
						p_u_14:Snap(p_u_14._target)
					else
						p_u_14._value = p_u_14._target - v20 * 0.025 ^ p19
						p_u_14:_applyIfChanged(p_u_14._value)
						if p_u_14._onStep then
							p_u_14._onStep(p_u_14._value)
						end
					end
				end)
			end
			return
		end
	end
	p_u_14:Snap(p15)
end
function v_u_2.Destroy(p24) -- name: Destroy
	p24:_stop()
end
return v_u_2
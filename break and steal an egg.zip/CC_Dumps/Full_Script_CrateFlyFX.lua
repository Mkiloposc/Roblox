local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = require(script.Parent.Parent.UiSounds)
local v4 = {}
local v_u_5 = Random.new()
local v_u_6 = nil
local function v_u_9(p7) -- name: ensureScreen
	-- upvalues: (ref) v_u_6, (copy) v_u_1
	local v8 = v_u_6
	if v8 == nil or v8.Parent == nil then
		v8 = Instance.new("ScreenGui")
		v8.Name = "CrateFlyFX"
		v8.ResetOnSpawn = false
		v8.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
		v8.Parent = v_u_1.LocalPlayer:WaitForChild("PlayerGui")
		v_u_6 = v8
	end
	v8.IgnoreGuiInset = p7.IgnoreGuiInset
	v8.ScreenInsets = p7.ScreenInsets
	v8.DisplayOrder = p7.DisplayOrder + 11
	return v8
end
function v4.HotbarSlot(p10, p11, p12, p13) -- name: HotbarSlot
	-- upvalues: (copy) v_u_9
	local v14 = v_u_9(p13).AbsoluteSize
	local v15
	if v14.Y < p12.SmallScreenHeight then
		v15 = p12.SmallSlotSize
	else
		v15 = p12.SlotSize
	end
	local v16 = v15 + p12.SlotGap
	local v17 = v14.X / 2 + (p10 - (p11 + 1) / 2) * v16
	local v18 = v14.Y - p12.BottomOffset - v15 / 2
	return Vector2.new(v17, v18), v15
end
local v_u_19 = {
	["label"] = nil,
	["stroke"] = nil,
	["scale"] = nil,
	["streak"] = 0,
	["token"] = 0,
	["shakeSerial"] = 0,
	["fades"] = nil,
	["fades"] = {}
}
local function v_u_23(p20, p21, p22) -- name: styleText
	p20.BackgroundTransparency = 1
	p20.TextScaled = true
	p20.AnchorPoint = Vector2.new(0.5, 0.5)
	p20.TextColor3 = Color3.new(1, 1, 1)
	if p21 then
		p20.FontFace = p21.FontFace
	else
		p20.Font = Enum.Font.GothamBlack
	end
	p20.Rotation = p22.CounterRotation
end
local function v_u_32(p24, p25, p26) -- name: ensureCounter
	-- upvalues: (copy) v_u_19, (copy) v_u_23
	local v27 = v_u_19.label
	if v27 == nil or v27.Parent ~= p24 then
		local v28 = Instance.new("TextLabel")
		v28.Name = "CrateCounter"
		v28.ZIndex = 3
		v_u_23(v28, p25, p26)
		if p25 then
			p25 = p25:FindFirstChildOfClass("UIStroke")
		end
		local v29 = Instance.new("UIStroke")
		local v30
		if p25 then
			v30 = p25.Color
		else
			v30 = Color3.new(0, 0, 0)
		end
		v29.Color = v30
		v29.Thickness = not p25 and 3 or p25.Thickness
		v29.Parent = v28
		local v31 = Instance.new("UIScale")
		v31.Parent = v28
		v28.Parent = p24
		v_u_19.label = v28
		v_u_19.stroke = v29
		v_u_19.scale = v31
		v_u_19.streak = 0
	end
	return v_u_19.label, v_u_19.stroke, v_u_19.scale
end
local function v_u_42(p33, p34, p35) -- name: burstText
	-- upvalues: (copy) v_u_2
	local v_u_36 = Instance.new("TextLabel")
	v_u_36.Name = "CounterBurst"
	v_u_36.BackgroundTransparency = 1
	v_u_36.TextScaled = true
	v_u_36.FontFace = p33.FontFace
	v_u_36.Text = p33.Text
	v_u_36.TextColor3 = Color3.new(1, 1, 1)
	v_u_36.AnchorPoint = p33.AnchorPoint
	v_u_36.Position = p33.Position
	v_u_36.Size = p33.Size
	v_u_36.Rotation = p33.Rotation
	v_u_36.ZIndex = p33.ZIndex - 1
	local v37 = Instance.new("UIStroke")
	v37.Color = Color3.new(1, 1, 1)
	v37.Thickness = p34.Thickness
	v37.Parent = v_u_36
	local v38 = Instance.new("UIScale")
	v38.Parent = v_u_36
	v_u_36.Parent = p33.Parent
	local v39 = p35.BurstTween
	local v40 = TweenInfo.new(v39.Duration, v39.Style, v39.Direction)
	local v41 = v_u_2:Create(v38, v40, {
		["Scale"] = p35.BurstScale
	})
	v41.Completed:Once(function()
		-- upvalues: (copy) v_u_36
		v_u_36:Destroy()
	end)
	v_u_2:Create(v_u_36, v40, {
		["TextTransparency"] = 1
	}):Play()
	v_u_2:Create(v37, v40, {
		["Transparency"] = 1
	}):Play()
	v41:Play()
end
local function v_u_74(p43, p_u_44, p45, p_u_46, p47) -- name: bumpCounter
	-- upvalues: (copy) v_u_32, (copy) v_u_19, (copy) v_u_2, (copy) v_u_42, (copy) v_u_5, (copy) v_u_3
	local v_u_48, v_u_49, v50 = v_u_32(p47, p45, p_u_46)
	for _, v51 in v_u_19.fades do
		v51:Cancel()
	end
	table.clear(v_u_19.fades)
	local v52 = v_u_19
	v52.streak = v52.streak + 1
	v_u_48.Text = ("%*x"):format(v_u_19.streak)
	v_u_48.Size = UDim2.fromOffset(p_u_44 * p_u_46.CounterWidth, p_u_44 * p_u_46.CounterHeight)
	local v_u_53 = UDim2.fromOffset(p43.X, p43.Y - p_u_44 * p_u_46.CounterAbove)
	local v_u_54 = p_u_46.CounterRotation
	v_u_48.Position = v_u_53
	v_u_48.Rotation = v_u_54
	v_u_48.TextTransparency = 0
	v_u_49.Transparency = 0
	v_u_48.Visible = true
	v50.Scale = p_u_46.CounterPopScale
	local v55 = v_u_2
	local v56 = p_u_46.CounterPopTween
	v55:Create(v50, TweenInfo.new(v56.Duration, v56.Style, v56.Direction), {
		["Scale"] = 1
	}):Play()
	v_u_42(v_u_48, v_u_49, p_u_46)
	local v57 = v_u_19
	v57.shakeSerial = v57.shakeSerial + 1
	local v_u_58 = v_u_19.shakeSerial
	task.spawn(function()
		-- upvalues: (copy) p_u_46, (ref) v_u_19, (copy) v_u_58, (copy) v_u_48, (ref) v_u_5, (copy) p_u_44, (copy) v_u_53, (copy) v_u_54
		local v59 = p_u_46.ShakeSteps
		for v60 = 1, v59 do
			if v_u_19.shakeSerial ~= v_u_58 or v_u_48.Parent == nil then
				return
			end
			local v61 = 1 - (v60 - 1) / v59
			local v62 = v_u_5:NextNumber(0, 6.283185307179586)
			local v63 = p_u_46.ShakeDistance * p_u_44 * v61
			v_u_48.Position = v_u_53 + UDim2.fromOffset(math.cos(v62) * v63, math.sin(v62) * v63)
			v_u_48.Rotation = v_u_54 + v_u_5:NextNumber(-1, 1) * p_u_46.ShakeTilt * v61
			task.wait(p_u_46.ShakeStepTime)
		end
		if v_u_19.shakeSerial == v_u_58 and v_u_48.Parent then
			v_u_48.Position = v_u_53
			v_u_48.Rotation = v_u_54
		end
	end)
	local v64 = p_u_46.PitchStart + p_u_46.PitchStep * (v_u_19.streak - 1)
	local v65 = p_u_46.PitchMax
	local v66 = math.min(v64, v65)
	v_u_3.Play(p_u_46.LandSound, p_u_46.LandSoundFolder, v66)
	local v67 = v_u_19
	v67.token = v67.token + 1
	local v_u_68 = v_u_19.token
	task.delay(p_u_46.CounterLinger, function()
		-- upvalues: (ref) v_u_19, (copy) v_u_68, (copy) v_u_48, (copy) p_u_46, (ref) v_u_2, (copy) v_u_49
		if v_u_19.token == v_u_68 and v_u_48.Parent ~= nil then
			local v69 = p_u_46.CounterFadeTween
			local v70 = TweenInfo.new(v69.Duration, v69.Style, v69.Direction)
			local v71 = v_u_2:Create(v_u_48, v70, {
				["TextTransparency"] = 1
			})
			local v72 = v_u_2:Create(v_u_49, v70, {
				["Transparency"] = 1
			})
			v_u_19.fades = { v71, v72 }
			v71.Completed:Once(function(p73)
				-- upvalues: (ref) v_u_19, (ref) v_u_68, (ref) v_u_48
				if p73 == Enum.PlaybackState.Completed and v_u_19.token == v_u_68 then
					v_u_48.Visible = false
					v_u_19.streak = 0
				end
			end)
			v71:Play()
			v72:Play()
		end
	end)
end
local function v_u_80(p75, p76) -- name: makeArt
	local v77 = Instance.new("ImageLabel")
	v77.Name = "FlyingCrate"
	v77.BackgroundTransparency = 1
	v77.AnchorPoint = Vector2.new(0.5, 0.5)
	v77.Size = UDim2.fromOffset(p76, p76)
	v77.Image = p75.Image
	v77.ImageColor3 = p75.ShadowColor
	v77.ImageTransparency = p75.ShadowTransparency
	v77.ZIndex = 2
	local v78 = Instance.new("ImageLabel")
	v78.Name = "Art"
	v78.BackgroundTransparency = 1
	v78.AnchorPoint = Vector2.new(0.5, 0.5)
	v78.Position = p75.InnerPosition
	v78.Size = UDim2.fromScale(1, 1)
	v78.Image = p75.Image
	v78.ImageColor3 = p75.Color
	v78.ImageTransparency = p75.Transparency
	v78.ZIndex = 2
	v78.Parent = v77
	local v79 = Instance.new("UIScale")
	v79.Scale = 0
	v79.Parent = v77
	return v77, v79
end
local function v_u_112(p81, p82) -- name: flyOne
	-- upvalues: (copy) v_u_9, (copy) v_u_80, (copy) v_u_5, (copy) v_u_2, (copy) v_u_74
	local v83 = p81.settings
	local v84 = v_u_9(p81.refGui)
	local v_u_85 = p81.startSize
	local v_u_86, v87 = v_u_80(p81.art, v_u_85)
	local v88 = v_u_5:NextInteger(0, 1) == 0 and -1 or 1
	local v89 = v_u_5:NextNumber(0.4, 1)
	local v90 = p81.from
	local v91 = v90 + Vector2.new(v88 * v89 * v83.PopSide * v_u_85, -v83.PopRise * v_u_85)
	v_u_86.Position = UDim2.fromOffset(v90.X, v90.Y)
	v_u_86.Rotation = v88 * v83.PopTilt
	v_u_86.Parent = v84
	local v92 = v83.PopTween
	local v93 = TweenInfo.new(v92.Duration, v92.Style, v92.Direction)
	v_u_2:Create(v87, v93, {
		["Scale"] = 1
	}):Play()
	local v94 = v_u_2:Create(v_u_86, v93, {
		["Position"] = UDim2.fromOffset(v91.X, v91.Y)
	})
	v94:Play()
	task.wait(v83.PopHold)
	v94:Cancel()
	if v_u_86.Parent ~= nil then
		local v_u_95 = Vector2.new(v_u_86.Position.X.Offset, v_u_86.Position.Y.Offset)
		local v_u_96, v97 = p81.target()
		local v_u_98 = (v_u_95 + v_u_96) / 2 + Vector2.new(v88 * v89 * v83.CurveSide * v_u_85, -v83.CurveLift * v_u_85)
		local v_u_99 = v97 * v83.EndSize
		local v_u_100 = v_u_86.Rotation
		local v101 = Instance.new("NumberValue")
		v101.Changed:Connect(function(p102)
			-- upvalues: (copy) v_u_95, (copy) v_u_98, (copy) v_u_96, (copy) v_u_86, (copy) v_u_85, (copy) v_u_99, (copy) v_u_100
			local v103 = v_u_95
			local v104 = v_u_98
			local v105 = v_u_96
			local v106 = 1 - p102
			local v107 = v103 * (v106 * v106) + v104 * (v106 * 2 * p102) + v105 * (p102 * p102)
			v_u_86.Position = UDim2.fromOffset(v107.X, v107.Y)
			local v108 = v_u_85 + (v_u_99 - v_u_85) * p102
			v_u_86.Size = UDim2.fromOffset(v108, v108)
			v_u_86.Rotation = v_u_100 * (1 - p102)
		end)
		local v109 = v_u_2
		local v110 = v83.FlightTween
		local v111 = v109:Create(v101, TweenInfo.new(v110.Duration, v110.Style, v110.Direction), {
			["Value"] = 1
		})
		v111:Play()
		v111.Completed:Wait()
		v101:Destroy()
		v_u_86:Destroy()
		p81.onLand(p82)
		v_u_74(v_u_96, v97, p81.textStyle, v83, v84)
	end
end
function v4.Fly(p113) -- name: Fly
	-- upvalues: (copy) v_u_112
	for v114 = 1, p113.count do
		task.delay((v114 - 1) * p113.settings.Stagger, v_u_112, p113, v114)
	end
end
return v4
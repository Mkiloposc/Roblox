local v1 = require(script.Parent.PetInventoryConfig)
local v2 = {
	["GuiName"] = "Scatchel",
	["MobileGuiName"] = "MobileScatchel",
	["HotbarName"] = "BottomHUD",
	["InventoryName"] = "Inventory",
	["TemplateName"] = "Template",
	["HotbarSlotsFull"] = 10,
	["HotbarSlotsMini"] = 5,
	["EquipRetryCount"] = 2,
	["EquipRetryDelay"] = 0.15,
	["ToggleKey"] = Enum.KeyCode.Backquote,
	["DragThreshold"] = 8,
	["TouchHoldTime"] = 0.3,
	["TouchDragSlop"] = 14,
	["HotbarDropMargin"] = 16,
	["TopbarPlusPath"] = {
		"Satchel",
		"SatchelLoader",
		"Satchel",
		"Packages",
		"topbarplus"
	},
	["Icon"] = {
		["Name"] = "Inventory",
		["Caption"] = "Inventory",
		["ImageOpen"] = "rbxasset://textures/ui/TopBar/inventoryOn.png",
		["ImageClosed"] = "rbxasset://textures/ui/TopBar/inventoryOff.png",
		["Order"] = -1
	}
}
local v3 = {
	["Pets"] = {
		["Button"] = "Pets",
		["Title"] = "All Pets",
		["CountLabel"] = "Pets",
		["CountTag"] = "AnimalTool",
		["Capacity"] = nil,
		["Capacity"] = v1.MaxPets
	},
	["Eggs"] = {
		["Button"] = "Eggs",
		["Title"] = "All Eggs",
		["CountLabel"] = "Eggs",
		["MatchTag"] = "MergeEggTool",
		["CountTag"] = "MergeEggTool",
		["Capacity"] = nil,
		["HideCount"] = true,
		["SortBy"] = nil,
		["SortBy"] = { "Rarity", "Kg" }
	},
	["RideablePets"] = {
		["Button"] = "RideablePets",
		["Title"] = "All Mounts",
		["CountLabel"] = "Mounts",
		["MatchTag"] = "RideableTool",
		["Rideables"] = true,
		["Capacity"] = nil,
		["HideSell"] = true
	}
}
v2.Categories = v3
v2.DefaultCategory = "Pets"
v2.RideableCountFormat = "%s x%d"
v2.RestoredAttribute = "BackpackRestored"
v2.RestoredGoToInventory = true
v2.HotbarShowInfo = true
v2.InventoryShowInfo = true
v2.HoverScale = 1.03
v2.PressScale = 0.98
v2.HoverTweenTime = 0.08
v2.LockedTintColor = Color3.fromRGB(190, 55, 45)
v2.LockedTintTransparency = 0.1
v2.LockedTintFadeTime = 0.2
v2.ShakeAngle = 14
v2.ShakeTime = 0.4
v2.ShakeCycles = 3
v2.WeightFormat = "[%sKG]"
v2.NameWeightFormat = "%s (%sKG)"
v2.AnimalInfoName = "AnimalInfo"
v2.AnimalInfoNameFormat = "%s [%sKG]"
v2.AnimalInfoEarningsFormat = "$%s/s"
v2.AnimalInfoEggScale = 0.8
v2.AnimalInfoCursorGap = 30
v2.ViewportFov = 40
v2.ViewportDirection = Vector3.new(0.55, 0.35, -1)
v2.SelectedStrokeName = "Selected"
v2.SwapMarkThicknessMult = 2
v2.GamepadDoubleTapTime = 0.4
return v2
local v_u_1 = table.freeze({})
local function v_u_3(p2) -- name: is_action
	-- upvalues: (copy) v_u_1
	return getmetatable(p2) == v_u_1
end
local function v_u_8(p4, p5) -- name: action
	-- upvalues: (copy) v_u_1
	local v6 = {
		["priority"] = p5 or 1,
		["callback"] = p4
	}
	local v7 = v_u_1
	setmetatable(v6, v7)
	return table.freeze(v6)
end
return function()
	-- upvalues: (copy) v_u_8, (copy) v_u_3
	return v_u_8, v_u_3
end
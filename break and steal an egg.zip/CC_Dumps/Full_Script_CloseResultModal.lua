local v1 = script.Parent.Parent
local v_u_2 = require(v1.Actions.CloseResultModal)
return function(p3)
	-- upvalues: (copy) v_u_2
	p3:dispatch(v_u_2())
end
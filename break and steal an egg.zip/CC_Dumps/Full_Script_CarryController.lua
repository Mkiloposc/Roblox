local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("StarterGui")
local v_u_4 = require(v2.Shared.AnimationAssets)
local v_u_5 = require(script.Parent.AnimationCache)
local v_u_6 = require(script.Parent.Parent.Modules.BackpackGui)
local v7 = require(v2.Shared.HudVisibility)
local v8 = {}
local v_u_9 = {
	["MainGUI"] = true,
	["ProximityPrompts"] = true,
	["RewardFlashHolder"] = true,
	["TouchGui"] = true,
	["ContextActionGui"] = true
}
local v_u_10 = { "Currencies" }
local v_u_11 = v1.LocalPlayer
local v_u_12 = {}
local v_u_13 = {}
local v_u_14 = nil
local v_u_15 = false
local v_u_16 = false
local v_u_17 = false
local v_u_18 = v7.new()
local v_u_19 = false
local v_u_20 = {}
local v_u_21 = {}
local v_u_22 = false
local function v_u_46(p23) -- name: setUiHidden
	-- upvalues: (copy) v_u_11, (copy) v_u_9, (copy) v_u_12, (copy) v_u_13, (ref) v_u_15, (copy) v_u_18, (copy) v_u_10, (ref) v_u_17, (copy) v_u_3
	local v24 = v_u_11:FindFirstChildOfClass("PlayerGui")
	if p23 then
		if v24 then
			for _, v_u_25 in v24:GetChildren() do
				if not v_u_25:IsA("ScreenGui") or (not v_u_25.Enabled or v_u_9[v_u_25.Name]) then
					continue
				end
				v_u_25.Enabled = false
				local v26 = v_u_12
				table.insert(v26, v_u_25)
				local v27 = v_u_13
				local v28 = v_u_25:GetPropertyChangedSignal("Enabled")
				local function v29()
					-- upvalues: (ref) v_u_15, (copy) v_u_25
					if v_u_15 and v_u_25.Enabled then
						v_u_25.Enabled = false
					end
				end
				table.insert(v27, v28:Connect(v29))
			end
			v_u_18:HideChildren(v24:FindFirstChild("MainGUI"), v_u_10)
			local v30 = v_u_13
			local v31 = v24.ChildAdded
			local function v38(p_u_32)
				-- upvalues: (ref) v_u_15, (ref) v_u_18, (ref) v_u_10, (ref) v_u_9, (ref) v_u_12, (ref) v_u_13
				task.defer(function()
					-- upvalues: (ref) v_u_15, (copy) p_u_32, (ref) v_u_18, (ref) v_u_10, (ref) v_u_9, (ref) v_u_12, (ref) v_u_13
					if v_u_15 and p_u_32:IsA("ScreenGui") then
						if p_u_32.Name == "MainGUI" then
							v_u_18:HideChildren(p_u_32, v_u_10)
						elseif p_u_32.Enabled and not v_u_9[p_u_32.Name] then
							local v_u_33 = p_u_32
							v_u_33.Enabled = false
							local v34 = v_u_12
							table.insert(v34, v_u_33)
							local v35 = v_u_13
							local v36 = v_u_33:GetPropertyChangedSignal("Enabled")
							local function v37()
								-- upvalues: (ref) v_u_15, (copy) v_u_33
								if v_u_15 and v_u_33.Enabled then
									v_u_33.Enabled = false
								end
							end
							table.insert(v35, v36:Connect(v37))
						end
					else
						return
					end
				end)
			end
			table.insert(v30, v31:Connect(v38))
		end
		local function v39()
			-- upvalues: (ref) v_u_17, (ref) v_u_3
			v_u_17 = v_u_3:GetCoreGuiEnabled(Enum.CoreGuiType.Backpack)
			v_u_3:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
		end
		pcall(v39)
	else
		for _, v40 in v_u_13 do
			v40:Disconnect()
		end
		table.clear(v_u_13)
		for _, v41 in v_u_12 do
			if not v41.Parent then
				continue
			end
			v41.Enabled = true
		end
		table.clear(v_u_12)
		v_u_18:RestoreAll()
		local v42 = v_u_3.SetCoreGuiEnabled
		local v43 = v_u_3
		local v44 = Enum.CoreGuiType.Backpack
		local v45 = v_u_17
		pcall(v42, v43, v44, v45)
	end
end
local function v_u_70(p47) -- name: setJailUiHidden
	-- upvalues: (ref) v_u_19, (copy) v_u_11, (copy) v_u_6, (copy) v_u_20, (copy) v_u_21, (ref) v_u_22, (copy) v_u_3
	if p47 == v_u_19 then
		return
	else
		v_u_19 = p47
		local v48 = v_u_11:FindFirstChildOfClass("PlayerGui")
		if p47 then
			local v_u_49
			if v48 then
				v_u_49 = v48:FindFirstChild(v_u_6.Name())
			else
				v_u_49 = v48
			end
			if v_u_49 and (v_u_49:IsA("ScreenGui") and v_u_49.Enabled) then
				v_u_49.Enabled = false
				local v50 = v_u_20
				table.insert(v50, v_u_49)
				local v51 = v_u_21
				local v52 = v_u_49:GetPropertyChangedSignal("Enabled")
				local function v53()
					-- upvalues: (ref) v_u_19, (copy) v_u_49
					if v_u_19 and v_u_49.Enabled then
						v_u_49.Enabled = false
					end
				end
				table.insert(v51, v52:Connect(v53))
			end
			if v48 then
				local v54 = v_u_21
				local v55 = v48.ChildAdded
				local function v62(p_u_56)
					-- upvalues: (ref) v_u_19, (ref) v_u_6, (ref) v_u_20, (ref) v_u_21
					task.defer(function()
						-- upvalues: (ref) v_u_19, (copy) p_u_56, (ref) v_u_6, (ref) v_u_20, (ref) v_u_21
						if v_u_19 and (p_u_56.Name == v_u_6.Name() and (p_u_56:IsA("ScreenGui") and p_u_56.Enabled)) then
							local v_u_57 = p_u_56
							v_u_57.Enabled = false
							local v58 = v_u_20
							table.insert(v58, v_u_57)
							local v59 = v_u_21
							local v60 = v_u_57:GetPropertyChangedSignal("Enabled")
							local function v61()
								-- upvalues: (ref) v_u_19, (copy) v_u_57
								if v_u_19 and v_u_57.Enabled then
									v_u_57.Enabled = false
								end
							end
							table.insert(v59, v60:Connect(v61))
						end
					end)
				end
				table.insert(v54, v55:Connect(v62))
			end
			local function v63()
				-- upvalues: (ref) v_u_22, (ref) v_u_3
				v_u_22 = v_u_3:GetCoreGuiEnabled(Enum.CoreGuiType.Backpack)
				v_u_3:SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, false)
			end
			pcall(v63)
		else
			for _, v64 in v_u_21 do
				v64:Disconnect()
			end
			table.clear(v_u_21)
			for _, v65 in v_u_20 do
				if not v65.Parent then
					continue
				end
				v65.Enabled = true
			end
			table.clear(v_u_20)
			local v66 = v_u_3.SetCoreGuiEnabled
			local v67 = v_u_3
			local v68 = Enum.CoreGuiType.Backpack
			local v69 = v_u_22
			pcall(v66, v67, v68, v69)
		end
	end
end
local function v_u_73(p71) -- name: loadTrack
	-- upvalues: (ref) v_u_14, (copy) v_u_5, (copy) v_u_4, (copy) v_u_11, (ref) v_u_16
	v_u_14 = nil
	local v72 = v_u_5.Warm(p71, v_u_4.Carry, Enum.AnimationPriority.Action, true)
	if v72 then
		if v_u_11.Character == p71 then
			v_u_14 = v72
			if v_u_16 then
				v72:Play(0.15)
			end
		end
	else
		return
	end
end
local function v_u_78() -- name: refreshState
	-- upvalues: (copy) v_u_11, (ref) v_u_15, (copy) v_u_46, (ref) v_u_16, (ref) v_u_14, (copy) v_u_70
	local v74 = v_u_11:GetAttribute("Carrying") ~= nil
	local v75 = v_u_11:GetAttribute("CarryingJail") == true
	local v76 = v_u_11:GetAttribute("Jailed") == true
	if v74 ~= v_u_15 then
		v_u_15 = v74
		v_u_46(v_u_15)
	end
	local v77 = v74 or v75
	if v77 ~= v_u_16 then
		v_u_16 = v77
		if v77 then
			if v_u_14 then
				v_u_14:Play(0.15)
			end
		elseif v_u_14 then
			v_u_14:Stop(0.15)
		end
	end
	v_u_70(v75 or (v76 or v_u_11:GetAttribute("GuardMorph") ~= nil))
end
function v8.Start() -- name: Start
	-- upvalues: (copy) v_u_11, (copy) v_u_78, (copy) v_u_73
	v_u_11:GetAttributeChangedSignal("Carrying"):Connect(v_u_78)
	v_u_11:GetAttributeChangedSignal("CarryingJail"):Connect(v_u_78)
	v_u_11:GetAttributeChangedSignal("Jailed"):Connect(v_u_78)
	v_u_11:GetAttributeChangedSignal("GuardMorph"):Connect(v_u_78)
	v_u_11.CharacterAdded:Connect(function(p79)
		-- upvalues: (ref) v_u_73
		task.spawn(v_u_73, p79)
	end)
	if v_u_11.Character then
		task.spawn(v_u_73, v_u_11.Character)
	end
	v_u_78()
end
return v8
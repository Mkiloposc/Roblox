local v_u_1 = game:GetService("Players")
local v2 = game:GetService("CorePackages")
local v_u_3 = require(v2.Workspace.Packages.ExpChat)
local v_u_4 = require(script.Parent.Parent.Types)
local v_u_5 = require(script.Parent.Parent.Helpers.maybeAssert)
local v_u_6 = require(script.Parent.AddMessageWithTimeout)
return function(p_u_7) -- name: addMessageFromEvent
	-- upvalues: (copy) v_u_5, (copy) v_u_4, (copy) v_u_1, (copy) v_u_3, (copy) v_u_6
	v_u_5(v_u_4.IMessageData(p_u_7))
	return function(p8)
		-- upvalues: (ref) v_u_1, (copy) p_u_7, (ref) v_u_3, (ref) v_u_6
		local v9, v10 = pcall(function()
			-- upvalues: (ref) v_u_1, (ref) p_u_7
			return v_u_1:GetPlayerByUserId(p_u_7.SpeakerUserId)
		end)
		local v11 = v9 and (v10 and v10.Character)
		if v11 then
			local v12 = {}
			local v13 = p_u_7.ID
			v12.id = tostring(v13)
			local v14 = p_u_7.SpeakerUserId
			v12.userId = tostring(v14)
			v12.name = p_u_7.FromSpeaker
			v12.text = p_u_7.Message or ""
			v12.timestamp = p_u_7.Time
			v12.adornee = v11
			v_u_3.Events.LegacyBubbleCreated(v12)
			return p8:dispatch(v_u_6(v12))
		end
	end
end
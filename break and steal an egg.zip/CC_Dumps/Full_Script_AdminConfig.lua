local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v_u_3 = {
	["UserIds"] = {
		[9679848455] = true,
		[1247492319] = true,
		[1754608862] = true
	},
	["OwnerUserIds"] = {
		[9679848455] = true
	},
	["Usernames"] = {
		["realrran"] = true,
		["monkisrok"] = true
	},
	["DevPlaceId"] = 123834297139486,
	["DevConsoleUserIds"] = {
		[1199429781] = true
	},
	["LimitedConsoleUserIds"] = {
		[1199429781] = true
	},
	["LimitedRole"] = "limited-admin",
	["GivePermission"] = "admin-give",
	["LimitedBlocked"] = {
		["cash"] = true,
		["speed"] = true,
		["giveanimal"] = true,
		["givescale"] = true,
		["givebest"] = true,
		["giveall"] = true,
		["index"] = true,
		["grantpurchase"] = true,
		["givepotion"] = true,
		["globalpotion"] = true,
		["givecandycorn"] = true,
		["setbat"] = true,
		["batstrength"] = true,
		["bathitbox"] = true,
		["tricktest"] = true,
		["cheatermode"] = true,
		["announce"] = true,
		["globalinvite"] = true,
		["adminabuse"] = true,
		["endadminabuse"] = true,
		["ban"] = true,
		["unban"] = true
	},
	["TagOnlyConsoleUserIds"] = {
		[1195778415] = true
	},
	["TagOnlyRole"] = "tag-admin",
	["TagPermission"] = "admin-tag",
	["TagOnlyCommands"] = {
		["tag"] = true,
		["untag"] = true,
		["tags"] = true
	},
	["TagOnlyTitles"] = {
		["Tester"] = true,
		["ContentCreator"] = true
	},
	["TagOnlyAttribute"] = "IsTagOnlyAdmin",
	["StudioAlwaysAdmin"] = true,
	["Role"] = "super-user",
	["Permission"] = "admin",
	["Keybind"] = Enum.KeyCode.F2,
	["Attribute"] = "IsAdmin",
	["PanelAttribute"] = "IsPanelAdmin",
	["PanelButtonName"] = "AdminPanel(ADMINS ONLY!)",
	["PanelFrameName"] = "AdminPanel",
	["PanelStorage"] = "AdminUI",
	["PanelScopes"] = { "Client", "Server", "Global" },
	["PanelDefaultScope"] = "Client",
	["PanelHoverScale"] = 0.95,
	["PanelPressScale"] = 0.88,
	["PanelCards"] = {
		["Announce"] = "Announcements",
		["Gift"] = "Gifting",
		["Poll"] = "CreatePoll",
		["BossSpawn"] = "BossSpawning",
		["Treadmill"] = "AdminTreadmillSpawn",
		["AdminAbuse"] = "AdminAbuse",
		["GlobalBoost"] = "GlobalBoosts",
		["TitanicEgg"] = "TitanicEggSpawn",
		["EventRsvp"] = "EventRsvpPrompt"
	},
	["PollCreateFrame"] = "GlobalPollCreate",
	["AdminOnlyFrames"] = { "GlobalPollCreate" }
}
local v4 = {
	["Sections"] = nil,
	["DefaultType"] = "Animals",
	["EveryoneWords"] = nil,
	["GlobalToggleName"] = "GlobalEdit",
	["DefaultGlobal"] = false,
	["GlobalOnStyle"] = "Green",
	["GlobalOffStyle"] = "Red",
	["GlobalOnText"] = "[ON]",
	["GlobalOffText"] = "[OFF]",
	["GlobalTypes"] = nil,
	["StyleSources"] = nil,
	["PotionStyles"] = nil,
	["MaxAnimalAmount"] = 25,
	["AnimalColor"] = nil,
	["KgSuffix"] = "KG",
	["AmountSuffix"] = "x",
	["MinutesSuffix"] = "m",
	["MaxKg"] = 1000000000000000,
	["MaxPotionSeconds"] = 86400,
	["Sections"] = {
		["Potions"] = "PotionGifting",
		["Animals"] = "AnimalGifting"
	},
	["EveryoneWords"] = {
		["all"] = true,
		["everyone"] = true,
		["@a"] = true
	},
	["GlobalTypes"] = {
		["Potions"] = true
	},
	["StyleSources"] = {
		["Red"] = { "Announcements", "Client" },
		["Green"] = { "Announcements", "Server" },
		["Blue"] = { "Announcements", "Global" }
	},
	["PotionStyles"] = {
		["WalkSpeed"] = "Blue",
		["Cash"] = "Green",
		["Treadmill"] = "Red"
	},
	["AnimalColor"] = Color3.fromRGB(255, 210, 60)
}
v_u_3.Gift = v4
v_u_3.PanelRemotes = {
	["Announce"] = "AdminPanelAnnounce",
	["Gift"] = "AdminPanelGift",
	["Poll"] = "AdminPanelPoll",
	["BossSpawn"] = "AdminPanelBossSpawn",
	["Treadmill"] = "AdminPanelTreadmill",
	["AdminAbuse"] = "AdminPanelAdminAbuse",
	["GlobalBoost"] = "AdminPanelGlobalBoost",
	["TitanicEgg"] = "AdminPanelTitanicEgg",
	["EventRsvp"] = "AdminPanelEventRsvp"
}
v_u_3.GlobalBoost = {
	["Scopes"] = nil,
	["DefaultScope"] = "Global",
	["Choices"] = nil,
	["AllName"] = "All Boosts",
	["AllColor"] = "#FFD23C",
	["MaxMultiplier"] = 100,
	["MaxSeconds"] = 86400,
	["MinutesSuffix"] = "m",
	["MultiplierPrefix"] = "x",
	["Scopes"] = {
		["Server"] = true,
		["Global"] = true
	},
	["Choices"] = {
		"Cash",
		"WalkSpeed",
		"Treadmill",
		"EggGrowth",
		"Swing",
		"EggLuck",
		"all"
	}
}
v_u_3.TitanicEgg = {
	["ToggleName"] = "ZoneEdit",
	["ListName"] = "ZoneList",
	["SettingName"] = "ZoneSetting",
	["RandomOption"] = "Random"
}
v_u_3.ChatPrefix = "/"
v_u_3.RawTextCommands = { "announce" }
v_u_3.LogPrefix = "[admin]"
function v_u_3.IsAdmin(p5) -- name: IsAdmin
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	return v_u_3.UserIds[p5.UserId] and true or (v_u_3.Usernames[string.lower(p5.Name)] and true or (v_u_3.StudioAlwaysAdmin and v_u_2:IsStudio() and true or false))
end
function v_u_3.IsOwner(p6) -- name: IsOwner
	-- upvalues: (copy) v_u_3
	local v7
	if p6 == nil then
		v7 = false
	else
		v7 = v_u_3.OwnerUserIds[p6.UserId] == true
	end
	return v7
end
function v_u_3.HasConsole(p8) -- name: HasConsole
	-- upvalues: (copy) v_u_3
	if v_u_3.IsAdmin(p8) then
		return true
	end
	if v_u_3.LimitedConsoleUserIds[p8.UserId] then
		return true
	end
	if v_u_3.TagOnlyConsoleUserIds[p8.UserId] then
		return true
	end
	local v9
	if game.PlaceId == v_u_3.DevPlaceId then
		v9 = v_u_3.DevConsoleUserIds[p8.UserId] == true
	else
		v9 = false
	end
	return v9
end
function v_u_3.IsLimited(p10) -- name: IsLimited
	-- upvalues: (copy) v_u_3
	local v11 = p10 ~= nil and not v_u_3.IsAdmin(p10)
	if v11 then
		if v_u_3.LimitedConsoleUserIds[p10.UserId] == true then
			local v12
			if game.PlaceId == v_u_3.DevPlaceId then
				v12 = v_u_3.DevConsoleUserIds[p10.UserId] == true
			else
				v12 = false
			end
			v11 = not v12
		else
			v11 = false
		end
	end
	return v11
end
function v_u_3.IsTagOnly(p13) -- name: IsTagOnly
	-- upvalues: (copy) v_u_3
	local v14 = p13 ~= nil and v_u_3.TagOnlyConsoleUserIds[p13.UserId] == true and not (v_u_3.IsAdmin(p13) or v_u_3.LimitedConsoleUserIds[p13.UserId])
	if v14 then
		local v15
		if game.PlaceId == v_u_3.DevPlaceId then
			v15 = v_u_3.DevConsoleUserIds[p13.UserId] == true
		else
			v15 = false
		end
		v14 = not v15
	end
	return v14
end
function v_u_3.CanGrantTitle(p16, p17) -- name: CanGrantTitle
	-- upvalues: (copy) v_u_3
	return not v_u_3.IsTagOnly(p16) and true or v_u_3.TagOnlyTitles[p17] == true
end
function v_u_3.CanRun(p18, p19) -- name: CanRun
	-- upvalues: (copy) v_u_3
	if v_u_3.IsTagOnly(p18) then
		return v_u_3.TagOnlyCommands[p19] == true
	else
		return not v_u_3.IsLimited(p18) and true or not v_u_3.LimitedBlocked[p19]
	end
end
function v_u_3.IsListedAdmin(p20) -- name: IsListedAdmin
	-- upvalues: (copy) v_u_3
	return v_u_3.UserIds[p20.UserId] == true and true or v_u_3.Usernames[string.lower(p20.Name)] == true
end
function v_u_3.IsAdminUserId(p21) -- name: IsAdminUserId
	-- upvalues: (copy) v_u_3
	return v_u_3.UserIds[p21] == true
end
function v_u_3.CurrentAdmins() -- name: CurrentAdmins
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v22 = {}
	for _, v23 in v_u_1:GetPlayers() do
		if not v_u_3.HasConsole(v23) then
			continue
		end
		table.insert(v22, v23)
	end
	return v22
end
return v_u_3
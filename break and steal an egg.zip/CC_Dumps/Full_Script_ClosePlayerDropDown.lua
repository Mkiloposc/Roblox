return require(script.Parent.Parent.ActionCreator)("ClosePlayerDropDown", function()
	return {}
end)
local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = require(script.Parent.AnimalPlaceVFXController)
local v_u_6 = require(v_u_3.Shared.AnimalPlacementConfig)
local v_u_7 = require(v_u_3.Shared.GamepadConfig)
local v8 = require(script.Parent.OwnBase)
local v_u_9 = require(script.Parent.Parent.Modules.PlaceClickRay)
local v_u_10 = require(v_u_3.Shared.PlotUpgradeConfig)
local v11 = require(v_u_3.Shared.SafeZoneQuery)
local v_u_12 = {}
local v_u_13 = v2.LocalPlayer
local v_u_14 = {}
local v_u_15 = v8.Get
local v_u_16 = v11.IsPositionInPart
local function v_u_26(p17) -- name: canPlaceAt
	-- upvalues: (copy) v_u_15, (copy) v_u_16, (copy) v_u_13, (copy) v_u_6, (copy) v_u_10
	local v18 = v_u_15()
	local v19
	if v18 then
		v19 = v18:FindFirstChild("Hitbox")
	else
		v19 = v18
	end
	if not (v18 and (v19 and v19:IsA("BasePart"))) then
		return false
	end
	if v18:GetAttribute("RestoringPets") then
		return false
	end
	if not v_u_16(v19, p17) then
		return false
	end
	local v20 = v_u_13.Character
	if v20 then
		v20 = v20:FindFirstChild("HumanoidRootPart")
	end
	if not (v20 and v20:IsA("BasePart")) then
		return false
	end
	local v21 = p17 - v20.Position
	local v22 = v21.X
	local v23 = v21.Z
	if Vector3.new(v22, 0, v23).Magnitude > v_u_6.MaxPlaceDistance then
		return false
	end
	local v24 = v18:GetAttribute("AnimalsPlaced") or 0
	local v25 = v18:GetAttribute("PlotLevel") or v_u_10.DefaultLevel
	return v24 < (v18:GetAttribute("MaxAnimals") or v_u_10.Capacity(v25))
end
v_u_12.CanPlaceAt = v_u_26
local function v_u_35(p27) -- name: hideToolLocally
	local v_u_28 = {}
	local v_u_29 = {}
	local v_u_30 = {}
	for _, v31 in p27:GetDescendants() do
		if v31:IsA("BasePart") and v31.Name ~= "Handle" then
			v31.LocalTransparencyModifier = 1
			table.insert(v_u_30, v31)
		elseif v31:IsA("Decal") or v31:IsA("Texture") then
			v31.LocalTransparencyModifier = 1
			table.insert(v_u_28, v31)
		else
			if not (v31:IsA("BillboardGui") and v31.Enabled) then
				continue
			end
			v31.Enabled = false
			table.insert(v_u_29, v31)
		end
	end
	return function()
		-- upvalues: (copy) v_u_30, (copy) v_u_28, (copy) v_u_29
		for _, v32 in v_u_30 do
			v32.LocalTransparencyModifier = 0
		end
		for _, v33 in v_u_28 do
			v33.LocalTransparencyModifier = 0
		end
		for _, v34 in v_u_29 do
			v34.Enabled = true
		end
	end
end
local v_u_36 = {}
local v_u_37 = 0
local v_u_38 = {}
function v_u_12.PlaceAt(p_u_39, p40) -- name: PlaceAt
	-- upvalues: (copy) v_u_36, (copy) v_u_3, (ref) v_u_37, (copy) v_u_26, (copy) v_u_35, (copy) v_u_38, (copy) v_u_5
	if v_u_36[p_u_39] then
		return false
	end
	local v41 = v_u_3:FindFirstChild("PlaceAnimalRemote")
	if not (v41 and v41:IsA("RemoteEvent")) then
		return false
	end
	v_u_37 = v_u_37 + 1
	local v_u_42 = v_u_37
	v41:FireServer(p_u_39, p40, v_u_42)
	if not v_u_26(p40) then
		return true
	end
	v_u_36[p_u_39] = v_u_35(p_u_39)
	v_u_38[p_u_39] = v_u_42
	v_u_5.PredictPlacement(p40)
	task.delay(2, function()
		-- upvalues: (ref) v_u_38, (copy) p_u_39, (copy) v_u_42, (ref) v_u_36
		if v_u_38[p_u_39] == v_u_42 then
			local v43 = v_u_36[p_u_39]
			v_u_36[p_u_39] = nil
			v_u_38[p_u_39] = nil
			if v43 and p_u_39.Parent ~= nil then
				v43()
			end
		end
	end)
	return true
end
local function v_u_48(p44, p45) -- name: onPlaceRejected
	-- upvalues: (copy) v_u_38, (copy) v_u_36, (copy) v_u_5, (copy) v_u_13
	if typeof(p44) == "Instance" and p44:IsA("Tool") then
		if p45 == v_u_38[p44] then
			local v46 = v_u_36[p44]
			if v46 then
				v_u_36[p44] = nil
				v_u_38[p44] = nil
				v_u_5.CancelPrediction()
				if p44.Parent ~= nil then
					v46()
					local v47 = v_u_13.Character
					if p44.Parent ~= v47 then
						if v47 then
							v47 = v47:FindFirstChildOfClass("Humanoid")
						end
						if v47 and (v47.Health > 0 and p44.Parent == v_u_13:FindFirstChild("Backpack")) then
							v47:EquipTool(p44)
						end
					end
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end
function v_u_12.GetHeldTool() -- name: GetHeldTool
	-- upvalues: (copy) v_u_13, (copy) v_u_1
	local v49 = v_u_13.Character
	if not v49 then
		return nil
	end
	for _, v50 in v49:GetChildren() do
		if not (v50:IsA("Tool") and v_u_1:HasTag(v50, "AnimalTool")) then
			continue
		end
		return v50
	end
	return nil
end
local function v_u_53(p_u_51) -- name: hookTool
	-- upvalues: (copy) v_u_14, (copy) v_u_7, (copy) v_u_4, (copy) v_u_9, (copy) v_u_12, (copy) v_u_36, (copy) v_u_38
	if p_u_51:IsA("Tool") and not v_u_14[p_u_51] then
		v_u_14[p_u_51] = true
		p_u_51.Activated:Connect(function()
			-- upvalues: (ref) v_u_7, (ref) v_u_4, (ref) v_u_9, (ref) v_u_12, (copy) p_u_51
			if v_u_7.IsGamepadInput(v_u_4:GetLastInputType()) then
				return
			else
				local v52 = v_u_9.Get()
				if v52 then
					v_u_12.PlaceAt(p_u_51, v52)
				end
			end
		end)
		p_u_51.Destroying:Connect(function()
			-- upvalues: (ref) v_u_14, (copy) p_u_51, (ref) v_u_36, (ref) v_u_38
			v_u_14[p_u_51] = nil
			v_u_36[p_u_51] = nil
			v_u_38[p_u_51] = nil
		end)
	end
end
function v_u_12.Start() -- name: Start
	-- upvalues: (copy) v_u_1, (copy) v_u_53, (copy) v_u_3, (copy) v_u_48
	for _, v54 in v_u_1:GetTagged("AnimalTool") do
		v_u_53(v54)
	end
	v_u_1:GetInstanceAddedSignal("AnimalTool"):Connect(v_u_53)
	task.spawn(function()
		-- upvalues: (ref) v_u_3, (ref) v_u_48
		local v55 = v_u_3:WaitForChild("PlaceAnimalRemote", 30)
		if v55 and v55:IsA("RemoteEvent") then
			v55.OnClientEvent:Connect(v_u_48)
		end
	end)
end
return v_u_12
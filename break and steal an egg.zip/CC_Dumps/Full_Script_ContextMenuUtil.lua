local v1 = game:GetService("CoreGui")
local v_u_2 = game:GetService("Players")
local v_u_3 = game:GetService("ContextActionService")
local v_u_4 = game:GetService("GuiService")
local v_u_5 = game:GetService("UserInputService")
local v_u_6 = game:GetService("RobloxReplicatedStorage")
local v7 = game:GetService("CorePackages")
local v_u_8 = require(v7.Workspace.Packages.AppCommonLib).isTenFootInterface
local v9 = v1:WaitForChild("RobloxGui"):WaitForChild("Modules"):WaitForChild("AvatarContextMenu")
require(v9.ThemeHandler)
local v_u_10 = require(v7.Workspace.Packages.BlockingUtility)
local v_u_11 = v_u_2.LocalPlayer
while not v_u_11 do
	v_u_2.PlayerAdded:Wait()
	v_u_11 = v_u_2.LocalPlayer
end
local v_u_12 = {}
v_u_12.__index = v_u_12
function v_u_12.GetHeadshotForPlayer(_, p13) -- name: GetHeadshotForPlayer
	return "rbxthumb://type=AvatarHeadShot&id=" .. p13.UserId .. "&w=150&h=150"
end
function v_u_12.HasOrGettingHeadShot(p14, p15) -- name: HasOrGettingHeadShot
	return p14.HeadShotUrlCache[p15] ~= nil
end
function v_u_12.FindPlayerFromPart(_, p16) -- name: FindPlayerFromPart
	-- upvalues: (copy) v_u_2
	if p16 and p16.Parent then
		while p16 and not p16:IsA("Model") do
			p16 = p16.Parent
		end
		if p16 then
			return v_u_2:GetPlayerFromCharacter(p16)
		end
	end
	return nil
end
function v_u_12.GetPlayerPosition(_, p17) -- name: GetPlayerPosition
	local v18 = p17.Character and p17.Character:FindFirstChild("HumanoidRootPart")
	if v18 then
		return v18.Position
	else
		return nil
	end
end
local v_u_19 = true
function v_u_12.DisablePlayerMovement(_) -- name: DisablePlayerMovement
	-- upvalues: (ref) v_u_19, (copy) v_u_3
	if v_u_19 then
		v_u_19 = false
		v_u_3:BindCoreActionAtPriority("AvatarContextMenuStopInput", function(_, p20)
			if p20 == Enum.UserInputState.End then
				return Enum.ContextActionResult.Pass
			else
				return Enum.ContextActionResult.Sink
			end
		end, false, Enum.ContextActionPriority.Low.Value, Enum.PlayerActions.CharacterForward, Enum.PlayerActions.CharacterBackward, Enum.PlayerActions.CharacterLeft, Enum.PlayerActions.CharacterRight, Enum.PlayerActions.CharacterJump, Enum.UserInputType.Gamepad1, Enum.UserInputType.Gamepad2, Enum.UserInputType.Gamepad3, Enum.UserInputType.Gamepad4)
	end
end
function v_u_12.EnablePlayerMovement(_) -- name: EnablePlayerMovement
	-- upvalues: (ref) v_u_19, (copy) v_u_3
	if not v_u_19 then
		v_u_19 = true
		v_u_3:UnbindCoreAction("AvatarContextMenuStopInput")
	end
end
function v_u_12.GetFriendStatus(_, p_u_21) -- name: GetFriendStatus
	-- upvalues: (ref) v_u_11
	local v22, v23 = pcall(function()
		-- upvalues: (ref) v_u_11, (copy) p_u_21
		return v_u_11:GetFriendStatus(p_u_21)
	end)
	if v22 then
		return v23
	else
		return Enum.FriendStatus.NotFriend
	end
end
local v_u_24 = {}
coroutine.wrap(function()
	-- upvalues: (copy) v_u_6, (copy) v_u_24
	v_u_6:WaitForChild("CanChatWith", (1 / 0)).OnClientEvent:Connect(function(...)
		-- upvalues: (ref) v_u_24
		local v25 = { ... }
		if #v25 == 1 then
			local v26 = v25[1]
			for v27, v28 in pairs(v26) do
				v_u_24[v27] = v28
			end
		elseif #v25 == 2 then
			v_u_24[v25[1]] = v25[2]
		end
	end)
end)()
function v_u_12.GetCanChatWith(_, p29) -- name: GetCanChatWith
	-- upvalues: (copy) v_u_10, (copy) v_u_24
	if v_u_10:IsPlayerBlockedByUserId(p29.UserId) then
		return false
	else
		return v_u_24[p29.UserId] == nil and true or v_u_24[p29.UserId]
	end
end
local v_u_30 = Instance.new("ImageLabel")
v_u_30.Image = ""
v_u_30.BackgroundTransparency = 1
local function v_u_40(p31, p32, p_u_33, p_u_34) -- name: MakeDefaultButton
	-- upvalues: (copy) v_u_30, (copy) v_u_5, (copy) v_u_4
	local v_u_35 = Instance.new("ImageButton")
	v_u_35.Name = p31
	v_u_35.Image = p_u_34.ButtonImage
	v_u_35.ScaleType = p_u_34.ButtonImageScaleType
	v_u_35.SliceCenter = p_u_34.ButtonImageSliceCenter
	v_u_35.BackgroundColor3 = p_u_34.ButtonColor
	v_u_35.BackgroundTransparency = p_u_34.ButtonTransparency
	v_u_35.AutoButtonColor = false
	v_u_35.Size = p32
	v_u_35.ZIndex = 2
	v_u_35.SelectionImageObject = v_u_30
	v_u_35.BorderSizePixel = 0
	local v36 = Instance.new("Frame")
	v36.Name = "Underline"
	v36.BackgroundColor3 = p_u_34.ButtonUnderlineColor
	v36.AnchorPoint = Vector2.new(0.5, 1)
	v36.BorderSizePixel = 0
	v36.Position = UDim2.new(0.5, 0, 1, 0)
	v36.Size = UDim2.new(0.95, 0, 0, 1)
	v36.Parent = v_u_35
	if p_u_33 then
		v_u_35.MouseButton1Click:Connect(function()
			-- upvalues: (copy) p_u_33, (ref) v_u_5
			p_u_33(v_u_5:GetLastInputType())
		end)
	end
	v_u_35.InputBegan:Connect(function(p_u_37)
		-- upvalues: (copy) v_u_35, (copy) p_u_34
		if v_u_35.Selectable and (p_u_37.UserInputType == Enum.UserInputType.MouseMovement or p_u_37.UserInputType == Enum.UserInputType.Touch) then
			v_u_35.BackgroundColor3 = p_u_34.ButtonHoverColor
			v_u_35.BackgroundTransparency = p_u_34.ButtonHoverTransparency
			p_u_37:GetPropertyChangedSignal("UserInputState"):connect(function()
				-- upvalues: (copy) p_u_37, (ref) v_u_35, (ref) p_u_34
				if p_u_37.UserInputState == Enum.UserInputState.End then
					v_u_35.BackgroundColor3 = p_u_34.ButtonColor
					v_u_35.BackgroundTransparency = p_u_34.ButtonTransparency
				end
			end)
		end
	end)
	v_u_35.InputEnded:Connect(function(p38)
		-- upvalues: (copy) v_u_35, (ref) v_u_4, (copy) p_u_34
		if v_u_35.Selectable and v_u_4.SelectedCoreObject ~= v_u_35 and (p38.UserInputType == Enum.UserInputType.MouseMovement or p38.UserInputType == Enum.UserInputType.Touch) then
			v_u_35.BackgroundColor3 = p_u_34.ButtonColor
			v_u_35.BackgroundTransparency = p_u_34.ButtonTransparency
		end
	end)
	v_u_35.SelectionGained:Connect(function()
		-- upvalues: (copy) v_u_35, (copy) p_u_34
		v_u_35.BackgroundColor3 = p_u_34.ButtonHoverColor
		v_u_35.BackgroundTransparency = p_u_34.ButtonHoverTransparency
	end)
	v_u_35.SelectionLost:Connect(function()
		-- upvalues: (copy) v_u_35, (copy) p_u_34
		v_u_35.BackgroundColor3 = p_u_34.ButtonColor
		v_u_35.BackgroundTransparency = p_u_34.ButtonTransparency
	end)
	v_u_4.Changed:Connect(function(p39)
		-- upvalues: (ref) v_u_4, (copy) v_u_35, (copy) p_u_34
		if p39 == "SelectedCoreObject" then
			if v_u_4.SelectedCoreObject == nil or v_u_4.SelectedCoreObject ~= v_u_35 then
				v_u_35.BackgroundColor3 = p_u_34.ButtonColor
				v_u_35.BackgroundTransparency = p_u_34.ButtonTransparency
			elseif v_u_35.Selectable then
				v_u_35.BackgroundColor3 = p_u_34.ButtonHoverColor
				v_u_35.BackgroundTransparency = p_u_34.ButtonHoverTransparency
			end
		else
			return
		end
	end)
	return v_u_35
end
local function v_u_42() -- name: getViewportSize
	while not workspace.CurrentCamera do
		workspace.Changed:Wait()
	end
	local v41 = workspace.CurrentCamera
	assert(v41, "")
	while workspace.CurrentCamera.ViewportSize == Vector2.new(0, 0) or workspace.CurrentCamera.ViewportSize == Vector2.new(1, 1) do
		workspace.CurrentCamera.Changed:Wait()
	end
	return workspace.CurrentCamera.ViewportSize
end
function v_u_12.MakeStyledButton(_, p43, p44, p45, p46, p47) -- name: MakeStyledButton
	-- upvalues: (copy) v_u_40, (copy) v_u_42, (copy) v_u_5, (copy) v_u_8
	local v48 = v_u_40(p43, p45, p46, p47)
	local v49 = Instance.new("TextLabel")
	v49.Name = p43 .. "TextLabel"
	v49.BackgroundTransparency = 1
	v49.BorderSizePixel = 0
	v49.Size = UDim2.new(1, 0, 1, -8)
	v49.Position = UDim2.new(0, 0, 0, 0)
	v49.TextColor3 = Color3.fromRGB(255, 255, 255)
	v49.TextYAlignment = Enum.TextYAlignment.Center
	v49.Font = p47.Font
	v49.TextSize = 24 * p47.TextScale
	local v50 = v_u_42()
	local v51 = v_u_5.TouchEnabled
	if v51 then
		v51 = v50.Y < 500 and true or v50.X < 700
	end
	if v51 then
		v49.TextSize = 18 * p47.TextScale
	elseif v_u_8() then
		v49.TextSize = 36 * p47.TextScale
	end
	v49.Text = p44
	v49.TextScaled = true
	v49.TextWrapped = true
	v49.ZIndex = 2
	v49.Parent = v48
	Instance.new("UITextSizeConstraint", v49).MaxTextSize = v49.TextSize
	return v48, v49
end
function v_u_12.new() -- name: new
	-- upvalues: (copy) v_u_12
	local v52 = v_u_12
	return setmetatable({}, v52)
end
return v_u_12.new()
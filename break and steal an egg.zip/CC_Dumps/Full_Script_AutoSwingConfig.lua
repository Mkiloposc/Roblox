return {
	["ButtonName"] = "AutoSwing",
	["ShowOnlyWhileEquipped"] = true,
	["StateGradientsFolder"] = "AutoSwingState",
	["TweenDuration"] = 0.22,
	["TweenEasingStyle"] = nil,
	["TweenEasingDirection"] = nil,
	["DefaultOn"] = false,
	["TickInterval"] = 0.1,
	["ToggleDebounce"] = 0.2,
	["RangeMargin"] = 2,
	["StickyRangeMargin"] = 0.5,
	["EquipPickaxeOnEnable"] = true,
	["BatInHell"] = true,
	["TweenEasingStyle"] = Enum.EasingStyle.Quad,
	["TweenEasingDirection"] = Enum.EasingDirection.Out
}
local v_u_1 = require(script.Parent.EggRewards)
local v_u_2 = require(script.Parent.ZonesConfig)
local v_u_3 = {}
local v_u_4 = {
	["Basic Egg"] = "Forest Egg"
}
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = {
	"Cosmic",
	"Secret",
	"Celestial",
	"Inferno",
	"Void",
	"Omega",
	"Spectral",
	"Ethereal"
}
function v_u_3.Ladder() -- name: Ladder
	-- upvalues: (ref) v_u_5, (copy) v_u_2, (copy) v_u_7
	if not v_u_5 then
		local v8 = {}
		for _, v9 in v_u_2.Zones do
			if not v9.Rarity then
				continue
			end
			local v10 = v9.Rarity
			table.insert(v8, v10)
		end
		for _, v11 in v_u_7 do
			if table.find(v8, v11) then
				continue
			end
			table.insert(v8, v11)
		end
		v_u_5 = v8
	end
	return v_u_5
end
function v_u_3.IndexOf(p12) -- name: IndexOf
	-- upvalues: (copy) v_u_3
	if p12 then
		return table.find(v_u_3.Ladder(), p12)
	else
		return nil
	end
end
local function v_u_26() -- name: buildEggRarities
	-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_4, (ref) v_u_6
	local v13 = {}
	local v14 = {}
	for _, v15 in v_u_1.Pool do
		local v16 = v15.Zone
		if not (v16 and v15.Rarity) then
			continue
		end
		local v17 = v_u_3.IndexOf(v15.Rarity)
		if v17 then
			if v13[v16] ~= nil and v17 >= v13[v16] then
				continue
			end
			v13[v16] = v17
			v14[v16] = v15.Rarity
		else
			warn((("[EggRarity] Zone%* pet \"%*\" has unknown rarity \"%*\""):format(v16, v15.Name, v15.Rarity)))
		end
	end
	local v18 = {}
	for v19, v20 in v_u_1.ZoneEggs do
		local v21 = string.match
		local v22 = tonumber(v21(v19, "%d+"))
		if v22 then
			v22 = v14[v_u_1.RosterZoneOf(v22)]
		end
		if not v22 then
			continue
		end
		for _, v23 in v20.Eggs do
			v18[v23] = v22
		end
	end
	for v24, v25 in v_u_4 do
		if v18[v24] ~= nil then
			continue
		end
		v18[v24] = v18[v25]
	end
	v_u_6 = v18
end
function v_u_3.ForEggType(p27) -- name: ForEggType
	-- upvalues: (ref) v_u_6, (copy) v_u_26
	if not p27 then
		return nil
	end
	if not v_u_6 then
		v_u_26()
	end
	return v_u_6[p27]
end
function v_u_3.Resolve(p28, p29) -- name: Resolve
	-- upvalues: (copy) v_u_3
	return v_u_3.ForEggType(p28) or p29 and p29.Rarity or "Common"
end
function v_u_3.PoolEggType(p30) -- name: PoolEggType
	-- upvalues: (copy) v_u_4
	if p30 then
		return v_u_4[p30] or p30
	else
		return nil
	end
end
local v_u_31 = nil
function v_u_3.LadderSpot(p32) -- name: LadderSpot
	-- upvalues: (copy) v_u_3, (ref) v_u_31, (copy) v_u_1
	local v33 = v_u_3.PoolEggType(p32)
	if v33 then
		if not v_u_31 then
			local v34 = {}
			for v35, v36 in v_u_1.ZoneEggs do
				local v37 = string.match
				local v38 = tonumber(v37(v35, "%d+"))
				if not v38 then
					continue
				end
				for v39, v40 in v36.Eggs do
					v34[v40] = {
						["Zone"] = v38,
						["Tier"] = v39
					}
				end
			end
			v_u_31 = v34
		end
		local v41 = v_u_31[v33]
		if v41 then
			return v41.Zone, v41.Tier
		else
			return nil, nil
		end
	else
		return nil, nil
	end
end
function v_u_3.IsFirstZoneEgg(p42) -- name: IsFirstZoneEgg
	-- upvalues: (copy) v_u_3
	return v_u_3.LadderSpot(p42) == 1
end
function v_u_3.IsStrongerEgg(p43, p44) -- name: IsStrongerEgg
	-- upvalues: (copy) v_u_3
	local v45, v46 = v_u_3.LadderSpot(p43)
	if not (v45 and v46) then
		return false
	end
	local v47
	if v45 == 1 then
		v47 = p44 <= v46
	else
		v47 = false
	end
	return v47
end
function v_u_3.IsPlainStarterEgg(p48, p49) -- name: IsPlainStarterEgg
	-- upvalues: (copy) v_u_3
	if p48:GetAttribute("Lucky") or (p48:GetAttribute("Titanic") or p48:GetAttribute("Variant")) then
		return false
	end
	local v50 = p48:GetAttribute("EggType")
	local v51 = v_u_3.IsFirstZoneEgg(v50)
	if v51 then
		v51 = not v_u_3.IsStrongerEgg(v50, p49)
	end
	return v51
end
return v_u_3
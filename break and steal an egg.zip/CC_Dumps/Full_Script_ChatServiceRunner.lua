local v1 = game:GetService("ReplicatedStorage")
local v2 = script
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("Chat")
local v_u_6 = require(v2:WaitForChild("ChatService"))
local v7 = v_u_5:WaitForChild("ClientChatModules")
local v8 = require(v7:WaitForChild("ChatSettings"))
local v_u_9 = nil
pcall(function()
	-- upvalues: (ref) v_u_9, (copy) v_u_5
	v_u_9 = require(v_u_5.ClientChatModules.ChatLocalization)
end)
v_u_9 = v_u_9 or {}
local v_u_10 = v8.MaxChannelNameCheckLength or 50
local v_u_11 = v8.MaximumMessageLength
if not (v_u_9.FormatMessageToSend and v_u_9.LocalizeFormattedMessage) then
	function v_u_9.FormatMessageToSend(_, _, p12) -- name: FormatMessageToSend
		return p12
	end
end
local v13 = {}
local v14 = v1:FindFirstChild("DefaultChatSystemChatEvents")
if not v14 then
	v14 = Instance.new("Folder")
	v14.Name = "DefaultChatSystemChatEvents"
	v14.Archivable = false
	v14.Parent = v1
end
local function v_u_16(p15) -- name: validateMessageLength
	-- upvalues: (copy) v_u_11
	if p15:len() > v_u_11 * 6 then
		return false
	elseif utf8.len(p15) == nil then
		return false
	else
		return v_u_11 >= utf8.len(utf8.nfcnormalize(p15))
	end
end
local function v_u_18(p17) -- name: validateChannelNameLength
	-- upvalues: (copy) v_u_10
	if p17:len() > v_u_10 * 6 then
		return false
	elseif utf8.len(p17) == nil then
		return false
	else
		return v_u_10 >= utf8.len(utf8.nfcnormalize(p17))
	end
end
local function v19() -- name: emptyFunction end
local function v24(p20, p21, p22) -- name: GetObjectWithNameAndType
	for _, v23 in pairs(p20:GetChildren()) do
		if not v23:IsA(p22) or v23.Name ~= p21 then
			continue
		end
		return v23
	end
	return nil
end
local v25 = v24(v14, "OnNewMessage", "RemoteEvent")
if not v25 then
	v25 = Instance.new("RemoteEvent")
	v25.Name = "OnNewMessage"
	v25.Parent = v14
end
v13.OnNewMessage = v25
v25.OnServerEvent:Connect(v19)
local v26 = v24(v14, "OnMessageDoneFiltering", "RemoteEvent")
if not v26 then
	v26 = Instance.new("RemoteEvent")
	v26.Name = "OnMessageDoneFiltering"
	v26.Parent = v14
end
v13.OnMessageDoneFiltering = v26
v26.OnServerEvent:Connect(v19)
local v27 = v24(v14, "OnNewSystemMessage", "RemoteEvent")
if not v27 then
	v27 = Instance.new("RemoteEvent")
	v27.Name = "OnNewSystemMessage"
	v27.Parent = v14
end
v13.OnNewSystemMessage = v27
v27.OnServerEvent:Connect(v19)
local v28 = v24(v14, "OnChannelJoined", "RemoteEvent")
if not v28 then
	v28 = Instance.new("RemoteEvent")
	v28.Name = "OnChannelJoined"
	v28.Parent = v14
end
v13.OnChannelJoined = v28
v28.OnServerEvent:Connect(v19)
local v29 = v24(v14, "OnChannelLeft", "RemoteEvent")
if not v29 then
	v29 = Instance.new("RemoteEvent")
	v29.Name = "OnChannelLeft"
	v29.Parent = v14
end
v13.OnChannelLeft = v29
v29.OnServerEvent:Connect(v19)
local v30 = v24(v14, "OnMuted", "RemoteEvent")
if not v30 then
	v30 = Instance.new("RemoteEvent")
	v30.Name = "OnMuted"
	v30.Parent = v14
end
v13.OnMuted = v30
v30.OnServerEvent:Connect(v19)
local v31 = v24(v14, "OnUnmuted", "RemoteEvent")
if not v31 then
	v31 = Instance.new("RemoteEvent")
	v31.Name = "OnUnmuted"
	v31.Parent = v14
end
v13.OnUnmuted = v31
v31.OnServerEvent:Connect(v19)
local v32 = v24(v14, "OnMainChannelSet", "RemoteEvent")
if not v32 then
	v32 = Instance.new("RemoteEvent")
	v32.Name = "OnMainChannelSet"
	v32.Parent = v14
end
v13.OnMainChannelSet = v32
v32.OnServerEvent:Connect(v19)
local v33 = v24(v14, "ChannelNameColorUpdated", "RemoteEvent")
if not v33 then
	v33 = Instance.new("RemoteEvent")
	v33.Name = "ChannelNameColorUpdated"
	v33.Parent = v14
end
v13.ChannelNameColorUpdated = v33
v33.OnServerEvent:Connect(v19)
local v34 = v24(v14, "SayMessageRequest", "RemoteEvent")
if not v34 then
	v34 = Instance.new("RemoteEvent")
	v34.Name = "SayMessageRequest"
	v34.Parent = v14
end
v13.SayMessageRequest = v34
v34.OnServerEvent:Connect(v19)
local v35 = v24(v14, "SetBlockedUserIdsRequest", "RemoteEvent")
if not v35 then
	v35 = Instance.new("RemoteEvent")
	v35.Name = "SetBlockedUserIdsRequest"
	v35.Parent = v14
end
v13.SetBlockedUserIdsRequest = v35
v35.OnServerEvent:Connect(v19)
local v36 = v24(v14, "GetInitDataRequest", "RemoteFunction")
if not v36 then
	v36 = Instance.new("RemoteFunction")
	v36.Name = "GetInitDataRequest"
	v36.Parent = v14
end
v13.GetInitDataRequest = v36
local v37 = v24(v14, "MutePlayerRequest", "RemoteFunction")
if not v37 then
	v37 = Instance.new("RemoteFunction")
	v37.Name = "MutePlayerRequest"
	v37.Parent = v14
end
v13.MutePlayerRequest = v37
local v38 = v24(v14, "UnMutePlayerRequest", "RemoteFunction")
if not v38 then
	v38 = Instance.new("RemoteFunction")
	v38.Name = "UnMutePlayerRequest"
	v38.Parent = v14
end
v13.UnMutePlayerRequest = v38
local v_u_39 = v13
local function v_u_52(p_u_40) -- name: CreatePlayerSpeakerObject
	-- upvalues: (copy) v_u_6, (ref) v_u_39
	if v_u_6:GetSpeaker(p_u_40.Name) then
		v_u_6:RemoveSpeaker(p_u_40.Name)
	end
	local v_u_41 = v_u_6:InternalAddSpeakerWithPlayerObject(p_u_40.Name, p_u_40, false)
	for _, v42 in pairs(v_u_6:GetAutoJoinChannelList()) do
		v_u_41:JoinChannel(v42.Name)
	end
	v_u_41:InternalAssignEventFolder(v_u_39)
	v_u_41.ChannelJoined:connect(function(p43, p44)
		-- upvalues: (ref) v_u_6, (ref) v_u_41, (ref) v_u_39, (copy) p_u_40
		local v45 = v_u_6:GetChannel(p43)
		local v46, v47
		if v45 then
			v46 = v45:GetHistoryLogForSpeaker(v_u_41)
			v47 = v45.ChannelNameColor
		else
			v46 = nil
			v47 = nil
		end
		v_u_39.OnChannelJoined:FireClient(p_u_40, p43, p44, v46, v47)
	end)
	v_u_41.Muted:connect(function(p48, p49, p50)
		-- upvalues: (ref) v_u_39, (copy) p_u_40
		v_u_39.OnMuted:FireClient(p_u_40, p48, p49, p50)
	end)
	v_u_41.Unmuted:connect(function(p51)
		-- upvalues: (ref) v_u_39, (copy) p_u_40
		v_u_39.OnUnmuted:FireClient(p_u_40, p51)
	end)
	v_u_6:InternalFireSpeakerAdded(v_u_41.Name)
end
v_u_39.SayMessageRequest.OnServerEvent:connect(function(p53, p54, p55)
	-- upvalues: (copy) v_u_16, (copy) v_u_18, (copy) v_u_6
	if type(p54) == "string" then
		if v_u_16(p54) then
			if type(p55) == "string" then
				if v_u_18(p55) then
					local v56 = v_u_6:GetSpeaker(p53.Name)
					if v56 then
						return v56:SayMessage(p54, p55)
					else
						return nil
					end
				else
					return
				end
			else
				return
			end
		else
			return
		end
	else
		return
	end
end)
function v_u_39.MutePlayerRequest.OnServerInvoke(p57, p58)
	-- upvalues: (copy) v_u_6
	if type(p58) == "string" then
		local v59 = v_u_6:GetSpeaker(p57.Name)
		local v60 = v59 and v_u_6:GetSpeaker(p58)
		if not v60 then
			return false
		end
		v59:AddMutedSpeaker(v60.Name)
		return true
	end
end
function v_u_39.UnMutePlayerRequest.OnServerInvoke(p61, p62)
	-- upvalues: (copy) v_u_6
	if type(p62) == "string" then
		local v63 = v_u_6:GetSpeaker(p61.Name)
		local v64 = v63 and v_u_6:GetSpeaker(p62)
		if not v64 then
			return false
		end
		v63:RemoveMutedSpeaker(v64.Name)
		return true
	end
end
local v_u_65 = {}
v_u_3.PlayerAdded:connect(function(p66)
	-- upvalues: (copy) v_u_65, (copy) v_u_6
	for v67, v68 in pairs(v_u_65) do
		local v69 = v_u_6:GetSpeaker(v67.Name)
		if not v69 then
			continue
		end
		for v70 = 1, #v68 do
			if v68[v70] ~= p66.UserId then
				continue
			end
			v69:AddMutedSpeaker(p66.Name)
		end
	end
end)
v_u_3.PlayerRemoving:connect(function(p71)
	-- upvalues: (copy) v_u_65
	v_u_65[p71] = nil
end)
v_u_39.SetBlockedUserIdsRequest.OnServerEvent:Connect(function(p72, p73)
	-- upvalues: (copy) v_u_6, (copy) v_u_3, (copy) v_u_65
	if type(p73) == "table" then
		local v74 = {}
		local v75 = v_u_6:GetSpeaker(p72.Name)
		if v75 then
			local v76 = #p73
			for v77 = 1, math.min(v76, 50) do
				local v78 = p73[v77]
				if type(v78) ~= "number" then
					continue
				end
				local v79 = p73[v77]
				table.insert(v74, v79)
				local v80 = v_u_3:GetPlayerByUserId(p73[v77])
				if not v80 then
					continue
				end
				v75:AddMutedSpeaker(v80.Name)
			end
			v_u_65[p72] = v74
		end
	end
end)
function v_u_39.GetInitDataRequest.OnServerInvoke(p81)
	-- upvalues: (copy) v_u_6, (copy) v_u_52
	local v82 = v_u_6:GetSpeaker(p81.Name)
	if not (v82 and v82:GetPlayer()) then
		v_u_52(p81)
		v82 = v_u_6:GetSpeaker(p81.Name)
	end
	local v83 = {
		["Channels"] = {},
		["SpeakerExtraData"] = {}
	}
	for _, v84 in pairs(v82:GetChannelList()) do
		local v85 = v_u_6:GetChannel(v84)
		if not v85 then
			continue
		end
		local v86 = {
			v84,
			v85:GetWelcomeMessageForSpeaker(v82),
			v85:GetHistoryLogForSpeaker(v82),
			v85.ChannelNameColor
		}
		local v87 = v83.Channels
		table.insert(v87, v86)
	end
	for _, v88 in pairs(v_u_6:GetSpeakerList()) do
		local v89 = v_u_6:GetSpeaker(v88)
		v83.SpeakerExtraData[v88] = v89.ExtraData
	end
	return v83
end
local function v_u_95(p90, p91, p92) -- name: DoJoinCommand
	-- upvalues: (copy) v_u_6, (ref) v_u_9
	local v93 = v_u_6:GetSpeaker(p90)
	local v94 = v_u_6:GetChannel(p91)
	if v93 then
		if v94 then
			if v94.Joinable then
				if v93:IsInChannel(v94.Name) then
					v93:SetMainChannel(v94.Name)
					v93:SendSystemMessage(v_u_9:FormatMessageToSend("GameChat_SwitchChannel_NowInChannel", string.format("You are now chatting in channel: \'%s\'", v94.Name), "RBX_NAME", v94.Name), v94.Name)
				else
					v93:JoinChannel(v94.Name)
				end
			else
				v93:SendSystemMessage(v_u_9:FormatMessageToSend("GameChat_ChatServiceRunner_YouCannotJoinChannel", "You cannot join channel \'" .. p91 .. "\'.", "RBX_NAME", p91), p92)
				return
			end
		end
		v93:SendSystemMessage(v_u_9:FormatMessageToSend("GameChat_ChatServiceRunner_ChannelDoesNotExist", "Channel \'" .. p91 .. "\' does not exist.", "RBX_NAME", p91), p92)
	end
end
local function v_u_101(p96, p97, p98) -- name: DoLeaveCommand
	-- upvalues: (copy) v_u_6, (ref) v_u_9
	local v99 = v_u_6:GetSpeaker(p96)
	local v100 = v_u_6:GetChannel(p97)
	if v99 then
		if v99:IsInChannel(p97) then
			if v100.Leavable then
				v99:LeaveChannel(v100.Name)
				v99:SendSystemMessage(v_u_9:FormatMessageToSend("GameChat_ChatService_YouHaveLeftChannel", string.format("You have left channel \'%s\'", p97), "RBX_NAME", v100.Name), "System")
			else
				v99:SendSystemMessage(v_u_9:FormatMessageToSend("GameChat_ChatServiceRunner_YouCannotLeaveChannel", "You cannot leave channel \'" .. p97 .. "\'.", "RBX_NAME", p97), p98)
			end
		end
		v99:SendSystemMessage(v_u_9:FormatMessageToSend("GameChat_ChatServiceRunner_YouAreNotInChannel", "You are not in channel \'" .. p97 .. "\'.", "RBX_NAME", p97), p98)
	end
end
v_u_6:RegisterProcessCommandsFunction("default_commands", function(p102, p103, p104)
	-- upvalues: (copy) v_u_95, (copy) v_u_101
	if string.sub(p103, 1, 6):lower() == "/join " then
		v_u_95(p102, string.sub(p103, 7), p104)
		return true
	end
	if string.sub(p103, 1, 3):lower() == "/j " then
		v_u_95(p102, string.sub(p103, 4), p104)
		return true
	end
	if string.sub(p103, 1, 7):lower() == "/leave " then
		v_u_101(p102, string.sub(p103, 8), p104)
		return true
	end
	if string.sub(p103, 1, 3):lower() ~= "/l " then
		return false
	end
	v_u_101(p102, string.sub(p103, 4), p104)
	return true
end)
if v8.GeneralChannelName and v8.GeneralChannelName ~= "" then
	local v105 = v_u_6:AddChannel(v8.GeneralChannelName)
	v105.Leavable = false
	v105.AutoJoin = true
	v105:RegisterGetWelcomeMessageFunction(function(p106)
		-- upvalues: (copy) v_u_4, (copy) v_u_5
		if v_u_4:IsStudio() then
			return nil
		end
		local v_u_107 = p106:GetPlayer()
		if v_u_107 then
			local v108, v109 = pcall(function()
				-- upvalues: (ref) v_u_5, (copy) v_u_107
				return v_u_5:CanUserChatAsync(v_u_107.UserId)
			end)
			if v108 and not v109 then
				return ""
			end
		end
	end)
end
local v_u_110 = v_u_6:AddChannel("System")
v_u_110.Leavable = false
v_u_110.AutoJoin = true
v_u_110.WelcomeMessage = v_u_9:FormatMessageToSend("GameChat_ChatServiceRunner_SystemChannelWelcomeMessage", "This channel is for system and game notifications.")
v_u_110.SpeakerJoined:connect(function(p111)
	-- upvalues: (copy) v_u_110
	v_u_110:MuteSpeaker(p111)
end)
local function v_u_114(p112) -- name: TryRunModule
	-- upvalues: (copy) v_u_6
	if p112:IsA("ModuleScript") then
		local v113 = require(p112)
		if type(v113) == "function" then
			v113(v_u_6)
		end
	end
end
local v115 = v_u_5:WaitForChild("ChatModules")
v115.ChildAdded:connect(function(p116)
	-- upvalues: (copy) v_u_114
	local v117, v118 = pcall(v_u_114, p116)
	if not v117 and v118 then
		print("Error running module " .. p116.Name .. ": " .. v118)
	end
end)
for _, v119 in pairs(v115:GetChildren()) do
	local v120, v121 = pcall(v_u_114, v119)
	if v120 or not v121 then
		continue
	end
	print("Error running module " .. v119.Name .. ": " .. v121)
end
v_u_3.PlayerRemoving:connect(function(p122)
	-- upvalues: (copy) v_u_6
	if v_u_6:GetSpeaker(p122.Name) then
		v_u_6:RemoveSpeaker(p122.Name)
	end
end)
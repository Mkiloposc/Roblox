local v_u_1 = {
	["Visible"] = nil,
	["IsCoreGuiEnabled"] = nil,
	["TopbarEnabled"] = nil,
	["VisibilityStateChanged"] = nil
}
local v2, v3 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserHandleFriendJoinNotifierOnClient")
end)
if not v2 then
	v3 = false
end
local v4, v5 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserIsChatTranslationEnabled2")
end)
local v_u_6 = v4 and v5
local v7, v8 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserAddBetterConsoleCheckForLegacyChat")
end)
local v9 = v7 and v8
game:GetService("RunService")
local v10 = game:GetService("ReplicatedStorage")
local v_u_11 = game:GetService("Chat")
local v_u_12 = game:GetService("StarterGui")
game:GetService("ContextActionService")
local v_u_13 = v10:WaitForChild("DefaultChatSystemChatEvents")
local v14 = v10:WaitForChild("DefaultChatSystemChatEvents")
local v15 = v_u_11:WaitForChild("ClientChatModules")
local v_u_16 = require(v15:WaitForChild("ChatConstants"))
local v_u_17 = require(v15:WaitForChild("ChatSettings"))
local v18 = v15:WaitForChild("MessageCreatorModules")
local v19 = require(v18:WaitForChild("Util"))
local v_u_20 = nil
pcall(function()
	-- upvalues: (ref) v_u_20
	v_u_20 = require(game:GetService("Chat").ClientChatModules.ChatLocalization)
end)
local v_u_22 = v_u_20 == nil and {
	["Get"] = function(_, _, p21) -- name: Get
		return p21
	end
} or v_u_20
local v_u_23
if v_u_6 then
	v_u_23 = script:FindFirstChild("ChatTranslationEnabled")
	if v_u_23 == nil then
		local v_u_24 = nil
		v_u_24 = script.ChildAdded:Connect(function(p25)
			-- upvalues: (ref) v_u_23, (ref) v_u_24
			if p25.Name == "ChatTranslationEnabled" then
				v_u_23 = p25
				v_u_24:Disconnect()
			end
		end)
	end
else
	v_u_23 = nil
end
local v_u_26 = 10
local v_u_27 = {
	["OnNewMessage"] = "RemoteEvent",
	["OnMessageDoneFiltering"] = "RemoteEvent",
	["OnNewSystemMessage"] = "RemoteEvent",
	["OnChannelJoined"] = "RemoteEvent",
	["OnChannelLeft"] = "RemoteEvent",
	["OnMuted"] = "RemoteEvent",
	["OnUnmuted"] = "RemoteEvent",
	["OnMainChannelSet"] = "RemoteEvent",
	["SayMessageRequest"] = "RemoteEvent",
	["GetInitDataRequest"] = "RemoteFunction"
}
local v_u_28 = {}
local v_u_29 = Instance.new("BindableEvent")
function TryRemoveChildWithVerifyingIsCorrectType(p30) -- name: TryRemoveChildWithVerifyingIsCorrectType
	-- upvalues: (copy) v_u_27, (copy) v_u_28, (ref) v_u_26
	if v_u_27[p30.Name] and p30:IsA(v_u_27[p30.Name]) then
		v_u_27[p30.Name] = nil
		v_u_28[p30.Name] = p30
		v_u_26 = v_u_26 - 1
	end
end
local v_u_31 = v_u_26
for _, v32 in pairs(v14:GetChildren()) do
	TryRemoveChildWithVerifyingIsCorrectType(v32)
end
if v_u_31 > 0 then
	local v34 = v14.ChildAdded:connect(function(p33)
		-- upvalues: (ref) v_u_31, (copy) v_u_29
		TryRemoveChildWithVerifyingIsCorrectType(p33)
		if v_u_31 < 1 then
			v_u_29:Fire()
		end
	end)
	v_u_29.Event:wait()
	v34:disconnect()
	v_u_29:Destroy()
end
local v_u_35 = game:GetService("UserInputService")
local v_u_36 = game:GetService("RunService")
local v_u_37 = game:GetService("Players")
local v_u_38 = v_u_37.LocalPlayer
while not v_u_38 do
	v_u_37.ChildAdded:wait()
	v_u_38 = v_u_37.LocalPlayer
end
local v_u_39 = true
local v40 = v_u_17.ScreenGuiDisplayOrder == nil and 6 or v_u_17.ScreenGuiDisplayOrder
local v41 = v_u_38:WaitForChild("PlayerGui")
local v_u_42 = Instance.new("ScreenGui")
v_u_42.Name = "Chat"
v_u_42.ResetOnSpawn = false
v_u_42.DisplayOrder = v40
v_u_42.Parent = v41
if v9 and game:GetService("GuiService"):IsTenFootInterface() then
	v_u_42.Enabled = false
end
local v_u_43 = false
local v_u_44 = script
local v45 = require(v_u_44:WaitForChild("ChatWindow"))
local v46 = require(v_u_44:WaitForChild("ChatBar"))
local v47 = require(v_u_44:WaitForChild("ChannelsBar"))
require(v_u_44:WaitForChild("MessageLabelCreator"))
local v_u_48 = require(v_u_44:WaitForChild("MessageLogDisplay"))
require(v_u_44:WaitForChild("ChatChannel"))
local v49 = require(v_u_44:WaitForChild("CommandProcessor"))
local v_u_50 = v45.new()
local v_u_51 = v47.new()
local v_u_52 = v_u_48.new()
local v_u_53 = v49.new()
local v_u_54 = v46.new(v_u_53, v_u_50)
v_u_50:CreateGuiObjects(v_u_42)
v_u_50:RegisterChatBar(v_u_54)
v_u_50:RegisterChannelsBar(v_u_51)
v_u_50:RegisterMessageLogDisplay(v_u_52)
v19:RegisterChatWindow(v_u_50)
local v_u_55 = require(v_u_44:WaitForChild("MessageSender"))
v_u_55:RegisterSayMessageFunction(v_u_28.SayMessageRequest)
if v_u_35.TouchEnabled then
	v_u_54:SetTextLabelText(v_u_22:Get("GameChat_ChatMain_ChatBarTextTouch", "Tap here to chat"))
else
	v_u_54:SetTextLabelText(v_u_22:Get("GameChat_ChatMain_ChatBarText", "To chat click here or press \"/\" key"))
end
spawn(function()
	-- upvalues: (copy) v_u_44, (copy) v_u_17, (copy) v_u_50
	local v56 = require(v_u_44:WaitForChild("CurveUtil"))
	local v57 = 1 / (v_u_17.ChatAnimationFPS or 20)
	local v58 = tick()
	while true do
		local v59 = tick()
		local v60 = v56:DeltaTimeToTimescale(v59 - v58)
		if v60 ~= 0 then
			v_u_50:Update(v60)
		end
		wait(v57)
		v58 = v59
	end
end)
function CheckIfPointIsInSquare(p61, p62, p63) -- name: CheckIfPointIsInSquare
	local v64
	if p62.X <= p61.X and (p61.X <= p63.X and p62.Y <= p61.Y) then
		v64 = p61.Y <= p63.Y
	else
		v64 = false
	end
	return v64
end
local v_u_65 = false
local v_u_66 = false
local v_u_67 = 0
local v_u_68 = 0
local v_u_69 = Instance.new("BindableEvent")
local v_u_70 = Instance.new("BindableEvent")
local v_u_71 = Instance.new("BindableEvent")
function DoBackgroundFadeIn(p72) -- name: DoBackgroundFadeIn
	-- upvalues: (ref) v_u_68, (ref) v_u_65, (copy) v_u_69, (copy) v_u_50, (copy) v_u_17, (copy) v_u_52, (copy) v_u_48
	v_u_68 = tick()
	v_u_65 = false
	v_u_69:Fire()
	v_u_50:FadeInBackground(p72 or v_u_17.ChatDefaultFadeDuration)
	if v_u_50:GetCurrentChannel() then
		local v73 = v_u_52.Scroller
		v73.ScrollingEnabled = true
		v73.ScrollBarThickness = v_u_48.ScrollBarThickness
	end
end
function DoBackgroundFadeOut(p74) -- name: DoBackgroundFadeOut
	-- upvalues: (ref) v_u_68, (ref) v_u_65, (copy) v_u_69, (copy) v_u_50, (copy) v_u_17, (copy) v_u_52
	v_u_68 = tick()
	v_u_65 = true
	v_u_69:Fire()
	v_u_50:FadeOutBackground(p74 or v_u_17.ChatDefaultFadeDuration)
	if v_u_50:GetCurrentChannel() then
		local v75 = v_u_52.Scroller
		v75.ScrollingEnabled = false
		v75.ScrollBarThickness = 0
	end
end
function DoTextFadeIn(p76) -- name: DoTextFadeIn
	-- upvalues: (ref) v_u_67, (ref) v_u_66, (copy) v_u_69, (copy) v_u_50, (copy) v_u_17
	v_u_67 = tick()
	v_u_66 = false
	v_u_69:Fire()
	v_u_50:FadeInText((p76 or v_u_17.ChatDefaultFadeDuration) * 0)
end
function DoTextFadeOut(p77) -- name: DoTextFadeOut
	-- upvalues: (ref) v_u_67, (ref) v_u_66, (copy) v_u_69, (copy) v_u_50, (copy) v_u_17
	v_u_67 = tick()
	v_u_66 = true
	v_u_69:Fire()
	v_u_50:FadeOutText(p77 or v_u_17.ChatDefaultFadeDuration)
end
function DoFadeInFromNewInformation() -- name: DoFadeInFromNewInformation
	-- upvalues: (copy) v_u_17
	DoTextFadeIn()
	if v_u_17.ChatShouldFadeInFromNewInformation then
		DoBackgroundFadeIn()
	end
end
function InstantFadeIn() -- name: InstantFadeIn
	DoBackgroundFadeIn(0)
	DoTextFadeIn(0)
end
function InstantFadeOut() -- name: InstantFadeOut
	DoBackgroundFadeOut(0)
	DoTextFadeOut(0)
end
local v_u_78 = nil
function UpdateFadingForMouseState(p79) -- name: UpdateFadingForMouseState
	-- upvalues: (ref) v_u_78, (copy) v_u_70, (copy) v_u_54
	v_u_78 = p79
	v_u_70:Fire()
	if v_u_54:IsFocused() then
		return
	elseif p79 then
		DoBackgroundFadeIn()
		DoTextFadeIn()
	else
		DoBackgroundFadeIn()
	end
end
spawn(function()
	-- upvalues: (copy) v_u_36, (ref) v_u_78, (copy) v_u_54, (copy) v_u_70, (copy) v_u_71, (ref) v_u_65, (ref) v_u_68, (copy) v_u_17, (ref) v_u_66, (ref) v_u_67, (copy) v_u_69
	while true do
		v_u_36.RenderStepped:wait()
		while v_u_78 or v_u_54:IsFocused() do
			if v_u_78 then
				v_u_70.Event:wait()
			end
			if not v_u_54:IsFocused() then
				continue
			end
			v_u_71.Event:wait()
		end
		if v_u_65 then
			if v_u_66 then
				v_u_69.Event:wait()
			else
				if tick() - v_u_67 <= v_u_17.ChatWindowTextFadeOutTime then
					break
				end
				DoTextFadeOut()
			end
		else
			if tick() - v_u_68 <= v_u_17.ChatWindowBackgroundFadeOutTime then
				break
			end
			DoBackgroundFadeOut()
		end
	end
end)
function getClassicChatEnabled() -- name: getClassicChatEnabled
	-- upvalues: (copy) v_u_17, (copy) v_u_37
	if v_u_17.ClassicChatEnabled == nil then
		return v_u_37.ClassicChat
	else
		return v_u_17.ClassicChatEnabled
	end
end
function getBubbleChatEnabled() -- name: getBubbleChatEnabled
	-- upvalues: (copy) v_u_17, (copy) v_u_37
	if v_u_17.BubbleChatEnabled == nil then
		return v_u_37.BubbleChat
	else
		return v_u_17.BubbleChatEnabled
	end
end
function bubbleChatOnly() -- name: bubbleChatOnly
	local v80 = not getClassicChatEnabled()
	if v80 then
		v80 = getBubbleChatEnabled()
	end
	return v80
end
function UpdateMousePosition(p81) -- name: UpdateMousePosition
	-- upvalues: (copy) v_u_1, (copy) v_u_17, (copy) v_u_50, (ref) v_u_78
	if v_u_1.Visible and (v_u_1.IsCoreGuiEnabled and (v_u_1.TopbarEnabled or v_u_17.ChatOnWithTopBarOff)) then
		if not bubbleChatOnly() then
			local v82 = v_u_50.GuiObject.AbsolutePosition
			local v83 = v_u_50.GuiObject.AbsoluteSize
			local v84 = CheckIfPointIsInSquare(p81, v82, v82 + v83)
			if v84 ~= v_u_78 then
				UpdateFadingForMouseState(v84)
			end
		end
	else
		return
	end
end
v_u_35.InputChanged:connect(function(p85, _)
	if p85.UserInputType == Enum.UserInputType.MouseMovement then
		local v86 = Vector2.new(p85.Position.X, p85.Position.Y)
		UpdateMousePosition(v86)
	end
end)
v_u_35.TouchTap:connect(function(p87, _)
	UpdateMousePosition(p87[1])
end)
v_u_35.TouchMoved:connect(function(p88, _)
	local v89 = Vector2.new(p88.Position.X, p88.Position.Y)
	UpdateMousePosition(v89)
end)
v_u_35.Changed:connect(function(p90)
	-- upvalues: (copy) v_u_35, (copy) v_u_50, (copy) v_u_42
	if p90 == "MouseBehavior" and v_u_35.MouseBehavior == Enum.MouseBehavior.LockCenter then
		local v91 = v_u_50.GuiObject.AbsolutePosition
		local v92 = v_u_50.GuiObject.AbsoluteSize
		local v93 = v_u_42.AbsoluteSize
		if CheckIfPointIsInSquare(v93 / 2, v91, v91 + v92) then
			v_u_35.MouseBehavior = Enum.MouseBehavior.Default
		end
	end
end)
UpdateFadingForMouseState(true)
UpdateFadingForMouseState(false)
local v104 = {
	["Signal"] = function() -- name: Signal
		local v94 = {}
		local v_u_95 = Instance.new("BindableEvent")
		local v_u_96 = nil
		local v_u_97 = nil
		function v94.fire(_, ...) -- name: fire
			-- upvalues: (ref) v_u_96, (ref) v_u_97, (copy) v_u_95
			v_u_96 = { ... }
			v_u_97 = select("#", ...)
			v_u_95:Fire()
		end
		function v94.connect(_, p_u_98) -- name: connect
			-- upvalues: (copy) v_u_95, (ref) v_u_96, (ref) v_u_97
			if not p_u_98 then
				error("connect(nil)", 2)
			end
			return v_u_95.Event:connect(function()
				-- upvalues: (copy) p_u_98, (ref) v_u_96, (ref) v_u_97
				local v99 = v_u_96
				local v100 = v_u_97
				p_u_98(unpack(v99, 1, v100))
			end)
		end
		function v94.wait(_) -- name: wait
			-- upvalues: (copy) v_u_95, (ref) v_u_96, (ref) v_u_97
			v_u_95.Event:wait()
			local v101 = v_u_96
			assert(v101, "Missing arg data, likely due to :TweenSize/Position corrupting threadrefs.")
			local v102 = v_u_96
			local v103 = v_u_97
			return unpack(v102, 1, v103)
		end
		return v94
	end
}
function SetVisibility(p105) -- name: SetVisibility
	-- upvalues: (copy) v_u_50, (copy) v_u_1
	v_u_50:SetVisible(p105)
	v_u_1.VisibilityStateChanged:fire(p105)
	v_u_1.Visible = p105
	if v_u_1.IsCoreGuiEnabled then
		if p105 then
			InstantFadeIn()
			return
		end
		InstantFadeOut()
	end
end
local v_u_106 = nil
v_u_1.TopbarEnabled = true
v_u_1.MessageCount = 0
v_u_1.Visible = true
v_u_1.IsCoreGuiEnabled = true
function v_u_1.ToggleVisibility(_) -- name: ToggleVisibility
	-- upvalues: (copy) v_u_50
	SetVisibility(not v_u_50:GetVisible())
end
function v_u_1.SetVisible(_, p107) -- name: SetVisible
	-- upvalues: (copy) v_u_50
	if v_u_50:GetVisible() ~= p107 then
		SetVisibility(p107)
	end
end
function v_u_1.FocusChatBar(_) -- name: FocusChatBar
	-- upvalues: (copy) v_u_54
	v_u_54:CaptureFocus()
end
function v_u_1.EnterWhisperState(_, p108) -- name: EnterWhisperState
	-- upvalues: (copy) v_u_54
	v_u_54:EnterWhisperState(p108)
end
function v_u_1.GetVisibility(_) -- name: GetVisibility
	-- upvalues: (copy) v_u_50
	return v_u_50:GetVisible()
end
function v_u_1.GetMessageCount(p109) -- name: GetMessageCount
	return p109.MessageCount
end
function v_u_1.TopbarEnabledChanged(p110, p111) -- name: TopbarEnabledChanged
	p110.TopbarEnabled = p111
	p110.CoreGuiEnabled:fire(game:GetService("StarterGui"):GetCoreGuiEnabled(Enum.CoreGuiType.Chat))
end
function v_u_1.IsFocused(_, _) -- name: IsFocused
	-- upvalues: (copy) v_u_54
	return v_u_54:IsFocused()
end
v_u_1.ChatBarFocusChanged = v104.Signal()
v_u_1.VisibilityStateChanged = v104.Signal()
v_u_1.MessagesChanged = v104.Signal()
v_u_1.MessagePosted = v104.Signal()
v_u_1.CoreGuiEnabled = v104.Signal()
v_u_1.ChatMakeSystemMessageEvent = v104.Signal()
v_u_1.ChatWindowPositionEvent = v104.Signal()
v_u_1.ChatWindowSizeEvent = v104.Signal()
v_u_1.ChatBarDisabledEvent = v104.Signal()
function v_u_1.fChatWindowPosition(_) -- name: fChatWindowPosition
	-- upvalues: (copy) v_u_50
	return v_u_50.GuiObject.Position
end
function v_u_1.fChatWindowSize(_) -- name: fChatWindowSize
	-- upvalues: (copy) v_u_50
	return v_u_50.GuiObject.Size
end
function v_u_1.fChatBarDisabled(_) -- name: fChatBarDisabled
	-- upvalues: (copy) v_u_54
	return not v_u_54:GetEnabled()
end
function v_u_1.SpecialKeyPressed(_, p112, _) -- name: SpecialKeyPressed
	-- upvalues: (ref) v_u_39, (ref) v_u_106
	if p112 == Enum.SpecialKey.ChatHotkey and v_u_39 then
		v_u_106()
	end
end
v_u_1.CoreGuiEnabled:connect(function(p113)
	-- upvalues: (copy) v_u_1, (copy) v_u_17, (copy) v_u_50, (copy) v_u_54
	v_u_1.IsCoreGuiEnabled = p113
	if p113 then
		p113 = v_u_1.TopbarEnabled or v_u_17.ChatOnWithTopBarOff
	end
	v_u_50:SetCoreGuiEnabled(p113)
	if p113 then
		InstantFadeIn()
	else
		v_u_54:ReleaseFocus()
		InstantFadeOut()
	end
end)
function trimTrailingSpaces(p114) -- name: trimTrailingSpaces
	local v115 = #p114
	while v115 > 0 and p114:find("^%s", v115) do
		v115 = v115 - 1
	end
	return p114:sub(1, v115)
end
v_u_1.ChatMakeSystemMessageEvent:connect(function(p116)
	-- upvalues: (ref) v_u_43, (copy) v_u_17, (copy) v_u_50, (copy) v_u_16, (copy) v_u_51, (copy) v_u_1
	if p116.Text then
		local v117 = p116.Text
		if type(v117) == "string" then
			while not v_u_43 do
				wait()
			end
			local v118 = v_u_17.GeneralChannelName
			local v119 = v_u_50:GetChannel(v118)
			if v119 then
				local v120 = {
					["ID"] = -1,
					["FromSpeaker"] = nil,
					["SpeakerUserId"] = 0,
					["OriginalChannel"] = nil,
					["IsFiltered"] = true,
					["MessageLength"] = nil,
					["MessageLengthUtf8"] = nil,
					["Message"] = nil,
					["MessageType"] = nil,
					["Time"] = nil,
					["ExtraData"] = nil,
					["OriginalChannel"] = v118
				}
				local v121 = p116.Text
				v120.MessageLength = string.len(v121)
				v120.MessageLengthUtf8 = utf8.len(utf8.nfcnormalize(p116.Text))
				v120.Message = trimTrailingSpaces(p116.Text)
				v120.MessageType = v_u_16.MessageTypeSetCore
				v120.Time = os.time()
				v120.ExtraData = p116
				v119:AddMessageToChannel(v120)
				v_u_51:UpdateMessagePostedInChannel(v118)
				v_u_1.MessageCount = v_u_1.MessageCount + 1
				v_u_1.MessagesChanged:fire(v_u_1.MessageCount)
			end
		end
	end
end)
v_u_1.ChatBarDisabledEvent:connect(function(p122)
	-- upvalues: (ref) v_u_39, (copy) v_u_54
	if v_u_39 then
		v_u_54:SetEnabled(not p122)
		if p122 then
			v_u_54:ReleaseFocus()
		end
	end
end)
v_u_1.ChatWindowSizeEvent:connect(function(p123)
	-- upvalues: (copy) v_u_50
	v_u_50.GuiObject.Size = p123
end)
v_u_1.ChatWindowPositionEvent:connect(function(p124)
	-- upvalues: (copy) v_u_50
	v_u_50.GuiObject.Position = p124
end)
v_u_106 = function() -- name: DoChatBarFocus
	-- upvalues: (copy) v_u_50, (copy) v_u_54, (copy) v_u_1
	if v_u_50:GetCoreGuiEnabled() then
		if v_u_54:GetEnabled() then
			if not v_u_54:IsFocused() and v_u_54:GetVisible() then
				v_u_1:SetVisible(true)
				InstantFadeIn()
				v_u_54:CaptureFocus()
				v_u_1.ChatBarFocusChanged:fire(true)
			end
		end
	else
		return
	end
end
v_u_71.Event:connect(function(p125)
	-- upvalues: (copy) v_u_1
	v_u_1.ChatBarFocusChanged:fire(p125)
end)
function DoSwitchCurrentChannel(p126) -- name: DoSwitchCurrentChannel
	-- upvalues: (copy) v_u_50
	if v_u_50:GetChannel(p126) then
		v_u_50:SwitchCurrentChannel(p126)
	end
end
function SendMessageToSelfInTargetChannel(p127, p128, p129) -- name: SendMessageToSelfInTargetChannel
	-- upvalues: (copy) v_u_50, (copy) v_u_16
	local v130 = v_u_50:GetChannel(p128)
	if v130 then
		v130:AddMessageToChannel({
			["ID"] = -1,
			["FromSpeaker"] = nil,
			["SpeakerUserId"] = 0,
			["OriginalChannel"] = nil,
			["IsFiltered"] = true,
			["MessageLength"] = nil,
			["MessageLengthUtf8"] = nil,
			["Message"] = nil,
			["MessageType"] = nil,
			["Time"] = nil,
			["ExtraData"] = nil,
			["OriginalChannel"] = p128,
			["MessageLength"] = string.len(p127),
			["MessageLengthUtf8"] = utf8.len(utf8.nfcnormalize(p127)),
			["Message"] = trimTrailingSpaces(p127),
			["MessageType"] = v_u_16.MessageTypeSystem,
			["Time"] = os.time(),
			["ExtraData"] = p129
		})
	end
end
function chatBarFocused() -- name: chatBarFocused
	-- upvalues: (ref) v_u_78, (ref) v_u_66, (copy) v_u_71
	if not v_u_78 then
		DoBackgroundFadeIn()
		if v_u_66 then
			DoTextFadeIn()
		end
	end
	v_u_71:Fire(true)
end
function chatBarFocusLost(p131, _) -- name: chatBarFocusLost
	-- upvalues: (copy) v_u_71, (copy) v_u_54, (copy) v_u_1, (copy) v_u_53, (copy) v_u_50, (copy) v_u_17, (copy) v_u_55
	DoBackgroundFadeIn()
	v_u_71:Fire(false)
	if p131 then
		local v132 = v_u_54:GetTextBox().Text
		if v_u_54:IsInCustomState() then
			v132 = v_u_54:GetCustomMessage() or v132
			local v133 = v_u_54:CustomStateProcessCompletedMessage(v132)
			v_u_54:ResetCustomState()
			if v133 then
				return
			end
		end
		v_u_54:GetTextBox().Text = ""
		if v132 ~= "" then
			v_u_1.MessagePosted:fire(v132)
			if not v_u_53:ProcessCompletedChatMessage(v132, v_u_50) then
				if v_u_17.DisallowedWhiteSpace then
					for v134 = 1, #v_u_17.DisallowedWhiteSpace do
						if v_u_17.DisallowedWhiteSpace[v134] == "\t" then
							v132 = string.gsub(v132, v_u_17.DisallowedWhiteSpace[v134], " ")
						else
							v132 = string.gsub(v132, v_u_17.DisallowedWhiteSpace[v134], "")
						end
					end
				end
				local v135 = string.gsub(v132, "\n", "")
				local v136 = string.gsub(v135, "[ ]+", " ")
				local v137 = v_u_50:GetTargetMessageChannel()
				if v137 then
					v_u_55:SendMessage(v136, v137)
					return
				end
				v_u_55:SendMessage(v136, nil)
			end
		end
	end
end
local v_u_138 = {}
function setupChatBarConnections() -- name: setupChatBarConnections
	-- upvalues: (ref) v_u_138, (copy) v_u_54
	for v139 = 1, #v_u_138 do
		v_u_138[v139]:Disconnect()
	end
	v_u_138 = {}
	local v140 = v_u_54:GetTextBox().FocusLost:connect(chatBarFocusLost)
	local v141 = v_u_138
	table.insert(v141, v140)
	local v142 = v_u_54:GetTextBox().Focused:connect(chatBarFocused)
	local v143 = v_u_138
	table.insert(v143, v142)
end
setupChatBarConnections()
v_u_54.GuiObjectsChanged:connect(setupChatBarConnections)
function getEchoMessagesInGeneral() -- name: getEchoMessagesInGeneral
	-- upvalues: (copy) v_u_17
	return v_u_17.EchoMessagesInGeneralChannel == nil and true or v_u_17.EchoMessagesInGeneralChannel
end
v_u_28.OnMessageDoneFiltering.OnClientEvent:connect(function(p144)
	-- upvalues: (copy) v_u_17, (ref) v_u_38, (copy) v_u_50
	if v_u_17.ShowUserOwnFilteredMessage or p144.FromSpeaker ~= v_u_38.Name then
		local v145 = p144.OriginalChannel
		local v146 = v_u_50:GetChannel(v145)
		if v146 then
			v146:UpdateMessageFiltered(p144)
		end
		local v147 = getEchoMessagesInGeneral() and v_u_17.GeneralChannelName and (v145 ~= v_u_17.GeneralChannelName and v_u_50:GetChannel(v_u_17.GeneralChannelName))
		if v147 then
			v147:UpdateMessageFiltered(p144)
		end
	end
end)
v_u_28.OnNewMessage.OnClientEvent:connect(function(p148, p149)
	-- upvalues: (copy) v_u_50, (ref) v_u_38, (copy) v_u_51, (copy) v_u_17, (copy) v_u_1
	local v150 = v_u_50:GetChannel(p149)
	if v150 then
		v150:AddMessageToChannel(p148)
		if p148.FromSpeaker ~= v_u_38.Name then
			v_u_51:UpdateMessagePostedInChannel(p149)
		end
		local v151 = getEchoMessagesInGeneral() and v_u_17.GeneralChannelName and (p149 ~= v_u_17.GeneralChannelName and v_u_50:GetChannel(v_u_17.GeneralChannelName))
		if v151 then
			v151:AddMessageToChannel(p148)
		end
		v_u_1.MessageCount = v_u_1.MessageCount + 1
		v_u_1.MessagesChanged:fire(v_u_1.MessageCount)
		DoFadeInFromNewInformation()
	end
end)
v_u_28.OnNewSystemMessage.OnClientEvent:connect(function(p152, p153)
	-- upvalues: (copy) v_u_50, (copy) v_u_51, (copy) v_u_1, (copy) v_u_17
	local v154 = p153 or "System"
	local v155 = v_u_50:GetChannel(v154)
	if v155 then
		v155:AddMessageToChannel(p152)
		v_u_51:UpdateMessagePostedInChannel(v154)
		v_u_1.MessageCount = v_u_1.MessageCount + 1
		v_u_1.MessagesChanged:fire(v_u_1.MessageCount)
		DoFadeInFromNewInformation()
		local v156 = getEchoMessagesInGeneral() and v_u_17.GeneralChannelName and (v154 ~= v_u_17.GeneralChannelName and v_u_50:GetChannel(v_u_17.GeneralChannelName))
		if v156 then
			v156:AddMessageToChannel(p152)
			return
		end
	else
		warn(string.format("Just received system message for channel I\'m not in [%s]", v154))
	end
end)
function HandleChannelJoined(p157, p158, p159, p160, p161, p162) -- name: HandleChannelJoined
	-- upvalues: (copy) v_u_50, (copy) v_u_17, (ref) v_u_43, (copy) v_u_54, (copy) v_u_16, (ref) v_u_22, (ref) v_u_6, (ref) v_u_23
	if v_u_50:GetChannel(p157) then
		v_u_50:RemoveChannel(p157)
	end
	if p157 == v_u_17.GeneralChannelName then
		v_u_43 = true
	end
	if p160 then
		v_u_54:SetChannelNameColor(p157, p160)
	end
	local v163 = v_u_50:AddChannel(p157)
	if v163 then
		if p157 == v_u_17.GeneralChannelName then
			DoSwitchCurrentChannel(p157)
		end
		if p159 then
			local v164 = #p159 <= v_u_17.MessageHistoryLengthPerChannel and 1 or #p159 - v_u_17.MessageHistoryLengthPerChannel
			for v165 = v164, #p159 do
				v163:AddMessageToChannel(p159[v165])
			end
			if getEchoMessagesInGeneral() and (p161 and (v_u_17.GeneralChannelName and p157 ~= v_u_17.GeneralChannelName)) then
				local v166 = v_u_50:GetChannel(v_u_17.GeneralChannelName)
				if v166 then
					v166:AddMessagesToChannelByTimeStamp(p159, v164)
				end
			end
		end
		if p158 ~= "" then
			local v167 = {
				["ID"] = -1,
				["FromSpeaker"] = nil,
				["SpeakerUserId"] = 0,
				["OriginalChannel"] = nil,
				["IsFiltered"] = true,
				["MessageLength"] = nil,
				["MessageLengthUtf8"] = nil,
				["Message"] = nil,
				["MessageType"] = nil,
				["Time"] = nil,
				["ExtraData"] = nil,
				["OriginalChannel"] = p157,
				["MessageLength"] = string.len(p158),
				["MessageLengthUtf8"] = utf8.len(utf8.nfcnormalize(p158)),
				["Message"] = trimTrailingSpaces(p158),
				["MessageType"] = v_u_16.MessageTypeWelcome,
				["Time"] = os.time()
			}
			v163:AddMessageToChannel(v167)
			local v168 = getEchoMessagesInGeneral() and (p162 and (not v_u_17.ShowChannelsBar and p157 ~= v_u_17.GeneralChannelName)) and v_u_50:GetChannel(v_u_17.GeneralChannelName)
			if v168 then
				v168:AddMessageToChannel(v167)
			end
		end
		local v169 = v_u_22:Get("GameChat_ChatMain_ChatTranslationOnboarding", "Text chat will be translated into your language. Tap the symbol in front of the message to see the original. You can turn off translations in the Settings menu.")
		if v_u_6 and (v169 ~= "" and (p157 == v_u_17.GeneralChannelName and (v_u_23 ~= nil and v_u_23.Value))) then
			v163:AddMessageToChannel({
				["ID"] = -2,
				["FromSpeaker"] = nil,
				["SpeakerUserId"] = 0,
				["OriginalChannel"] = nil,
				["IsFiltered"] = true,
				["MessageLength"] = nil,
				["MessageLengthUtf8"] = nil,
				["Message"] = nil,
				["MessageType"] = nil,
				["Time"] = nil,
				["ExtraData"] = nil,
				["OriginalChannel"] = p157,
				["MessageLength"] = string.len(v169),
				["MessageLengthUtf8"] = utf8.len(utf8.nfcnormalize(v169)),
				["Message"] = trimTrailingSpaces(v169),
				["MessageType"] = v_u_16.MessageTypeWelcome,
				["Time"] = os.time()
			})
		end
		DoFadeInFromNewInformation()
	end
end
v_u_28.OnChannelJoined.OnClientEvent:connect(function(p170, p171, p172, p173)
	HandleChannelJoined(p170, p171, p172, p173, false, true)
end)
v_u_28.OnChannelLeft.OnClientEvent:connect(function(p174)
	-- upvalues: (copy) v_u_50
	v_u_50:RemoveChannel(p174)
	DoFadeInFromNewInformation()
end)
v_u_28.OnMuted.OnClientEvent:connect(function(_) end)
v_u_28.OnUnmuted.OnClientEvent:connect(function(_) end)
v_u_28.OnMainChannelSet.OnClientEvent:connect(function(p175)
	DoSwitchCurrentChannel(p175)
end)
coroutine.wrap(function()
	-- upvalues: (copy) v_u_13, (copy) v_u_54
	local v176 = v_u_13:WaitForChild("ChannelNameColorUpdated", 5)
	if v176 then
		v176.OnClientEvent:connect(function(p177, p178)
			-- upvalues: (ref) v_u_54
			v_u_54:SetChannelNameColor(p177, p178)
		end)
	end
end)()
local v_u_179 = nil
local v_u_180 = nil
local v_u_181 = nil
local v_u_182 = nil
pcall(function()
	-- upvalues: (ref) v_u_179, (copy) v_u_12, (ref) v_u_180, (ref) v_u_181, (ref) v_u_182
	v_u_179 = v_u_12:GetCore("PlayerBlockedEvent")
	v_u_180 = v_u_12:GetCore("PlayerMutedEvent")
	v_u_181 = v_u_12:GetCore("PlayerUnblockedEvent")
	v_u_182 = v_u_12:GetCore("PlayerUnmutedEvent")
end)
function SendSystemMessageToSelf(p183) -- name: SendSystemMessageToSelf
	-- upvalues: (copy) v_u_50, (copy) v_u_16
	local v184 = v_u_50:GetCurrentChannel()
	if v184 then
		v184:AddMessageToChannel({
			["ID"] = -1,
			["FromSpeaker"] = nil,
			["SpeakerUserId"] = 0,
			["OriginalChannel"] = nil,
			["IsFiltered"] = true,
			["MessageLength"] = nil,
			["MessageLengthUtf8"] = nil,
			["Message"] = nil,
			["MessageType"] = nil,
			["Time"] = nil,
			["ExtraData"] = nil,
			["OriginalChannel"] = v184.Name,
			["MessageLength"] = string.len(p183),
			["MessageLengthUtf8"] = utf8.len(utf8.nfcnormalize(p183)),
			["Message"] = trimTrailingSpaces(p183),
			["MessageType"] = v_u_16.MessageTypeSystem,
			["Time"] = os.time()
		})
	end
end
function MutePlayer(p185) -- name: MutePlayer
	-- upvalues: (copy) v_u_13
	local v186 = v_u_13:FindFirstChild("MutePlayerRequest")
	if v186 then
		return v186:InvokeServer(p185.Name)
	else
		return false
	end
end
if v_u_179 then
	v_u_179.Event:connect(function(p187)
		-- upvalues: (copy) v_u_17, (ref) v_u_22
		if MutePlayer(p187) then
			local v188
			if v_u_17.PlayerDisplayNamesEnabled then
				v188 = p187.DisplayName
			else
				v188 = p187.Name
			end
			SendSystemMessageToSelf(v_u_22:Get("GameChat_ChatMain_SpeakerHasBeenBlocked", string.format("Speaker \'%s\' has been blocked.", v188), {
				["RBX_NAME"] = v188
			}))
		end
	end)
end
if v3 then
	local v189
	if v_u_17.ShowFriendJoinNotification == nil then
		v189 = false
	else
		v189 = v_u_17.ShowFriendJoinNotification
	end
	if v189 then
		v_u_37.PlayerAdded:Connect(function(p_u_190)
			-- upvalues: (ref) v_u_38, (copy) v_u_17, (ref) v_u_22
			local v191, v192 = pcall(function()
				-- upvalues: (copy) p_u_190, (ref) v_u_38
				return p_u_190:IsFriendsWith(v_u_38.UserId)
			end)
			if v191 and v192 then
				local v193 = p_u_190.Name
				if v_u_17.PlayerDisplayNamesEnabled then
					v193 = p_u_190.DisplayName
				end
				local v194 = v_u_22:FormatMessageToSend("GameChat_FriendChatNotifier_JoinMessage", string.format("Your friend %s has joined the game.", v193), "RBX_NAME", v193)
				SendSystemMessageToSelf(v194)
			end
		end)
	end
end
if v_u_180 then
	v_u_180.Event:connect(function(p195)
		-- upvalues: (copy) v_u_17, (ref) v_u_22
		if MutePlayer(p195) then
			local v196
			if v_u_17.PlayerDisplayNamesEnabled then
				v196 = p195.DisplayName
			else
				v196 = p195.Name
			end
			SendSystemMessageToSelf(v_u_22:Get("GameChat_ChatMain_SpeakerHasBeenMuted", string.format("Speaker \'%s\' has been muted.", v196), {
				["RBX_NAME"] = v196
			}))
		end
	end)
end
function UnmutePlayer(p197) -- name: UnmutePlayer
	-- upvalues: (copy) v_u_13
	local v198 = v_u_13:FindFirstChild("UnMutePlayerRequest")
	if v198 then
		return v198:InvokeServer(p197.Name)
	else
		return false
	end
end
if v_u_181 then
	v_u_181.Event:connect(function(p199)
		-- upvalues: (copy) v_u_17, (ref) v_u_22
		if UnmutePlayer(p199) then
			local v200
			if v_u_17.PlayerDisplayNamesEnabled then
				v200 = p199.DisplayName
			else
				v200 = p199.Name
			end
			SendSystemMessageToSelf(v_u_22:Get("GameChat_ChatMain_SpeakerHasBeenUnBlocked", string.format("Speaker \'%s\' has been unblocked.", v200), {
				["RBX_NAME"] = v200
			}))
		end
	end)
end
if v_u_182 then
	v_u_182.Event:connect(function(p201)
		-- upvalues: (copy) v_u_17, (ref) v_u_22
		if UnmutePlayer(p201) then
			local v202
			if v_u_17.PlayerDisplayNamesEnabled then
				v202 = p201.DisplayName
			else
				v202 = p201.Name
			end
			SendSystemMessageToSelf(v_u_22:Get("GameChat_ChatMain_SpeakerHasBeenUnMuted", string.format("Speaker \'%s\' has been unmuted.", v202), {
				["RBX_NAME"] = v202
			}))
		end
	end)
end
spawn(function()
	-- upvalues: (ref) v_u_38, (copy) v_u_12, (copy) v_u_13
	if v_u_38.UserId > 0 then
		pcall(function()
			-- upvalues: (ref) v_u_12, (ref) v_u_13
			local v203 = v_u_12:GetCore("GetBlockedUserIds")
			local v204 = #v203 > 0 and v_u_13:FindFirstChild("SetBlockedUserIdsRequest")
			if v204 then
				v204:FireServer(v203)
			end
		end)
	end
end)
spawn(function()
	-- upvalues: (copy) v_u_11, (ref) v_u_38, (ref) v_u_39, (copy) v_u_36
	local v205, v206 = pcall(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_38
		return v_u_11:CanUserChatAsync(v_u_38.UserId)
	end)
	if v205 then
		v_u_39 = v_u_36:IsStudio() or v206
	end
end)
local v207 = v_u_28.GetInitDataRequest:InvokeServer()
for _, v208 in pairs(v207.Channels) do
	if v208[1] ~= v_u_17.GeneralChannelName then
		continue
	end
	HandleChannelJoined(v208[1], v208[2], v208[3], v208[4], true, false)
end
for _, v209 in pairs(v207.Channels) do
	if v209[1] == v_u_17.GeneralChannelName then
		continue
	end
	HandleChannelJoined(v209[1], v209[2], v209[3], v209[4], true, false)
end
return v_u_1
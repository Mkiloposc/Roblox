local v_u_1 = game:GetService("Lighting")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = game:GetService("Workspace")
local v_u_6 = require(v_u_3.Shared.AdminAbuseConfig)
local v_u_7 = require(script.Parent.CameraFovController)
local v_u_8 = require(script.Parent.Parent.Modules.EventLighting)
local v_u_9 = v_u_6.Transition
local v_u_10 = v2.LocalPlayer
local v11 = {}
local v_u_12 = Instance.new("NumberValue")
v_u_12.Name = "AdminAbuseFXAlpha"
v_u_12.Value = 0
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = 0
local v_u_16 = {}
local v_u_17 = nil
local function v_u_20(p18) -- name: setAdminSky
	-- upvalues: (copy) v_u_8, (copy) v_u_1, (copy) v_u_9
	if p18 then
		local v19 = v_u_1:FindFirstChild(v_u_9.SkiesFolderName)
		if v19 then
			v19 = v19:FindFirstChild(v_u_9.SkyName)
		end
		if v19 and v19:IsA("Sky") then
			v_u_8.SetAdminSky(v19, v_u_9.HideSun)
		else
			warn("[AdminAbuseFXController] Admin sky template is missing")
		end
	else
		v_u_8.SetAdminSky(nil, false)
		return
	end
end
local function v_u_25(p21) -- name: setAdminVfx
	-- upvalues: (ref) v_u_17, (copy) v_u_3, (copy) v_u_9, (copy) v_u_5
	if p21 then
		if v_u_17 == nil or v_u_17.Parent == nil then
			local v22 = v_u_3:FindFirstChild(v_u_9.VFXFolderName)
			if v22 then
				v22 = v22:FindFirstChild(v_u_9.VFXName)
			end
			if v22 == nil then
				warn((("[AdminAbuseFXController] ReplicatedStorage.%*.%* not found"):format(v_u_9.VFXFolderName, v_u_9.VFXName)))
			else
				local v23 = v22:Clone()
				for _, v24 in v23:GetDescendants() do
					if not v24:IsA("BasePart") then
						continue
					end
					v24.Anchored = true
					v24.CanCollide = false
					v24.CanQuery = false
					v24.CanTouch = false
				end
				v23.Parent = v_u_5
				v_u_17 = v23
			end
		else
			return
		end
	else
		if v_u_17 ~= nil then
			v_u_17:Destroy()
			v_u_17 = nil
		end
		return
	end
end
local function v_u_28() -- name: applyFx
	-- upvalues: (copy) v_u_12, (ref) v_u_13, (copy) v_u_1, (copy) v_u_9, (copy) v_u_7
	local v26 = v_u_12.Value
	local v27 = v_u_13
	if v27 == nil or v27.Parent == nil then
		v27 = Instance.new("BlurEffect")
		v27.Name = "AdminAbuseBlur"
		v27.Size = 0
		v27.Enabled = false
		v27.Parent = v_u_1
		v_u_13 = v27
	end
	v27.Size = v_u_9.BlurSize * v26
	v27.Enabled = v26 > 0.001
	if v26 <= 0.001 then
		v_u_7.Clear("AdminAbuse")
	else
		v_u_7.Set("AdminAbuse", v_u_9.FovIncrease * v26)
	end
end
local function v_u_32() -- name: getHolder
	-- upvalues: (copy) v_u_10, (copy) v_u_9
	local v29 = v_u_10:WaitForChild("PlayerGui")
	local v30 = v29:FindFirstChild("AdminAbuseFXHolder")
	if v30 ~= nil and v30:IsA("ScreenGui") then
		return v30
	end
	local v31 = Instance.new("ScreenGui")
	v31.Name = "AdminAbuseFXHolder"
	v31.IgnoreGuiInset = true
	v31.DisplayOrder = v_u_9.DisplayOrder
	v31.ResetOnSpawn = false
	v31.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	v31.Parent = v29
	return v31
end
local function v_u_35() -- name: getOverlay
	-- upvalues: (ref) v_u_14, (copy) v_u_9, (copy) v_u_32
	local v33 = v_u_14
	if v33 ~= nil and v33.Parent ~= nil then
		return v33
	end
	local v34 = Instance.new("Frame")
	v34.Name = "WhiteOverlay"
	v34.AnchorPoint = Vector2.new(0.5, 0.5)
	v34.Position = UDim2.fromScale(0.5, 0.5)
	v34.Size = UDim2.fromScale(v_u_9.OverlayScale, v_u_9.OverlayScale)
	v34.BackgroundColor3 = v_u_9.OverlayColor
	v34.BackgroundTransparency = 1
	v34.BorderSizePixel = 0
	v34.Visible = false
	v34.Parent = v_u_32()
	v_u_14 = v34
	return v34
end
function v11.Start() -- name: Start
	-- upvalues: (copy) v_u_12, (copy) v_u_28, (copy) v_u_5, (copy) v_u_6, (copy) v_u_1, (copy) v_u_9, (copy) v_u_8, (copy) v_u_25, (copy) v_u_16, (ref) v_u_15, (copy) v_u_35, (copy) v_u_4, (copy) v_u_20, (ref) v_u_17, (ref) v_u_14
	v_u_12.Changed:Connect(v_u_28)
	local v_u_36 = v_u_5:GetAttribute(v_u_6.StartedAtAttribute) ~= nil
	if v_u_36 then
		local v37 = v_u_1:FindFirstChild(v_u_9.SkiesFolderName)
		if v37 then
			v37 = v37:FindFirstChild(v_u_9.SkyName)
		end
		if v37 and v37:IsA("Sky") then
			v_u_8.SetAdminSky(v37, v_u_9.HideSun)
		else
			warn("[AdminAbuseFXController] Admin sky template is missing")
		end
		v_u_25(true)
	end
	v_u_5:GetAttributeChangedSignal(v_u_6.StartedAtAttribute):Connect(function()
		-- upvalues: (ref) v_u_5, (ref) v_u_6, (ref) v_u_36, (ref) v_u_9, (ref) v_u_16, (ref) v_u_15, (ref) v_u_35, (ref) v_u_12, (ref) v_u_4, (ref) v_u_20, (ref) v_u_25, (ref) v_u_8, (ref) v_u_17, (ref) v_u_14
		local v38 = v_u_5:GetAttribute(v_u_6.StartedAtAttribute) ~= nil
		if v38 == v_u_36 then
			return
		else
			v_u_36 = v38
			if v38 or v_u_9.PlayOnEnd then
				for _, v39 in v_u_16 do
					v39:Cancel()
				end
				table.clear(v_u_16)
				v_u_15 = v_u_15 + 1
				local v_u_40 = v_u_15
				task.spawn(function()
					-- upvalues: (ref) v_u_35, (ref) v_u_12, (ref) v_u_9, (ref) v_u_4, (ref) v_u_16, (copy) v_u_40, (ref) v_u_15, (ref) v_u_5, (ref) v_u_6, (ref) v_u_20, (ref) v_u_25
					local v41 = v_u_35()
					v41.Visible = true
					local v42 = v_u_4:Create(v_u_12, TweenInfo.new(v_u_9.EffectInTime, v_u_9.EffectEasingStyle, Enum.EasingDirection.Out), {
						["Value"] = 1
					})
					local v43 = v_u_16
					table.insert(v43, v42)
					v42:Play()
					local v44 = v_u_4:Create(v41, TweenInfo.new(v_u_9.FadeInTime, v_u_9.FadeInEasingStyle, v_u_9.FadeInEasingDirection), {
						["BackgroundTransparency"] = 0
					})
					local v45 = v_u_16
					table.insert(v45, v44)
					v44:Play()
					if (v44.PlaybackState == Enum.PlaybackState.Completed and true or v44.Completed:Wait() == Enum.PlaybackState.Completed) and v_u_40 == v_u_15 then
						local v46 = v_u_5:GetAttribute(v_u_6.StartedAtAttribute) ~= nil
						v_u_20(v46)
						v_u_25(v46)
						task.wait(v_u_9.HoldTime)
						if v_u_40 == v_u_15 then
							local v47 = v_u_4:Create(v_u_12, TweenInfo.new(v_u_9.EffectOutTime, v_u_9.EffectEasingStyle, Enum.EasingDirection.InOut), {
								["Value"] = 0
							})
							local v48 = v_u_16
							table.insert(v48, v47)
							v47:Play()
							local v49 = v_u_4:Create(v41, TweenInfo.new(v_u_9.FadeOutTime, v_u_9.FadeOutEasingStyle, v_u_9.FadeOutEasingDirection), {
								["BackgroundTransparency"] = 1
							})
							local v50 = v_u_16
							table.insert(v50, v49)
							v49:Play()
							if (v49.PlaybackState == Enum.PlaybackState.Completed and true or v49.Completed:Wait() == Enum.PlaybackState.Completed) and v_u_40 == v_u_15 then
								v41.Visible = false
							end
						end
					else
						return
					end
				end)
			else
				for _, v51 in v_u_16 do
					v51:Cancel()
				end
				table.clear(v_u_16)
				v_u_15 = v_u_15 + 1
				v_u_8.SetAdminSky(nil, false)
				if v_u_17 ~= nil then
					v_u_17:Destroy()
					v_u_17 = nil
				end
				v_u_12.Value = 0
				if v_u_14 ~= nil then
					v_u_14.Visible = false
					v_u_14.BackgroundTransparency = 1
				end
			end
		end
	end)
end
return v11
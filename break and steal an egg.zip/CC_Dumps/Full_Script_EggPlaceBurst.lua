local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v3 = require(v_u_1.Shared.EggRewards)
local v_u_4 = require(v_u_1.Shared.VFXScaler)
local v5 = {}
local v_u_6 = v3.TargetHeight
function v5.Play(p7, p8) -- name: Play
	-- upvalues: (copy) v_u_1, (copy) v_u_6, (copy) v_u_4, (copy) v_u_2
	local v9 = v_u_1:FindFirstChild("VFX")
	if v9 then
		v9 = v9:FindFirstChild("EggPlaceVFX")
	end
	if not (v9 and v9:IsA("BasePart")) then
		v9 = nil
	end
	if v9 then
		local v10 = p8 / v_u_6
		local v11 = math.clamp(v10, 0.25, 20)
		local v_u_12 = v9:Clone()
		v_u_12.Anchored = true
		v_u_12.CanCollide = false
		v_u_12.CanQuery = false
		v_u_12.CanTouch = false
		v_u_12.Transparency = 1
		local v13 = CFrame.new
		local v14 = v11 * 0.1
		v_u_12.CFrame = v13(p7 + Vector3.new(0, v14, 0))
		local v15 = {}
		local v16 = 0
		for _, v17 in v_u_12:GetDescendants() do
			if not v17:IsA("ParticleEmitter") then
				continue
			end
			v17.Enabled = false
			v_u_4.ScaleParticle(v17, v11)
			table.insert(v15, v17)
			local v18 = v17.Lifetime.Max
			local v19 = v17.TimeScale
			local v20 = v18 / math.max(v19, 0.05)
			v16 = math.max(v16, v20)
		end
		v_u_12.Parent = v_u_2
		for _, v21 in v15 do
			local v22 = tonumber(v21:GetAttribute("EmitCount")) or v21.Rate
			v21:Emit((math.max(v22, 1)))
		end
		task.delay(v16 + 0.5, function()
			-- upvalues: (copy) v_u_12
			v_u_12:Destroy()
		end)
	else
		warn("[EggPlaceBurst] ReplicatedStorage.VFX.EggPlaceVFX missing")
	end
end
return v5
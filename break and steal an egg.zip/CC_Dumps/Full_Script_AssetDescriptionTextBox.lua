local v1 = game:GetService("CorePackages")
local v_u_2 = game:GetService("TextService")
local v_u_3 = require(v1.Packages.Roact)
local v4 = require(v1.Packages.RoactRodux)
local v5 = require(v1.Packages.t)
local v6 = require(v1.Packages.RoactGamepad)
local v_u_7 = require(v1.Workspace.Packages.RobloxTranslator)
local v_u_8 = v6.Focusable
local v9 = require(v1.Packages.UIBlox)
local v10 = require(v1.Packages.Foundation)
local v_u_11 = v10.Utility.normalizeFontFace
local v_u_12 = require(v1.Workspace.Packages.Style).GetTextSize
local v_u_13 = v10.Utility.Flags.FoundationFontFaceMigration
local v_u_14 = v9.Style.withStyle
local v_u_15 = v9.App.SelectionImage.withSelectionCursorProvider
local v_u_16 = v9.App.SelectionImage.CursorKind
local v17 = v9.App.ImageSet.Images
local v_u_18 = v9.Core.ImageSet.ImageSetLabel
local v_u_19 = v17["component_assets/circle_17_stroke_1"]
local v_u_20 = Rect.new(8, 8, 8, 8)
local v21 = script.Parent.Parent
local v_u_22 = require(v21.GetFFlagValidateDescription)
local v23 = v_u_3.PureComponent:extend("AssetDescriptionTextBox")
v23.validateProps = v5.strictInterface({
	["Size"] = v5.optional(v5.UDim2),
	["Position"] = v5.optional(v5.UDim2),
	["onAssetDescriptionUpdated"] = v5.callback,
	["descriptionTextBoxRef"] = v5.optional(v5.table),
	["NextSelectionUp"] = v5.optional(v5.table),
	["assetType"] = v5.optional(v5.enum(Enum.AssetType)),
	["defaultDescription"] = v5.optional(v5.string)
})
function v23.init(p_u_24) -- name: init
	p_u_24:setState({
		["lastValidDescription"] = "",
		["assetDescription"] = nil,
		["descriptionLength"] = 0,
		["scrollingFrameHeight"] = 100,
		["canvasHeight"] = 100,
		["canvasPosition"] = 0,
		["cursorPosition"] = 0,
		["textBoxWidth"] = 100,
		["isDescriptionValid"] = true,
		["assetDescription"] = p_u_24.props.defaultDescription or ""
	})
	p_u_24.wasInitiallyFocused = false
	function p_u_24.tryFocusTextBox()
		-- upvalues: (copy) p_u_24
		if not p_u_24.wasInitiallyFocused then
			local v25 = p_u_24.props.descriptionTextBoxRef:getValue()
			if v25 and v25:IsDescendantOf(game) then
				v25:CaptureFocus()
				p_u_24.wasInitiallyFocused = true
			end
		end
	end
end
function v23.calculateNeedsRescroll(p26, p27, p28) -- name: calculateNeedsRescroll
	-- upvalues: (copy) v_u_13, (copy) v_u_12, (copy) v_u_2
	if p26.state.cursorPosition == -1 then
		return
	else
		local v29 = (p26.state.assetDescription or ""):sub(1, p26.state.cursorPosition - 1)
		local v30 = p28.RelativeSize * p27.Font.BaseSize
		local v31 = Vector2.new(p26.state.textBoxWidth, 10000)
		local v32
		if v_u_13 then
			v32 = v_u_12(v29, v30, p27.Tokens.Typography.BodySmall.Font, v31, {
				["addTemporaryPadding"] = false
			})
		else
			v32 = v_u_2:GetTextSize(v29, v30, p28.Font, v31)
		end
		if v32.Y > p26.state.scrollingFrameHeight + p26.state.canvasPosition then
			p26:setState({
				["canvasPosition"] = v32.Y - p26.state.scrollingFrameHeight
			})
		elseif v32.Y - v30 < p26.state.canvasPosition then
			p26:setState({
				["canvasPosition"] = v32.Y - v30
			})
		end
	end
end
function v23.onTextChanged(p33, p34, p35, p36) -- name: onTextChanged
	-- upvalues: (copy) v_u_22, (copy) v_u_13, (copy) v_u_12, (copy) v_u_2
	local v37 = p34.Text
	local v38 = (not v_u_22() or v37 ~= "") and true or false
	local v39 = p33.state.lastValidDescription
	local v40 = utf8.len(utf8.nfcnormalize(v37))
	local v41
	if (v40 == nil and 0 or v40) > 1000 then
		p34.Text = v39
		v41 = v39
	else
		v41 = p34.Text
		v39 = v37
	end
	local v42 = utf8.len(utf8.nfcnormalize(v39))
	local v43 = v42 == nil and 0 or v42
	local v44 = p36.RelativeSize * p35.Font.BaseSize
	local v45 = Vector2.new(p33.state.textBoxWidth, 10000)
	local v46
	if v_u_13 then
		v46 = v_u_12(v39, v44, p35.Tokens.Typography.BodySmall.Font, v45, {
			["addTemporaryPadding"] = false
		})
	else
		v46 = v_u_2:GetTextSize(v39, v44, p36.Font, v45)
	end
	local v47 = {
		["lastValidDescription"] = v41,
		["assetDescription"] = v39,
		["descriptionLength"] = v43
	}
	local v48 = v46.Y
	v47.canvasHeight = math.max(100, v48)
	v47.isDescriptionValid = v38
	p33:setState(v47)
	p33.props.onAssetDescriptionUpdated(v39, v38)
end
function v23.renderWithProviders(p_u_49, p_u_50, p51) -- name: renderWithProviders
	-- upvalues: (copy) v_u_22, (copy) v_u_3, (copy) v_u_18, (copy) v_u_19, (copy) v_u_20, (copy) v_u_8, (copy) v_u_13, (copy) v_u_11, (copy) v_u_7, (copy) v_u_16
	local v52 = p_u_50.Font
	local v_u_53 = v52.CaptionBody
	local v54 = p_u_50.Theme
	local v55
	if v_u_22() then
		v55 = not p_u_49.state.isDescriptionValid
	else
		v55 = false
	end
	local v56 = v_u_3.createElement
	local v57 = "Frame"
	local v58 = {
		["BackgroundTransparency"] = 1,
		["Size"] = nil,
		["Position"] = nil,
		["Size"] = p_u_49.props.Size,
		["Position"] = p_u_49.props.Position
	}
	local v59 = {}
	local v60 = v_u_3.createElement
	local v61 = v_u_18
	local v62 = {
		["BackgroundTransparency"] = 1,
		["Image"] = nil,
		["ImageColor3"] = nil,
		["ImageTransparency"] = nil,
		["LayoutOrder"] = 1,
		["ScaleType"] = nil,
		["Size"] = nil,
		["SliceCenter"] = nil,
		["Image"] = v_u_19,
		["ImageColor3"] = v54.UIDefault.Color,
		["ImageTransparency"] = v54.UIDefault.Transparency,
		["ScaleType"] = Enum.ScaleType.Slice,
		["Size"] = UDim2.new(1, 0, 1, -15),
		["SliceCenter"] = v_u_20
	}
	local v63 = {}
	local v64 = v_u_3.createElement
	local v65 = "ScrollingFrame"
	local v68 = {
		["Size"] = UDim2.fromScale(1, 1),
		["BackgroundTransparency"] = 1,
		["CanvasPosition"] = Vector2.new(0, p_u_49.state.canvasPosition),
		["AutomaticCanvasSize"] = Enum.AutomaticSize.Y,
		["ScrollBarThickness"] = 12,
		["BorderSizePixel"] = 0,
		[v_u_3.Change.CanvasPosition] = function(p66)
			-- upvalues: (copy) p_u_49
			p_u_49:setState({
				["canvasPosition"] = p66.CanvasPosition.Y
			})
		end,
		[v_u_3.Change.AbsoluteSize] = function(p67)
			-- upvalues: (copy) p_u_49, (copy) p_u_50, (copy) v_u_53
			p_u_49:setState({
				["scrollingFrameHeight"] = p67.AbsoluteSize.Y
			})
			p_u_49:calculateNeedsRescroll(p_u_50, v_u_53)
		end
	}
	local v69 = {}
	local v70 = v_u_3.createElement
	local v71 = v_u_8.TextBox
	local v72 = {
		["Text"] = p_u_49.state.assetDescription,
		["BackgroundTransparency"] = 1,
		["ClearTextOnFocus"] = false
	}
	local v73
	if v_u_13 then
		v73 = nil
	else
		v73 = v52.Header2.Font
	end
	v72.Font = v73
	local v74
	if v_u_13 then
		v74 = v_u_11(p_u_50.Tokens.Typography.TitleLarge.Font)
	else
		v74 = nil
	end
	v72.FontFace = v74
	v72.TextSize = v52.BaseSize * v_u_53.RelativeSize
	v72.PlaceholderColor3 = v54.PlaceHolder.Color
	v72.PlaceholderText = v_u_7:FormatByKey("CoreScripts.PublishAssetPrompt.AssetDescriptionPlaceholder")
	v72.Position = UDim2.fromOffset(6, 0)
	v72.Size = UDim2.new(1, -24, 0, p_u_49.state.canvasHeight)
	v72.MultiLine = true
	v72.TextColor3 = v54.TextDefault.Color
	v72.TextTruncate = Enum.TextTruncate.AtEnd
	v72.TextWrapped = true
	v72.TextXAlignment = Enum.TextXAlignment.Left
	v72.TextYAlignment = Enum.TextYAlignment.Top
	v72.OverlayNativeInput = true
	v72.NextSelectionUp = p_u_49.props.NextSelectionUp
	v72[v_u_3.Change.TextFits] = p_u_49.onTextFitsChanged
	v72.SelectionImageObject = p51(v_u_16.InputFields)
	v72[v_u_3.Ref] = p_u_49.props.descriptionTextBoxRef
	v72[v_u_3.Event.AncestryChanged] = p_u_49.tryFocusTextBox
	v72[v_u_3.Change.Text] = function(p75)
		-- upvalues: (copy) p_u_49, (copy) p_u_50, (copy) v_u_53
		p_u_49:onTextChanged(p75, p_u_50, v_u_53)
	end
	v72[v_u_3.Change.AbsoluteSize] = function(p76)
		-- upvalues: (copy) p_u_49, (copy) p_u_50, (copy) v_u_53
		p_u_49:setState({
			["textBoxWidth"] = p76.AbsoluteSize.X
		})
		p_u_49:calculateNeedsRescroll(p_u_50, v_u_53)
	end
	v72[v_u_3.Change.CursorPosition] = function(p77)
		-- upvalues: (copy) p_u_49, (copy) p_u_50, (copy) v_u_53
		p_u_49:setState({
			["cursorPosition"] = p77.CursorPosition
		})
		p_u_49:calculateNeedsRescroll(p_u_50, v_u_53)
	end
	v69.Textbox = v70(v71, v72)
	v63.ScrollingFrame = v64(v65, v68, v69)
	v59.TextboxContainer = v60(v61, v62, v63)
	local v78
	if p_u_49.state.descriptionLength / 1000 > 0.9 then
		v78 = v_u_3.createElement("TextLabel", {
			["Size"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = nil,
			["Text"] = nil,
			["TextXAlignment"] = nil,
			["TextColor3"] = nil,
			["BackgroundTransparency"] = 1,
			["Size"] = UDim2.new(v_u_22() and 0.2 or 1, 0, 0, 15),
			["AnchorPoint"] = Vector2.new(1, 1),
			["Position"] = UDim2.fromScale(1, 1),
			["Text"] = p_u_49.state.descriptionLength .. "/" .. 1000,
			["TextXAlignment"] = Enum.TextXAlignment.Right,
			["TextColor3"] = v54.TextDefault.Color
		})
	else
		v78 = nil
	end
	v59.LengthDisplay = v78
	local v79 = v_u_22()
	if v79 then
		if v55 then
			local v80 = v_u_3.createElement
			local v81 = "TextLabel"
			local v82 = {
				["Position"] = nil,
				["BackgroundTransparency"] = 1,
				["Text"] = nil,
				["TextXAlignment"] = nil,
				["TextYAlignment"] = nil,
				["Size"] = nil,
				["TextColor3"] = nil,
				["TextWrapped"] = true,
				["Font"] = nil,
				["FontFace"] = nil,
				["TextSize"] = 12,
				["Position"] = UDim2.new(0, 0, 1, -15),
				["Text"] = v_u_7:FormatByKey("CoreScripts.PublishAssetPrompt.InvalidDescription"),
				["TextXAlignment"] = Enum.TextXAlignment.Left,
				["TextYAlignment"] = Enum.TextYAlignment.Top,
				["Size"] = UDim2.new(0.8, 0, 0, 20),
				["TextColor3"] = v54.Alert.Color
			}
			local v83
			if v_u_13 then
				v83 = nil
			else
				v83 = v52.Body.Font
			end
			v82.Font = v83
			local v84
			if v_u_13 then
				v84 = v_u_11(p_u_50.Tokens.Typography.BodyLarge.Font)
			else
				v84 = nil
			end
			v82.FontFace = v84
			v55 = v80(v81, v82)
		end
	else
		v55 = v79
	end
	v59.WarningText = v55
	return v56(v57, v58, v59)
end
function v23.render(p_u_85) -- name: render
	-- upvalues: (copy) v_u_14, (copy) v_u_15
	return v_u_14(function(p_u_86)
		-- upvalues: (ref) v_u_15, (copy) p_u_85
		return v_u_15(function(p87)
			-- upvalues: (ref) p_u_85, (copy) p_u_86
			return p_u_85:renderWithProviders(p_u_86, p87)
		end)
	end)
end
function v23.didMount(p88) -- name: didMount
	p88.tryFocusTextBox()
end
return v4.connect(function(p89) -- name: mapStateToProps
	return {
		["assetType"] = p89.promptRequest.promptInfo.assetType
	}
end)(v23)
local v1, v2 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserShouldMuteUnfilteredMessage")
end)
local v_u_3 = v1 and v2
local v4, v5 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserRemoveMessageOnTextFilterFailures")
end)
local v_u_6 = v4 and v5
local v7, v8 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserIsChatTranslationEnabled2")
end)
local v_u_9 = v7 and v8
local v10 = {}
local v11 = script.Parent
local v_u_12 = game:GetService("Chat")
local v_u_13 = game:GetService("RunService")
local v14 = v_u_12:WaitForChild("ClientChatModules")
local v_u_15 = require(v14:WaitForChild("ChatSettings"))
local v_u_16 = require(v14:WaitForChild("ChatConstants"))
local v_u_17 = require(v11:WaitForChild("Util"))
local v_u_18 = nil
pcall(function()
	-- upvalues: (ref) v_u_18
	v_u_18 = require(game:GetService("Chat").ClientChatModules.ChatLocalization)
end)
v_u_18 = v_u_18 or {}
if not (v_u_18.FormatMessageToSend and v_u_18.LocalizeFormattedMessage) then
	function v_u_18.FormatMessageToSend(_, _, p19) -- name: FormatMessageToSend
		return p19
	end
end
local v_u_20 = {}
v_u_20.__index = v_u_20
function v_u_20.SendSystemMessage(p_u_21, p22, p23) -- name: SendSystemMessage
	local v_u_24 = p_u_21:InternalCreateMessageObject(p22, nil, true, p23)
	local v25, v26 = pcall(function()
		-- upvalues: (copy) p_u_21, (copy) v_u_24
		p_u_21.eMessagePosted:Fire(v_u_24)
	end)
	if not v25 and v26 then
		print("Error posting message: " .. v26)
	end
	p_u_21:InternalAddMessageToHistoryLog(v_u_24)
	for _, v27 in pairs(p_u_21.Speakers) do
		v27:InternalSendSystemMessage(v_u_24, p_u_21.Name)
	end
	return v_u_24
end
function v_u_20.SendSystemMessageToSpeaker(p28, p29, p30, p31) -- name: SendSystemMessageToSpeaker
	-- upvalues: (copy) v_u_13
	local v32 = p28.Speakers[p30]
	if v32 then
		v32:InternalSendSystemMessage(p28:InternalCreateMessageObject(p29, nil, true, p31), p28.Name)
	elseif v_u_13:IsStudio() then
		warn(string.format("Speaker \'%s\' is not in channel \'%s\' and cannot be sent a system message", p30, p28.Name))
	end
end
function v_u_20.SendMessageObjToFilters(p33, p34, p35, p36) -- name: SendMessageObjToFilters
	local v37 = p35.Message
	p35.Message = p34
	p33:InternalDoMessageFilter(p36.Name, p35, p33.Name)
	p33.ChatService:InternalDoMessageFilter(p36.Name, p35, p33.Name)
	local v38 = p35.Message
	p35.Message = v37
	return v38
end
function v_u_20.CanCommunicateByUserId(_, p_u_39, p_u_40) -- name: CanCommunicateByUserId
	-- upvalues: (copy) v_u_13, (copy) v_u_12
	if v_u_13:IsStudio() then
		return true
	end
	if p_u_39 == 0 or p_u_40 == 0 then
		return true
	end
	local v41, v42 = pcall(function()
		-- upvalues: (ref) v_u_12, (copy) p_u_39, (copy) p_u_40
		return v_u_12:CanUsersChatAsync(p_u_39, p_u_40)
	end)
	return v41 and v42
end
function v_u_20.CanCommunicate(p43, p44, p45) -- name: CanCommunicate
	local v46 = p44:GetPlayer()
	local v47 = p45:GetPlayer()
	return not (v46 and v47) and true or p43:CanCommunicateByUserId(v46.UserId, v47.UserId)
end
function v_u_20.SendMessageToSpeaker(p48, p49, p50, p51, p52) -- name: SendMessageToSpeaker
	-- upvalues: (copy) v_u_13
	local v53 = p48.Speakers[p50]
	local v54 = p48.ChatService:GetSpeaker(p51)
	if v53 and v54 then
		if v53:IsSpeakerMuted(p51) then
			return
		end
		if not p48:CanCommunicate(v53, v54) then
			return
		end
		local v55 = p48:InternalCreateMessageObject(p49, p51, p50 == p51, p52)
		local v56 = p48:SendMessageObjToFilters(p49, v55, p51)
		v53:InternalSendMessage(v55, p48.Name)
		local v57 = p48.Private and Enum.TextFilterContext.PrivateChat or Enum.TextFilterContext.PublicChat
		local v58, v59, v60 = p48.ChatService:InternalApplyRobloxFilterNewAPI(v55.FromSpeaker, v56, v57)
		if v58 then
			v55.FilterResult = v60
			v55.IsFilterResult = v59
			v55.IsFiltered = true
			v53:InternalSendFilteredMessageWithFilterResult(v55, p48.Name)
			return
		end
	elseif v_u_13:IsStudio() then
		warn(string.format("Speaker \'%s\' is not in channel \'%s\' and cannot be sent a message", p50, p48.Name))
	end
end
function v_u_20.KickSpeaker(p61, p62, p63) -- name: KickSpeaker
	local v64 = p61.ChatService:GetSpeaker(p62)
	if not v64 then
		error("Speaker \"" .. p62 .. "\" does not exist!")
	end
	local v65 = v64:GetNameForDisplay()
	local v66, v67
	if p63 then
		v66 = string.format("You were kicked from \'%s\' for the following reason(s): %s", p61.Name, p63)
		v67 = string.format("%s was kicked for the following reason(s): %s", v65, p63)
	else
		v66 = string.format("You were kicked from \'%s\'", p61.Name)
		v67 = string.format("%s was kicked", v65)
	end
	p61:SendSystemMessageToSpeaker(v66, p62)
	v64:LeaveChannel(p61.Name)
	p61:SendSystemMessage(v67)
end
function v_u_20.MuteSpeaker(p_u_68, p_u_69, p_u_70, p_u_71) -- name: MuteSpeaker
	local v72 = p_u_68.ChatService:GetSpeaker(p_u_69)
	if not v72 then
		error("Speaker \"" .. p_u_69 .. "\" does not exist!")
	end
	p_u_68.Mutes[p_u_69:lower()] = (p_u_71 == 0 or p_u_71 == nil) and 0 or os.time() + p_u_71
	if p_u_70 then
		local v73 = v72:GetNameForDisplay()
		p_u_68:SendSystemMessage(string.format("%s was muted for the following reason(s): %s", v73, p_u_70))
	end
	local v74, v75 = pcall(function()
		-- upvalues: (copy) p_u_68, (copy) p_u_69, (copy) p_u_70, (copy) p_u_71
		p_u_68.eSpeakerMuted:Fire(p_u_69, p_u_70, p_u_71)
	end)
	if not v74 and v75 then
		print("Error mutting speaker: " .. v75)
	end
	local v_u_76 = p_u_68.ChatService:GetSpeaker(p_u_69)
	if v_u_76 then
		local v77, v78 = pcall(function()
			-- upvalues: (copy) v_u_76, (copy) p_u_68, (copy) p_u_70, (copy) p_u_71
			v_u_76.eMuted:Fire(p_u_68.Name, p_u_70, p_u_71)
		end)
		if not v77 and v78 then
			print("Error mutting speaker: " .. v78)
		end
	end
end
function v_u_20.UnmuteSpeaker(p_u_79, p_u_80) -- name: UnmuteSpeaker
	if not p_u_79.ChatService:GetSpeaker(p_u_80) then
		error("Speaker \"" .. p_u_80 .. "\" does not exist!")
	end
	p_u_79.Mutes[p_u_80:lower()] = nil
	local v81, v82 = pcall(function()
		-- upvalues: (copy) p_u_79, (copy) p_u_80
		p_u_79.eSpeakerUnmuted:Fire(p_u_80)
	end)
	if not v81 and v82 then
		print("Error unmuting speaker: " .. v82)
	end
	local v_u_83 = p_u_79.ChatService:GetSpeaker(p_u_80)
	if v_u_83 then
		local v84, v85 = pcall(function()
			-- upvalues: (copy) v_u_83, (copy) p_u_79
			v_u_83.eUnmuted:Fire(p_u_79.Name)
		end)
		if not v84 and v85 then
			print("Error unmuting speaker: " .. v85)
		end
	end
end
function v_u_20.IsSpeakerMuted(p86, p87) -- name: IsSpeakerMuted
	return p86.Mutes[p87:lower()] ~= nil
end
function v_u_20.GetSpeakerList(p88) -- name: GetSpeakerList
	local v89 = {}
	for _, v90 in pairs(p88.Speakers) do
		local v91 = v90.Name
		table.insert(v89, v91)
	end
	return v89
end
function v_u_20.RegisterFilterMessageFunction(p92, p93, p94, p95) -- name: RegisterFilterMessageFunction
	if p92.FilterMessageFunctions:HasFunction(p93) then
		error(string.format("FilterMessageFunction \'%s\' already exists", p93))
	end
	p92.FilterMessageFunctions:AddFunction(p93, p94, p95)
end
function v_u_20.FilterMessageFunctionExists(p96, p97) -- name: FilterMessageFunctionExists
	return p96.FilterMessageFunctions:HasFunction(p97)
end
function v_u_20.UnregisterFilterMessageFunction(p98, p99) -- name: UnregisterFilterMessageFunction
	if not p98.FilterMessageFunctions:HasFunction(p99) then
		error(string.format("FilterMessageFunction \'%s\' does not exists", p99))
	end
	p98.FilterMessageFunctions:RemoveFunction(p99)
end
function v_u_20.RegisterProcessCommandsFunction(p100, p101, p102, p103) -- name: RegisterProcessCommandsFunction
	if p100.ProcessCommandsFunctions:HasFunction(p101) then
		error(string.format("ProcessCommandsFunction \'%s\' already exists", p101))
	end
	p100.ProcessCommandsFunctions:AddFunction(p101, p102, p103)
end
function v_u_20.ProcessCommandsFunctionExists(p104, p105) -- name: ProcessCommandsFunctionExists
	return p104.ProcessCommandsFunctions:HasFunction(p105)
end
function v_u_20.UnregisterProcessCommandsFunction(p106, p107) -- name: UnregisterProcessCommandsFunction
	if not p106.ProcessCommandsFunctions:HasFunction(p107) then
		error(string.format("ProcessCommandsFunction \'%s\' does not exist", p107))
	end
	p106.ProcessCommandsFunctions:RemoveFunction(p107)
end
function v_u_20.GetHistoryLog(p108) -- name: GetHistoryLog
	local v109 = p108.ChatHistory
	local v110 = {}
	for v111, v112 in pairs(v109) do
		v110[v111] = v112
	end
	return v110
end
function v_u_20.GetHistoryLogForSpeaker(p113, p114) -- name: GetHistoryLogForSpeaker
	-- upvalues: (copy) v_u_16
	local v115 = p114:GetPlayer()
	local v116 = not v115 and -1 or v115.UserId
	local v117 = {}
	for v118 = 1, #p113.ChatHistory do
		if not p113:CanCommunicateByUserId(v116, p113.ChatHistory[v118].SpeakerUserId) then
			continue
		end
		local v119 = p113.ChatHistory[v118]
		local v120 = {}
		for v121, v122 in pairs(v119) do
			v120[v121] = v122
		end
		if v120.MessageType == v_u_16.MessageTypeDefault or v120.MessageType == v_u_16.MessageTypeMeCommand then
			local v123 = v120.FilterResult
			if v120.IsFilterResult then
				if v115 then
					v120.Message = v123:GetChatForUserAsync(v115.UserId)
				else
					v120.Message = v123:GetNonChatStringForBroadcastAsync()
				end
			else
				v120.Message = v123
			end
		end
		table.insert(v117, v120)
	end
	return v117
end
function v_u_20.InternalDestroy(p124) -- name: InternalDestroy
	for _, v125 in pairs(p124.Speakers) do
		v125:LeaveChannel(p124.Name)
	end
	p124.eDestroyed:Fire()
	p124.eDestroyed:Destroy()
	p124.eMessagePosted:Destroy()
	p124.eSpeakerJoined:Destroy()
	p124.eSpeakerLeft:Destroy()
	p124.eSpeakerMuted:Destroy()
	p124.eSpeakerUnmuted:Destroy()
end
function v_u_20.InternalDoMessageFilter(p126, p_u_127, p_u_128, p_u_129) -- name: InternalDoMessageFilter
	for v130, v_u_131, _ in p126.FilterMessageFunctions:GetIterator() do
		local v132, v133 = pcall(function()
			-- upvalues: (copy) v_u_131, (copy) p_u_127, (copy) p_u_128, (copy) p_u_129
			v_u_131(p_u_127, p_u_128, p_u_129)
		end)
		if v132 then
			continue
		end
		warn(string.format("DoMessageFilter Function \'%s\' failed for reason: %s", v130, v133))
	end
end
function v_u_20.InternalDoProcessCommands(p134, p_u_135, p_u_136, p_u_137) -- name: InternalDoProcessCommands
	for v138, v_u_139, _ in p134.ProcessCommandsFunctions:GetIterator() do
		local v141, v142 = pcall(function()
			-- upvalues: (copy) v_u_139, (copy) p_u_135, (copy) p_u_136, (copy) p_u_137
			local v140 = v_u_139(p_u_135, p_u_136, p_u_137)
			if type(v140) ~= "boolean" then
				error("Process command functions must return a bool")
			end
			return v140
		end)
		if v141 then
			if not v142 then
				continue
			end
			return true
		end
		warn(string.format("DoProcessCommands Function \'%s\' failed for reason: %s", v138, v142))
	end
	return false
end
function getLanguageCodeFromLocale(p143) -- name: getLanguageCodeFromLocale
	return string.gmatch(p143, "[^-]+")() or "en"
end
function v_u_20.InternalPostMessage(p_u_144, p145, p146, p147) -- name: InternalPostMessage
	-- upvalues: (ref) v_u_18, (copy) v_u_12, (ref) v_u_3, (ref) v_u_9, (ref) v_u_6
	if p_u_144:InternalDoProcessCommands(p145.Name, p146, p_u_144.Name) then
		return false
	end
	if p_u_144.Mutes[p145.Name:lower()] ~= nil then
		local v148 = p_u_144.Mutes[p145.Name:lower()]
		if v148 <= 0 or v148 >= os.time() then
			p_u_144:SendSystemMessageToSpeaker(v_u_18:FormatMessageToSend("GameChat_ChatChannel_MutedInChannel", "You are muted and cannot talk in this channel"), p145.Name)
			return false
		end
		p_u_144:UnmuteSpeaker(p145.Name)
	end
	local v_u_149 = p_u_144:InternalCreateMessageObject(p146, p145.Name, false, p147)
	v_u_149.Message = p146
	local v_u_150 = nil
	pcall(function()
		-- upvalues: (ref) v_u_150, (ref) v_u_12, (ref) v_u_149
		v_u_150 = v_u_12:InvokeChatCallback(Enum.ChatCallbackType.OnServerReceivingMessage, v_u_149)
	end)
	v_u_149.Message = nil
	if v_u_150 then
		if v_u_150.ShouldDeliver == false then
			return false
		end
		v_u_149 = v_u_150
	end
	local v151 = p_u_144:SendMessageObjToFilters(p146, v_u_149, p145)
	local v152 = {}
	for _, v153 in pairs(p_u_144.Speakers) do
		if v153:IsSpeakerMuted(p145.Name) or not p_u_144:CanCommunicate(p145, v153) then
			continue
		end
		local v154 = v153.Name
		table.insert(v152, v154)
		if v153.Name == p145.Name then
			local v155 = {}
			for v156, v157 in pairs(v_u_149) do
				v155[v156] = v157
			end
			if v_u_3 then
				local v158 = v_u_149.MessageLengthUtf8 or v_u_149.MessageLength
				v155.Message = string.rep("_", v158)
			else
				v155.Message = v151
			end
			v155.IsFiltered = true
			v153:InternalSendMessage(v155, p_u_144.Name)
		else
			v153:InternalSendMessage(v_u_149, p_u_144.Name)
		end
	end
	local v159, v160 = pcall(function()
		-- upvalues: (copy) p_u_144, (ref) v_u_149
		p_u_144.eMessagePosted:Fire(v_u_149)
	end)
	if not v159 and v160 then
		print("Error posting message: " .. v160)
	end
	local v161 = p_u_144.Private and Enum.TextFilterContext.PrivateChat or Enum.TextFilterContext.PublicChat
	local v162 = nil
	if v_u_9 then
		local v163 = {}
		local v164 = {}
		for _, v165 in pairs(p_u_144.Speakers) do
			local v166 = v165:GetPlayer()
			if v166 == nil or v166.LocaleId == nil then
				continue
			end
			v163[getLanguageCodeFromLocale(v166.LocaleId)] = true
		end
		for v167, _ in v163 do
			table.insert(v164, v167)
		end
		local v168, v169, v170 = p_u_144.ChatService:InternalApplyRobloxFilterAndTranslate(v_u_149.FromSpeaker, v164, v151, v161)
		if v168 then
			if v169 then
				v_u_149.FilterResult = v170.SourceText
			else
				v_u_149.FilterResult = v170
			end
			v_u_149.IsFilterResult = v169
			if v169 then
				v162 = v170
			end
		else
			if not v_u_6 then
				return false
			end
			v_u_149.IsFilterResult = false
			v_u_149.FilterResult = ""
			v_u_149.MessageLength = 0
		end
	else
		local v171, v172, v173 = p_u_144.ChatService:InternalApplyRobloxFilterNewAPI(v_u_149.FromSpeaker, v151, v161)
		if v171 then
			v_u_149.FilterResult = v173
			v_u_149.IsFilterResult = v172
		else
			if not v_u_6 then
				return false
			end
			v_u_149.IsFilterResult = false
			v_u_149.FilterResult = ""
			v_u_149.MessageLength = 0
		end
	end
	v_u_149.IsFiltered = true
	p_u_144:InternalAddMessageToHistoryLog(v_u_149)
	for _, v174 in pairs(v152) do
		local v175 = p_u_144.Speakers[v174]
		if not v175 then
			continue
		end
		local v176 = v_u_9
		if v176 then
			if v162 then
				if p145:GetPlayer() == nil or v175:GetPlayer() == nil then
					v176 = false
				else
					v176 = p145:GetPlayer().LocaleId ~= v175:GetPlayer().LocaleId
				end
			else
				v176 = v162
			end
		end
		if v176 then
			v175:InternalSendFilteredMessageWithTranslatedFilterResult(v_u_149, p_u_144.Name, v162)
		else
			v175:InternalSendFilteredMessageWithFilterResult(v_u_149, p_u_144.Name)
		end
	end
	local v177 = {}
	for _, v178 in pairs(p_u_144.Speakers) do
		if v178:IsSpeakerMuted(p145.Name) or not p_u_144:CanCommunicate(p145, v178) then
			continue
		end
		local v179 = false
		for _, v180 in pairs(v152) do
			if v178.Name ~= v180 then
				continue
			end
			v179 = true
		end
		if v179 then
			break
		end
		local v181 = v178.Name
		table.insert(v177, v181)
	end
	for _, v182 in pairs(v177) do
		local v183 = p_u_144.Speakers[v182]
		if not v183 then
			continue
		end
		v183:InternalSendFilteredMessageWithFilterResult(v_u_149, p_u_144.Name)
	end
	return v_u_149
end
function v_u_20.InternalAddSpeaker(p_u_184, p_u_185) -- name: InternalAddSpeaker
	if p_u_184.Speakers[p_u_185.Name] then
		warn("Speaker \"" .. p_u_185.name .. "\" is already in the channel!")
	else
		p_u_184.Speakers[p_u_185.Name] = p_u_185
		local v186, v187 = pcall(function()
			-- upvalues: (copy) p_u_184, (copy) p_u_185
			p_u_184.eSpeakerJoined:Fire(p_u_185.Name)
		end)
		if not v186 and v187 then
			print("Error removing channel: " .. v187)
		end
	end
end
function v_u_20.InternalRemoveSpeaker(p_u_188, p_u_189) -- name: InternalRemoveSpeaker
	if p_u_188.Speakers[p_u_189.Name] then
		p_u_188.Speakers[p_u_189.Name] = nil
		local v190, v191 = pcall(function()
			-- upvalues: (copy) p_u_188, (copy) p_u_189
			p_u_188.eSpeakerLeft:Fire(p_u_189.Name)
		end)
		if not v190 and v191 then
			print("Error removing speaker: " .. v191)
		end
	else
		warn("Speaker \"" .. p_u_189.name .. "\" is not in the channel!")
	end
end
function v_u_20.InternalRemoveExcessMessagesFromLog(p192) -- name: InternalRemoveExcessMessagesFromLog
	local v193 = table.remove
	while #p192.ChatHistory > p192.MaxHistory do
		v193(p192.ChatHistory, 1)
	end
end
function v_u_20.InternalAddMessageToHistoryLog(p194, p195) -- name: InternalAddMessageToHistoryLog
	local v196 = p194.ChatHistory
	table.insert(v196, p195)
	p194:InternalRemoveExcessMessagesFromLog()
end
function v_u_20.GetMessageType(_, _, p197) -- name: GetMessageType
	-- upvalues: (copy) v_u_16
	if p197 == nil then
		return v_u_16.MessageTypeSystem
	else
		return v_u_16.MessageTypeDefault
	end
end
function v_u_20.InternalCreateMessageObject(p198, p199, p200, p201, p202) -- name: InternalCreateMessageObject
	-- upvalues: (copy) v_u_15
	local v203 = p198:GetMessageType(p199, p200)
	local v204 = -1
	local v205 = nil
	local v206
	if p200 then
		v206 = p198.ChatService:GetSpeaker(p200)
		if v206 then
			local v207 = v206:GetPlayer()
			if v207 then
				v204 = v207.UserId
				if v_u_15.PlayerDisplayNamesEnabled then
					v205 = v206:GetNameForDisplay()
				end
			else
				v204 = 0
			end
		end
	else
		v206 = nil
	end
	local v208 = {
		["ID"] = p198.ChatService:InternalGetUniqueMessageId(),
		["FromSpeaker"] = p200,
		["SpeakerDisplayName"] = v205,
		["SpeakerUserId"] = v204,
		["OriginalChannel"] = p198.Name,
		["MessageLength"] = string.len(p199),
		["MessageLengthUtf8"] = utf8.len(utf8.nfcnormalize(p199)),
		["MessageType"] = v203,
		["IsFiltered"] = p201,
		["Message"] = p201 and p199 and p199 or nil,
		["Time"] = os.time(),
		["ExtraData"] = {}
	}
	if v206 then
		for v209, v210 in pairs(v206.ExtraData) do
			v208.ExtraData[v209] = v210
		end
	end
	if p202 then
		for v211, v212 in pairs(p202) do
			v208.ExtraData[v211] = v212
		end
	end
	return v208
end
function v_u_20.SetChannelNameColor(p213, p214) -- name: SetChannelNameColor
	p213.ChannelNameColor = p214
	for _, v215 in pairs(p213.Speakers) do
		v215:UpdateChannelNameColor(p213.Name, p214)
	end
end
function v_u_20.GetWelcomeMessageForSpeaker(p216, p217) -- name: GetWelcomeMessageForSpeaker
	return p216.GetWelcomeMessageFunction and p216.GetWelcomeMessageFunction(p217) or p216.WelcomeMessage
end
function v_u_20.RegisterGetWelcomeMessageFunction(p218, p219) -- name: RegisterGetWelcomeMessageFunction
	if type(p219) ~= "function" then
		error("RegisterGetWelcomeMessageFunction must be called with a function.")
	end
	p218.GetWelcomeMessageFunction = p219
end
function v_u_20.UnRegisterGetWelcomeMessageFunction(p220) -- name: UnRegisterGetWelcomeMessageFunction
	p220.GetWelcomeMessageFunction = nil
end
function v10.new(p221, p222, p223, p224) -- name: new
	-- upvalues: (copy) v_u_20, (copy) v_u_17
	local v225 = v_u_20
	local v226 = setmetatable({}, v225)
	v226.ChatService = p221
	v226.Name = p222
	v226.WelcomeMessage = p223 or ""
	v226.GetWelcomeMessageFunction = nil
	v226.ChannelNameColor = p224
	v226.Joinable = true
	v226.Leavable = true
	v226.AutoJoin = false
	v226.Private = false
	v226.Speakers = {}
	v226.Mutes = {}
	v226.MaxHistory = 200
	v226.HistoryIndex = 0
	v226.ChatHistory = {}
	v226.FilterMessageFunctions = v_u_17:NewSortedFunctionContainer()
	v226.ProcessCommandsFunctions = v_u_17:NewSortedFunctionContainer()
	v226.eDestroyed = Instance.new("BindableEvent")
	v226.eMessagePosted = Instance.new("BindableEvent")
	v226.eSpeakerJoined = Instance.new("BindableEvent")
	v226.eSpeakerLeft = Instance.new("BindableEvent")
	v226.eSpeakerMuted = Instance.new("BindableEvent")
	v226.eSpeakerUnmuted = Instance.new("BindableEvent")
	v226.MessagePosted = v226.eMessagePosted.Event
	v226.SpeakerJoined = v226.eSpeakerJoined.Event
	v226.SpeakerLeft = v226.eSpeakerLeft.Event
	v226.SpeakerMuted = v226.eSpeakerMuted.Event
	v226.SpeakerUnmuted = v226.eSpeakerUnmuted.Event
	v226.Destroyed = v226.eDestroyed.Event
	return v226
end
return v10
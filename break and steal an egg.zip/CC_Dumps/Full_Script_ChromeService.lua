local v1 = script:FindFirstAncestor("ChromeShared")
local v2 = game:GetService("CorePackages")
local v_u_3 = game:GetService("LocalizationService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = game:GetService("GamepadService")
local v6 = require(v2.Workspace.Packages.SharedFlags)
local v7 = require(v2.Workspace.Packages.AppCommonLib)
local v_u_8 = require(v2.Workspace.Packages.InExperienceLocales).Localization
local v9 = require(v2.Workspace.Packages.Chrome)
local v_u_10 = v9.Enums.SideSheetPlacement
local v_u_11 = v7.Signal
local v12 = v9.FocusUtils
local v_u_13 = v12.FocusOnChromeSignal
local v_u_14 = v12.FocusOffChromeSignal
local v_u_15 = require(v1.Service.ChromeUtils)
local v_u_16 = require(v1.Service.LocalStore)
local v_u_17 = require(v1.Service.ViewportUtil)
local v_u_18 = require(v1.Service.WindowSizeSignal)
local v_u_19 = v_u_15.ObservableValue
local v_u_20 = v_u_15.NotifySignal
local v_u_21 = v_u_15.AvailabilitySignal
local v_u_22 = require(v1.Unibar.Constants)
local v_u_23 = require(v1.Service.ShortcutService)
local v_u_24 = v6.FFlagEnableConsoleExpControls
local v_u_25 = require(v2.Workspace.Packages.SharedExperimentDefinition).isInExperienceUIVREnabled
local v_u_26 = require(v2.Workspace.Packages.PioneerUtils).isPioneerLaunch
local v_u_27 = require(v1.Parent.Flags.FFlagIntegrationsChromeShortcutTelemetry)
local v_u_28 = game:DefineFastFlag("ChromeDeprecateMRUs", false)
local v_u_29 = require(v2.Workspace.Packages.InExperienceSideSheetUtils.isSideSheetEnabled)
local v_u_30 = v6.FFlagEnableSideSheetWidgets
local v_u_31 = require(v1.Flags).FFlagEnableChromeWindowsNotInMenu
local v_u_32 = require(v1.Flags).FFlagChromeNineDotActivityIndicator
local v33 = require(v2.Workspace.Packages.InExperienceSideSheet)
local v_u_34 = v33.toggleSideSheet
local v_u_35 = v33.getSideSheetVisibility
local v_u_36 = v33.registerSideSheetIntegrations
local v_u_37 = {}
v_u_37.__index = v_u_37
v_u_37.AvailabilitySignal = v_u_15.AvailabilitySignalState
v_u_37.IntegrationStatus = {
	["None"] = 0,
	["Icon"] = 1,
	["Window"] = 2
}
function noop() -- name: noop end
local v_u_38 = {
	["id"] = "div",
	["label"] = "div",
	["initialAvailability"] = nil,
	["availability"] = nil,
	["notification"] = nil,
	["components"] = nil,
	["hideNotificationCountWhileOpen"] = false,
	["sideSheetPlacement"] = nil,
	["initialAvailability"] = v_u_37.AvailabilitySignal.Unavailable,
	["availability"] = v_u_21.new(v_u_37.AvailabilitySignal.Unavailable),
	["notification"] = v_u_20.new(),
	["components"] = {}
}
local v39
if v_u_29 then
	v39 = v_u_10.None
else
	v39 = nil
end
v_u_38.sideSheetPlacement = v39
function createUnibarLayoutInfo(p40, p41) -- name: createUnibarLayoutInfo
	return Rect.new(p40, p40 + p41)
end
function v_u_37.new() -- name: new
	-- upvalues: (copy) v_u_3, (copy) v_u_24, (copy) v_u_23, (copy) v_u_15, (copy) v_u_19, (copy) v_u_20, (copy) v_u_8, (copy) v_u_32, (copy) v_u_11, (copy) v_u_25, (copy) v_u_37, (copy) v_u_17, (copy) v_u_28, (copy) v_u_13, (copy) v_u_14
	local v42 = v_u_3.RobloxLocaleId
	local v_u_43 = {}
	local v44
	if v_u_24 then
		v44 = v_u_23.new()
	else
		v44 = nil
	end
	v_u_43._shortcutService = v44
	v_u_43._layout = v_u_15.ObservableValue.new(createUnibarLayoutInfo(Vector2.zero, Vector2.zero))
	v_u_43._menuAbsolutePosition = Vector2.zero
	v_u_43._menuAbsoluteSizeOpen = Vector2.zero
	v_u_43._currentSubMenu = v_u_15.ObservableValue.new(nil)
	v_u_43._selectedItem = v_u_15.ObservableValue.new(nil)
	v_u_43._selectedItemIdx = 0
	v_u_43._integrations = {}
	v_u_43._integrationsConnections = {}
	v_u_43._integrationsStatus = {}
	v_u_43._menuConfig = {}
	v_u_43._subMenuConfig = {}
	v_u_43._subMenuNotifications = {}
	v_u_43._menuList = v_u_19.new({})
	v_u_43._windowList = v_u_19.new({})
	v_u_43._dragConnection = {}
	v_u_43._windowPositions = v_u_19.new({})
	v_u_43._totalNotifications = v_u_20.new(true)
	v_u_43._mostRecentlyUsedAndPinnedLimit = -1
	v_u_43._localization = v_u_8.new(v42)
	v_u_43._localizedLabelKeys = {}
	v_u_43._currentShortcutBar = v_u_19.new(nil)
	v_u_43._notificationIndicator = v_u_19.new(nil)
	local v45
	if v_u_32 then
		v45 = v_u_19.new(false)
	else
		v45 = nil
	end
	v_u_43._nineDotActivityIndicatorVisible = v45
	v_u_43._nineDotActivityIndicatorKeys = v_u_32 and {} or nil
	v_u_43._orderAlignment = v_u_19.new(Enum.HorizontalAlignment.Left)
	v_u_43._onIntegrationRegistered = v_u_11.new()
	v_u_43._onIntegrationActivated = v_u_11.new()
	v_u_43._onIntegrationStatusChanged = v_u_11.new()
	v_u_43._onIntegrationHovered = v_u_11.new()
	v_u_43._triggerMenuIcon = v_u_11.new()
	local v46
	if v_u_25 then
		v46 = v_u_11.new()
	else
		v46 = nil
	end
	v_u_43._triggerVRToggleButton = v46
	local v47
	if v_u_25 then
		v47 = v_u_19.new(nil)
	else
		v47 = nil
	end
	v_u_43._topBarVisibility = v47
	v_u_43._inFocusNav = v_u_19.new(false)
	local v48 = v_u_37
	local v_u_49 = setmetatable(v_u_43, v48)
	v_u_17.viewport:connect(function(p50)
		-- upvalues: (ref) v_u_28, (copy) v_u_49
		if v_u_28 then
			v_u_49:updateWindowSizeSignals()
		else
			v_u_49:updateScreenSize(p50.size, p50.isMobileDevice, p50.portraitOrientation, p50.tinyPortrait)
		end
	end, true)
	if v_u_24 then
		v_u_43._shortcutService.onShortcutBarChanged:connect(function(p51)
			-- upvalues: (copy) v_u_49
			v_u_49._currentShortcutBar:set(p51)
		end)
	end
	if v_u_32 then
		v_u_43._currentSubMenu:connect(function()
			-- upvalues: (copy) v_u_49
			v_u_49:updateNineDotActivityIndicatorVisible()
		end)
	end
	v_u_13:connect(function(p52)
		-- upvalues: (copy) v_u_43, (copy) v_u_49
		if p52 and not v_u_43._subMenuConfig.nine_dot[p52] then
			v_u_49:setSelected(p52)
		end
		v_u_49:enableFocusNav()
	end)
	v_u_14:connect(function()
		-- upvalues: (copy) v_u_49, (ref) v_u_24
		v_u_49:disableFocusNav()
		if v_u_24 then
			v_u_49:setShortcutBar(nil)
		end
	end)
	return v_u_49
end
function v_u_37.storeChromeInteracted(_) -- name: storeChromeInteracted
	-- upvalues: (copy) v_u_16
	if v_u_16.isEnabled() then
		v_u_16.storeForLocalPlayer("ChromeInteracted3", true)
	end
end
function v_u_37.updateScreenSize(p53, _, p54, p55, p56) -- name: updateScreenSize
	-- upvalues: (copy) v_u_22
	local v57
	if p54 then
		if p56 then
			v57 = v_u_22.MOBILE_TINY_PORTRAIT_SLOTS - v_u_22.CORE_SLOTS
		elseif p55 then
			v57 = v_u_22.MOBILE_PORTRAIT_SLOTS - v_u_22.CORE_SLOTS
		else
			v57 = v_u_22.MOBILE_LANDSCAPE_SLOTS - v_u_22.CORE_SLOTS
		end
	else
		v57 = v_u_22.NON_MOBILE_SLOTS - v_u_22.CORE_SLOTS
	end
	if v57 ~= p53._mostRecentlyUsedAndPinnedLimit then
		p53._mostRecentlyUsedAndPinnedLimit = v57
		p53:updateMenuList()
		p53:updateNotificationTotals()
	end
	p53:updateWindowSizeSignals()
end
function v_u_37.updateWindowSizeSignals(p58) -- name: updateWindowSizeSignals
	for _, v59 in p58._integrations do
		if not v59.windowSize then
			continue
		end
		v59.windowSize:updateConstraints()
	end
end
function v_u_37.notificationIndicator(p60) -- name: notificationIndicator
	return p60._notificationIndicator
end
function v_u_37.nineDotActivityIndicatorVisible(p61) -- name: nineDotActivityIndicatorVisible
	return p61._nineDotActivityIndicatorVisible
end
function v_u_37.setNineDotActivityIndicatorVisible(p62, p63, p64) -- name: setNineDotActivityIndicatorVisible
	p62._nineDotActivityIndicatorKeys[p63] = p64 and true or nil
	p62:updateNineDotActivityIndicatorVisible()
end
function v_u_37.updateNineDotActivityIndicatorVisible(p65) -- name: updateNineDotActivityIndicatorVisible
	local v66 = next(p65._nineDotActivityIndicatorKeys) ~= nil
	if p65._currentSubMenu:get() == "nine_dot" then
		v66 = false
	end
	p65._nineDotActivityIndicatorVisible:set(v66)
end
function v_u_37.toggleSubMenu(p67, p68) -- name: toggleSubMenu
	-- upvalues: (copy) v_u_29, (ref) v_u_34
	if v_u_29 and v_u_34 then
		v_u_34(true)
		return
	elseif p67._subMenuConfig[p68] then
		if p67._currentSubMenu:get() == p68 then
			p67._currentSubMenu:set(nil)
		else
			p67._currentSubMenu:set(p68)
		end
	else
		warn("Not a valid subMenuId:" .. p68)
		return
	end
end
function v_u_37.currentSubMenu(p69) -- name: currentSubMenu
	return p69._currentSubMenu
end
function v_u_37.inFocusNav(p70) -- name: inFocusNav
	return p70._inFocusNav
end
function v_u_37.enableFocusNav(p71) -- name: enableFocusNav
	-- upvalues: (copy) v_u_5, (copy) v_u_24, (copy) v_u_22
	if not v_u_5.GamepadCursorEnabled then
		if not p71._inFocusNav:get() then
			p71._inFocusNav:set(true)
		end
		if v_u_24 then
			p71:setShortcutBar(v_u_22.UNIBAR_SHORTCUTBAR_ID)
		end
	end
end
function v_u_37.disableFocusNav(p72) -- name: disableFocusNav
	-- upvalues: (copy) v_u_5
	if not v_u_5.GamepadCursorEnabled then
		if p72._inFocusNav:get() then
			p72._inFocusNav:set(false)
			p72._selectedItem:set(nil)
			p72._currentSubMenu:set(nil)
		end
	end
end
function v_u_37.toggleWindow(p73, p74) -- name: toggleWindow
	-- upvalues: (copy) v_u_37, (copy) v_u_16
	if p73._integrations[p74].components.Window then
		if p73._integrationsStatus[p74] and (p73._integrationsStatus[p74] ~= v_u_37.IntegrationStatus.None and p73._integrationsStatus[p74] ~= v_u_37.IntegrationStatus.Icon) then
			p73._integrationsStatus[p74] = v_u_37.IntegrationStatus.Icon
		else
			p73._integrationsStatus[p74] = v_u_37.IntegrationStatus.Window
		end
		p73._onIntegrationStatusChanged:fire(p74, p73._integrationsStatus[p74])
	end
	if v_u_16.isEnabled() and (p73._integrations[p74] and p73._integrations[p74].persistWindowState) then
		local v75 = v_u_16.loadForLocalPlayer("ChromeWindowStatus") or {}
		v75[p74] = p73._integrationsStatus[p74] == v_u_37.IntegrationStatus.Window
		v_u_16.storeForLocalPlayer("ChromeWindowStatus", v75)
	end
	p73:updateMenuList()
end
function v_u_37.isWindowOpen(p76, p77) -- name: isWindowOpen
	-- upvalues: (copy) v_u_37
	local v78 = p76._integrations[p77].components.Window
	if v78 then
		v78 = p76._integrationsStatus[p77] == v_u_37.IntegrationStatus.Window
	end
	return v78
end
function v_u_37.menuList(p79) -- name: menuList
	return p79._menuList
end
function v_u_37.windowList(p80) -- name: windowList
	return p80._windowList
end
function v_u_37.dragConnection(p81, p82) -- name: dragConnection
	if p81._integrations[p82] then
		return p81._dragConnection[p82]
	else
		return nil
	end
end
function v_u_37.updateLocalization(p_u_83, p84) -- name: updateLocalization
	p_u_83._localizedLabelKeys[p84.id] = {}
	p_u_83._localizedLabelKeys[p84.id].label = p84.label
	local v_u_85 = p84.label
	local v86, v87 = pcall(function()
		-- upvalues: (ref) v_u_85, (copy) p_u_83
		v_u_85 = p_u_83._localization:Format(v_u_85)
	end)
	if not v86 then
		v_u_85 = p84.label
		warn(v87)
	end
	p84.label = v_u_85
	if p84.secondaryAction then
		p_u_83._localizedLabelKeys[p84.id].secondaryActionLabel = p84.secondaryAction.label
		local v_u_88 = p84.secondaryAction.label
		local v89, v90 = pcall(function()
			-- upvalues: (ref) v_u_88, (copy) p_u_83
			v_u_88 = p_u_83._localization:Format(v_u_88)
		end)
		if not v89 then
			v_u_88 = p84.secondaryAction.label
			warn(v90)
		end
		p84.secondaryAction.label = v_u_88
	end
	return p84
end
function v_u_37.register(p_u_91, p_u_92) -- name: register
	-- upvalues: (copy) v_u_29, (copy) v_u_10, (copy) v_u_37, (copy) v_u_21, (copy) v_u_20, (copy) v_u_18, (copy) v_u_22, (copy) v_u_24, (copy) v_u_5
	if p_u_91._integrations[p_u_92.id] then
		warn(string.format(p_u_92.id .. "already registered", debug.traceback()))
		for _, v93 in p_u_91._integrationsConnections[p_u_92.id] do
			v93:disconnect()
		end
	end
	p_u_91._integrationsConnections[p_u_92.id] = {}
	local v94 = p_u_91._integrationsConnections[p_u_92.id]
	if v_u_29 and p_u_92.sideSheetPlacement == nil then
		p_u_92.sideSheetPlacement = v_u_10.BelowFold
	end
	if p_u_92.initialAvailability == nil then
		p_u_92.initialAvailability = v_u_37.AvailabilitySignal.Unavailable
	end
	if p_u_92.availability == nil then
		p_u_92.availability = v_u_21.new(p_u_92.initialAvailability or v_u_37.AvailabilitySignal.Unavailable)
	end
	if p_u_92.notification == nil then
		p_u_92.notification = v_u_20.new()
	end
	if p_u_92.components == nil then
		p_u_92.components = {}
	end
	if p_u_92.availability then
		v94[#v94 + 1] = p_u_92.availability:connect(function()
			-- upvalues: (copy) p_u_91, (ref) p_u_92
			p_u_91:availabilityChanged(p_u_92)
		end)
	end
	if p_u_92.notification and not p_u_92.notification:excludeFromTotalCounts() then
		v94[#v94 + 1] = p_u_92.notification:connect(function()
			-- upvalues: (copy) p_u_91
			p_u_91:updateNotificationTotals()
		end)
	end
	if p_u_92.windowSize == nil and (p_u_92.components and p_u_92.components.Window) then
		p_u_92.windowSize = v_u_18.new()
	end
	if v_u_37:getWindowStatusFromStore(p_u_92.id) and p_u_92.persistWindowState or p_u_92.windowDefaultOpen then
		p_u_91._integrationsStatus[p_u_92.id] = v_u_37.IntegrationStatus.Window
		p_u_91._onIntegrationStatusChanged:fire(p_u_92.id, p_u_91._integrationsStatus[p_u_92.id])
	end
	local v95 = UDim2.fromOffset(v_u_22.MENU_ICON_SCREEN_SIDE_OFFSET, v_u_22.WINDOW_DEFAULT_PADDING)
	if p_u_92.startingWindowPosition then
		if p_u_92.persistWindowState then
			v95 = p_u_91:getWindowPositionFromStore(p_u_92.id) or p_u_92.startingWindowPosition
		else
			v95 = p_u_92.startingWindowPosition
		end
	end
	p_u_91._windowPositions[p_u_92.id] = v95
	local v_u_96 = p_u_91:updateLocalization(p_u_92)
	local v_u_97 = v_u_96
	p_u_91._integrations[v_u_96.id] = v_u_97
	if v_u_24 and v_u_96.selected then
		v94[#v94 + 1] = p_u_91:selectedItem():connect(function(p98)
			-- upvalues: (copy) v_u_97, (ref) v_u_5, (ref) v_u_96
			if v_u_97.id == p98 then
				if v_u_5.GamepadCursorEnabled then
					return
				end
				v_u_96.selected(v_u_97)
			end
		end)
	end
	return v_u_97
end
function v_u_37.createIconProps(p_u_99, p_u_100, p101) -- name: createIconProps
	-- upvalues: (copy) v_u_38
	local v102 = p101 or 0
	return p_u_99._integrations[p_u_100] and {
		["id"] = nil,
		["children"] = nil,
		["order"] = nil,
		["component"] = nil,
		["integration"] = nil,
		["isDivider"] = false,
		["activated"] = nil,
		["id"] = p_u_100,
		["children"] = {},
		["order"] = v102,
		["component"] = p_u_99._integrations[p_u_100].components.Icon,
		["integration"] = p_u_99._integrations[p_u_100],
		["activated"] = function() -- name: activated
			-- upvalues: (copy) p_u_99, (copy) p_u_100
			p_u_99:activate(p_u_100)
		end
	} or {
		["id"] = p_u_100,
		["children"] = {},
		["order"] = v102,
		["activated"] = noop,
		["integration"] = v_u_38
	}
end
function v_u_37.createWidgetProps(p103, p104, p105) -- name: createWidgetProps
	local v106 = p103._integrations[p104]
	return v106 and v106.components.Widget and {
		["id"] = p104,
		["children"] = {},
		["order"] = p105 or 0,
		["component"] = v106.components.Widget,
		["integration"] = v106,
		["activated"] = noop
	} or nil
end
function v_u_37.isIntegrationValid(p107, p108) -- name: isIntegrationValid
	-- upvalues: (copy) v_u_37
	local v109 = p107._integrations[p108]
	if not v109 then
		return false
	end
	local v110 = v109.availability
	if v110 then
		v110 = v110:get() ~= v_u_37.AvailabilitySignal.Unavailable
	end
	return v110
end
function v_u_37.updateMenuList(p_u_111) -- name: updateMenuList
	-- upvalues: (copy) v_u_38, (copy) v_u_29, (copy) v_u_31
	local v_u_112 = 0
	local v_u_113 = 0
	local function v_u_115(p114) -- name: iconProps
		-- upvalues: (ref) v_u_113, (copy) p_u_111
		v_u_113 = v_u_113 + 1
		return p_u_111:createIconProps(p114, v_u_113)
	end
	local function v_u_117(p116) -- name: windowProps
		-- upvalues: (ref) v_u_113, (copy) p_u_111, (ref) v_u_38
		v_u_113 = v_u_113 + 1
		return p_u_111._integrations[p116] and {
			["id"] = p116,
			["children"] = {},
			["order"] = v_u_113,
			["component"] = p_u_111._integrations[p116].components.Window,
			["activated"] = noop,
			["integration"] = p_u_111._integrations[p116]
		} or {
			["id"] = p116,
			["children"] = {},
			["order"] = v_u_113,
			["activated"] = noop,
			["integration"] = v_u_38
		}
	end
	local function v_u_118(_) -- name: divider
		-- upvalues: (ref) v_u_112, (ref) v_u_113, (ref) v_u_38
		v_u_112 = v_u_112 + 1
		v_u_113 = v_u_113 + 1
		return {
			["id"] = nil,
			["order"] = nil,
			["isDivider"] = true,
			["children"] = nil,
			["activated"] = nil,
			["integration"] = nil,
			["id"] = "DIV" .. v_u_112,
			["order"] = v_u_113,
			["children"] = {},
			["activated"] = noop,
			["integration"] = v_u_38
		}
	end
	local function v_u_136(p119, p120, p121) -- name: collectMenu
		-- upvalues: (copy) v_u_118, (ref) v_u_112, (copy) v_u_136, (ref) v_u_29, (copy) p_u_111, (ref) v_u_113, (copy) v_u_117, (copy) v_u_115
		local v122 = 0
		for v123, v124 in pairs(p119) do
			if type(v124) == "table" then
				if false then
					local v125 = p120.children
					local v126 = v_u_118(v_u_112)
					table.insert(v125, v126)
				end
				if v_u_136(v124, p120, p121) <= 0 then
					continue
				end
				local v127 = p120.children
				local v128 = v_u_118(v_u_112)
				table.insert(v127, v128)
			else
				if typeof(v124) ~= "string" then
					error((("Only tables or strings should be passed into the items list, received %* (at key %*)"):format(v124, v123)))
				end
				if v_u_29 or not p_u_111._subMenuConfig[v124] then
					if not p_u_111:isIntegrationValid(v124) then
						continue
					end
					if p_u_111:isWindowOpen(v124) then
						local v129 = v_u_117(v124)
						table.insert(p121, v129)
						local v130 = p120.children
						local v131 = v_u_115
						table.insert(v130, v131(v124))
						v122 = v122 + 1
					else
						local v132 = p120.children
						local v133 = v_u_115
						table.insert(v132, v133(v124))
						v122 = v122 + 1
					end
				else
					if not p_u_111:isIntegrationValid(v124) then
						continue
					end
					v_u_113 = v_u_113 + 1
					local v134 = p_u_111:createIconProps(v124, v_u_113)
					v122 = v122 + 1
					v_u_136(p_u_111._subMenuConfig[v124], v134, p121)
					if #v134.children <= 0 then
						continue
					end
					local v135 = p120.children
					table.insert(v135, v134)
				end
			end
		end
		return v122
	end
	local v137 = {
		["children"] = {}
	}
	local v138 = {}
	v_u_136(p_u_111._menuConfig, v137, v138)
	if v137.children[#v137.children] and v137.children[#v137.children].isDivider then
		table.remove(v137.children, #v137.children)
	end
	if v_u_31 then
		local v139 = {}
		for _, v140 in v138 do
			v139[v140.id] = true
		end
		for v141, _ in p_u_111._integrations do
			if not p_u_111:isWindowOpen(v141) or v139[v141] then
				continue
			end
			local v142 = v_u_117(v141)
			table.insert(v138, v142)
		end
	end
	p_u_111._menuList:set(v137.children)
	p_u_111._windowList:set(v138)
	p_u_111:repairSelected()
end
if v_u_29 then
	function v_u_37.updateSideSheet(p_u_143) -- name: updateSideSheet
		-- upvalues: (copy) v_u_10, (copy) v_u_30, (copy) v_u_26, (ref) v_u_36
		local v_u_144 = 0
		local v_u_145 = {}
		local v_u_146 = {}
		local v_u_147 = {}
		local v_u_148 = {}
		local v_u_149 = {}
		local v_u_150 = {}
		local function v169(p151) -- name: addIntegration
			-- upvalues: (copy) p_u_143, (ref) v_u_10, (copy) v_u_146, (ref) v_u_144, (copy) v_u_145, (copy) v_u_147, (copy) v_u_148, (ref) v_u_30, (ref) v_u_26, (copy) v_u_149, (copy) v_u_150
			local v152 = p_u_143._integrations[p151]
			if v152 and (v152.sideSheetPlacement ~= v_u_10.None and p_u_143:isIntegrationValid(p151)) then
				if v152.sideSheetPlacement == v_u_10.Unibar then
					local v153 = v_u_146
					local v154 = p_u_143
					local v155 = v_u_144
					table.insert(v153, v154:createIconProps(p151, v155))
					return
				elseif v152.sideSheetPlacement == v_u_10.AboveFold then
					local v156 = v_u_145
					local v157 = p_u_143
					local v158 = v_u_144
					table.insert(v156, v157:createIconProps(p151, v158))
					return
				elseif v152.sideSheetPlacement == v_u_10.BelowFold then
					local v159 = v_u_147
					local v160 = p_u_143
					local v161 = v_u_144
					table.insert(v159, v160:createIconProps(p151, v161))
					return
				elseif v152.sideSheetPlacement == v_u_10.SessionAction then
					local v162 = v_u_148
					local v163 = p_u_143
					local v164 = v_u_144
					table.insert(v162, v163:createIconProps(p151, v164))
				elseif v152.sideSheetPlacement == v_u_10.ScrollableContentTop then
					local v165 = (v_u_30 or v_u_26()) and p_u_143:createWidgetProps(p151, v_u_144)
					if v165 then
						local v166 = v_u_149
						table.insert(v166, v165)
						return
					end
				else
					local v167 = v152.sideSheetPlacement == v_u_10.ScrollableContentBottom and (v_u_30 or v_u_26()) and p_u_143:createWidgetProps(p151, v_u_144)
					if v167 then
						local v168 = v_u_150
						table.insert(v168, v167)
					end
				end
			else
				return
			end
		end
		local v170 = v_u_144
		for _, v171 in p_u_143._menuConfig do
			for _, v172 in v171 do
				v_u_144 = v170 + 1
				v169(v172)
				v170 = v_u_144
			end
		end
		for _, v173 in p_u_143._subMenuConfig do
			for _, v174 in v173 do
				v_u_144 = v170 + 1
				v169(v174)
				v170 = v_u_144
			end
		end
		v_u_36({
			["unibarIntegrations"] = v_u_146,
			["aboveFoldIntegrations"] = v_u_145,
			["belowFoldIntegrations"] = v_u_147,
			["sessionActionIntegrations"] = v_u_148,
			["scrollableContentTopWidgetIntegrations"] = v_u_149,
			["scrollableContentBottomWidgetIntegrations"] = v_u_150
		})
	end
end
function v_u_37.availabilityChanged(p175, _) -- name: availabilityChanged
	-- upvalues: (copy) v_u_29
	p175:updateNotificationTotals()
	p175:updateMenuList()
	if v_u_29 then
		p175:updateSideSheet()
	end
end
function v_u_37.subMenuNotifications(p176, p177) -- name: subMenuNotifications
	-- upvalues: (copy) v_u_20
	if not p176._subMenuNotifications[p177] then
		p176._subMenuNotifications[p177] = v_u_20.new(true)
	end
	return p176._subMenuNotifications[p177]
end
function v_u_37.totalNotifications(p178) -- name: totalNotifications
	return p178._totalNotifications
end
function v_u_37.onIntegrationRegistered(p179) -- name: onIntegrationRegistered
	return p179._onIntegrationRegistered
end
function v_u_37.onIntegrationActivated(p180) -- name: onIntegrationActivated
	return p180._onIntegrationActivated
end
function v_u_37.onIntegrationHovered(p181) -- name: onIntegrationHovered
	return p181._onIntegrationHovered
end
function v_u_37.onIntegrationStatusChanged(p182) -- name: onIntegrationStatusChanged
	return p182._onIntegrationStatusChanged
end
function v_u_37.integrations(p183) -- name: integrations
	return p183._integrations
end
function v_u_37.updateNotificationTotals(p184) -- name: updateNotificationTotals
	-- upvalues: (copy) v_u_37
	local v185 = 0
	for _, v186 in p184._integrations do
		if v186.availability:get() == v_u_37.AvailabilitySignal.Unavailable or (v186.availability:get() == v_u_37.AvailabilitySignal.Pinned or v186.notification:excludeFromTotalCounts()) then
			continue
		end
		local v187 = v186.notification:get()
		if not v187 or v187.type ~= "count" then
			continue
		end
		local v188 = v187.value
		local v189 = typeof(v188) == "number"
		assert(v189, "Expected count value to be number")
		v185 = v185 + v187.value
	end
	p184._totalNotifications:fireCount(v185)
	for v190, v191 in p184._subMenuNotifications do
		local v192 = p184:withinCurrentTopLevelMenu(v190)
		local v193 = 0
		if not v192 then
			continue
		end
		for _, v194 in v192.children do
			if p184:withinCurrentTopLevelMenu(v194.id) or (v194.integration.availability:get() == v_u_37.AvailabilitySignal.Unavailable or v194.integration.notification:excludeFromTotalCounts()) then
				continue
			end
			local v195 = v194.integration.notification:get()
			if not v195 or v195.type ~= "count" then
				continue
			end
			local v196 = v195.value
			local v197 = typeof(v196) == "number"
			assert(v197, "Expected count value to be number")
			v193 = v193 + v195.value
		end
		v191:fireCount(v193)
	end
end
function v_u_37.configureMenu(p198, p199) -- name: configureMenu
	p198._menuConfig = p199
	p198:updateNotificationTotals()
	p198:updateMenuList()
end
function v_u_37.configureSubMenu(p200, p201, p202) -- name: configureSubMenu
	-- upvalues: (copy) v_u_20, (copy) v_u_29
	p200._subMenuConfig[p201] = p202
	if not p200._subMenuNotifications[p201] then
		p200._subMenuNotifications[p201] = v_u_20.new(true)
	end
	p200:updateNotificationTotals()
	p200:updateMenuList()
	if v_u_29 then
		p200:updateSideSheet()
	end
end
if v_u_24 then
	function v_u_37.registerShortcut(p203, p204) -- name: registerShortcut
		-- upvalues: (copy) v_u_37
		p203._shortcutService:registerShortcut(p204)
		local v_u_205 = p203._shortcutService:getShortcut(p204.id)
		if v_u_205.integration and p203._integrations[v_u_205.integration] then
			local v_u_206 = p203._integrations[v_u_205.integration]
			if v_u_206.availability:get() == v_u_37.AvailabilitySignal.Unavailable then
				v_u_205.availability:unavailable()
			end
			v_u_206.availability:connect(function()
				-- upvalues: (copy) v_u_206, (ref) v_u_37, (copy) v_u_205
				local v207 = v_u_206.availability:get()
				if v207 == v_u_37.AvailabilitySignal.Unavailable then
					v_u_205.availability:unavailable()
				elseif v207 == v_u_37.AvailabilitySignal.Available or v207 == v_u_37.AvailabilitySignal.Pinned then
					v_u_205.availability:available()
				end
			end)
		end
	end
	function v_u_37.activateShortcut(p208, p209) -- name: activateShortcut
		-- upvalues: (copy) v_u_27
		local v210 = p208._shortcutService:getShortcut(p209)
		if v210.integration then
			if not v210.activated then
				if v_u_27 then
					p208:activate(v210.integration, {
						["fromShortcut"] = true
					})
				else
					p208:activate(v210.integration)
				end
			end
			if v_u_27 then
				p208._shortcutService:activateShortcut(p209)
				p208._onIntegrationActivated:fire(v210.integration, {
					["fromShortcut"] = true
				})
				return
			end
		else
			p208._shortcutService:activateShortcut(p209)
		end
	end
	function v_u_37.configureShortcutBar(p211, p212, p213) -- name: configureShortcutBar
		p211._shortcutService:configureShortcutBar(p212, p213)
	end
	function v_u_37.setShortcutBar(p214, p215) -- name: setShortcutBar
		p214._shortcutService:setShortcutBar(p215)
	end
	function v_u_37.getCurrentShortcutBar(p216) -- name: getCurrentShortcutBar
		return p216._currentShortcutBar
	end
	function v_u_37.getShortcutsFromBar(p217, p218) -- name: getShortcutsFromBar
		return p217._shortcutService:getShortcutsFromBar(p218, p217._integrations)
	end
	function v_u_37.getCurrentShortcuts(p219) -- name: getCurrentShortcuts
		return p219:getShortcutsFromBar(p219._currentShortcutBar:get())
	end
	function v_u_37.onShortcutBarChanged(p220) -- name: onShortcutBarChanged
		return p220._shortcutService.onShortcutBarChanged
	end
	function v_u_37.selectMenuIcon(p221) -- name: selectMenuIcon
		p221._triggerMenuIcon:fire()
	end
	function v_u_37.onTriggerMenuIcon(p222) -- name: onTriggerMenuIcon
		return p222._triggerMenuIcon
	end
	function v_u_37.setHideShortcutBar(p223, p224, p225) -- name: setHideShortcutBar
		p223._shortcutService:setHideShortcutBar(p224, p225)
	end
	function v_u_37.getHideShortcutBar(p226) -- name: getHideShortcutBar
		return p226._shortcutService:getHideShortcutBar()
	end
end
if v_u_25 then
	function v_u_37.onTriggerVRToggleButton(p227) -- name: onTriggerVRToggleButton
		return p227._triggerVRToggleButton
	end
	function v_u_37.showTopBar(p228) -- name: showTopBar
		return p228._topBarVisibility:get()
	end
	function v_u_37.getTopBarVisibiity(p229) -- name: getTopBarVisibiity
		return p229._topBarVisibility
	end
	function v_u_37.connectTopBarVisibility(p230, p231) -- name: connectTopBarVisibility
		p230._topBarVisibility = p231
	end
end
function v_u_37.gesture(p232, p233, p234, p235) -- name: gesture
	if p232._integrations[p233] then
		p232._dragConnection[p233] = {
			["connection"] = p234,
			["inputObject"] = p235
		}
	end
end
function v_u_37.withinCurrentTopLevelMenu(p236, p237) -- name: withinCurrentTopLevelMenu
	for v238, v239 in p236._menuList:get() do
		if v239.id ~= p237 then
			continue
		end
		return v239, v238
	end
	return nil, 0
end
function v_u_37.withinCurrentSubmenu(p240, p241) -- name: withinCurrentSubmenu
	local v242 = p240._currentSubMenu:get()
	if not v242 then
		return false
	end
	local v243 = nil
	for _, v244 in p240._menuList:get() do
		if v244.id ~= v242 then
			continue
		end
		v243 = v244.children
	end
	if not v243 then
		return false
	end
	for _, v245 in v243 do
		if v245.id ~= p241 then
			continue
		end
		return true
	end
	return false
end
if v_u_29 then
	function v_u_37.withinOpenSideSheet(p246, p247) -- name: withinOpenSideSheet
		-- upvalues: (ref) v_u_35, (copy) v_u_10
		if not v_u_35() then
			return false
		end
		for _, v248 in p246._integrations do
			if v248.id ~= p247 or v248.sideSheetPlacement == v_u_10.None then
				continue
			end
			return true
		end
		return false
	end
end
function v_u_37.windowPosition(p249, p250) -- name: windowPosition
	return p249._windowPositions[p250]
end
function v_u_37.updateWindowPosition(p251, p252, p253) -- name: updateWindowPosition
	-- upvalues: (copy) v_u_16
	if v_u_16.isEnabled() and (p251._integrations[p252] and p251._integrations[p252].persistWindowState) then
		local v254 = v_u_16.loadForLocalPlayer("ChromeWindowPosition") or {}
		v254[p252] = {
			p253.X.Scale,
			p253.X.Offset,
			p253.Y.Scale,
			p253.Y.Offset
		}
		v_u_16.storeForLocalPlayer("ChromeWindowPosition", v254)
	end
	p251._windowPositions[p252] = p253
end
function v_u_37.getWindowStatusFromStore(_, p255) -- name: getWindowStatusFromStore
	-- upvalues: (copy) v_u_16
	if v_u_16.isEnabled() then
		return (v_u_16.loadForLocalPlayer("ChromeWindowStatus") or {})[p255] or false
	else
		return nil
	end
end
function v_u_37.getWindowPositionFromStore(_, p256) -- name: getWindowPositionFromStore
	-- upvalues: (copy) v_u_16
	if v_u_16.isEnabled() then
		local v257 = (v_u_16.loadForLocalPlayer("ChromeWindowPosition") or {})[p256] or nil
		if v257 then
			return UDim2.new(v257[1], v257[2], v257[3], v257[4])
		else
			return nil
		end
	else
		return nil
	end
end
function v_u_37.activate(p_u_258, p_u_259, p260) -- name: activate
	-- upvalues: (copy) v_u_27, (copy) v_u_24
	local v261 = nil
	local v262
	if p_u_258._integrations[p_u_259] then
		local v_u_263 = p_u_258._integrations[p_u_259].activated
		if v_u_27 then
			p_u_258._onIntegrationActivated:fire(p_u_259, p260)
		else
			p_u_258._onIntegrationActivated:fire(p_u_259)
		end
		p_u_258:storeChromeInteracted()
		if v_u_263 then
			local v264
			v264, v262 = pcall(function()
				-- upvalues: (copy) v_u_263, (copy) p_u_258, (copy) p_u_259, (ref) v_u_24
				v_u_263(p_u_258._integrations[p_u_259])
				if not v_u_24 then
					p_u_258:disableFocusNav()
				end
			end)
			if v264 then
				v262 = v261
			else
				warn("ChromeService: activate error thrown for " .. p_u_259)
			end
		else
			if p_u_258._subMenuConfig[p_u_259] then
				p_u_258:toggleSubMenu(p_u_259)
			end
			p_u_258:toggleWindow(p_u_259)
			v262 = v261
		end
		if p_u_258._currentSubMenu:get() ~= p_u_259 then
			p_u_258._currentSubMenu:set(nil)
		end
	else
		v262 = v261
	end
	if v262 then
		error(v262)
	end
end
function v_u_37.selectedItem(p265) -- name: selectedItem
	return p265._selectedItem
end
function v_u_37.setSelected(p266, p267) -- name: setSelected
	-- upvalues: (copy) v_u_4
	local v268, v269 = p266:withinCurrentTopLevelMenu(p267 or "")
	if v268 then
		local v270 = v_u_4:GetLastInputType()
		local v271 = v270 == Enum.UserInputType.MouseButton1 and true or v270 == Enum.UserInputType.Touch
		local v272 = p266._currentSubMenu:get()
		if v272 and (v272 ~= p267 and not v271) then
			p266:toggleSubMenu(v272)
		end
		p266._selectedItemIdx = v269
		p266._selectedItem:set(p267)
	end
end
function v_u_37.setSelectedByOffset(p273, p274) -- name: setSelectedByOffset
	local v275 = p273._menuList:get()
	local _, v276 = p273:withinCurrentTopLevelMenu(p273._selectedItem:get() or "")
	if v276 > 0 then
		local v277 = v276 + p274
		local v278 = #v275
		p273:setSelected(v275[math.clamp(v277, 1, v278)].id)
	end
end
function v_u_37.repairSelected(p279) -- name: repairSelected
	if p279._selectedItem:get() then
		local _, v280 = p279:withinCurrentTopLevelMenu(p279._selectedItem:get() or "")
		if v280 == 0 then
			v280 = p279._selectedItemIdx
		end
		local v281 = p279._menuList:get()
		local v282 = #v281
		p279:setSelected(v281[math.clamp(v280, 1, v282)].id)
	end
end
function v_u_37.configureOrderAlignment(p283, p284) -- name: configureOrderAlignment
	if p283._orderAlignment:get() ~= p284 then
		p283._orderAlignment:set(p284)
		p283:updateMenuList()
	end
end
function v_u_37.orderAlignment(p285) -- name: orderAlignment
	return p285._orderAlignment
end
function v_u_37.setMenuAbsolutePosition(p286, p287) -- name: setMenuAbsolutePosition
	if p287 ~= p286._menuAbsolutePosition then
		p286._menuAbsolutePosition = p287
		p286._layout:set(createUnibarLayoutInfo(p287, p286._menuAbsoluteSizeOpen))
	end
end
function v_u_37.setMenuAbsoluteSize(p288, p289) -- name: setMenuAbsoluteSize
	if p289 ~= p288._menuAbsoluteSizeOpen then
		p288._menuAbsoluteSizeOpen = p289
		p288._layout:set(createUnibarLayoutInfo(p288._menuAbsolutePosition, p289))
	end
end
function v_u_37.layout(p290) -- name: layout
	return p290._layout
end
return v_u_37
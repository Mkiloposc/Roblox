local v1 = game:GetService("Chat"):WaitForChild("ClientChatModules")
local v_u_2 = require(v1:WaitForChild("ChatConstants"))
local v3, v4 = pcall(function()
	return UserSettings():IsUserFeatureEnabled("UserAddChatThrottlingToAllChannels")
end)
if not v3 then
	v4 = false
end
local v_u_5 = not v4
local v_u_6 = {}
local v_u_7 = {}
local v_u_8 = nil
pcall(function()
	-- upvalues: (ref) v_u_8
	v_u_8 = require(game:GetService("Chat").ClientChatModules.ChatLocalization)
end)
v_u_8 = v_u_8 == nil and {} or v_u_8
if not (v_u_8.FormatMessageToSend and v_u_8.LocalizeFormattedMessage) then
	function v_u_8.FormatMessageToSend(_, _, p9) -- name: FormatMessageToSend
		return p9
	end
end
return function(p_u_10) -- name: Run
	-- upvalues: (copy) v_u_7, (copy) v_u_6, (ref) v_u_5, (ref) v_u_8, (copy) v_u_2
	p_u_10:RegisterProcessCommandsFunction("flood_detection", function(p11, _, p12) -- name: FloodDetectionProcessCommandsFunction
		-- upvalues: (ref) v_u_7, (copy) p_u_10, (ref) v_u_6, (ref) v_u_5, (ref) v_u_8
		if v_u_7[p11] then
			return false
		end
		local v13 = p_u_10:GetSpeaker(p11)
		if not v13 then
			return false
		end
		if not v13:GetPlayer() then
			return false
		end
		if not v_u_6[p11] then
			v_u_6[p11] = {}
		end
		local v14
		if v_u_5 then
			if not v_u_6[p11][p12] then
				v_u_6[p11][p12] = {}
			end
			v14 = v_u_6[p11][p12]
		else
			v14 = v_u_6[p11]
		end
		local v15 = tick()
		while #v14 > 0 and v14[1] < v15 do
			table.remove(v14, 1)
		end
		if #v14 < 7 then
			local v16 = tick() + 15
			table.insert(v14, v16)
			return false
		end
		local v17 = v14[1] - v15
		local v18 = math.ceil(v17)
		v13:SendSystemMessage(v_u_8:FormatMessageToSend("GameChat_ChatFloodDetector_MessageDisplaySeconds", string.format("You must wait %d %s before sending another message!", v18, v18 > 1 and "seconds" or "second"), "RBX_NUMBER", (tostring(v18))), p12)
		return true
	end, v_u_2.LowPriority)
	p_u_10.SpeakerRemoved:connect(function(p19)
		-- upvalues: (ref) v_u_6
		v_u_6[p19] = nil
	end)
end
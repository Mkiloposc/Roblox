return {
	["IdleSeconds"] = 1080,
	["CheckIntervalSeconds"] = 2,
	["RetrySeconds"] = 25,
	["ServerCooldownSeconds"] = 15,
	["ReturnTtlSeconds"] = 300,
	["MemoryStoreMapName"] = "AntiAfkReturn",
	["TreadmillResumeTimeoutSeconds"] = 20,
	["TreadmillResumeResyncSeconds"] = nil,
	["TreadmillResumeResyncSeconds"] = { 1, 3 }
}
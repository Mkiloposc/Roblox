local v_u_1 = game:GetService("GuiService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = require(v2.Shared.BackpackUiConfig)
local v_u_6 = require(v2.Shared.EggRewards)
local v_u_7 = require(v2.Shared.FormatNumber)
local v_u_8 = require(v2.Shared.RarityGradientFX)
local v_u_9 = require(v2.Shared.WeightTag)
local v_u_10 = require(script.Parent.BackpackSlotVisuals)
local v_u_11 = {}
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = nil
local v_u_20 = nil
local v_u_21 = nil
function v_u_11.Init(p22) -- name: Init
	-- upvalues: (copy) v_u_5, (ref) v_u_21, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (ref) v_u_15, (ref) v_u_16, (ref) v_u_17, (ref) v_u_19, (ref) v_u_18
	local v23 = p22:FindFirstChild(v_u_5.AnimalInfoName, true)
	if v23 and v23:IsA("GuiObject") then
		if v_u_21 then
			v_u_21:Disconnect()
			v_u_21 = nil
		end
		local v24 = v23:FindFirstChild("List") or v23
		v_u_12 = v23
		v_u_13 = v23:FindFirstAncestorWhichIsA("ScreenGui")
		local v25 = v24:FindFirstChild("AnimalName")
		if not (v25 and v25:IsA("TextLabel")) then
			v25 = nil
		end
		v_u_14 = v25
		local v26 = v24:FindFirstChild("Rarity")
		if not (v26 and v26:IsA("TextLabel")) then
			v26 = nil
		end
		v_u_15 = v26
		local v27 = v24:FindFirstChild("Earnings")
		if not (v27 and v27:IsA("TextLabel")) then
			v27 = nil
		end
		v_u_16 = v27
		v_u_17 = v23.Size
		if v_u_15 then
			v_u_19 = v_u_15.TextColor3
			local v28 = v_u_15:FindFirstChildWhichIsA("UIGradient")
			local v29
			if v28 then
				v29 = v28:Clone()
			else
				v29 = nil
			end
			v_u_18 = v29
		end
		v23.Visible = false
	else
		warn((("[BackpackAnimalInfo] no authored %* frame inside %*"):format(v_u_5.AnimalInfoName, (p22:GetFullName()))))
	end
end
local function v_u_33(p30, p31) -- name: paintRarity
	-- upvalues: (copy) v_u_8, (ref) v_u_19, (ref) v_u_18
	for _, v32 in p30:GetChildren() do
		if not v32:IsA("UIGradient") then
			continue
		end
		v_u_8.Detach(v32)
		v32:Destroy()
	end
	if not (p31 and v_u_8.ApplyToLabel(p30, p31)) then
		if v_u_19 then
			p30.TextColor3 = v_u_19
		end
		if v_u_18 then
			v_u_18:Clone().Parent = p30
		end
	end
end
local function v_u_37(p34) -- name: rarityOf
	-- upvalues: (copy) v_u_6
	local v35 = p34:GetAttribute("Rarity")
	if typeof(v35) ~= "string" then
		local v36 = p34:GetAttribute("AnimalName")
		if typeof(v36) == "string" then
			v35 = v_u_6.RarityOf(v36)
		else
			v35 = nil
		end
	end
	if typeof(v35) == "string" then
		return v35
	else
		return nil
	end
end
local function v_u_40(p38) -- name: cashPerSecond
	-- upvalues: (copy) v_u_6
	local v39 = p38:GetAttribute("AnimalName")
	if typeof(v39) == "string" then
		return v_u_6.PlacedCashPerSecond(v39, p38:GetAttribute("SizeMult"), p38:GetAttribute("Mutation"), p38:GetAttribute("WeightKg"), (p38:GetAttribute("Variant")))
	else
		return nil
	end
end
local v_u_41 = nil
local function v_u_57() -- name: updatePosition
	-- upvalues: (ref) v_u_12, (ref) v_u_13, (ref) v_u_41, (copy) v_u_1, (copy) v_u_4, (copy) v_u_5
	local v42 = v_u_12
	local v43 = v_u_13
	if v42 and v43 then
		if v42.Parent then
			local v44
			if v43.IgnoreGuiInset then
				v44 = Vector2.zero
			else
				v44 = v_u_1:GetGuiInset()
			end
			local v45 = v_u_4:GetMouseLocation() - v44
			local v46 = v43.AbsoluteSize
			local v47 = v42.AbsoluteSize
			local v48 = v_u_5.AnimalInfoCursorGap
			local v49 = v45.X + v48
			if v49 + v47.X > v46.X then
				v49 = v45.X - v48 - v47.X
			end
			local v50 = v46.X - v47.X
			local v51 = math.max(v50, 0)
			local v52 = math.clamp(v49, 0, v51)
			local v53 = v45.Y - v47.Y / 2
			local v54 = v46.Y - v47.Y
			local v55 = math.max(v54, 0)
			local v56 = math.clamp(v53, 0, v55)
			v42.AnchorPoint = Vector2.zero
			v42.Position = UDim2.fromOffset(v52, v56)
		else
			v_u_41()
		end
	else
		return
	end
end
v_u_41 = function() -- name: stopFollowing
	-- upvalues: (ref) v_u_21
	if v_u_21 then
		v_u_21:Disconnect()
		v_u_21 = nil
	end
end
function v_u_11.Show(p58) -- name: Show
	-- upvalues: (ref) v_u_12, (copy) v_u_10, (copy) v_u_11, (ref) v_u_14, (copy) v_u_5, (copy) v_u_9, (ref) v_u_15, (copy) v_u_33, (copy) v_u_37, (ref) v_u_16, (copy) v_u_40, (copy) v_u_7, (ref) v_u_17, (ref) v_u_20, (ref) v_u_21, (copy) v_u_57, (copy) v_u_3
	local v59 = v_u_12
	if v59 then
		if p58 and (v_u_10.IsPet(p58) or v_u_10.IsEgg(p58)) then
			local v60 = v_u_10.IsEgg(p58)
			local v61 = p58:GetAttribute("WeightKg")
			local v62 = typeof(v61) == "number"
			local v63 = v_u_10.DisplayName(p58)
			if v_u_14 then
				local v64 = v_u_14
				if not v60 and v62 then
					v63 = string.format(v_u_5.AnimalInfoNameFormat, v63, v_u_9.FormatKg(v61))
				end
				v64.Text = v63
			end
			if v_u_15 then
				if v60 then
					v_u_15.Text = not v62 and "" or string.format(v_u_5.WeightFormat, v_u_9.FormatKg(v61))
					v_u_15.Visible = v62
					v_u_33(v_u_15, nil)
				else
					local v65 = v_u_37(p58)
					v_u_15.Text = v65 or ""
					v_u_15.Visible = v65 ~= nil
					v_u_33(v_u_15, v65)
				end
			end
			if v_u_16 then
				local v66
				if v60 then
					v66 = nil
				else
					v66 = v_u_40(p58)
				end
				v_u_16.Text = not v66 and "" or string.format(v_u_5.AnimalInfoEarningsFormat, v_u_7.Short(v66))
				v_u_16.Visible = v66 ~= nil
			end
			if v_u_17 then
				local v67 = v_u_17
				if v60 then
					local v68 = v_u_5.AnimalInfoEggScale
					v67 = UDim2.new(v67.X.Scale * v68, v67.X.Offset * v68, v67.Y.Scale * v68, v67.Y.Offset * v68)
				end
				v59.Size = v67
			end
			v_u_20 = p58
			if not v_u_21 then
				v_u_57()
				v_u_21 = v_u_3.RenderStepped:Connect(v_u_57)
			end
			v59.Visible = true
		else
			v_u_11.Hide()
		end
	else
		return
	end
end
function v_u_11.Refresh(p69) -- name: Refresh
	-- upvalues: (ref) v_u_20, (copy) v_u_11
	if v_u_20 == p69 then
		v_u_11.Show(p69)
	end
end
function v_u_11.Hide(p70) -- name: Hide
	-- upvalues: (ref) v_u_20, (ref) v_u_41, (ref) v_u_12
	if not p70 or v_u_20 == p70 then
		v_u_20 = nil
		v_u_41()
		if v_u_12 then
			v_u_12.Visible = false
		end
	end
end
return v_u_11
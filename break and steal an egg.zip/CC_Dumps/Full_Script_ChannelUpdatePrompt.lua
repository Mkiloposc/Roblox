local v_u_1 = game:GetService("CoreGui").RobloxGui
local v2 = game:GetService("CorePackages")
local v_u_3 = game:GetService("NotificationService")
local v_u_4 = game:GetService("HttpService")
local v_u_5 = game:GetService("AppUpdateService")
local v_u_6 = require(v_u_1.Modules.ErrorPrompt)
local v_u_7 = require(v2.Workspace.Packages.RobloxTranslator)
local function v_u_8() -- name: performUpdate
	-- upvalues: (copy) v_u_5
	v_u_5:PerformManagedUpdate()
end
return {
	["init"] = function() -- name: init
		-- upvalues: (copy) v_u_6, (copy) v_u_1, (copy) v_u_7, (copy) v_u_8, (copy) v_u_3, (copy) v_u_4, (copy) v_u_5
		local v_u_9 = v_u_6.new("Default", {
			["MessageTextScaled"] = true,
			["HideErrorCode"] = true,
			["MenuIsOpenKey"] = "ChannelUpdatePrompt"
		})
		v_u_9:setParent(v_u_1)
		local function v_u_22(p10, p11) -- name: showUpdatePrompt
			-- upvalues: (ref) v_u_7, (copy) v_u_9
			local v12 = p11 or ""
			local v13
			if p10 == "BetaProgram" then
				v13 = "An update is required for the Beta Program you are in: \"" .. v12 .. "\"."
				local v_u_14 = {
					["RBX_NAME"] = v12
				}
				local v_u_15 = "InGame.ChannelUpdatePrompt.Message.BetaProgram"
				local v16, v17 = pcall(function()
					-- upvalues: (ref) v_u_7, (copy) v_u_15, (copy) v_u_14
					return v_u_7:FormatByKey(v_u_15, v_u_14)
				end)
				if v16 then
					v13 = v17 or v13
				end
			else
				if p10 ~= "BoundChannel" then
					warn("ChannelUpdatePrompt: unknown updateType \'" .. tostring(p10) .. "\', skipping prompt")
					return
				end
				v13 = "An update is required for the channel you are bound to: \"" .. v12 .. "\"."
				local v_u_18 = {
					["RBX_NAME"] = v12
				}
				local v_u_19 = "InGame.ChannelUpdatePrompt.Message.BoundChannel"
				local v20, v21 = pcall(function()
					-- upvalues: (ref) v_u_7, (copy) v_u_19, (copy) v_u_18
					return v_u_7:FormatByKey(v_u_19, v_u_18)
				end)
				if v20 then
					v13 = v21 or v13
				end
			end
			v_u_9:_open(v13)
		end
		v_u_9:updateButtons({
			{
				["Text"] = "Restart Now",
				["LocalizationKey"] = "InGame.CommonUI.Button.RestartNow",
				["LayoutOrder"] = 1,
				["Callback"] = nil,
				["Primary"] = true,
				["Callback"] = v_u_8
			}
		})
		v_u_9:setErrorTitle("Update Required", "InGame.CommonUI.Title.UpdateRequired")
		local v_u_23 = v_u_1.AbsoluteSize.X
		local v_u_24 = v_u_1.AbsoluteSize.Y
		local function v27() -- name: onScreenSizeChanged
			-- upvalues: (ref) v_u_1, (ref) v_u_23, (ref) v_u_24, (copy) v_u_9
			local v25 = v_u_1.AbsoluteSize.X
			local v26 = v_u_1.AbsoluteSize.Y
			if v_u_23 ~= v25 or v_u_24 ~= v26 then
				v_u_23 = v25
				v_u_24 = v26
				v_u_9:resizeWidthAndHeight(v_u_23, v_u_24)
			end
		end
		v_u_1:GetPropertyChangedSignal("AbsoluteSize"):Connect(v27)
		local v28 = v_u_1.AbsoluteSize.X
		local v29 = v_u_1.AbsoluteSize.Y
		if v_u_23 ~= v28 or v_u_24 ~= v29 then
			v_u_23 = v28
			v_u_24 = v29
			v_u_9:resizeWidthAndHeight(v_u_23, v_u_24)
		end
		v_u_3.RobloxEventReceived:Connect(function(p30)
			-- upvalues: (ref) v_u_4, (copy) v_u_22
			if p30.namespace == "ChannelUpdateRequired" then
				local v31 = v_u_4:JSONDecode(p30.detail)
				local v32 = v31.updateType
				local v33
				if v32 == "BetaProgram" then
					v33 = v31.betaProgramName
				elseif v32 == "BoundChannel" then
					v33 = v31.channelName
				else
					v33 = nil
				end
				v_u_22(v31.updateType, v33)
			end
		end)
		local v34, v35 = pcall(function()
			-- upvalues: (ref) v_u_5
			return v_u_5:GetProtocolLaunchUpdateType()
		end)
		local v36, v37 = pcall(function()
			-- upvalues: (ref) v_u_5
			return v_u_5:GetProtocolLaunchUpdateName()
		end)
		if v34 and v35 ~= "" then
			v_u_22(v35, v36 and v37 and v37 or "")
		end
	end
}
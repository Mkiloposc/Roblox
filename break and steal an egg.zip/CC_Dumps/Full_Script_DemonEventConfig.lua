local v_u_8 = {
	["CurrencyName"] = "Fallen Tokens",
	["BalanceAttribute"] = "DemonTokens",
	["RemoteName"] = "DemonEventRequest",
	["TokenIcon"] = "rbxassetid://72991528594731",
	["BossReward"] = nil,
	["Eggs"] = nil,
	["EggTabOffer"] = "Demon",
	["PotionOfferSeconds"] = 600,
	["PotionOffers"] = nil,
	["RequiredSpeedPower"] = 750000000,
	["SpeedPowerAttribute"] = "SpeedPower",
	["FurnaceUnlockedAttribute"] = "FurnaceUnlocked",
	["FurnacePromptObjectText"] = "Mysterious Egg Incubator",
	["FurnaceLockedActionText"] = "Locked",
	["FurnaceUnlockedActionText"] = "Interact",
	["BossReward"] = {
		["Min"] = 150,
		["Max"] = 750
	},
	["Eggs"] = {
		["Demon"] = {
			["EggType"] = "Demon",
			["Price"] = 500
		}
	},
	["PotionOffers"] = {
		{
			["PotionId"] = "Swing",
			["Price"] = 400,
			["Quantity"] = 1
		},
		{
			["PotionId"] = "EggGrowth",
			["Price"] = 325,
			["Quantity"] = 1
		},
		{
			["PotionId"] = "Cash",
			["Price"] = 275,
			["Quantity"] = 1
		},
		{
			["PotionId"] = "Treadmill",
			["Price"] = 250,
			["Quantity"] = 1
		},
		{
			["PotionId"] = "WalkSpeed",
			["Price"] = 150,
			["Quantity"] = 1
		}
	},
	["PotionOffer"] = function(p1) -- name: PotionOffer
		-- upvalues: (copy) v_u_8
		if typeof(p1) ~= "string" then
			return nil
		end
		for _, v2 in v_u_8.PotionOffers do
			if v2.PotionId ~= p1 then
				continue
			end
			return v2
		end
		return nil
	end,
	["BossRewardFor"] = function(p3) -- name: BossRewardFor
		-- upvalues: (copy) v_u_8
		local v4 = v_u_8.BossReward
		local v5 = p3 ~= p3 and 0 or p3
		local v6 = math.clamp(v5, 0, 1)
		local v7 = v4.Min + (v4.Max - v4.Min) * v6 + 0.5
		return math.floor(v7)
	end
}
return v_u_8
return {
	["ThrottleUpdateEventName"] = "AvatarChatThrottleUpdateEvent"
}
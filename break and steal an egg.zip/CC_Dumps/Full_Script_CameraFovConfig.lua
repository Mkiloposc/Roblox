return {
	["DefaultFov"] = 70,
	["MinFov"] = 1,
	["MaxFov"] = 120,
	["StrayResetDelay"] = 1.5
}
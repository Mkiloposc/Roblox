local v1 = {
	["Enabled"] = true,
	["GroupId"] = require(script.Parent.GroupRewardConfig).GroupId,
	["AttributeName"] = "ChatTag",
	["Order"] = { "ContentCreator" }
}
local v2 = {
	["ContentCreator"] = {
		["Text"] = "[Content Creator]",
		["RoleIds"] = nil,
		["Ranks"] = nil,
		["Roles"] = nil,
		["Color"] = "#FF3B3B",
		["Gradient"] = nil,
		["GradientRotation"] = 0,
		["RoleIds"] = { 893480064 },
		["Ranks"] = { 2 },
		["Roles"] = { "Content Creator" },
		["Gradient"] = ColorSequence.new({ ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 50, 70)), ColorSequenceKeypoint.new(0.5, Color3.fromRGB(255, 80, 190)), ColorSequenceKeypoint.new(1, Color3.fromRGB(190, 90, 255)) })
	}
}
v1.Tags = v2
return v1
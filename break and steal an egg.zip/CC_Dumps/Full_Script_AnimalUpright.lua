local v_u_15 = {
	["YawOnly"] = function(p1) -- name: YawOnly
		local v2 = p1.LookVector
		local v3 = v2.X
		local v4 = v2.Z
		local v5 = Vector3.new(v3, 0, v4)
		if v5.Magnitude < 0.0001 then
			local v6 = p1.UpVector
			local v7 = v2.Y > 0 and -1 or 1
			local v8 = v6.X
			local v9 = v6.Z
			v5 = Vector3.new(v8, 0, v9) * v7
		end
		if v5.Magnitude < 0.0001 then
			return CFrame.identity
		else
			return CFrame.lookAt(Vector3.new(0, 0, 0), v5.Unit)
		end
	end,
	["AlignPivotToMesh"] = function(p10, p11) -- name: AlignPivotToMesh
		-- upvalues: (copy) v_u_15
		local v12 = p10:GetPivot()
		if (v12.Rotation:Inverse() * p11.CFrame.Rotation).UpVector.Y > 0.999 then
			return false
		end
		local v13 = CFrame.new(v12.Position) * v_u_15.YawOnly(p11.CFrame.Rotation)
		local v14 = p10.PrimaryPart
		if v14 then
			v14.PivotOffset = v14.CFrame:Inverse() * v13
		else
			p10.WorldPivot = v13
		end
		return true
	end
}
return v_u_15
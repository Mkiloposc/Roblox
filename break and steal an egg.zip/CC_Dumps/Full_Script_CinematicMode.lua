local v1 = game:GetService("Players")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = game:GetService("Workspace")
local v_u_4 = v1.LocalPlayer
local v5 = {}
local v_u_6 = nil
local v_u_7 = {}
local v_u_8 = {}
local function v_u_22(p9, p10, p11) -- name: setBars
	-- upvalues: (copy) v_u_4, (ref) v_u_6, (copy) v_u_2
	local v_u_12
	if p9.BarsGui then
		v_u_12 = v_u_4:FindFirstChildOfClass("PlayerGui")
		if v_u_12 then
			v_u_12 = v_u_12:FindFirstChild(p9.BarsGui)
		end
		if not (v_u_12 and v_u_12:IsA("ScreenGui")) then
			v_u_12 = nil
		end
	else
		v_u_12 = nil
	end
	if v_u_12 then
		if p10 then
			v_u_12.Enabled = true
		elseif p11 then
			v_u_12.Enabled = false
		else
			task.delay(p9.BarsTime, function()
				-- upvalues: (ref) v_u_6, (copy) v_u_12
				if not v_u_6 then
					v_u_12.Enabled = false
				end
			end)
		end
		local v13 = TweenInfo.new(p11 and 0 or p9.BarsTime, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
		for _, v14 in { "Top", "Bottom" } do
			local v15 = v_u_12:FindFirstChild(v14)
			if not (v15 and v15:IsA("GuiObject")) then
				continue
			end
			local v16 = v14 == "Top" and 0 or 1
			local v17
			if v14 == "Top" then
				v17 = -v15.Size.Y.Scale
			else
				v17 = 1 + v15.Size.Y.Scale
			end
			local v18 = UDim2.new
			local v19 = v15.Position.X.Scale
			local v20 = v15.Position.X.Offset
			if p10 then
				v17 = v16
			end
			local v21 = v18(v19, v20, v17, 0)
			if p11 then
				v15.Position = v21
			else
				v_u_2:Create(v15, v13, {
					["Position"] = v21
				}):Play()
			end
		end
	end
end
local function v_u_30(p23) -- name: hideInTheWay
	-- upvalues: (copy) v_u_3, (copy) v_u_8
	for _, v24 in p23 do
		local v25 = v_u_3
		for _, v26 in v24 do
			if not v25 then
				continue
			end
			v25 = v25:FindFirstChild(v26)
		end
		if not v25 then
			break
		end
		for _, v27 in v25:GetDescendants() do
			if not (v27:IsA("BasePart") or (v27:IsA("Decal") or v27:IsA("Texture"))) then
				continue
			end
			v27.LocalTransparencyModifier = 1
			local v28 = v_u_8
			table.insert(v28, v27)
		end
		if not v25:IsA("BasePart") then
			break
		end
		v25.LocalTransparencyModifier = 1
		local v29 = v_u_8
		table.insert(v29, v25)
	end
end
function v5.IsActive() -- name: IsActive
	-- upvalues: (ref) v_u_6
	return v_u_6 ~= nil
end
function v5.ParkBars(p31) -- name: ParkBars
	-- upvalues: (ref) v_u_6, (copy) v_u_22
	if not v_u_6 then
		v_u_22(p31, false, true)
	end
end
function v5.Enter(p32) -- name: Enter
	-- upvalues: (ref) v_u_6, (copy) v_u_30, (copy) v_u_22, (copy) v_u_4, (copy) v_u_7
	if v_u_6 then
		return false
	end
	v_u_6 = p32
	if p32.HideInCutscene then
		v_u_30(p32.HideInCutscene)
	end
	v_u_22(p32, false, true)
	local v33 = v_u_4:FindFirstChildOfClass("PlayerGui")
	if v33 then
		for _, v34 in v33:GetChildren() do
			if not v34:IsA("ScreenGui") or (v34.Name == p32.BarsGui or not v34.Enabled) then
				continue
			end
			v_u_7[v34] = true
			v34.Enabled = false
		end
	end
	v_u_22(p32, true)
	return true
end
function v5.Exit() -- name: Exit
	-- upvalues: (ref) v_u_6, (copy) v_u_8, (copy) v_u_7, (copy) v_u_22
	local v35 = v_u_6
	if v35 then
		v_u_6 = nil
		for _, v36 in v_u_8 do
			if not v36.Parent then
				continue
			end
			v36.LocalTransparencyModifier = 0
		end
		table.clear(v_u_8)
		for v37 in v_u_7 do
			if not v37.Parent then
				continue
			end
			v37.Enabled = true
		end
		table.clear(v_u_7)
		v_u_22(v35, false)
	end
end
return v5
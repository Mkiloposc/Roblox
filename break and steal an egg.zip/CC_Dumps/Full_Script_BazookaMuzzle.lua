local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Shared.RranBossConfig)
local v_u_20 = {
	["Get"] = function(p4) -- name: Get
		-- upvalues: (copy) v_u_3
		local v5 = p4:FindFirstChild(v_u_3.LauncherName)
		local v6 = p4.PrimaryPart
		if not (v5 and v6) then
			return nil, nil
		end
		if v5:IsA("Model") then
			local v7 = v5:FindFirstChild(v_u_3.MuzzlePartName, true)
			if not (v7 and v7:IsA("BasePart")) then
				return nil, nil
			end
			local v8 = v5:GetBoundingBox().Position
			local v9 = v7.Position - v8
			if v9.Magnitude < 0.001 then
				v9 = v6.CFrame.LookVector
			end
			return v7.Position, v9.Unit
		end
		if not v5:IsA("BasePart") then
			return nil, nil
		end
		local v10 = v5.Size
		local v11 = v5.CFrame
		local v12 = v11.LookVector
		local v13 = v10.Z / 2
		if v10.X > v10.Y and v10.X > v10.Z then
			v12 = v11.RightVector
			v13 = v10.X / 2
		elseif v10.Y > v10.X and v10.Y > v10.Z then
			v12 = v11.UpVector
			v13 = v10.Y / 2
		end
		if v12:Dot(v6.CFrame.LookVector + Vector3.new(0, 0.5, 0)) < 0 then
			v12 = -v12
		end
		return v5.Position + v12 * v13, v12
	end,
	["Nearest"] = function(p14, p15) -- name: Nearest
		-- upvalues: (copy) v_u_1, (copy) v_u_3, (copy) v_u_20
		local v16 = nil
		for _, v17 in v_u_1:GetTagged(v_u_3.Tag) do
			if not v17:IsA("Model") then
				continue
			end
			local v18 = v_u_20.Get(v17)
			local v19 = not v18 and (1 / 0) or (v18 - p14).Magnitude
			if v19 >= p15 then
				continue
			end
			v16 = v17
			p15 = v19
		end
		return v16
	end
}
return v_u_20
local v1 = {}
local v_u_2 = game:GetService("Players")
game:GetService("Chat")
local v_u_3 = v_u_2.LocalPlayer:WaitForChild("PlayerGui")
local v_u_4 = game:GetService("Chat")
local v5 = v_u_4:WaitForChild("ClientChatModules")
local v6 = script.Parent
local v_u_7 = require(v6:WaitForChild("ChatChannel"))
local v_u_8 = require(v5:WaitForChild("ChatSettings"))
local v_u_9 = require(v6:WaitForChild("CurveUtil"))
local v_u_10 = {}
v_u_10.__index = v_u_10
function getClassicChatEnabled() -- name: getClassicChatEnabled
	-- upvalues: (copy) v_u_8, (copy) v_u_2
	if v_u_8.ClassicChatEnabled == nil then
		return v_u_2.ClassicChat
	else
		return v_u_8.ClassicChatEnabled
	end
end
function getBubbleChatEnabled() -- name: getBubbleChatEnabled
	-- upvalues: (copy) v_u_8, (copy) v_u_2
	if v_u_8.BubbleChatEnabled == nil then
		return v_u_2.BubbleChat
	else
		return v_u_8.BubbleChatEnabled
	end
end
function bubbleChatOnly() -- name: bubbleChatOnly
	local v11 = not getClassicChatEnabled()
	if v11 then
		v11 = getBubbleChatEnabled()
	end
	return v11
end
function mergeProps(p12, p13) -- name: mergeProps
	if p12 and p13 then
		for v14, v15 in pairs(p12) do
			if p13[v14] == nil then
				continue
			end
			p13[v14] = v15
		end
	end
end
function v_u_10.CreateGuiObjects(p16, p17) -- name: CreateGuiObjects
	-- upvalues: (copy) v_u_4, (copy) v_u_8, (copy) v_u_3
	local v_u_18 = nil
	pcall(function()
		-- upvalues: (ref) v_u_18, (ref) v_u_4
		v_u_18 = v_u_4:InvokeChatCallback(Enum.ChatCallbackType.OnCreatingChatWindow, nil)
	end)
	mergeProps(v_u_18, v_u_8)
	local v19 = Instance.new("Frame")
	v19.BackgroundTransparency = 1
	v19.Active = v_u_8.WindowDraggable
	v19.Parent = p17
	v19.AutoLocalize = false
	local v_u_20 = Instance.new("Frame")
	v_u_20.Selectable = false
	v_u_20.Name = "ChatBarParentFrame"
	v_u_20.BackgroundTransparency = 1
	v_u_20.Parent = v19
	local v_u_21 = Instance.new("Frame")
	v_u_21.Selectable = false
	v_u_21.Name = "ChannelsBarParentFrame"
	v_u_21.BackgroundTransparency = 1
	v_u_21.Position = UDim2.new(0, 0, 0, 0)
	v_u_21.Parent = v19
	local v_u_22 = Instance.new("Frame")
	v_u_22.Selectable = false
	v_u_22.Name = "ChatChannelParentFrame"
	v_u_22.BackgroundTransparency = 1
	v_u_22.BackgroundColor3 = v_u_8.BackGroundColor
	v_u_22.BackgroundTransparency = 0.6
	v_u_22.BorderSizePixel = 0
	v_u_22.Parent = v19
	local v_u_23 = Instance.new("ImageButton")
	v_u_23.Selectable = false
	v_u_23.Image = ""
	v_u_23.BackgroundTransparency = 0.6
	v_u_23.BorderSizePixel = 0
	v_u_23.Visible = false
	v_u_23.BackgroundColor3 = v_u_8.BackGroundColor
	v_u_23.Active = true
	if bubbleChatOnly() then
		v_u_23.Position = UDim2.new(1, -v_u_23.AbsoluteSize.X, 0, 0)
	else
		v_u_23.Position = UDim2.new(1, -v_u_23.AbsoluteSize.X, 1, -v_u_23.AbsoluteSize.Y)
	end
	v_u_23.Parent = v19
	local v24 = Instance.new("ImageLabel")
	v24.Selectable = false
	v24.Size = UDim2.new(0.8, 0, 0.8, 0)
	v24.Position = UDim2.new(0.2, 0, 0.2, 0)
	v24.BackgroundTransparency = 1
	v24.Image = "rbxassetid://261880743"
	v24.Parent = v_u_23
	local v_u_25 = v19
	local v26 = 3
	while v19 and not v19:IsA("ScreenGui") do
		v19 = v19.Parent
	end
	local v_u_27 = v19.AbsoluteSize.X <= 640 and 1 or (v19.AbsoluteSize.X <= 1024 and 2 or v26)
	local v_u_28 = false
	local function v_u_46() -- name: doCheckSizeBounds
		-- upvalues: (ref) v_u_28, (copy) v_u_25, (ref) v_u_3, (ref) v_u_8, (copy) v_u_21, (copy) v_u_20
		if v_u_28 then
			return
		else
			v_u_28 = true
			if v_u_25:IsDescendantOf(v_u_3) then
				local v29 = v_u_25
				while v29 and not v29:IsA("ScreenGui") do
					v29 = v29.Parent
				end
				local v30 = v_u_8.MinimumWindowSize
				local v31 = v_u_8.MaximumWindowSize
				local v32 = v_u_21.AbsoluteSize.Y + v_u_20.AbsoluteSize.Y
				local v33 = v30.X.Scale * v29.AbsoluteSize.X + v30.X.Offset
				local v34 = v30.Y.Scale * v29.AbsoluteSize.Y + v30.Y.Offset
				local v35 = math.max(v34, v32)
				local v36 = v31.X.Scale * v29.AbsoluteSize.X + v31.X.Offset
				local v37 = v31.Y.Scale * v29.AbsoluteSize.Y + v31.Y.Offset
				local v38 = v_u_25.AbsoluteSize.X
				local v39 = v_u_25.AbsoluteSize.Y
				if v38 < v33 then
					local v40 = UDim2.new(0, v33 - v38, 0, 0)
					v_u_25.Size = v_u_25.Size + v40
				elseif v36 < v38 then
					local v41 = UDim2.new(0, v36 - v38, 0, 0)
					v_u_25.Size = v_u_25.Size + v41
				end
				if v39 < v35 then
					local v42 = UDim2.new(0, 0, 0, v35 - v39)
					v_u_25.Size = v_u_25.Size + v42
				elseif v37 < v39 then
					local v43 = UDim2.new(0, 0, 0, v37 - v39)
					v_u_25.Size = v_u_25.Size + v43
				end
				local v44 = v_u_25.AbsoluteSize.X / v29.AbsoluteSize.X
				local v45 = v_u_25.AbsoluteSize.Y / v29.AbsoluteSize.Y
				v_u_25.Size = UDim2.new(v44, 0, v45, 0)
				v_u_28 = false
			end
		end
	end
	v_u_25.Changed:connect(function(p47)
		-- upvalues: (copy) v_u_46
		if p47 == "AbsoluteSize" then
			v_u_46()
		end
	end)
	v_u_23.DragBegin:connect(function(_)
		-- upvalues: (copy) v_u_25
		v_u_25.Draggable = false
	end)
	local function v_u_50(p48) -- name: UpdatePositionFromDrag
		-- upvalues: (ref) v_u_8, (copy) v_u_25, (copy) v_u_23
		if v_u_8.WindowDraggable == false and v_u_8.WindowResizable == false then
			return
		else
			local v49 = p48 - v_u_25.AbsolutePosition + v_u_23.AbsoluteSize
			v_u_25.Size = UDim2.new(0, v49.X, 0, v49.Y)
			if bubbleChatOnly() then
				v_u_23.Position = UDim2.new(1, -v_u_23.AbsoluteSize.X, 0, 0)
			else
				v_u_23.Position = UDim2.new(1, -v_u_23.AbsoluteSize.X, 1, -v_u_23.AbsoluteSize.Y)
			end
		end
	end
	v_u_23.DragStopped:connect(function(_, _)
		-- upvalues: (copy) v_u_25, (ref) v_u_8
		v_u_25.Draggable = v_u_8.WindowDraggable
	end)
	local v_u_51 = false
	v_u_23.Changed:connect(function(p52)
		-- upvalues: (copy) v_u_25, (ref) v_u_51, (copy) v_u_50, (copy) v_u_23
		if p52 == "AbsolutePosition" and not v_u_25.Draggable then
			if v_u_51 then
				return
			end
			v_u_51 = true
			v_u_50(v_u_23.AbsolutePosition)
			v_u_51 = false
		end
	end)
	local v_u_53
	if bubbleChatOnly() then
		v_u_20.Position = UDim2.new(0, 0, 0, 0)
		v_u_21.Visible = false
		v_u_21.Active = false
		v_u_22.Visible = false
		v_u_22.Active = false
		v_u_53 = v_u_25
		while v_u_25 and not v_u_25:IsA("ScreenGui") do
			v_u_25 = v_u_25.Parent
		end
		local v54, v55
		if v_u_27 == 1 then
			v54 = v_u_8.DefaultWindowSizePhone.X.Scale
			v55 = v_u_8.DefaultWindowSizePhone.X.Offset
		elseif v_u_27 == 2 then
			v54 = v_u_8.DefaultWindowSizeTablet.X.Scale
			v55 = v_u_8.DefaultWindowSizeTablet.X.Offset
		else
			v54 = v_u_8.DefaultWindowSizeDesktop.X.Scale
			v55 = v_u_8.DefaultWindowSizeDesktop.X.Offset
		end
		local v56 = nil
		local v57
		if v_u_27 == 1 then
			v57 = v56 or v_u_8.ChatBarTextSizePhone
		else
			v57 = v56 or v_u_8.ChatBarTextSize
		end
		local v58 = v57 + 14 + 10
		v_u_53.Size = UDim2.new(v54, v55, 0, v58)
		v_u_53.Position = v_u_8.DefaultWindowPosition
	else
		v_u_53 = v_u_25
		while v_u_25 and not v_u_25:IsA("ScreenGui") do
			v_u_25 = v_u_25.Parent
		end
		if v_u_27 == 1 then
			v_u_53.Size = v_u_8.DefaultWindowSizePhone
		elseif v_u_27 == 2 then
			v_u_53.Size = v_u_8.DefaultWindowSizeTablet
		else
			v_u_53.Size = v_u_8.DefaultWindowSizeDesktop
		end
		v_u_53.Position = v_u_8.DefaultWindowPosition
	end
	if v_u_27 == 1 then
		v_u_8.ChatWindowTextSize = v_u_8.ChatWindowTextSizePhone
		v_u_8.ChatChannelsTabTextSize = v_u_8.ChatChannelsTabTextSizePhone
		v_u_8.ChatBarTextSize = v_u_8.ChatBarTextSizePhone
	end
	local function v_u_61(p59) -- name: UpdateResizable
		-- upvalues: (copy) v_u_23, (copy) v_u_20
		v_u_23.Visible = p59
		v_u_23.Draggable = p59
		local v60 = v_u_20.Size.Y.Offset
		if p59 then
			v_u_20.Size = UDim2.new(1, -v60 - 2, 0, v60)
			if not bubbleChatOnly() then
				v_u_20.Position = UDim2.new(0, 0, 1, -v60)
				return
			end
		else
			v_u_20.Size = UDim2.new(1, 0, 0, v60)
			if not bubbleChatOnly() then
				v_u_20.Position = UDim2.new(0, 0, 1, -v60)
			end
		end
	end
	local function v_u_69() -- name: UpdateChatChannelParentFrameSize
		-- upvalues: (ref) v_u_27, (ref) v_u_8, (copy) v_u_22
		local v62 = nil
		local v63
		if v_u_27 == 1 then
			v63 = v62 or v_u_8.ChatChannelsTabTextSizePhone
		else
			v63 = v62 or v_u_8.ChatChannelsTabTextSize
		end
		local v64 = v63 + 8
		local v65 = math.max(32, v64) + 2
		local v66 = nil
		local v67
		if v_u_27 == 1 then
			v67 = v66 or v_u_8.ChatBarTextSizePhone
		else
			v67 = v66 or v_u_8.ChatBarTextSize
		end
		local v68 = v67 + 14 + 10
		if v_u_8.ShowChannelsBar then
			v_u_22.Size = UDim2.new(1, 0, 1, -(v65 + v68 + 2 + 2))
			v_u_22.Position = UDim2.new(0, 0, 0, v65 + 2)
		else
			v_u_22.Size = UDim2.new(1, 0, 1, -(v68 + 2 + 2))
			v_u_22.Position = UDim2.new(0, 0, 0, 2)
		end
	end
	local function v_u_73(p70) -- name: UpdateChatBarTextSize
		-- upvalues: (ref) v_u_27, (ref) v_u_8, (copy) v_u_20, (copy) v_u_23, (copy) v_u_69, (copy) v_u_61
		local v71
		if v_u_27 == 1 then
			v71 = p70 or v_u_8.ChatBarTextSizePhone
		else
			v71 = p70 or v_u_8.ChatBarTextSize
		end
		local v72 = v71 + 14 + 10
		v_u_20.Size = UDim2.new(1, 0, 0, v72)
		if not bubbleChatOnly() then
			v_u_20.Position = UDim2.new(0, 0, 1, -v72)
		end
		v_u_23.Size = UDim2.new(0, v72, 0, v72)
		v_u_23.Position = UDim2.new(1, -v72, 1, -v72)
		v_u_69()
		v_u_61(v_u_8.WindowResizable)
	end
	local v74 = v_u_8.ChatChannelsTabTextSize
	local v75
	if v_u_27 == 1 then
		v75 = v74 or v_u_8.ChatChannelsTabTextSizePhone
	else
		v75 = v74 or v_u_8.ChatChannelsTabTextSize
	end
	local v76 = v75 + 8
	local v77 = math.max(32, v76) + 2
	v_u_21.Size = UDim2.new(1, 0, 0, v77)
	v_u_69()
	v_u_73(v_u_8.ChatBarTextSize)
	local v78 = v_u_8.WindowDraggable
	v_u_53.Active = v78
	v_u_53.Draggable = v78
	v_u_61(v_u_8.WindowResizable)
	v_u_21.Visible = v_u_8.ShowChannelsBar
	v_u_69()
	v_u_8.SettingsChanged:connect(function(p79, p80)
		-- upvalues: (copy) v_u_53, (copy) v_u_61, (ref) v_u_27, (ref) v_u_8, (copy) v_u_21, (copy) v_u_69, (copy) v_u_73
		if p79 == "WindowDraggable" then
			v_u_53.Active = p80
			v_u_53.Draggable = p80
			return
		elseif p79 == "WindowResizable" then
			v_u_61(p80)
			return
		elseif p79 == "ChatChannelsTabTextSize" then
			local v81
			if v_u_27 == 1 then
				v81 = p80 or v_u_8.ChatChannelsTabTextSizePhone
			else
				v81 = p80 or v_u_8.ChatChannelsTabTextSize
			end
			local v82 = v81 + 8
			local v83 = math.max(32, v82) + 2
			v_u_21.Size = UDim2.new(1, 0, 0, v83)
			v_u_69()
			return
		elseif p79 == "ChatBarTextSize" then
			v_u_73(p80)
		elseif p79 == "ShowChannelsBar" then
			v_u_21.Visible = p80
			v_u_69()
		end
	end)
	p16.GuiObject = v_u_53
	p16.GuiObjects.BaseFrame = v_u_53
	p16.GuiObjects.ChatBarParentFrame = v_u_20
	p16.GuiObjects.ChannelsBarParentFrame = v_u_21
	p16.GuiObjects.ChatChannelParentFrame = v_u_22
	p16.GuiObjects.ChatResizerFrame = v_u_23
	p16.GuiObjects.ResizeIcon = v24
	p16:AnimGuiObjects()
end
function v_u_10.GetChatBar(p84) -- name: GetChatBar
	return p84.ChatBar
end
function v_u_10.RegisterChatBar(p85, p86) -- name: RegisterChatBar
	p85.ChatBar = p86
	p85.ChatBar:CreateGuiObjects(p85.GuiObjects.ChatBarParentFrame)
end
function v_u_10.RegisterChannelsBar(p87, p88) -- name: RegisterChannelsBar
	p87.ChannelsBar = p88
	p87.ChannelsBar:CreateGuiObjects(p87.GuiObjects.ChannelsBarParentFrame)
end
function v_u_10.RegisterMessageLogDisplay(p89, p90) -- name: RegisterMessageLogDisplay
	p89.MessageLogDisplay = p90
	p89.MessageLogDisplay.GuiObject.Parent = p89.GuiObjects.ChatChannelParentFrame
end
function v_u_10.AddChannel(p_u_91, p_u_92) -- name: AddChannel
	-- upvalues: (copy) v_u_7
	if not p_u_91:GetChannel(p_u_92) then
		local v93 = v_u_7.new(p_u_92, p_u_91.MessageLogDisplay)
		p_u_91.Channels[p_u_92:lower()] = v93
		v93:SetActive(false)
		local v94 = p_u_91.ChannelsBar:AddChannelTab(p_u_92)
		v94.NameTag.MouseButton1Click:connect(function()
			-- upvalues: (copy) p_u_91, (copy) p_u_92
			p_u_91:SwitchCurrentChannel(p_u_92)
		end)
		v93:RegisterChannelTab(v94)
		return v93
	end
	error("Channel \'" .. p_u_92 .. "\' already exists!")
end
function v_u_10.GetFirstChannel(p95) -- name: GetFirstChannel
	for _, v96 in pairs(p95.Channels) do
		return v96
	end
	return nil
end
function v_u_10.RemoveChannel(p97, p98) -- name: RemoveChannel
	-- upvalues: (copy) v_u_8
	if not p97:GetChannel(p98) then
		error("Channel \'" .. p98 .. "\' does not exist!")
	end
	local v99 = p98:lower()
	local v100
	if p97.Channels[v99] == p97:GetCurrentChannel() then
		p97:SwitchCurrentChannel(nil)
		v100 = true
	else
		v100 = false
	end
	p97.Channels[v99]:Destroy()
	p97.Channels[v99] = nil
	p97.ChannelsBar:RemoveChannelTab(p98)
	if v100 then
		local v101
		if p97:GetChannel(v_u_8.GeneralChannelName) ~= nil and v99 ~= v_u_8.GeneralChannelName:lower() then
			v101 = v_u_8.GeneralChannelName
		else
			local v102 = p97:GetFirstChannel()
			v101 = v102 and v102.Name or nil
		end
		p97:SwitchCurrentChannel(v101)
	end
	if not v_u_8.ShowChannelsBar and p97.ChatBar.TargetChannel == p98 then
		p97.ChatBar:SetChannelTarget(v_u_8.GeneralChannelName)
	end
end
function v_u_10.GetChannel(p103, p104) -- name: GetChannel
	return p104 and p103.Channels[p104:lower()] or nil
end
function v_u_10.GetTargetMessageChannel(p105) -- name: GetTargetMessageChannel
	-- upvalues: (copy) v_u_8
	if not v_u_8.ShowChannelsBar then
		return p105.ChatBar.TargetChannel
	end
	local v106 = p105:GetCurrentChannel()
	if v106 then
		v106 = v106.Name
	end
	return v106
end
function v_u_10.GetCurrentChannel(p107) -- name: GetCurrentChannel
	return p107.CurrentChannel
end
function v_u_10.SwitchCurrentChannel(p108, p109) -- name: SwitchCurrentChannel
	-- upvalues: (copy) v_u_8
	if not v_u_8.ShowChannelsBar then
		local v110 = p108:GetChannel(p109)
		if v110 then
			p108.ChatBar:SetChannelTarget(v110.Name)
		end
		p109 = v_u_8.GeneralChannelName
	end
	local v111 = p108:GetCurrentChannel()
	local v112 = p108:GetChannel(p109)
	if v112 == nil then
		error(string.format("Channel \'%s\' does not exist.", p109))
	end
	if v112 ~= v111 then
		if v111 then
			v111:SetActive(false)
			p108.ChannelsBar:GetChannelTab(v111.Name):SetActive(false)
		end
		if v112 then
			v112:SetActive(true)
			p108.ChannelsBar:GetChannelTab(v112.Name):SetActive(true)
		end
		p108.CurrentChannel = v112
	end
end
function v_u_10.UpdateFrameVisibility(p113) -- name: UpdateFrameVisibility
	local v114 = p113.GuiObject
	local v115 = p113.Visible
	if v115 then
		v115 = p113.CoreGuiEnabled
	end
	v114.Visible = v115
end
function v_u_10.GetVisible(p116) -- name: GetVisible
	return p116.Visible
end
function v_u_10.SetVisible(p117, p118) -- name: SetVisible
	p117.Visible = p118
	p117:UpdateFrameVisibility()
end
function v_u_10.GetCoreGuiEnabled(p119) -- name: GetCoreGuiEnabled
	return p119.CoreGuiEnabled
end
function v_u_10.SetCoreGuiEnabled(p120, p121) -- name: SetCoreGuiEnabled
	p120.CoreGuiEnabled = p121
	p120:UpdateFrameVisibility()
end
function v_u_10.EnableResizable(p122) -- name: EnableResizable
	p122.GuiObjects.ChatResizerFrame.Active = true
end
function v_u_10.DisableResizable(p123) -- name: DisableResizable
	p123.GuiObjects.ChatResizerFrame.Active = false
end
function v_u_10.FadeOutBackground(p124, p125) -- name: FadeOutBackground
	-- upvalues: (copy) v_u_9
	p124.ChannelsBar:FadeOutBackground(p125)
	p124.MessageLogDisplay:FadeOutBackground(p125)
	p124.ChatBar:FadeOutBackground(p125)
	p124.AnimParams.Background_TargetTransparency = 1
	p124.AnimParams.Background_NormalizedExptValue = v_u_9:NormalizedDefaultExptValueInSeconds(p125)
end
function v_u_10.FadeInBackground(p126, p127) -- name: FadeInBackground
	-- upvalues: (copy) v_u_9
	p126.ChannelsBar:FadeInBackground(p127)
	p126.MessageLogDisplay:FadeInBackground(p127)
	p126.ChatBar:FadeInBackground(p127)
	p126.AnimParams.Background_TargetTransparency = 0.6
	p126.AnimParams.Background_NormalizedExptValue = v_u_9:NormalizedDefaultExptValueInSeconds(p127)
end
function v_u_10.FadeOutText(p128, p129) -- name: FadeOutText
	p128.MessageLogDisplay:FadeOutText(p129)
	p128.ChannelsBar:FadeOutText(p129)
end
function v_u_10.FadeInText(p130, p131) -- name: FadeInText
	p130.MessageLogDisplay:FadeInText(p131)
	p130.ChannelsBar:FadeInText(p131)
end
function v_u_10.AnimGuiObjects(p132) -- name: AnimGuiObjects
	p132.GuiObjects.ChatChannelParentFrame.BackgroundTransparency = p132.AnimParams.Background_CurrentTransparency
	p132.GuiObjects.ChatResizerFrame.BackgroundTransparency = p132.AnimParams.Background_CurrentTransparency
	p132.GuiObjects.ResizeIcon.ImageTransparency = p132.AnimParams.Background_CurrentTransparency
end
function v_u_10.InitializeAnimParams(p133) -- name: InitializeAnimParams
	-- upvalues: (copy) v_u_9
	p133.AnimParams.Background_TargetTransparency = 0.6
	p133.AnimParams.Background_CurrentTransparency = 0.6
	p133.AnimParams.Background_NormalizedExptValue = v_u_9:NormalizedDefaultExptValueInSeconds(0)
end
function v_u_10.Update(p134, p135) -- name: Update
	-- upvalues: (copy) v_u_9
	p134.ChatBar:Update(p135)
	p134.ChannelsBar:Update(p135)
	p134.MessageLogDisplay:Update(p135)
	p134.AnimParams.Background_CurrentTransparency = v_u_9:Expt(p134.AnimParams.Background_CurrentTransparency, p134.AnimParams.Background_TargetTransparency, p134.AnimParams.Background_NormalizedExptValue, p135)
	p134:AnimGuiObjects()
end
function v1.new() -- name: new
	-- upvalues: (copy) v_u_10
	local v136 = v_u_10
	local v137 = setmetatable({}, v136)
	v137.GuiObject = nil
	v137.GuiObjects = {}
	v137.ChatBar = nil
	v137.ChannelsBar = nil
	v137.MessageLogDisplay = nil
	v137.Channels = {}
	v137.CurrentChannel = nil
	v137.Visible = true
	v137.CoreGuiEnabled = true
	v137.AnimParams = {}
	v137:InitializeAnimParams()
	return v137
end
return v1
local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = require(v1.Shared.BatConfig)
local v4 = {}
local v_u_5 = nil
local v_u_6 = nil
local v_u_7 = nil
function v4.SetTarget(p8) -- name: SetTarget
	-- upvalues: (ref) v_u_5, (ref) v_u_7, (ref) v_u_6, (copy) v_u_3, (copy) v_u_2
	if p8 == v_u_5 then
		return
	else
		if v_u_7 then
			v_u_7:Cancel()
			v_u_7 = nil
		end
		if v_u_6 then
			v_u_6:Destroy()
			v_u_6 = nil
		end
		v_u_5 = nil
		if p8 then
			local v9 = v_u_3.Highlight
			local v10 = Instance.new("Highlight")
			v10.Name = "BatTargetHighlight"
			v10.Adornee = p8
			v10.DepthMode = Enum.HighlightDepthMode.Occluded
			v10.FillColor = v9.FillColor
			v10.OutlineColor = v9.OutlineColor
			v10.FillTransparency = 1
			v10.OutlineTransparency = 1
			v10.Enabled = true
			v10.Parent = p8
			v_u_5 = p8
			v_u_6 = v10
			v_u_7 = v_u_2:Create(v10, TweenInfo.new(v9.FadeTime, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
				["FillTransparency"] = v9.FillTransparency,
				["OutlineTransparency"] = v9.OutlineTransparency
			})
			v_u_7:Play()
		end
	end
end
function v4.Clear() -- name: Clear
	-- upvalues: (ref) v_u_7, (ref) v_u_6, (ref) v_u_5
	if v_u_7 then
		v_u_7:Cancel()
		v_u_7 = nil
	end
	if v_u_6 then
		v_u_6:Destroy()
		v_u_6 = nil
	end
	v_u_5 = nil
end
return v4
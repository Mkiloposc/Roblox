local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.AnimalRenders)
local v_u_3 = require(v1.Shared.EggRewards)
local v_u_4 = require(v1.Shared.FloatingIconConfig)
local v_u_5 = require(v1.Shared.RarityGradientFX)
local v_u_6 = require(script.Parent.FloatingIconFX)
local v_u_21 = {
	["HoverScale"] = 1.03,
	["PressScale"] = 0.95,
	["SetRender"] = function(p7, p8, p9) -- name: SetRender
		-- upvalues: (copy) v_u_2
		if p7 and p7:IsA("ImageLabel") then
			v_u_2.Apply(p7, p8, p9)
			for _, v10 in p7:GetDescendants() do
				if not v10:IsA("ImageLabel") then
					continue
				end
				v_u_2.Apply(v10, p8, p9)
			end
		end
	end,
	["PaintBackground"] = function(p11, p12) -- name: PaintBackground
		-- upvalues: (copy) v_u_5, (copy) v_u_3
		local v13 = p11:FindFirstChild("RarityGradient") or p11:FindFirstChildOfClass("UIGradient")
		if not v13 then
			v13 = Instance.new("UIGradient")
			v13.Name = "RarityGradient"
			v13.Parent = p11
		end
		if v13:IsA("UIGradient") then
			p11.BackgroundColor3 = Color3.new(1, 1, 1)
			v_u_5.Attach(v13, not (p12 and v_u_3.RarityGradients[p12]) and "Common" or p12)
		end
	end,
	["Prepare"] = function(p14, p15) -- name: Prepare
		-- upvalues: (copy) v_u_21, (copy) v_u_6, (copy) v_u_4
		p14.Active = true
		for _, v16 in p14:GetDescendants() do
			if not v16:IsA("GuiObject") then
				continue
			end
			v16.Active = false
		end
		p14:SetAttribute("HoverScale", v_u_21.HoverScale)
		p14:SetAttribute("PressScale", v_u_21.PressScale)
		if p15 and (p15:IsA("GuiObject") and p14:IsA("GuiButton")) then
			v_u_6.Attach(p15, v_u_4.Styles.AnimalTile, p14)
		end
	end,
	["SetupGrid"] = function(p17) -- name: SetupGrid
		local v18 = p17:FindFirstChildOfClass("UIListLayout")
		if v18 then
			v18.FillDirection = Enum.FillDirection.Horizontal
			v18.Wraps = true
			v18.SortOrder = Enum.SortOrder.LayoutOrder
		end
		local v19 = p17:FindFirstChild("Title")
		if v19 and v19:IsA("GuiObject") then
			v19.LayoutOrder = -2
		end
		local v20 = p17:FindFirstChild("None")
		if v20 and v20:IsA("GuiObject") then
			v20.LayoutOrder = -1
		end
		p17.CanvasSize = UDim2.new()
		p17.AutomaticCanvasSize = Enum.AutomaticSize.Y
	end
}
return v_u_21
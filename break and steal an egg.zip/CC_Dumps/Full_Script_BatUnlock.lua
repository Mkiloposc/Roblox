local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v_u_1.Shared.BatConfig)
local v_u_3 = require(v_u_1.Shared.EggRewards)
local v_u_4 = {}
local v_u_5 = {}
for v6, v7 in v_u_2.Tiers do
	local v8 = v7.Zone
	if typeof(v8) ~= "number" and typeof(v8) ~= "string" then
		continue
	end
	v_u_4[v7.Zone] = v6
end
local v_u_9 = nil
local function v_u_17() -- name: buildRosters
	-- upvalues: (ref) v_u_9, (copy) v_u_3
	if v_u_9 then
		return v_u_9
	end
	local v10 = {}
	for _, v11 in v_u_3.Pool do
		if v11.IndexHidden then
			continue
		end
		local v12 = nil
		if v11.IndexLimited then
			local v13 = v11.IndexLimited
			v12 = typeof(v13) ~= "string" and "Limited" or v11.IndexLimited
		else
			local v14 = v11.Zone
			if typeof(v14) == "number" then
				v12 = v11.Zone
			end
		end
		if v12 == nil then
			continue
		end
		v10[v12] = v10[v12] or {}
		local v15 = v10[v12]
		local v16 = v11.Name
		table.insert(v15, v16)
	end
	v_u_9 = v10
	return v10
end
function v_u_5.TierForZone(p18) -- name: TierForZone
	-- upvalues: (copy) v_u_4
	if typeof(p18) == "number" and true or typeof(p18) == "string" then
		return v_u_4[p18]
	else
		return nil
	end
end
function v_u_5.ZoneRoster(p19) -- name: ZoneRoster
	-- upvalues: (copy) v_u_17
	return v_u_17()[p19] or {}
end
function v_u_5.IsZoneComplete(p20, p21) -- name: IsZoneComplete
	-- upvalues: (copy) v_u_5
	if typeof(p20) ~= "table" then
		return false
	end
	local v22 = v_u_5.ZoneRoster(p21)
	if #v22 == 0 then
		return false
	end
	for _, v23 in v22 do
		if p20[v23] ~= nil then
			continue
		end
		return false
	end
	return true
end
function v_u_5.TemplateFor(p24) -- name: TemplateFor
	-- upvalues: (copy) v_u_2, (copy) v_u_1
	local v25 = v_u_2.Tiers[p24]
	local v26
	if v25 then
		v26 = v_u_1:FindFirstChild(v_u_2.TemplatesFolderName)
	else
		v26 = v25
	end
	if v26 then
		v26 = v26:FindFirstChild(v25.Template)
	end
	if v26 and v26:IsA("Tool") then
		return v26
	else
		return nil
	end
end
return v_u_5
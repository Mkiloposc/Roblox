local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = game:GetService("ContentProvider")
local v_u_5 = {
	["VERSION"] = 2
}
local v_u_6 = {
	"Lifetime",
	"SizeEnd",
	"TransparencyEnd",
	"SpinEnd",
	"OffsetEnd"
}
local v_u_7 = {
	"EmitDelay",
	"EmitCount",
	"EmitDuration",
	"Duration",
	"Spin",
	"EffectDuration"
}
local v_u_8 = setmetatable({}, {
	["__mode"] = "k"
})
local function v_u_17(p9, p10, p_u_11, p12, p13) -- name: enumAttribute
	local v_u_14 = p9:GetAttribute(p10)
	if v_u_14 == nil then
		return p12
	end
	local v15, v16 = pcall(function()
		-- upvalues: (copy) p_u_11, (copy) v_u_14
		return p_u_11[v_u_14]
	end)
	if v15 and v16 then
		return v16
	end
	if p13 then
		warn((("VFXEmit: %*.%* is not a valid %* name: %*"):format(p9:GetFullName(), p10, tostring(p_u_11), (tostring(v_u_14)))))
	end
	return p12
end
local function v_u_21(p18) -- name: meshPair
	if p18:IsA("Model") or p18:IsA("Folder") then
		local v19 = p18:FindFirstChild("Start")
		local v20 = p18:FindFirstChild("End")
		if v19 and (v20 and (v19:IsA("BasePart") and v20:IsA("BasePart"))) then
			return v19, v20
		else
			return nil
		end
	else
		return nil
	end
end
local function v_u_26(p22, p23) -- name: resolve
	-- upvalues: (copy) v_u_1
	if typeof(p22) == "Instance" then
		return p22
	end
	if type(p22) == "string" then
		local v24 = script.Parent or v_u_1:FindFirstChild("VFX")
		local v25
		if v24 then
			v25 = v24:FindFirstChild(p22)
		else
			v25 = v24
		end
		if v25 then
			return v25
		end
		error(("Emit: no effect named %q in %s"):format(p22, v24 and v24:GetFullName() or "ReplicatedStorage.VFX"), p23 or 3)
	end
	error("Emit: the effect must be a template or its name", p23 or 3)
end
local function v_u_30(p27, p28) -- name: toCFrame
	local v29 = typeof(p27)
	if v29 == "CFrame" then
		return p27
	end
	if v29 == "Vector3" then
		return CFrame.new(p27)
	end
	if v29 == "Instance" then
		if p27:IsA("Attachment") then
			return p27.WorldCFrame
		end
		if p27:IsA("BasePart") then
			return p27.CFrame
		end
		if p27:IsA("Model") then
			return p27:GetPivot()
		end
	end
	error("Emit: play it at a CFrame, Vector3, part, attachment or model", p28 or 3)
end
local function v_u_35(p31, p32) -- name: place
	if p31:IsA("Model") then
		p31:PivotTo(p32)
	else
		local v33 = p31.CFrame
		for _, v34 in p31:GetDescendants() do
			if not v34:IsA("BasePart") then
				continue
			end
			v34.CFrame = p32 * v33:ToObjectSpace(v34.CFrame)
		end
		p31.CFrame = p32
	end
end
local function v_u_82(p36, p37) -- name: timeline
	-- upvalues: (copy) v_u_21, (copy) v_u_17
	local v38 = {}
	local v39 = {}
	local v40 = 0
	local v41 = 0
	local v42 = p36:GetDescendants()
	table.insert(v42, p36)
	local v43 = v41
	local v44 = v40
	for _, v45 in v42 do
		if v45:IsA("ParticleEmitter") then
			local v46 = v45:GetAttribute("EmitDelay")
			if typeof(v46) ~= "number" or v46 ~= v46 then
				if v46 == nil or not p37 then
					v46 = 0
				else
					warn((("VFXEmit: %*.EmitDelay should be a number, got %*"):format(v45:GetFullName(), (typeof(v46)))))
					v46 = 0
				end
			end
			local v47 = math.max(v46, 0)
			local v48 = v45:GetAttribute("EmitCount")
			if typeof(v48) ~= "number" or v48 ~= v48 then
				if v48 == nil or not p37 then
					v48 = nil
				else
					warn((("VFXEmit: %*.EmitCount should be a number, got %*"):format(v45:GetFullName(), (typeof(v48)))))
					v48 = nil
				end
			end
			local v49 = v45:GetAttribute("EmitDuration")
			if typeof(v49) ~= "number" or v49 ~= v49 then
				if v49 == nil or not p37 then
					v49 = nil
				else
					warn((("VFXEmit: %*.EmitDuration should be a number, got %*"):format(v45:GetFullName(), (typeof(v49)))))
					v49 = nil
				end
			end
			if v48 == nil and v49 == nil then
				continue
			end
			local v50 = v45.Lifetime.Max
			local v51 = v45.TimeScale
			local v52 = v50 / math.max(v51, 0.05)
			local v53
			if v48 == nil then
				v53 = v48
			else
				local v54 = math.floor(v48)
				v53 = math.clamp(v54, 0, 500)
				if v53 ~= v48 and p37 then
					warn((("VFXEmit: %* EmitCount %* was bounded to %*"):format(v45:GetFullName(), v48, v53)))
				end
				v40 = math.max(v44, v47)
				local v55 = v47 + (v52 or 0)
				v41 = math.max(v43, v55)
				v43 = v41
				v44 = v40
			end
			if v49 ~= nil then
				v49 = math.max(v49, 0)
				local v56 = v47 + v49
				v40 = math.max(v44, v56)
				local v57 = v56 + (v52 or 0)
				v41 = math.max(v43, v57)
				v43 = v41
				v44 = v40
			end
			table.insert(v38, {
				["kind"] = "emitter",
				["instance"] = nil,
				["delay"] = nil,
				["count"] = nil,
				["on"] = nil,
				["instance"] = v45,
				["delay"] = v47,
				["count"] = v53,
				["on"] = v49
			})
		elseif v45:IsA("Beam") or v45:IsA("Trail") then
			local v58 = v45:GetAttribute("EmitDelay")
			if typeof(v58) ~= "number" or v58 ~= v58 then
				if v58 == nil or not p37 then
					v58 = 0
				else
					warn((("VFXEmit: %*.EmitDelay should be a number, got %*"):format(v45:GetFullName(), (typeof(v58)))))
					v58 = 0
				end
			end
			local v59 = math.max(v58, 0)
			local v60 = v45:GetAttribute("EmitDuration")
			if typeof(v60) ~= "number" or v60 ~= v60 then
				if v60 == nil or not p37 then
					v60 = nil
				else
					warn((("VFXEmit: %*.EmitDuration should be a number, got %*"):format(v45:GetFullName(), (typeof(v60)))))
					v60 = nil
				end
			end
			if v60 == nil then
				continue
			end
			local v61 = math.max(v60, 0)
			local v62 = v59 + v61
			local v63 = not v45:IsA("Trail") and 0 or v45.Lifetime
			v40 = math.max(v44, v62)
			local v64 = v62 + (v63 or 0)
			v41 = math.max(v43, v64)
			table.insert(v38, {
				["kind"] = "ribbon",
				["instance"] = nil,
				["delay"] = nil,
				["on"] = nil,
				["instance"] = v45,
				["delay"] = v59,
				["on"] = v61
			})
			v43 = v41
			v44 = v40
		elseif v45:IsA("PointLight") or (v45:IsA("SpotLight") or v45:IsA("SurfaceLight")) then
			local v65 = v45:GetAttribute("EmitDelay")
			if typeof(v65) ~= "number" or v65 ~= v65 then
				if v65 == nil or not p37 then
					v65 = 0
				else
					warn((("VFXEmit: %*.EmitDelay should be a number, got %*"):format(v45:GetFullName(), (typeof(v65)))))
					v65 = 0
				end
			end
			local v66 = math.max(v65, 0)
			local v67 = v45:GetAttribute("EmitDuration")
			if typeof(v67) ~= "number" or v67 ~= v67 then
				if v67 == nil or not p37 then
					v67 = nil
				else
					warn((("VFXEmit: %*.EmitDuration should be a number, got %*"):format(v45:GetFullName(), (typeof(v67)))))
					v67 = nil
				end
			end
			if v67 == nil then
				continue
			end
			local v68 = math.max(v67, 0)
			local v69 = v66 + v68
			v40 = math.max(v44, v69)
			local v70 = v69 + 0
			v41 = math.max(v43, v70)
			table.insert(v38, {
				["kind"] = "light",
				["instance"] = nil,
				["delay"] = nil,
				["on"] = nil,
				["instance"] = v45,
				["delay"] = v66,
				["on"] = v68
			})
			v43 = v41
			v44 = v40
		else
			local v71, v72 = v_u_21(v45)
			if not v71 then
				continue
			end
			local v73 = v45:GetAttribute("EmitDelay")
			if typeof(v73) ~= "number" or v73 ~= v73 then
				if v73 == nil or not p37 then
					v73 = 0
				else
					warn((("VFXEmit: %*.EmitDelay should be a number, got %*"):format(v45:GetFullName(), (typeof(v73)))))
					v73 = 0
				end
			end
			local v74 = math.max(v73, 0)
			local v75 = v45:GetAttribute("Duration")
			if typeof(v75) ~= "number" or v75 ~= v75 then
				if v75 == nil or not p37 then
					v75 = 0.4
				else
					warn((("VFXEmit: %*.Duration should be a number, got %*"):format(v45:GetFullName(), (typeof(v75)))))
					v75 = 0.4
				end
			end
			local v76 = math.max(v75, 0)
			local v77 = v74 + v76
			v40 = math.max(v44, v77)
			local v78 = v77 + 0
			v41 = math.max(v43, v78)
			local v79 = {
				["kind"] = "mesh",
				["instance"] = nil,
				["start"] = nil,
				["finish"] = nil,
				["delay"] = nil,
				["duration"] = nil,
				["style"] = nil,
				["direction"] = nil,
				["spin"] = nil,
				["instance"] = v45,
				["start"] = v71,
				["finish"] = v72,
				["delay"] = v74,
				["duration"] = v76,
				["style"] = v_u_17(v45, "Easing", Enum.EasingStyle, Enum.EasingStyle.Quad, p37),
				["direction"] = v_u_17(v45, "EasingDirection", Enum.EasingDirection, Enum.EasingDirection.Out, p37)
			}
			local v80 = v45:GetAttribute("Spin")
			if typeof(v80) ~= "number" or v80 ~= v80 then
				if v80 == nil or not p37 then
					v80 = 0
				else
					warn((("VFXEmit: %*.Spin should be a number, got %*"):format(v45:GetFullName(), (typeof(v80)))))
					v80 = 0
				end
			end
			v79.spin = math.rad(v80)
			table.insert(v39, v79)
			v43 = v41
			v44 = v40
		end
	end
	for _, v81 in v39 do
		table.insert(v38, v81)
	end
	return v38, v44, v43
end
function v_u_5.duration(p83) -- name: duration
	-- upvalues: (copy) v_u_26, (copy) v_u_82
	local v84 = v_u_26(p83)
	local _, v85, v86 = v_u_82(v84, false)
	local v87 = v84:GetAttribute("EffectDuration")
	if typeof(v87) ~= "number" or v87 ~= v87 then
		local _ = v87 == nil
		v87 = nil
	end
	if v87 ~= nil then
		v86 = math.max(v87, v85)
	end
	return math.clamp(v86, 0, 30)
end
local function v_u_92(p88, p89) -- name: relativeName
	if p89 == p88 then
		return p88.Name
	end
	local v90 = {}
	while p89 and p89 ~= p88 do
		local v91 = p89.Name
		table.insert(v90, 1, v91)
		p89 = p89.Parent
	end
	return table.concat(v90, ".")
end
local function v_u_94(p93) -- name: textureOf
	if p93:IsA("ParticleEmitter") or (p93:IsA("Beam") or (p93:IsA("Trail") or p93:IsA("Decal"))) then
		return p93.Texture
	elseif p93:IsA("MeshPart") then
		return p93.TextureID
	else
		return nil
	end
end
function v_u_5.check(p95) -- name: check
	-- upvalues: (copy) v_u_26, (copy) v_u_92, (copy) v_u_7, (copy) v_u_6, (copy) v_u_94, (copy) v_u_21, (copy) v_u_5
	local v96 = v_u_26(p95)
	local v97 = v96:GetDescendants()
	table.insert(v97, v96)
	local v98 = {}
	local v99 = 0
	for _, v100 in v97 do
		for _, v101 in v_u_7 do
			local v102 = v100:GetAttribute(v101)
			if v102 == nil or typeof(v102) == "number" and v102 == v102 then
				continue
			end
			local v103 = v101 .. " must be a number, not a " .. typeof(v102)
			local v104 = v_u_92(v96, v100) .. ": " .. v103
			table.insert(v98, v104)
		end
		for _, v105 in {
			{ "Easing", Enum.EasingStyle },
			{ "EasingDirection", Enum.EasingDirection }
		} do
			local v106 = v100:GetAttribute(v105[1])
			if v106 == nil then
				continue
			end
			local v107 = v105[1]
			local v_u_108 = v105[2]
			local v_u_109 = v100:GetAttribute(v107)
			local v110
			if v_u_109 == nil then
				v110 = nil
			else
				local v111, v112 = pcall(function()
					-- upvalues: (copy) v_u_108, (copy) v_u_109
					return v_u_108[v_u_109]
				end)
				v110 = v111 and v112 and v112 or nil
			end
			if v110 ~= nil then
				continue
			end
			local v113 = ("%s %s is not an Enum.%s name"):format(v105[1], tostring(v106), v105[1] == "Easing" and "EasingStyle" or "EasingDirection")
			local v114 = v_u_92(v96, v100) .. ": " .. v113
			table.insert(v98, v114)
		end
		if v100:IsA("BasePart") then
			for _, v115 in v_u_6 do
				if v100:GetAttribute(v115) == nil then
					continue
				end
				local v116 = v115 .. " is no longer read; animate a mesh with a Start/End pair in a Model or Folder"
				local v117 = v_u_92(v96, v100) .. ": " .. v116
				table.insert(v98, v117)
			end
		end
		local v118 = v100:GetAttribute("EmitCount")
		if typeof(v118) ~= "number" or v118 ~= v118 then
			local _ = v118 == nil
			v118 = nil
		end
		if v118 and v118 > 500 then
			local v119 = ("EmitCount %d is capped at %d"):format(v118, 500)
			local v120 = v_u_92(v96, v100) .. ": " .. v119
			table.insert(v98, v120)
		end
		local v121 = v100:GetAttribute("EmitDelay")
		if typeof(v121) ~= "number" or v121 ~= v121 then
			local _ = v121 == nil
			v121 = 0
		end
		local v122, v123, v124, v125, v143, v127, v128, v129, v130, v131, v132, v133, v134, v135, v136, v137, v138, v139
		if v121 > 30 then
			v122 = ("timings past %d seconds are cut off: an effect lasts at most %d seconds"):format(30, 30)
			v123 = v_u_92(v96, v100) .. ": " .. v122
			table.insert(v98, v123)
			v124 = v_u_94(v100)
			if type(v124) == "string" and v124:sub(1, 28) == "rbxasset://textures/ropilot/" then
				v99 = v99 + 1
			end
			v125 = v100:GetAttribute("EmitDuration")
			if typeof(v125) ~= "number" or v125 ~= v125 then
				local v143 = v125 == nil
				v125 = nil
			end
			if v100:IsA("ParticleEmitter") then
				if v118 == nil and v125 == nil then
					if v100.Enabled and v100.Rate > 0 then
						v127 = v_u_92(v96, v100) .. ": has no EmitCount or EmitDuration, so it runs on its own, not slowed or frozen with the effect (fine for an aura; give the effect an EffectDuration)"
						table.insert(v98, v127)
					else
						v128 = v_u_92(v96, v100) .. ": has no EmitCount or EmitDuration and isn\'t emitting, so it never emits"
						table.insert(v98, v128)
					end
				elseif (not v118 or v118 < 1) and (not v125 or v125 <= 0) then
					v129 = v_u_92(v96, v100) .. ": EmitCount and EmitDuration are 0, so it never emits"
					table.insert(v98, v129)
				end
				if v100.Orientation == Enum.ParticleOrientation.VelocityPerpendicular and v100.Speed.Max <= 0 then
					v130 = v_u_92(v96, v100) .. ": is VelocityPerpendicular with Speed 0, which doesn\'t draw; set Speed to 0.001"
					table.insert(v98, v130)
				end
				if v100.Texture == "" then
					v131 = v_u_92(v96, v100) .. ": has no Texture"
					table.insert(v98, v131)
				end
			elseif v100:IsA("Beam") or v100:IsA("Trail") or (v100:IsA("PointLight") or (v100:IsA("SpotLight") or v100:IsA("SurfaceLight"))) then
				if v125 == nil and v100:GetAttribute("EmitDelay") ~= nil then
					v132 = v_u_92(v96, v100) .. ": has EmitDelay but no EmitDuration, so Emit leaves it as it is"
					table.insert(v98, v132)
				end
				if not (v100:IsA("PointLight") or (v100:IsA("SpotLight") or v100:IsA("SurfaceLight")) or v100.Attachment0 and v100.Attachment1) then
					v133 = v_u_92(v96, v100) .. ": needs both Attachment0 and Attachment1"
					table.insert(v98, v133)
				end
			end
			v134 = v100:FindFirstChild("Start")
			v135 = v100:FindFirstChild("End")
			if v100:IsA("Model") or v100:IsA("Folder") then
				if v134 and (v135 and not (v134:IsA("BasePart") and v135:IsA("BasePart"))) then
					v136 = ("Start and End must both be BaseParts, not a %s and a %s"):format(v134.ClassName, v135.ClassName)
					v137 = v_u_92(v96, v100) .. ": " .. v136
					table.insert(v98, v137)
				else
					if not (v134 or v135) or v134 and v135 then
						break
					end
					v138 = v_u_92(v96, v100) .. ": " .. (v134 and "has a Start but no End, so nothing moves" or "has an End but no Start, so nothing moves")
					table.insert(v98, v138)
				end
			else
				if not (v134 and (v135 and (v134:IsA("BasePart") and v135:IsA("BasePart")))) then
					break
				end
				v139 = v_u_92(v96, v100) .. ": holds Start and End, but only a Model or Folder moves them; put them in one"
				table.insert(v98, v139)
			end
		else
			local v141 = v100:GetAttribute("EmitDuration")
			if typeof(v141) ~= "number" or v141 ~= v141 then
				local _ = v141 == nil
				v141 = 0
			end
			if v141 > 30 then
				v122 = ("timings past %d seconds are cut off: an effect lasts at most %d seconds"):format(30, 30)
				v123 = v_u_92(v96, v100) .. ": " .. v122
				table.insert(v98, v123)
				v124 = v_u_94(v100)
				if type(v124) == "string" and v124:sub(1, 28) == "rbxasset://textures/ropilot/" then
					v99 = v99 + 1
				end
				v125 = v100:GetAttribute("EmitDuration")
				if typeof(v125) ~= "number" or v125 ~= v125 then
					local v143 = v125 == nil
					v125 = nil
				end
				if v100:IsA("ParticleEmitter") then
					if v118 == nil and v125 == nil then
						if v100.Enabled and v100.Rate > 0 then
							v127 = v_u_92(v96, v100) .. ": has no EmitCount or EmitDuration, so it runs on its own, not slowed or frozen with the effect (fine for an aura; give the effect an EffectDuration)"
							table.insert(v98, v127)
						else
							v128 = v_u_92(v96, v100) .. ": has no EmitCount or EmitDuration and isn\'t emitting, so it never emits"
							table.insert(v98, v128)
						end
					elseif (not v118 or v118 < 1) and (not v125 or v125 <= 0) then
						v129 = v_u_92(v96, v100) .. ": EmitCount and EmitDuration are 0, so it never emits"
						table.insert(v98, v129)
					end
					if v100.Orientation == Enum.ParticleOrientation.VelocityPerpendicular and v100.Speed.Max <= 0 then
						v130 = v_u_92(v96, v100) .. ": is VelocityPerpendicular with Speed 0, which doesn\'t draw; set Speed to 0.001"
						table.insert(v98, v130)
					end
					if v100.Texture == "" then
						v131 = v_u_92(v96, v100) .. ": has no Texture"
						table.insert(v98, v131)
					end
				elseif v100:IsA("Beam") or v100:IsA("Trail") or (v100:IsA("PointLight") or (v100:IsA("SpotLight") or v100:IsA("SurfaceLight"))) then
					if v125 == nil and v100:GetAttribute("EmitDelay") ~= nil then
						v132 = v_u_92(v96, v100) .. ": has EmitDelay but no EmitDuration, so Emit leaves it as it is"
						table.insert(v98, v132)
					end
					if not (v100:IsA("PointLight") or (v100:IsA("SpotLight") or v100:IsA("SurfaceLight")) or v100.Attachment0 and v100.Attachment1) then
						v133 = v_u_92(v96, v100) .. ": needs both Attachment0 and Attachment1"
						table.insert(v98, v133)
					end
				end
				v134 = v100:FindFirstChild("Start")
				v135 = v100:FindFirstChild("End")
				if v100:IsA("Model") or v100:IsA("Folder") then
					if v134 and (v135 and not (v134:IsA("BasePart") and v135:IsA("BasePart"))) then
						v136 = ("Start and End must both be BaseParts, not a %s and a %s"):format(v134.ClassName, v135.ClassName)
						v137 = v_u_92(v96, v100) .. ": " .. v136
						table.insert(v98, v137)
					else
						if not (v134 or v135) or v134 and v135 then
							break
						end
						v138 = v_u_92(v96, v100) .. ": " .. (v134 and "has a Start but no End, so nothing moves" or "has an End but no Start, so nothing moves")
						table.insert(v98, v138)
					end
				else
					if not (v134 and (v135 and (v134:IsA("BasePart") and v135:IsA("BasePart")))) then
						break
					end
					v139 = v_u_92(v96, v100) .. ": holds Start and End, but only a Model or Folder moves them; put them in one"
					table.insert(v98, v139)
				end
			else
				v124 = v_u_94(v100)
				if type(v124) == "string" and v124:sub(1, 28) == "rbxasset://textures/ropilot/" then
					v99 = v99 + 1
				end
				v125 = v100:GetAttribute("EmitDuration")
				if typeof(v125) ~= "number" or v125 ~= v125 then
					local v143 = v125 == nil
					v125 = nil
				end
				if v100:IsA("ParticleEmitter") then
					if v118 == nil and v125 == nil then
						if v100.Enabled and v100.Rate > 0 then
							v127 = v_u_92(v96, v100) .. ": has no EmitCount or EmitDuration, so it runs on its own, not slowed or frozen with the effect (fine for an aura; give the effect an EffectDuration)"
							table.insert(v98, v127)
						else
							v128 = v_u_92(v96, v100) .. ": has no EmitCount or EmitDuration and isn\'t emitting, so it never emits"
							table.insert(v98, v128)
						end
					elseif (not v118 or v118 < 1) and (not v125 or v125 <= 0) then
						v129 = v_u_92(v96, v100) .. ": EmitCount and EmitDuration are 0, so it never emits"
						table.insert(v98, v129)
					end
					if v100.Orientation == Enum.ParticleOrientation.VelocityPerpendicular and v100.Speed.Max <= 0 then
						v130 = v_u_92(v96, v100) .. ": is VelocityPerpendicular with Speed 0, which doesn\'t draw; set Speed to 0.001"
						table.insert(v98, v130)
					end
					if v100.Texture == "" then
						v131 = v_u_92(v96, v100) .. ": has no Texture"
						table.insert(v98, v131)
					end
				elseif v100:IsA("Beam") or v100:IsA("Trail") or (v100:IsA("PointLight") or (v100:IsA("SpotLight") or v100:IsA("SurfaceLight"))) then
					if v125 == nil and v100:GetAttribute("EmitDelay") ~= nil then
						v132 = v_u_92(v96, v100) .. ": has EmitDelay but no EmitDuration, so Emit leaves it as it is"
						table.insert(v98, v132)
					end
					if not (v100:IsA("PointLight") or (v100:IsA("SpotLight") or v100:IsA("SurfaceLight")) or v100.Attachment0 and v100.Attachment1) then
						v133 = v_u_92(v96, v100) .. ": needs both Attachment0 and Attachment1"
						table.insert(v98, v133)
					end
				end
				v134 = v100:FindFirstChild("Start")
				v135 = v100:FindFirstChild("End")
				if v100:IsA("Model") or v100:IsA("Folder") then
					if v134 and (v135 and not (v134:IsA("BasePart") and v135:IsA("BasePart"))) then
						v136 = ("Start and End must both be BaseParts, not a %s and a %s"):format(v134.ClassName, v135.ClassName)
						v137 = v_u_92(v96, v100) .. ": " .. v136
						table.insert(v98, v137)
					else
						if not (v134 or v135) or v134 and v135 then
							break
						end
						v138 = v_u_92(v96, v100) .. ": " .. (v134 and "has a Start but no End, so nothing moves" or "has an End but no Start, so nothing moves")
						table.insert(v98, v138)
					end
				else
					if not (v134 and (v135 and (v134:IsA("BasePart") and v135:IsA("BasePart")))) then
						break
					end
					v139 = v_u_92(v96, v100) .. ": holds Start and End, but only a Model or Folder moves them; put them in one"
					table.insert(v98, v139)
				end
			end
		end
	end
	if v96:GetAttribute("Duration") ~= nil and v_u_21(v96) == nil then
		local v144 = v_u_92(v96, v96) .. ": Duration only times a Start/End motion; use EffectDuration for how long the effect lasts"
		table.insert(v98, v144)
	end
	if v99 > 0 then
		table.insert(v98, ("%d texture(s) are local previews (rbxasset://textures/ropilot/...), which only show in Studio on this computer: upload them and swap in the asset ids before publishing"):format(v99))
	end
	if v_u_5.duration(v96) <= 0 then
		table.insert(v98, "nothing in it has EmitCount, EmitDuration, a Start/End pair or EffectDuration, so it ends as soon as it starts")
	end
	return v98
end
function v_u_5.preload(p145, p146) -- name: preload
	-- upvalues: (copy) v_u_26, (copy) v_u_4
	local v_u_147 = v_u_26(p145)
	local v148 = tonumber(p146) or 10
	local v_u_149 = false
	task.spawn(function()
		-- upvalues: (ref) v_u_4, (copy) v_u_147, (ref) v_u_149
		local v150 = v_u_4.PreloadAsync
		local v151 = v_u_4
		local v152 = { v_u_147 }
		pcall(v150, v151, v152)
		v_u_149 = true
	end)
	local v153 = os.clock() + v148
	while not v_u_149 and os.clock() < v153 do
		task.wait()
	end
	return v_u_149
end
local v_u_154 = {}
v_u_154.__index = v_u_154
local v_u_155 = nil
function v_u_154._at(p156, p157, p158) -- name: _at
	local v159 = p156._events
	table.insert(v159, {
		["at"] = p157,
		["run"] = p158
	})
end
function v_u_154._over(p160, p161, p162, p163) -- name: _over
	local v164 = p160._tracks
	local v165 = {
		["from"] = p161,
		["seconds"] = math.max(p162, 0.001),
		["step"] = p163
	}
	table.insert(v164, v165)
end
function v_u_154._emitter(p166, p_u_167) -- name: _emitter
	local v_u_168 = p_u_167.instance
	local v169 = v_u_168.TimeScale
	p166._timeScales[v_u_168] = v169
	p166._restore[v_u_168] = {
		["Enabled"] = v_u_168.Enabled,
		["TimeScale"] = v169
	}
	v_u_168.Enabled = false
	if p_u_167.count ~= nil then
		p166:_at(p_u_167.delay, function()
			-- upvalues: (copy) v_u_168, (copy) p_u_167
			v_u_168:Emit(p_u_167.count)
		end)
	end
	if p_u_167.on ~= nil then
		p166:_at(p_u_167.delay, function()
			-- upvalues: (copy) v_u_168
			v_u_168.Enabled = true
		end)
		p166:_at(p_u_167.delay + p_u_167.on, function()
			-- upvalues: (copy) v_u_168
			v_u_168.Enabled = false
		end)
	end
end
function v_u_154._ribbon(p170, p171) -- name: _ribbon
	local v_u_172 = p171.instance
	local v173 = {
		["Enabled"] = v_u_172.Enabled
	}
	p170._restore[v_u_172] = v173
	v_u_172.Enabled = false
	p170:_at(p171.delay, function()
		-- upvalues: (copy) v_u_172
		v_u_172.Enabled = true
	end)
	p170:_at(p171.delay + p171.on, function()
		-- upvalues: (copy) v_u_172
		v_u_172.Enabled = false
	end)
	if v_u_172:IsA("Trail") then
		v173.Lifetime = v_u_172.Lifetime
		local v174 = p170._trails
		local v175 = {
			["trail"] = v_u_172,
			["lifetime"] = v_u_172.Lifetime
		}
		table.insert(v174, v175)
	else
		v173.TextureSpeed = v_u_172.TextureSpeed
		p170._beams[v_u_172] = v_u_172.TextureSpeed
	end
end
function v_u_154._light(p176, p177) -- name: _light
	-- upvalues: (copy) v_u_3
	local v_u_178 = p177.instance
	local v_u_179 = v_u_178.Brightness
	p176._restore[v_u_178] = {
		["Enabled"] = v_u_178.Enabled,
		["Brightness"] = v_u_179
	}
	v_u_178.Enabled = false
	p176:_at(p177.delay, function()
		-- upvalues: (copy) v_u_178
		v_u_178.Enabled = true
	end)
	p176:_over(p177.delay, p177.on, function(p180)
		-- upvalues: (copy) v_u_178, (copy) v_u_179, (ref) v_u_3
		v_u_178.Brightness = v_u_179 * (1 - v_u_3:GetValue(p180, Enum.EasingStyle.Quad, Enum.EasingDirection.Out))
	end)
	p176:_at(p177.delay + p177.on, function()
		-- upvalues: (copy) v_u_178
		v_u_178.Enabled = false
	end)
end
function v_u_154._mesh(p_u_181, p_u_182) -- name: _mesh
	-- upvalues: (copy) v_u_3
	local v_u_183 = p_u_182.start
	local v184 = p_u_182.finish
	local v_u_185 = {
		["CFrame"] = v_u_183.CFrame,
		["Size"] = v_u_183.Size,
		["Transparency"] = v_u_183.Transparency,
		["Color"] = v_u_183.Color
	}
	local v_u_186 = {
		["CFrame"] = v184.CFrame,
		["Size"] = v184.Size,
		["Transparency"] = v184.Transparency,
		["Color"] = v184.Color
	}
	local v_u_187 = p_u_181._origin:ToObjectSpace(v_u_185.CFrame)
	local v_u_188 = p_u_181._origin:ToObjectSpace(v_u_186.CFrame)
	local v_u_189 = v_u_183:FindFirstChildOfClass("SpecialMesh")
	local v_u_190 = v184:FindFirstChildOfClass("SpecialMesh")
	local v_u_191
	if v_u_189 then
		v_u_191 = v_u_189.Scale
	else
		v_u_191 = v_u_189
	end
	if v_u_190 then
		v_u_190 = v_u_190.Scale
	end
	if v_u_189 then
		p_u_181._restore[v_u_189] = {
			["Scale"] = v_u_191
		}
	end
	local v_u_192 = {}
	for _, v193 in v_u_183:GetChildren() do
		if not v193:IsA("Decal") then
			continue
		end
		local v194 = v184:FindFirstChild(v193.Name)
		local v195
		if v194 and v194:IsA("Decal") then
			v195 = v194.Transparency
		else
			v195 = v193.Transparency
		end
		local v196 = {
			["decal"] = v193,
			["from"] = v193.Transparency,
			["to"] = v195
		}
		table.insert(v_u_192, v196)
		p_u_181._restore[v193] = {
			["Transparency"] = v193.Transparency
		}
		v193.Transparency = 1
	end
	if p_u_181._owned then
		v184:Destroy()
	else
		p_u_181._restore[v184] = {
			["Transparency"] = v184.Transparency
		}
		v184.Transparency = 1
	end
	p_u_181._restore[v_u_183] = v_u_185
	v_u_183.Transparency = 1
	local v_u_197 = p_u_182.spin
	p_u_181:_over(p_u_182.delay, p_u_182.duration, function(p198)
		-- upvalues: (ref) v_u_3, (copy) p_u_182, (copy) v_u_183, (copy) p_u_181, (copy) v_u_187, (copy) v_u_188, (copy) v_u_197, (copy) v_u_185, (copy) v_u_186, (copy) v_u_189, (copy) v_u_191, (copy) v_u_190, (copy) v_u_192
		local v199 = v_u_3:GetValue(p198, p_u_182.style, p_u_182.direction)
		v_u_183.CFrame = p_u_181._placement * v_u_187:Lerp(v_u_188, v199) * CFrame.Angles(0, v_u_197 * v199, 0)
		v_u_183.Size = v_u_185.Size:Lerp(v_u_186.Size, v199)
		v_u_183.Transparency = v_u_185.Transparency + (v_u_186.Transparency - v_u_185.Transparency) * v199
		v_u_183.Color = v_u_185.Color:Lerp(v_u_186.Color, v199)
		if v_u_189 and (v_u_191 and v_u_190) then
			v_u_189.Scale = v_u_191:Lerp(v_u_190, v199)
		end
		for _, v200 in v_u_192 do
			v200.decal.Transparency = v200.from + (v200.to - v200.from) * v199
		end
		if p198 >= 1 then
			v_u_183.Transparency = 1
			for _, v201 in v_u_192 do
				v201.decal.Transparency = 1
			end
		end
	end)
end
function v_u_154._applyScale(p202, p203) -- name: _applyScale
	p202._scale = p203
	for v204, v205 in p202._timeScales do
		v204.TimeScale = v205 * p203
	end
	for _, v206 in p202._trails do
		local v207 = v206.lifetime
		local v208 = v206.trail
		local v209 = v207 / 20
		local v210 = v207 / math.max(p203, v209, 1e-6)
		v208.Lifetime = math.min(v210, 20)
	end
	for v211, v212 in p202._beams do
		v211.TextureSpeed = v212 * p203
	end
	for _, v213 in p202._children do
		if not v213.handle or v213.handle.finished then
			continue
		end
		v213.handle:_applyScale(p203)
	end
end
function v_u_154.setTimeScale(p214, p215) -- name: setTimeScale
	if not p214.finished then
		p214._freezeToken = nil
		local v216 = tonumber(p215) or 1
		p214:_applyScale((math.clamp(v216, 0, 1)))
	end
end
v_u_154.setSpeed = v_u_154.setTimeScale
function v_u_154.freeze(p_u_217, p218) -- name: freeze
	if not p_u_217.finished then
		if p_u_217._freezeToken == nil then
			p_u_217._resume = p_u_217._scale
		end
		local v_u_219 = {}
		p_u_217._freezeToken = v_u_219
		p_u_217:_applyScale(0)
		local v220 = task.delay
		local v221 = tonumber(p218) or 0
		v220(math.max(v221, 0), function()
			-- upvalues: (copy) p_u_217, (copy) v_u_219
			if p_u_217._freezeToken == v_u_219 and not p_u_217.finished then
				p_u_217._freezeToken = nil
				p_u_217:_applyScale(p_u_217._resume)
			end
		end)
	end
end
function v_u_154.getTime(p222) -- name: getTime
	return p222.time
end
function v_u_154.getSpeed(p223) -- name: getSpeed
	return p223._scale
end
function v_u_154.isDone(p224) -- name: isDone
	return p224.finished
end
function v_u_154.onDone(p225, p226) -- name: onDone
	if p225.finished then
		task.spawn(p226)
	else
		local v227 = p225._onDone
		table.insert(v227, p226)
	end
end
function v_u_154.onStep(p228, p229) -- name: onStep
	local v230 = p228._onStep
	table.insert(v230, p229)
end
function v_u_154.add(p231, p232, p233, p234) -- name: add
	-- upvalues: (copy) v_u_26, (copy) v_u_30
	v_u_26(p232)
	if p233 == nil then
		if not (p231.root:IsA("Model") or p231.root:IsA("BasePart")) then
			error("Emit: add needs where to play the effect", 2)
		end
	else
		v_u_30(p233)
	end
	local v235 = p231._children
	local v236 = {
		["effect"] = p232,
		["at"] = p233
	}
	local v237 = tonumber(p234) or p231.time
	v236.delay = math.max(v237, 0)
	table.insert(v235, v236)
end
function v_u_154._advance(p238, p239) -- name: _advance
	-- upvalues: (copy) v_u_30, (copy) v_u_35, (ref) v_u_155
	if p238.finished then
		return
	else
		p238.time = p238.time + p239
		if p238._follow then
			if not p238._follow.Parent then
				p238:stop()
				return
			end
			p238._placement = v_u_30(p238._follow) * p238._offset
			v_u_35(p238.root, p238._placement)
		end
		for _, v240 in table.clone(p238._onStep) do
			local v241 = p238.time
			local v242, v243 = pcall(v240, v241, p239)
			if v242 then
				continue
			end
			warn((("VFXEmit: onStep error: %*"):format(v243)))
		end
		if not p238.finished then
			local v244 = p238.time
			local v245 = {}
			for _, v246 in p238._events do
				if v246.at <= v244 then
					v246.run()
				else
					table.insert(v245, v246)
				end
			end
			p238._events = v245
			local v247 = {}
			for _, v248 in p238._tracks do
				if v248.from <= v244 then
					local v249 = (v244 - v248.from) / v248.seconds
					local v250 = math.min(v249, 1)
					v248.step(v250)
					if v250 >= 1 then
						continue
					end
					table.insert(v247, v248)
				else
					table.insert(v247, v248)
				end
			end
			p238._tracks = v247
			local v251 = true
			for _, v252 in p238._children do
				if v252.handle or v252.delay > v244 then
					if v252.handle and not v252.handle.finished then
						v252.handle:_advance(p239)
					end
				else
					local v253 = v252.at or p238.root:GetPivot()
					local v254 = v_u_155
					local v255 = v252.effect
					local v256 = {
						["parent"] = p238._childParent
					}
					local v257, v258 = pcall(v254, v255, v253, v256)
					if v257 then
						v252.handle = v258
						v258:_applyScale(p238._scale)
						v258:_advance(v244 - v252.delay)
					else
						warn((("VFXEmit: %*"):format(v258)))
						v252.handle = {
							["finished"] = true
						}
					end
				end
				if v252.handle and v252.handle.finished then
					continue
				end
				v251 = false
			end
			if p238.duration <= v244 and v251 then
				p238:stop()
			end
		end
	end
end
function v_u_154._cleanupSteps(p_u_259) -- name: _cleanupSteps
	local v260 = {}
	table.insert(v260, {
		["name"] = "disconnect from Heartbeat",
		["run"] = nil,
		["target"] = nil,
		["run"] = function()
			-- upvalues: (copy) p_u_259
			if p_u_259._connection then
				p_u_259._connection:Disconnect()
				p_u_259._connection = nil
			end
		end
	})
	for v261, v_u_262 in p_u_259._children do
		if not (v_u_262.handle and v_u_262.handle.stop) then
			continue
		end
		local v265 = {
			["name"] = nil,
			["run"] = nil,
			["target"] = nil,
			["name"] = ("stop added effect %*"):format(v261),
			["run"] = function()
				-- upvalues: (copy) v_u_262
				local v263, v264 = v_u_262.handle:stop()
				if v263 == false then
					error(table.concat(v264, "; "), 0)
				end
			end
		}
		table.insert(v260, v265)
	end
	if not p_u_259._owned then
		for v_u_266, v267 in p_u_259._restore do
			for v_u_268, v_u_269 in v267 do
				local v270 = {
					["name"] = ("restore %*.%*"):format(v_u_266:GetFullName(), v_u_268),
					["run"] = function()
						-- upvalues: (copy) v_u_266, (copy) v_u_268, (copy) v_u_269
						v_u_266[v_u_268] = v_u_269
					end,
					["target"] = v_u_266
				}
				table.insert(v260, v270)
			end
		end
		return v260
	end
	local v271 = {
		["name"] = ("destroy %*"):format((p_u_259.root:GetFullName())),
		["run"] = function()
			-- upvalues: (copy) p_u_259
			p_u_259.root:Destroy()
		end,
		["target"] = p_u_259.root
	}
	table.insert(v260, v271)
	return v260
end
function v_u_154.stop(p272) -- name: stop
	-- upvalues: (copy) v_u_8
	if not p272.finished then
		p272.finished = true
		p272._freezeToken = nil
		p272._pending = p272:_cleanupSteps()
	end
	local v273 = p272._pending
	local v274 = {}
	if v273 then
		local v275 = {}
		for _, v276 in v273 do
			local v277 = v276.run
			local v278, v279 = pcall(v277)
			if v278 then
				continue
			end
			if v276.target then
				local v_u_280 = v276.target
				local v281, v282 = pcall(function()
					-- upvalues: (copy) v_u_280
					return v_u_280:IsDescendantOf(game)
				end)
				if v281 then
					v281 = not v282
				end
				if v281 then
					continue
				end
			end
			table.insert(v275, v276)
			local v283 = ("%*: %*"):format(v276.name, v279)
			table.insert(v274, v283)
		end
		if #v275 <= 0 then
			v275 = nil
		end
		p272._pending = v275
		if p272._pending == nil and v_u_8[p272.root] == p272 then
			v_u_8[p272.root] = nil
		end
	end
	if not p272._doneFired then
		p272._doneFired = true
		for _, v284 in p272._onDone do
			task.spawn(v284)
		end
		table.clear(p272._onDone)
	end
	if #v274 <= 0 then
		return true
	end
	warn((("VFXEmit: stopping %* didn\'t finish; call stop() again. %*"):format(p272.root.Name, (table.concat(v274, "; ")))))
	return false, v274
end
local function v_u_305(p285, p286, p287, p288) -- name: start
	-- upvalues: (copy) v_u_82, (copy) v_u_154
	local v289, v290, v291 = v_u_82(p285, true)
	local v292 = p285:GetAttribute("EffectDuration")
	if typeof(v292) ~= "number" or v292 ~= v292 then
		if v292 == nil then
			v292 = nil
		else
			warn((("VFXEmit: %*.EffectDuration should be a number, got %*"):format(p285:GetFullName(), (typeof(v292)))))
			v292 = nil
		end
	end
	if v292 ~= nil then
		v291 = math.max(v292, v290)
	end
	local v293 = math.clamp(v291, 0, 30)
	if v292 == nil and #v289 == 0 then
		warn((("VFXEmit: nothing under %* has EmitCount, EmitDuration or Start/End to play"):format((p285:GetFullName()))))
	end
	local v294 = {
		["root"] = nil,
		["model"] = nil,
		["time"] = 0,
		["finished"] = false,
		["duration"] = nil,
		["_owned"] = nil,
		["_scale"] = 1,
		["_events"] = nil,
		["_tracks"] = nil,
		["_timeScales"] = nil,
		["_trails"] = nil,
		["_beams"] = nil,
		["_restore"] = nil,
		["_children"] = nil,
		["_onDone"] = nil,
		["_onStep"] = nil,
		["_origin"] = nil,
		["_placement"] = nil,
		["_childParent"] = nil,
		["root"] = p285,
		["model"] = p285,
		["duration"] = v293,
		["_owned"] = p286,
		["_events"] = {},
		["_tracks"] = {},
		["_timeScales"] = {},
		["_trails"] = {},
		["_beams"] = {},
		["_restore"] = {},
		["_children"] = {},
		["_onDone"] = {},
		["_onStep"] = {},
		["_origin"] = p288 or CFrame.identity,
		["_placement"] = p288 or CFrame.identity,
		["_childParent"] = p287.parent or workspace
	}
	local v295 = v_u_154
	local v296 = setmetatable(v294, v295)
	local v297 = p287.onDone
	if type(v297) == "function" then
		local v298 = v296._onDone
		local v299 = p287.onDone
		table.insert(v298, v299)
	end
	if p286 then
		local v300 = p285:GetDescendants()
		table.insert(v300, p285)
		for _, v301 in v300 do
			if not v301:IsA("BasePart") then
				continue
			end
			v301.Anchored = true
			v301.CanCollide = false
			v301.CanQuery = false
			v301.CanTouch = false
			v301.CastShadow = false
		end
	end
	for _, v302 in v289 do
		if v302.kind == "emitter" then
			v296:_emitter(v302)
		elseif v302.kind == "ribbon" then
			v296:_ribbon(v302)
		elseif v302.kind == "light" then
			v296:_light(v302)
		else
			v296:_mesh(v302)
		end
	end
	local v303 = p287.timeScale or p287.speed
	local v304 = tonumber(v303) or 1
	v296:_applyScale((math.clamp(v304, 0, 1)))
	return v296
end
v_u_155 = function(p306, p307, p308) -- name: startCopy
	-- upvalues: (copy) v_u_26, (copy) v_u_30, (copy) v_u_35, (copy) v_u_305
	local v309 = v_u_26(p306, 4)
	if not (v309:IsA("Model") or v309:IsA("BasePart")) then
		error(("Emit.play: %* must be a Model or a BasePart"):format((v309:GetFullName())), 4)
	end
	local v310 = p308.follow
	local v311 = p308.offset
	local v312
	if typeof(v311) == "CFrame" then
		v312 = p308.offset
	else
		v312 = CFrame.identity
	end
	local v313
	if v310 == nil then
		v313 = v_u_30(p307, 4)
	else
		v313 = v_u_30(v310, 4) * v312
	end
	local v314 = v309:Clone()
	if v314 == nil then
		error(("Emit.play: %* can\'t be copied; turn its Archivable back on"):format((v309:GetFullName())), 4)
	end
	v_u_35(v314, v313)
	local v315 = v_u_305
	local v316 = true
	if v310 == nil then
		v313 = nil
	end
	local v317 = v315(v314, v316, p308, v313)
	v317._follow = v310
	v317._offset = v312
	v314.Parent = p308.parent or workspace
	return v317
end
function v_u_5.play(p318, p319, p320) -- name: play
	-- upvalues: (ref) v_u_155, (copy) v_u_2
	local v_u_321 = v_u_155(p318, p319, p320 or {})
	v_u_321:_advance(0)
	if not v_u_321.finished then
		v_u_321._connection = v_u_2.Heartbeat:Connect(function(p322)
			-- upvalues: (copy) v_u_321
			v_u_321:_advance(p322 * v_u_321._scale)
		end)
	end
	return v_u_321
end
function v_u_5.emit(p323, p324) -- name: emit
	-- upvalues: (copy) v_u_8, (copy) v_u_305, (copy) v_u_2
	if typeof(p323) ~= "Instance" then
		error("Emit.emit: pass the instance whose effects should play", 2)
	end
	local v325 = v_u_8[p323]
	if v325 then
		local v326, v327 = v325:stop()
		if v326 == false then
			error(("Emit.emit: the previous play of %* couldn\'t be put back, so it can\'t play again yet: %*"):format(p323:GetFullName(), (table.concat(v327, "; "))), 2)
		end
	end
	local v_u_328 = v_u_305(p323, false, p324 or {}, nil)
	v_u_8[p323] = v_u_328
	v_u_328:_advance(0)
	if not v_u_328.finished then
		v_u_328._connection = v_u_2.Heartbeat:Connect(function(p329)
			-- upvalues: (copy) v_u_328
			v_u_328:_advance(p329 * v_u_328._scale)
		end)
	end
	return v_u_328
end
return v_u_5
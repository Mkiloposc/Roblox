local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = game:GetService("Workspace")
local v_u_7 = require(v3.Shared.EggDespawnClock)
local v_u_8 = require(v3.Shared.EggInfoUi)
local v_u_9 = require(v3.Shared.FormatNumber)
local v_u_10 = require(script.Parent.EggLocalHits)
local v11 = {}
local v_u_12 = v2.LocalPlayer
local v_u_13 = TweenInfo.new(0.15, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_14 = TweenInfo.new(0.18, Enum.EasingStyle.Back, Enum.EasingDirection.In)
local v_u_15 = {}
local v_u_16 = {}
local function v_u_99(p_u_17) -- name: setupEgg
	-- upvalues: (copy) v_u_8, (copy) v_u_6, (copy) v_u_12, (copy) v_u_7, (copy) v_u_5, (copy) v_u_14, (copy) v_u_9, (copy) v_u_4, (copy) v_u_10, (copy) v_u_13, (copy) v_u_16, (copy) v_u_15
	if p_u_17:IsA("BasePart") and not p_u_17:GetAttribute("_InfoHooked") then
		p_u_17:SetAttribute("_InfoHooked", true)
		task.spawn(function()
			-- upvalues: (ref) v_u_8, (copy) p_u_17, (ref) v_u_6, (ref) v_u_12, (ref) v_u_7, (ref) v_u_5, (ref) v_u_14, (ref) v_u_9, (ref) v_u_4, (ref) v_u_10, (ref) v_u_13, (ref) v_u_16, (ref) v_u_15
			local v_u_18 = v_u_8.WaitFor(p_u_17, 10)
			if v_u_18 and p_u_17.Parent then
				local v_u_19 = nil
				local v_u_20 = nil
				local v_u_21 = nil
				local function v_u_29() -- name: getHpRefs
					-- upvalues: (ref) v_u_19, (copy) v_u_18, (ref) v_u_20, (ref) v_u_21
					local v22 = v_u_19
					if v22 and (v22.hpBar.Parent and (v22.bar ~= nil and (v22.bar.Parent and (v22.hpAmount ~= nil and v22.hpAmount.Parent)))) then
						return v22
					end
					local v23 = v_u_18:FindFirstChild("HpBar", true)
					if not (v23 and v23:IsA("GuiObject")) then
						return nil
					end
					local v24 = v23:FindFirstChild("_HpScale")
					if not (v24 and v24:IsA("UIScale")) then
						v24 = Instance.new("UIScale")
						v24.Name = "_HpScale"
						v24.Parent = v23
					end
					local v25 = v23.Parent
					if not (v25 and v25:IsA("GuiObject")) then
						v25 = nil
					end
					if v_u_20 ~= v23 then
						v_u_20 = v23
						v23.Visible = false
						if v25 then
							v25.Visible = false
						end
						v23.ClipsDescendants = true
					end
					local v26 = v23:FindFirstChild("Bar")
					if v26 and (v26:IsA("GuiObject") and v_u_21 ~= v26) then
						v_u_21 = v26
						v26.AnchorPoint = Vector2.new(0, 0.5)
						v26.Position = UDim2.fromScale(0, 0.5)
					end
					local v27 = v23:FindFirstChild("HpAmount")
					local v28 = {
						["hpBar"] = v23,
						["row"] = v25
					}
					if not (v26 and v26:IsA("GuiObject")) then
						v26 = nil
					end
					v28.bar = v26
					if not (v27 and v27:IsA("TextLabel")) then
						v27 = nil
					end
					v28.hpAmount = v27
					v28.scale = v24
					v_u_19 = v28
					return v_u_19
				end
				task.spawn(function()
					-- upvalues: (ref) p_u_17, (copy) v_u_18, (ref) v_u_6, (ref) v_u_12, (ref) v_u_8, (ref) v_u_7
					local v30 = nil
					local v31 = nil
					while true do
						local v32, v33, v34, v35
						while true do
							if not (p_u_17.Parent and v_u_18.Parent) then
								return
							end
							if not (v30 and (v30.Parent and (v31 and v31.Parent))) then
								break
							end
							v32 = p_u_17:GetAttribute("DespawnAt")
							v33 = p_u_17:GetAttribute("Hatching") or (p_u_17:GetAttribute("Broken") or p_u_17:GetAttribute("Despawning"))
							if v32 then
								v34 = v32 - v_u_6:GetServerTimeNow()
								v35 = math.max(v34, 0)
								if not v33 and v_u_18.PlayerToHideFrom ~= v_u_12 then
									if v31 then
										v31.Text = v_u_8.FormatTimer(v35)
									end
									if not v30.Visible then
										v30.Visible = true
									end
								end
								if v35 <= 0 then
									break
								end
								task.wait(v_u_7.TickDelay(v35, v_u_7.IsSlowed(p_u_17)))
							else
								if v30.Visible and not v33 then
									v30.Visible = false
								end
								task.wait(1)
							end
						end
						v30 = v_u_18:FindFirstChild("Timer")
						if not (v30 and v30:IsA("GuiObject")) then
							v30 = nil
						end
						if v30 then
							v31 = v30:FindFirstChild("TimeLeft", true)
						else
							v31 = v30
						end
						if not (v31 and v31:IsA("TextLabel")) then
							v31 = nil
						end
						if v30 then
							v32 = p_u_17:GetAttribute("DespawnAt")
							v33 = p_u_17:GetAttribute("Hatching") or (p_u_17:GetAttribute("Broken") or p_u_17:GetAttribute("Despawning"))
							if v32 then
								v34 = v32 - v_u_6:GetServerTimeNow()
								v35 = math.max(v34, 0)
								if not v33 and v_u_18.PlayerToHideFrom ~= v_u_12 then
									if v31 then
										v31.Text = v_u_8.FormatTimer(v35)
									end
									if not v30.Visible then
										v30.Visible = true
									end
								end
								if v35 <= 0 then
									break
								end
								task.wait(v_u_7.TickDelay(v35, v_u_7.IsSlowed(p_u_17)))
							else
								if v30.Visible and not v33 then
									v30.Visible = false
								end
								task.wait(1)
							end
						else
							task.wait(0.5)
						end
					end
				end)
				local v_u_36 = nil
				local function v_u_44(p37) -- name: hideHpBar
					-- upvalues: (copy) v_u_29, (ref) v_u_36, (ref) v_u_5, (ref) v_u_14
					local v38 = v_u_29()
					if v38 then
						if p37 then
							if v_u_36 then
								local v39 = v_u_36
								v_u_36 = nil
								v39:Cancel()
							end
							v38.hpBar.Visible = false
							if v38.row then
								v38.row.Visible = false
							end
							v38.scale.Scale = 1
							return
						elseif v38.hpBar.Visible and not v_u_36 then
							local v_u_40 = v38.hpBar
							local v_u_41 = v38.row
							local v_u_42 = v38.scale
							local v_u_43 = v_u_5:Create(v_u_42, v_u_14, {
								["Scale"] = 0
							})
							v_u_36 = v_u_43
							v_u_43.Completed:Once(function()
								-- upvalues: (ref) v_u_36, (copy) v_u_43, (copy) v_u_40, (copy) v_u_41, (copy) v_u_42
								if v_u_36 == v_u_43 then
									v_u_36 = nil
									v_u_40.Visible = false
									if v_u_41 then
										v_u_41.Visible = false
									end
									v_u_42.Scale = 1
								end
							end)
							v_u_43:Play()
						end
					else
						return
					end
				end
				local v_u_45 = false
				local v_u_46 = nil
				local v_u_47 = nil
				local function v50() -- name: updateEnabled
					-- upvalues: (ref) v_u_45, (copy) v_u_18, (ref) p_u_17
					if not v_u_45 then
						local v48 = v_u_18
						local v49 = not (p_u_17:GetAttribute("Broken") or p_u_17:GetAttribute("Hatching"))
						if v49 then
							v49 = not p_u_17:GetAttribute("Despawning")
						end
						v48.Enabled = v49
					end
				end
				local v_u_51 = nil
				local v_u_52 = false
				local v_u_53 = 0
				local v_u_54 = false
				local v_u_55 = p_u_17:GetAttribute("Titanic") == true
				local function v_u_91() -- name: updateHealth
					-- upvalues: (copy) v_u_29, (ref) v_u_45, (ref) v_u_10, (ref) p_u_17, (ref) v_u_46, (ref) v_u_53, (copy) v_u_18, (ref) v_u_36, (ref) v_u_9, (ref) v_u_4, (copy) v_u_44, (ref) v_u_47, (ref) v_u_12, (ref) v_u_51, (ref) v_u_5, (ref) v_u_13, (copy) v_u_55, (ref) v_u_16, (ref) v_u_54, (ref) v_u_15, (copy) v_u_91, (ref) v_u_52
					local v56 = v_u_29()
					if v56 and not v_u_45 then
						local v57 = v_u_10.GetDisplayHealth(p_u_17)
						local v58 = p_u_17:GetAttribute("Health") or 0
						local v_u_59 = p_u_17:GetAttribute("MaxHealth") or 1
						local v60 = v57 / v_u_59
						local v61 = math.clamp(v60, 0, 1)
						local v62 = v_u_46
						v_u_46 = v57
						if v62 ~= nil and v57 < v62 then
							v_u_53 = os.clock()
						end
						if v57 <= 0 and (v62 ~= nil and v_u_59 <= v62) then
							local v_u_63 = v_u_29()
							if v_u_63 then
								v_u_45 = true
								v_u_18.Enabled = true
								local v64 = v_u_29()
								if v64 then
									if v_u_36 then
										local v65 = v_u_36
										v_u_36 = nil
										v65:Cancel()
									end
									v64.scale.Scale = 1
									v64.hpBar.Visible = true
									if v64.row then
										v64.row.Visible = true
									end
								end
								task.spawn(function()
									-- upvalues: (ref) v_u_9, (copy) v_u_59, (copy) v_u_63, (ref) p_u_17, (ref) v_u_4, (ref) v_u_44, (ref) v_u_45, (ref) v_u_18, (ref) v_u_47
									local v66 = v_u_59
									local v67 = v_u_9.Short((math.floor(v66)))
									local v68 = os.clock()
									while v_u_63.hpBar.Parent and p_u_17.Parent do
										local v69 = (os.clock() - v68) / 0.55
										local v70 = math.clamp(v69, 0, 1)
										local v71 = 1 - (1 - v70) ^ 2
										local v72 = v_u_59 * (1 - v71)
										if v_u_63.bar then
											v_u_63.bar.Position = UDim2.fromScale(-v71, 0.5)
										end
										if v_u_63.hpAmount then
											v_u_63.hpAmount.Text = ("%*/%* HP"):format(v_u_9.Short((math.floor(v72))), v67)
										end
										if v70 >= 1 then
											break
										end
										v_u_4.RenderStepped:Wait()
									end
									task.wait(0.2)
									if v_u_63.hpBar.Parent then
										v_u_44()
									end
									v_u_45 = false
									if not v_u_45 then
										local v73 = v_u_18
										local v74 = not (p_u_17:GetAttribute("Broken") or p_u_17:GetAttribute("Hatching"))
										if v74 then
											v74 = not p_u_17:GetAttribute("Despawning")
										end
										v73.Enabled = v74
									end
									if v_u_47 then
										v_u_47()
									end
								end)
							end
						else
							local v75 = v_u_18.PlayerToHideFrom == v_u_12
							if v56.bar and not v75 then
								if v_u_51 then
									v_u_51:Cancel()
								end
								v_u_51 = v_u_5:Create(v56.bar, v_u_13, {
									["Position"] = UDim2.fromScale(v61 - 1, 0.5)
								})
								v_u_51:Play()
							end
							if v56.hpAmount and not v75 then
								v56.hpAmount.Text = ("%*/%* HP"):format(v_u_9.Short((math.floor(v57))), (v_u_9.Short((math.floor(v_u_59)))))
							end
							if p_u_17:GetAttribute("Hatching") or p_u_17:GetAttribute("Broken") then
								local v76 = v_u_29()
								if v76 then
									if v_u_36 then
										local v77 = v_u_36
										v_u_36 = nil
										v77:Cancel()
									end
									v76.hpBar.Visible = false
									if v76.row then
										v76.row.Visible = false
									end
									v76.scale.Scale = 1
								end
							elseif v58 <= 0 then
								v_u_44()
							elseif v_u_55 then
								local v78 = v_u_29()
								if not v78 then
									return
								end
								if v_u_36 then
									local v79 = v_u_36
									v_u_36 = nil
									v79:Cancel()
								end
								v78.scale.Scale = 1
								v78.hpBar.Visible = true
								if v78.row then
									v78.row.Visible = true
									return
								end
							elseif v57 < v_u_59 then
								local v80 = v_u_53
								local v81 = v_u_16[p_u_17] or 0
								local v82 = math.max(v80, v81)
								local v83 = os.clock() - v82
								if v82 <= 0 or v83 >= 6 then
									v_u_44()
									return
								end
								local v84 = v_u_29()
								if v84 then
									if v_u_36 then
										local v85 = v_u_36
										v_u_36 = nil
										v85:Cancel()
									end
									v84.scale.Scale = 1
									v84.hpBar.Visible = true
									if v84.row then
										v84.row.Visible = true
									end
								end
								if not v_u_54 then
									v_u_54 = true
									task.delay(6 - v83 + 0.05, function()
										-- upvalues: (ref) v_u_54, (ref) p_u_17, (ref) v_u_15, (ref) v_u_91
										v_u_54 = false
										if p_u_17.Parent and v_u_15[p_u_17] then
											v_u_91()
										end
									end)
									return
								end
							else
								local v86 = v_u_16[p_u_17]
								local v87 = v_u_10.ConfirmWindow() + 0.2 + 0.8
								local v88 = math.max(2, v87)
								if v86 and os.clock() - v86 < v88 then
									local v89 = v_u_29()
									if v89 then
										if v_u_36 then
											local v90 = v_u_36
											v_u_36 = nil
											v90:Cancel()
										end
										v89.scale.Scale = 1
										v89.hpBar.Visible = true
										if v89.row then
											v89.row.Visible = true
										end
									end
									if not v_u_52 then
										v_u_52 = true
										task.delay(v88, function()
											-- upvalues: (ref) v_u_52, (ref) p_u_17, (ref) v_u_15, (ref) v_u_91
											v_u_52 = false
											if p_u_17.Parent and v_u_15[p_u_17] then
												v_u_91()
											end
										end)
										return
									end
								else
									v_u_44()
								end
							end
						end
					else
						return
					end
				end
				v_u_47 = v_u_91
				task.spawn(function()
					-- upvalues: (copy) v_u_18, (ref) p_u_17, (copy) v_u_29, (copy) v_u_91
					local v92 = os.clock() + 10
					while os.clock() < v92 and (v_u_18.Parent and p_u_17.Parent) do
						local v93 = v_u_29()
						if v93 and (v93.bar and v93.hpAmount) then
							v_u_91()
							return
						end
						task.wait(0.2)
					end
				end)
				p_u_17:GetAttributeChangedSignal("Health"):Connect(v_u_91)
				p_u_17:GetAttributeChangedSignal("MaxHealth"):Connect(v_u_91)
				p_u_17:GetAttributeChangedSignal("Broken"):Connect(function()
					-- upvalues: (ref) v_u_45, (copy) v_u_18, (ref) p_u_17, (copy) v_u_91
					if not v_u_45 then
						local v94 = v_u_18
						local v95 = not (p_u_17:GetAttribute("Broken") or p_u_17:GetAttribute("Hatching"))
						if v95 then
							v95 = not p_u_17:GetAttribute("Despawning")
						end
						v94.Enabled = v95
					end
					v_u_91()
				end)
				p_u_17:GetAttributeChangedSignal("Hatching"):Connect(function()
					-- upvalues: (ref) v_u_45, (copy) v_u_18, (ref) p_u_17, (copy) v_u_91
					if not v_u_45 then
						local v96 = v_u_18
						local v97 = not (p_u_17:GetAttribute("Broken") or p_u_17:GetAttribute("Hatching"))
						if v97 then
							v97 = not p_u_17:GetAttribute("Despawning")
						end
						v96.Enabled = v97
					end
					v_u_91()
				end)
				p_u_17:GetAttributeChangedSignal("Despawning"):Connect(v50)
				v_u_91()
				if not v_u_45 then
					local v98 = not (p_u_17:GetAttribute("Broken") or p_u_17:GetAttribute("Hatching"))
					if v98 then
						v98 = not p_u_17:GetAttribute("Despawning")
					end
					v_u_18.Enabled = v98
				end
				v_u_15[p_u_17] = v_u_91
				p_u_17.Destroying:Connect(function()
					-- upvalues: (ref) v_u_15, (ref) p_u_17, (ref) v_u_16
					v_u_15[p_u_17] = nil
					v_u_16[p_u_17] = nil
				end)
			end
		end)
	end
end
function v11.Start() -- name: Start
	-- upvalues: (copy) v_u_1, (copy) v_u_99, (copy) v_u_10, (copy) v_u_15, (copy) v_u_16
	for _, v100 in v_u_1:GetTagged("BreakableEgg") do
		v_u_99(v100)
	end
	v_u_1:GetInstanceAddedSignal("BreakableEgg"):Connect(v_u_99)
	v_u_10.OnHit(function(p_u_101)
		-- upvalues: (ref) v_u_15, (ref) v_u_16, (ref) v_u_10
		local v102 = v_u_15[p_u_101]
		if v102 then
			v_u_16[p_u_101] = os.clock()
			v102()
			task.delay(v_u_10.ConfirmWindow() + 0.2, function()
				-- upvalues: (ref) v_u_15, (copy) p_u_101
				local v103 = v_u_15[p_u_101]
				if v103 then
					v103()
				end
			end)
		end
	end)
	v_u_10.OnReject(function(p104)
		-- upvalues: (ref) v_u_15
		local v105 = v_u_15[p104]
		if v105 then
			v105()
		end
	end)
	v_u_10.OnConfirm(function(p106)
		-- upvalues: (ref) v_u_15
		local v107 = v_u_15[p106]
		if v107 then
			v107()
		end
	end)
end
return v11
local v_u_1 = require(script.Parent.BillboardAssets)
local v_u_2 = require(script.Parent.EggRewards)
local v_u_3 = require(script.Parent.RarityGradientFX)
local v_u_4 = require(script.Parent.VariantLabel)
local v_u_5 = {
	["TemplateName"] = "EggInfoUi",
	["AttachmentName"] = "EggOverhead",
	["Clearance"] = 1,
	["RefFootprint"] = 2.5,
	["MinScale"] = 0.75,
	["MaxScale"] = 2,
	["TitanicMaxScale"] = 7,
	["HatchExponent"] = 0.75,
	["HatchMaxScale"] = 9
}
local function v_u_12(p6, p7, p8, p9) -- name: fillRow
	local v10 = p6:FindFirstChild(p7, true)
	if v10 then
		if p8 then
			local v11
			if v10:IsA("TextLabel") then
				v11 = v10
			else
				v11 = v10:FindFirstChildWhichIsA("TextLabel", true)
			end
			if v11 then
				v11.Text = p8
				if p9 then
					v11.TextColor3 = p9
				end
			end
			if v10:IsA("GuiObject") then
				v10.Visible = true
			end
		elseif v10:IsA("GuiObject") then
			v10.Visible = false
		end
	else
		return
	end
end
local v_u_13 = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_5.Anchor(p14) -- name: Anchor
	-- upvalues: (copy) v_u_13, (copy) v_u_5
	local v15 = v_u_13[p14]
	if v15 and v15.Parent then
		return v15
	end
	local v16 = p14:FindFirstChild(v_u_5.AttachmentName)
	if not (v16 and v16:IsA("Attachment")) then
		v16 = p14:FindFirstAncestorOfClass("Model")
		if v16 then
			v16 = v16:FindFirstChild(v_u_5.AttachmentName, true)
		end
	end
	if not (v16 and v16:IsA("Attachment")) then
		return nil
	end
	v_u_13[p14] = v16
	return v16
end
function v_u_5.Host(p17) -- name: Host
	-- upvalues: (copy) v_u_5
	local v18 = v_u_5.Anchor(p17)
	if v18 then
		return v18
	else
		local v19 = p17:FindFirstAncestorOfClass("Model")
		if v19 and v19.PrimaryPart then
			return v19.PrimaryPart
		else
			return p17
		end
	end
end
local v_u_20 = setmetatable({}, {
	["__mode"] = "kv"
})
function v_u_5.Find(p21) -- name: Find
	-- upvalues: (copy) v_u_20, (copy) v_u_5
	local v22 = v_u_20[p21]
	if v22 and v22.Parent then
		return v22
	end
	local v23 = v_u_5.Anchor(p21)
	local v24
	if v23 then
		v24 = v23:FindFirstChild(v_u_5.TemplateName)
	else
		v24 = nil
	end
	if not (v24 and v24:IsA("BillboardGui")) then
		v24 = p21:FindFirstChild(v_u_5.TemplateName)
	end
	if not (v24 and v24:IsA("BillboardGui")) then
		local v25 = p21:FindFirstAncestorOfClass("Model")
		if v25 then
			v25 = v25.PrimaryPart
		end
		if v25 and v25 ~= p21 then
			v24 = v25:FindFirstChild(v_u_5.TemplateName)
		else
			v24 = nil
		end
	end
	if not (v24 and v24:IsA("BillboardGui")) then
		return nil
	end
	v_u_20[p21] = v24
	return v24
end
function v_u_5.WaitFor(p26, p27) -- name: WaitFor
	-- upvalues: (copy) v_u_5
	local v28 = os.clock() + (p27 or 10)
	while p26.Parent do
		local v29 = v_u_5.Find(p26)
		if v29 then
			return v29
		end
		if v28 <= os.clock() then
			break
		end
		task.wait(0.1)
	end
	return nil
end
function v_u_5.Attach(p30) -- name: Attach
	-- upvalues: (copy) v_u_5, (copy) v_u_1
	local v31 = v_u_5.Host(p30)
	local v32 = v_u_5.Find(p30)
	if v32 then
		if v32.Parent ~= v31 then
			v32.Parent = v31
		end
		v_u_5.Scale(p30, v32)
		return v32
	end
	local v33 = v_u_1.Get(v_u_5.TemplateName)
	if not v33 then
		return nil
	end
	local v34 = v33:Clone()
	v34.Parent = v31
	v_u_5.Scale(p30, v34)
	return v34
end
function v_u_5.Footprint(p35) -- name: Footprint
	local v36 = p35.Size.X
	local v37 = p35.Size.Z
	return math.min(v36, v37)
end
function v_u_5.ScaleFor(p38, p39) -- name: ScaleFor
	-- upvalues: (copy) v_u_5
	local v40 = p38 / v_u_5.RefFootprint
	local v41 = v_u_5.MinScale
	local v42 = p39 or v_u_5.MaxScale
	return math.clamp(v40, v41, v42)
end
function v_u_5.MaxScaleFor(p43) -- name: MaxScaleFor
	-- upvalues: (copy) v_u_5
	if p43:GetAttribute("Titanic") then
		return v_u_5.TitanicMaxScale
	else
		return v_u_5.MaxScale
	end
end
function v_u_5.GrowScale(p44, p45, p46) -- name: GrowScale
	-- upvalues: (copy) v_u_5
	local v47 = math.max(p45, 0.001) ^ v_u_5.HatchExponent
	local v48 = v_u_5.ScaleFor(p44, p46) * v47
	local v49 = v_u_5.HatchMaxScale
	return math.min(v48, v49)
end
local v_u_50 = nil
function v_u_5.ApplyScale(p51, p52, p53) -- name: ApplyScale
	-- upvalues: (ref) v_u_50, (copy) v_u_1, (copy) v_u_5
	local v54 = v_u_50
	if v54 == nil then
		local v55 = v_u_1.Find(v_u_5.TemplateName)
		if v55 then
			v54 = v55.Size
		else
			v54 = p51.Size
		end
		if v55 then
			v_u_50 = v54
		end
	end
	p51.Size = UDim2.new(v54.X.Scale * p52, v54.X.Offset * p52, v54.Y.Scale * p52, v54.Y.Offset * p52)
	local v56
	if p53 then
		local v57 = 0
		local v58 = v_u_5.Anchor(p53)
		local v59
		if v58 then
			v59 = v58.Parent
			if v59 and v59:IsA("BasePart") then
				v57 = v58.Position.Y
			else
				v59 = p53
			end
		else
			v59 = v_u_5.Host(p53)
			if not v59:IsA("BasePart") then
				v59 = p53
			end
		end
		local v60 = v54.Y.Scale * p52
		v56 = v59.Size.Y / 2 - v57 + v_u_5.Clearance - (p51.SizeOffset.Y - 0.5) * v60
	else
		v56 = 0
	end
	local v61 = Vector3.new(0, v56, 0)
	if p51.StudsOffset ~= Vector3.new(0, 0, 0) then
		p51.StudsOffset = Vector3.new(0, 0, 0)
	end
	if p51.StudsOffsetWorldSpace ~= v61 then
		p51.StudsOffsetWorldSpace = v61
	end
	if p51.ExtentsOffset ~= Vector3.new(0, 0, 0) then
		p51.ExtentsOffset = Vector3.new(0, 0, 0)
	end
	if p51.ExtentsOffsetWorldSpace ~= Vector3.new(0, 0, 0) then
		p51.ExtentsOffsetWorldSpace = Vector3.new(0, 0, 0)
	end
end
function v_u_5.Scale(p62, p63) -- name: Scale
	-- upvalues: (copy) v_u_5
	v_u_5.ApplyScale(p63, v_u_5.ScaleFor(v_u_5.Footprint(p62), v_u_5.MaxScaleFor(p62)), p62)
end
function v_u_5.Fill(p64, p65) -- name: Fill
	-- upvalues: (copy) v_u_5, (copy) v_u_12, (copy) v_u_2, (copy) v_u_3, (copy) v_u_4
	local v66 = v_u_5.Attach(p64)
	if not v66 then
		return nil
	end
	v_u_12(v66, "Name", p65.Name)
	local v67 = v_u_12
	local v68 = "Rarity"
	local v69 = p65.Rarity
	local v70
	if p65.Rarity then
		v70 = v_u_2.RarityColors[p65.Rarity] or nil
	else
		v70 = nil
	end
	v67(v66, v68, v69, v70)
	if p65.Rarity then
		local v71 = v66:FindFirstChild("Rarity", true)
		if v71 and not v71:IsA("TextLabel") then
			v71 = v71:FindFirstChildWhichIsA("TextLabel", true)
		end
		if v71 then
			v_u_3.ApplyToLabel(v71, p65.Rarity)
		end
	end
	local v72 = v66:FindFirstChild("Weight", true)
	if v72 and v72:IsA("GuiObject") then
		v72.Visible = false
	end
	local v73 = v66:FindFirstChild("Traits", true)
	if v73 and v73:IsA("GuiObject") then
		v73.Visible = false
	end
	v_u_4.Fill(v66, p65.Trait)
	local v74 = v66:FindFirstChild("LuckMultiList", true)
	if v74 and v74:IsA("GuiObject") then
		v74.Visible = false
	end
	if p65.LuckText then
		local v75 = v66:FindFirstChild("LuckMulti", true)
		if v75 and v75:IsA("TextLabel") then
			v75.Text = p65.LuckText
		end
	end
	v_u_5.Scale(p64, v66)
	return v66
end
function v_u_5.FormatTimer(p76) -- name: FormatTimer
	local v77 = math.ceil(p76)
	local v78 = math.max(v77, 0)
	if v78 >= 60 then
		return ("%*:%*"):format(v78 // 60, (string.format("%02d", v78 % 60)))
	else
		return ("%*s"):format(v78)
	end
end
return v_u_5
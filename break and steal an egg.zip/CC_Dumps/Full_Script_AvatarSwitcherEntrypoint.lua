local v1 = script:FindFirstAncestor("Chrome")
local v2 = game:GetService("CorePackages")
local v_u_3 = game:GetService("HttpRbxApiService")
local v_u_4 = game:GetService("HttpService")
local v5 = game:GetService("StarterGui")
local v_u_6 = require(v2.Packages.React)
local v_u_7 = require(v1.Service)
local v8 = require(v1.ChromeShared.Service.ChromeUtils)
local v9 = v8.MappedSignal
local v10 = require(v1.ChromeShared.Service.WindowSizeSignal)
local v_u_11 = require(v1.ChromeShared.Unibar.Constants)
local v_u_12 = require(v1.Integrations.AvatarSwitcher.AvatarSwitcherChromeWrapper)
local v_u_13 = require(v1.Integrations.AvatarSwitcher.AvatarSwitcherIcon)
local v14 = require(v2.Workspace.Packages.Http).Url
local v15 = require(v2.Workspace.Packages.Chrome).Enums.SideSheetPlacement
local v16 = require(v2.Workspace.Packages.SharedFlags)
local v17 = v16.FFlagChromeWindowSignalConstraintsToggle
local v18 = v16.FFlagRemoveAvatarSwitcherIfUnsupported
local v_u_19 = v9.new(v_u_7:onIntegrationStatusChanged(), function()
	-- upvalues: (copy) v_u_7, (copy) v_u_11
	return v_u_7:isWindowOpen(v_u_11.AVATAR_SWITCHER_ID)
end)
local v_u_20
if v18 then
	v_u_20 = v14.AVATAR_URL .. "v2/avatar/experience/get-experience-avatar-support"
else
	v_u_20 = nil
end
local v_u_21
if v17 then
	v_u_21 = v10.new(844, 754, false, true)
else
	v_u_21 = v10.new(844, 754, false)
end
local v_u_22 = v5:GetCoreGuiEnabled(Enum.CoreGuiType.All) or v5:GetCoreGuiEnabled(Enum.CoreGuiType.AvatarSwitcher)
local v23 = {
	["initialAvailability"] = nil,
	["id"] = nil,
	["label"] = "Feature.AvatarSwitcher.Heading.SwitchAvatar",
	["sideSheetPlacement"] = nil,
	["activated"] = nil,
	["isActivated"] = nil,
	["cachePosition"] = true,
	["draggable"] = true,
	["windowSize"] = nil,
	["components"] = nil
}
local v24
if v_u_22 and not v18 then
	v24 = v_u_7.AvailabilitySignal.Available
else
	v24 = v_u_7.AvailabilitySignal.Unavailable
end
v23.initialAvailability = v24
v23.id = v_u_11.AVATAR_SWITCHER_ID
v23.sideSheetPlacement = v15.AboveFold
function v23.activated(_) -- name: activated
	-- upvalues: (copy) v_u_7, (copy) v_u_11
	v_u_7:toggleWindow(v_u_11.AVATAR_SWITCHER_ID)
end
v23.isActivated = v_u_19
v23.windowSize = v_u_21
v23.components = {
	["Icon"] = function() -- name: Icon
		-- upvalues: (copy) v_u_6, (copy) v_u_13, (copy) v_u_19
		local v25 = {
			["isActive"] = v_u_19
		}
		return v_u_6.createElement(v_u_13, v25)
	end,
	["Window"] = function() -- name: Window
		-- upvalues: (copy) v_u_6, (copy) v_u_12, (copy) v_u_21
		local v26 = {
			["windowSize"] = nil,
			["maxWindowWidth"] = 844,
			["maxWindowHeight"] = 754,
			["windowSize"] = v_u_21
		}
		return v_u_6.createElement(v_u_12, v26)
	end
}
local v_u_27 = v_u_7:register(v23)
local v_u_28 = not v18
v8.setCoreGuiAvailability(v_u_27, Enum.CoreGuiType.AvatarSwitcher, function(p29)
	-- upvalues: (ref) v_u_22, (ref) v_u_28, (copy) v_u_27, (copy) v_u_7, (copy) v_u_11
	v_u_22 = p29
	if v_u_22 and v_u_28 then
		v_u_27.availability:available()
	else
		if v_u_7:isWindowOpen(v_u_11.AVATAR_SWITCHER_ID) then
			v_u_7:toggleWindow(v_u_11.AVATAR_SWITCHER_ID)
		end
		v_u_27.availability:unavailable()
	end
end)
if v18 then
	task.spawn(function()
		-- upvalues: (copy) v_u_3, (copy) v_u_20, (copy) v_u_4, (ref) v_u_28, (ref) v_u_22, (copy) v_u_27, (copy) v_u_7, (copy) v_u_11
		if not game:IsLoaded() then
			game.Loaded:Wait()
		end
		local v30, v31 = pcall(function()
			-- upvalues: (ref) v_u_3, (ref) v_u_20, (ref) v_u_4
			return v_u_4:JSONDecode((v_u_3:GetAsyncFullUrl(v_u_20)))
		end)
		if v30 and (v31 and v31.experienceAvatarSupportType ~= 0) then
			v_u_28 = true
			if v_u_22 and v_u_28 then
				v_u_27.availability:available()
				return
			end
			if v_u_7:isWindowOpen(v_u_11.AVATAR_SWITCHER_ID) then
				v_u_7:toggleWindow(v_u_11.AVATAR_SWITCHER_ID)
			end
			v_u_27.availability:unavailable()
		end
	end)
end
return v_u_27
local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v_u_1.Shared.BackpackSellConfig)
local v_u_3 = require(v_u_1.Shared.BackpackUiConfig)
local v4 = require(v_u_1.Shared.CountingNumber)
local v_u_5 = require(v_u_1.Shared.FormatNumber)
local v_u_6 = require(script.Parent.BackpackController)
local v_u_7 = require(script.Parent.Parent.Modules.BackpackSlotVisuals)
local v8 = {}
local v_u_9 = false
local v_u_10 = false
local v_u_11 = {}
local v_u_12 = nil
local v_u_13 = nil
local v_u_14 = nil
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v_u_22 = v4.new(function(p18)
	-- upvalues: (ref) v_u_17, (copy) v_u_5
	if v_u_17 then
		local v19 = v_u_17
		local v20 = v_u_5.Short
		local v21 = p18 + 0.5
		v19.Text = ("$%*"):format((v20((math.floor(v21)))))
	end
end)
local function v_u_27(p23, p24) -- name: decorate
	-- upvalues: (copy) v_u_7, (ref) v_u_9, (copy) v_u_11
	local v25 = v_u_7.SetSellSelected
	local v26 = v_u_9
	if v26 then
		if p23 == nil then
			v26 = false
		else
			v26 = v_u_11[p23] == true
		end
	end
	v25(p24, v26)
end
local function v_u_37(p28) -- name: onClick
	-- upvalues: (ref) v_u_10, (copy) v_u_2, (copy) v_u_11, (copy) v_u_6, (ref) v_u_12, (ref) v_u_15, (ref) v_u_9, (ref) v_u_16, (ref) v_u_14, (ref) v_u_13, (copy) v_u_22
	if v_u_10 then
		return true
	end
	if v_u_2.IsSellable(p28) then
		v_u_11[p28] = not v_u_11[p28] and true or nil
		if v_u_11[p28] then
			v_u_6.UnequipIfHeld(p28)
		end
		v_u_6.RefreshDecorations()
		if v_u_12 then
			local v29 = v_u_12
			local v30 = v_u_6.GetCategoryInfo()
			local v31
			if v30 == nil then
				v31 = false
			else
				v31 = v30.HideSell == true
			end
			v29.Visible = not v31
		end
		if v_u_15 then
			v_u_15.Visible = v_u_9
		end
		if v_u_16 then
			v_u_16.Visible = v_u_9
		end
		if v_u_14 then
			v_u_14.Enabled = v_u_9
		end
		if v_u_13 then
			local v32 = v_u_13
			local v33
			if v_u_9 then
				v33 = v_u_2.ConfirmText
			else
				v33 = v_u_2.SellText
			end
			v32.Text = v33
		end
		local v34 = v_u_22
		local v35 = 0
		for v36 in v_u_11 do
			v35 = v35 + v_u_2.ToolValue(v36)
		end
		v34:Set(v35)
	end
	return true
end
local function v_u_48() -- name: pruneSelection
	-- upvalues: (copy) v_u_11, (copy) v_u_6, (ref) v_u_12, (ref) v_u_15, (ref) v_u_9, (ref) v_u_16, (ref) v_u_14, (ref) v_u_13, (copy) v_u_2, (copy) v_u_22
	local v38 = false
	for v39 in v_u_11 do
		if v_u_6.HasTool(v39) then
			continue
		end
		v_u_11[v39] = nil
		v38 = true
	end
	if v38 then
		if v_u_12 then
			local v40 = v_u_12
			local v41 = v_u_6.GetCategoryInfo()
			local v42
			if v41 == nil then
				v42 = false
			else
				v42 = v41.HideSell == true
			end
			v40.Visible = not v42
		end
		if v_u_15 then
			v_u_15.Visible = v_u_9
		end
		if v_u_16 then
			v_u_16.Visible = v_u_9
		end
		if v_u_14 then
			v_u_14.Enabled = v_u_9
		end
		if v_u_13 then
			local v43 = v_u_13
			local v44
			if v_u_9 then
				v44 = v_u_2.ConfirmText
			else
				v44 = v_u_2.SellText
			end
			v43.Text = v44
		end
		local v45 = v_u_22
		local v46 = 0
		for v47 in v_u_11 do
			v46 = v46 + v_u_2.ToolValue(v47)
		end
		v45:Set(v46)
	end
end
local function v_u_71() -- name: confirmSell
	-- upvalues: (copy) v_u_11, (ref) v_u_9, (copy) v_u_22, (copy) v_u_6, (ref) v_u_12, (ref) v_u_15, (ref) v_u_16, (ref) v_u_14, (ref) v_u_13, (copy) v_u_2, (copy) v_u_1, (ref) v_u_10
	local v49 = {}
	for v50 in v_u_11 do
		table.insert(v49, v50)
	end
	if #v49 == 0 then
		if v_u_9 ~= false then
			v_u_9 = false
			table.clear(v_u_11)
			v_u_22:Snap(0)
			v_u_6.SetClickInterceptor(nil)
			v_u_6.RefreshDecorations()
			if v_u_12 then
				local v51 = v_u_12
				local v52 = v_u_6.GetCategoryInfo()
				local v53
				if v52 == nil then
					v53 = false
				else
					v53 = v52.HideSell == true
				end
				v51.Visible = not v53
			end
			if v_u_15 then
				v_u_15.Visible = v_u_9
			end
			if v_u_16 then
				v_u_16.Visible = v_u_9
			end
			if v_u_14 then
				v_u_14.Enabled = v_u_9
			end
			if v_u_13 then
				local v54 = v_u_13
				local v55
				if v_u_9 then
					v55 = v_u_2.ConfirmText
				else
					v55 = v_u_2.SellText
				end
				v54.Text = v55
			end
			local v56 = v_u_22
			local v57 = 0
			for v58 in v_u_11 do
				v57 = v57 + v_u_2.ToolValue(v58)
			end
			v56:Set(v57)
		end
	else
		local v59 = v_u_1:FindFirstChild(v_u_2.RemoteName)
		if not (v59 and v59:IsA("RemoteFunction")) then
			v59 = nil
		end
		if v59 then
			v_u_10 = true
			local v60 = v59.InvokeServer
			local v61, v62 = pcall(v60, v59, v49)
			v_u_10 = false
			if not v61 then
				warn((("[BackpackSellController] sell failed: %*"):format(v62)))
			end
			if v_u_9 ~= false then
				v_u_9 = false
				table.clear(v_u_11)
				v_u_22:Snap(0)
				v_u_6.SetClickInterceptor(nil)
				v_u_6.RefreshDecorations()
				if v_u_12 then
					local v63 = v_u_12
					local v64 = v_u_6.GetCategoryInfo()
					local v65
					if v64 == nil then
						v65 = false
					else
						v65 = v64.HideSell == true
					end
					v63.Visible = not v65
				end
				if v_u_15 then
					v_u_15.Visible = v_u_9
				end
				if v_u_16 then
					v_u_16.Visible = v_u_9
				end
				if v_u_14 then
					v_u_14.Enabled = v_u_9
				end
				if v_u_13 then
					local v66 = v_u_13
					local v67
					if v_u_9 then
						v67 = v_u_2.ConfirmText
					else
						v67 = v_u_2.SellText
					end
					v66.Text = v67
				end
				local v68 = v_u_22
				local v69 = 0
				for v70 in v_u_11 do
					v69 = v69 + v_u_2.ToolValue(v70)
				end
				v68:Set(v69)
			end
		else
			warn("[BackpackSellController] sell remote missing")
			return
		end
	end
end
local function v_u_80() -- name: onSellPressed
	-- upvalues: (ref) v_u_10, (ref) v_u_9, (copy) v_u_71, (copy) v_u_11, (copy) v_u_22, (copy) v_u_6, (copy) v_u_37, (ref) v_u_12, (ref) v_u_15, (ref) v_u_16, (ref) v_u_14, (ref) v_u_13, (copy) v_u_2
	if v_u_10 then
		return
	elseif v_u_9 then
		v_u_71()
		return
	elseif v_u_9 ~= true then
		v_u_9 = true
		table.clear(v_u_11)
		v_u_22:Snap(0)
		v_u_6.SetClickInterceptor(v_u_37)
		v_u_6.RefreshDecorations()
		if v_u_12 then
			local v72 = v_u_12
			local v73 = v_u_6.GetCategoryInfo()
			local v74
			if v73 == nil then
				v74 = false
			else
				v74 = v73.HideSell == true
			end
			v72.Visible = not v74
		end
		if v_u_15 then
			v_u_15.Visible = v_u_9
		end
		if v_u_16 then
			v_u_16.Visible = v_u_9
		end
		if v_u_14 then
			v_u_14.Enabled = v_u_9
		end
		if v_u_13 then
			local v75 = v_u_13
			local v76
			if v_u_9 then
				v76 = v_u_2.ConfirmText
			else
				v76 = v_u_2.SellText
			end
			v75.Text = v76
		end
		local v77 = v_u_22
		local v78 = 0
		for v79 in v_u_11 do
			v78 = v78 + v_u_2.ToolValue(v79)
		end
		v77:Set(v78)
	end
end
function v8.IsSelling() -- name: IsSelling
	-- upvalues: (ref) v_u_9
	return v_u_9
end
function v8.Start() -- name: Start
	-- upvalues: (copy) v_u_6, (ref) v_u_12, (ref) v_u_13, (ref) v_u_14, (copy) v_u_3, (copy) v_u_80, (ref) v_u_15, (ref) v_u_10, (ref) v_u_9, (copy) v_u_11, (copy) v_u_22, (ref) v_u_16, (copy) v_u_2, (ref) v_u_17, (copy) v_u_27, (copy) v_u_48
	local v81 = os.clock() + 60
	while not v_u_6.IsReady() do
		if v81 < os.clock() then
			warn("[BackpackSellController] backpack UI never came up \226\128\148 sell mode disabled")
			return
		end
		task.wait(0.1)
	end
	local v82 = v_u_6.GetInventoryFrame()
	if v82 then
		local v83 = v82:FindFirstChild("Sell")
		if v83 and v83:IsA("GuiButton") then
			v_u_12 = v83
			local v84 = v83:FindFirstChild("Title")
			if not (v84 and v84:IsA("TextLabel")) then
				v84 = nil
			end
			v_u_13 = v84
			local v85 = v83:FindFirstChild("SellEnabled")
			if not (v85 and v85:IsA("UIStroke")) then
				v85 = nil
			end
			v_u_14 = v85
			v83.AutoButtonColor = false
			v83:SetAttribute("HoverScale", v_u_3.HoverScale)
			v83:SetAttribute("PressScale", v_u_3.PressScale)
			v83.Activated:Connect(v_u_80)
		else
			warn("[BackpackSellController] Inventory.Sell button not found")
		end
		local v86 = v82:FindFirstChild("Cancel")
		if v86 and v86:IsA("GuiButton") then
			v_u_15 = v86
			v86.AutoButtonColor = false
			v86:SetAttribute("HoverScale", v_u_3.HoverScale)
			v86:SetAttribute("PressScale", v_u_3.PressScale)
			v86.Activated:Connect(function()
				-- upvalues: (ref) v_u_10, (ref) v_u_9, (ref) v_u_11, (ref) v_u_22, (ref) v_u_6, (ref) v_u_12, (ref) v_u_15, (ref) v_u_16, (ref) v_u_14, (ref) v_u_13, (ref) v_u_2
				if not v_u_10 then
					if v_u_9 == false then
						return
					end
					v_u_9 = false
					table.clear(v_u_11)
					v_u_22:Snap(0)
					v_u_6.SetClickInterceptor(nil)
					v_u_6.RefreshDecorations()
					if v_u_12 then
						local v87 = v_u_12
						local v88 = v_u_6.GetCategoryInfo()
						local v89
						if v88 == nil then
							v89 = false
						else
							v89 = v88.HideSell == true
						end
						v87.Visible = not v89
					end
					if v_u_15 then
						v_u_15.Visible = v_u_9
					end
					if v_u_16 then
						v_u_16.Visible = v_u_9
					end
					if v_u_14 then
						v_u_14.Enabled = v_u_9
					end
					if v_u_13 then
						local v90 = v_u_13
						local v91
						if v_u_9 then
							v91 = v_u_2.ConfirmText
						else
							v91 = v_u_2.SellText
						end
						v90.Text = v91
					end
					local v92 = v_u_22
					local v93 = 0
					for v94 in v_u_11 do
						v93 = v93 + v_u_2.ToolValue(v94)
					end
					v92:Set(v93)
				end
			end)
		end
		local v95 = v82:FindFirstChild("CashSellValue")
		if v95 and v95:IsA("GuiObject") then
			v_u_16 = v95
			local v96 = v95:FindFirstChild("List")
			if v96 then
				v96 = v96:FindFirstChild("Amount")
			end
			if not (v96 and v96:IsA("TextLabel")) then
				v96 = nil
			end
			v_u_17 = v96
		end
		v_u_6.SetSlotDecorator(v_u_27)
		v_u_6.ObserveChanged(v_u_48)
		v_u_6.ObserveChanged(function()
			-- upvalues: (ref) v_u_10, (ref) v_u_6, (ref) v_u_9, (ref) v_u_11, (ref) v_u_22, (ref) v_u_12, (ref) v_u_15, (ref) v_u_16, (ref) v_u_14, (ref) v_u_13, (ref) v_u_2
			if not v_u_10 then
				local v97 = v_u_6.GetCategoryInfo()
				local v98
				if v97 == nil then
					v98 = false
				else
					v98 = v97.HideSell == true
				end
				if v98 and (v_u_9 and v_u_9 ~= false) then
					v_u_9 = false
					table.clear(v_u_11)
					v_u_22:Snap(0)
					v_u_6.SetClickInterceptor(nil)
					v_u_6.RefreshDecorations()
					if v_u_12 then
						local v99 = v_u_12
						local v100 = v_u_6.GetCategoryInfo()
						local v101
						if v100 == nil then
							v101 = false
						else
							v101 = v100.HideSell == true
						end
						v99.Visible = not v101
					end
					if v_u_15 then
						v_u_15.Visible = v_u_9
					end
					if v_u_16 then
						v_u_16.Visible = v_u_9
					end
					if v_u_14 then
						v_u_14.Enabled = v_u_9
					end
					if v_u_13 then
						local v102 = v_u_13
						local v103
						if v_u_9 then
							v103 = v_u_2.ConfirmText
						else
							v103 = v_u_2.SellText
						end
						v102.Text = v103
					end
					local v104 = v_u_22
					local v105 = 0
					for v106 in v_u_11 do
						v105 = v105 + v_u_2.ToolValue(v106)
					end
					v104:Set(v105)
				end
				if v_u_12 then
					local v107 = v_u_12
					local v108 = v_u_6.GetCategoryInfo()
					local v109
					if v108 == nil then
						v109 = false
					else
						v109 = v108.HideSell == true
					end
					v107.Visible = not v109
				end
				if v_u_15 then
					v_u_15.Visible = v_u_9
				end
				if v_u_16 then
					v_u_16.Visible = v_u_9
				end
				if v_u_14 then
					v_u_14.Enabled = v_u_9
				end
				if v_u_13 then
					local v110 = v_u_13
					local v111
					if v_u_9 then
						v111 = v_u_2.ConfirmText
					else
						v111 = v_u_2.SellText
					end
					v110.Text = v111
				end
				local v112 = v_u_22
				local v113 = 0
				for v114 in v_u_11 do
					v113 = v113 + v_u_2.ToolValue(v114)
				end
				v112:Set(v113)
			end
		end)
		v_u_22:Snap(0)
		v_u_6.ObserveOpen(function(p115)
			-- upvalues: (ref) v_u_9, (ref) v_u_11, (ref) v_u_22, (ref) v_u_6, (ref) v_u_12, (ref) v_u_15, (ref) v_u_16, (ref) v_u_14, (ref) v_u_13, (ref) v_u_2
			if not p115 then
				if v_u_9 == false then
					return
				end
				v_u_9 = false
				table.clear(v_u_11)
				v_u_22:Snap(0)
				v_u_6.SetClickInterceptor(nil)
				v_u_6.RefreshDecorations()
				if v_u_12 then
					local v116 = v_u_12
					local v117 = v_u_6.GetCategoryInfo()
					local v118
					if v117 == nil then
						v118 = false
					else
						v118 = v117.HideSell == true
					end
					v116.Visible = not v118
				end
				if v_u_15 then
					v_u_15.Visible = v_u_9
				end
				if v_u_16 then
					v_u_16.Visible = v_u_9
				end
				if v_u_14 then
					v_u_14.Enabled = v_u_9
				end
				if v_u_13 then
					local v119 = v_u_13
					local v120
					if v_u_9 then
						v120 = v_u_2.ConfirmText
					else
						v120 = v_u_2.SellText
					end
					v119.Text = v120
				end
				local v121 = v_u_22
				local v122 = 0
				for v123 in v_u_11 do
					v122 = v122 + v_u_2.ToolValue(v123)
				end
				v121:Set(v122)
			end
		end)
		if v_u_12 then
			local v124 = v_u_12
			local v125 = v_u_6.GetCategoryInfo()
			local v126
			if v125 == nil then
				v126 = false
			else
				v126 = v125.HideSell == true
			end
			v124.Visible = not v126
		end
		if v_u_15 then
			v_u_15.Visible = v_u_9
		end
		if v_u_16 then
			v_u_16.Visible = v_u_9
		end
		if v_u_14 then
			v_u_14.Enabled = v_u_9
		end
		if v_u_13 then
			local v127 = v_u_13
			local v128
			if v_u_9 then
				v128 = v_u_2.ConfirmText
			else
				v128 = v_u_2.SellText
			end
			v127.Text = v128
		end
		local v129 = v_u_22
		local v130 = 0
		for v131 in v_u_11 do
			v130 = v130 + v_u_2.ToolValue(v131)
		end
		v129:Set(v130)
	end
end
return v8
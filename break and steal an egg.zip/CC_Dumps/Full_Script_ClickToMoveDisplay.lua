local v1 = {}
local v_u_2 = "rbxasset://textures/ui/traildot.png"
local v_u_3 = "rbxasset://textures/ui/waypoint.png"
local v_u_4 = false
local v_u_5 = UDim2.new(0, 42, 0, 50)
local v_u_6 = Vector2.new(0, 0.5)
local v_u_7 = Vector2.new(0, 1)
local v_u_8 = Vector2.new(0, 0.5)
local v_u_9 = Vector2.new(0.1, 0.5)
local v_u_10 = Vector2.new(-0.1, 0.5)
local v_u_11 = Vector2.new(1.5, 1.5)
local v_u_12 = RaycastParams.new()
v_u_12.FilterType = Enum.RaycastFilterType.Exclude
local v13 = game:GetService("Players")
local v_u_14 = game:GetService("TweenService")
local v_u_15 = game:GetService("RunService")
local v_u_16 = game:GetService("Workspace")
local v_u_17 = require(script.Parent.Parent:WaitForChild("CommonUtils")).get("FlagUtil").getUserFlag("UserRaycastUpdateAPI2")
local v_u_18 = v13.LocalPlayer
local function v_u_30() -- name: CreateWaypointTemplates
	-- upvalues: (ref) v_u_11, (ref) v_u_4, (ref) v_u_2, (copy) v_u_5, (copy) v_u_6, (ref) v_u_3, (copy) v_u_8
	local v19 = Instance.new("Part")
	v19.Size = Vector3.new(1, 1, 1)
	v19.Anchored = true
	v19.CanCollide = false
	v19.Name = "TrailDot"
	v19.Transparency = 1
	local v20 = Instance.new("ImageHandleAdornment")
	v20.Name = "TrailDotImage"
	v20.Size = v_u_11
	v20.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	v20.AlwaysOnTop = v_u_4
	v20.Image = v_u_2
	v20.Adornee = v19
	v20.Parent = v19
	local v21 = Instance.new("Part")
	v21.Size = Vector3.new(2, 2, 2)
	v21.Anchored = true
	v21.CanCollide = false
	v21.Name = "EndWaypoint"
	v21.Transparency = 1
	local v22 = Instance.new("ImageHandleAdornment")
	v22.Name = "TrailDotImage"
	v22.Size = v_u_11
	v22.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	v22.AlwaysOnTop = v_u_4
	v22.Image = v_u_2
	v22.Adornee = v21
	v22.Parent = v21
	local v23 = Instance.new("BillboardGui")
	v23.Name = "EndWaypointBillboard"
	v23.Size = v_u_5
	v23.LightInfluence = 0
	v23.SizeOffset = v_u_6
	v23.AlwaysOnTop = true
	v23.Adornee = v21
	v23.Parent = v21
	local v24 = Instance.new("ImageLabel")
	v24.Image = v_u_3
	v24.BackgroundTransparency = 1
	v24.Size = UDim2.new(1, 0, 1, 0)
	v24.Parent = v23
	local v25 = Instance.new("Part")
	v25.Size = Vector3.new(2, 2, 2)
	v25.Anchored = true
	v25.CanCollide = false
	v25.Name = "FailureWaypoint"
	v25.Transparency = 1
	local v26 = Instance.new("ImageHandleAdornment")
	v26.Name = "TrailDotImage"
	v26.Size = v_u_11
	v26.SizeRelativeOffset = Vector3.new(0, 0, -0.1)
	v26.AlwaysOnTop = v_u_4
	v26.Image = v_u_2
	v26.Adornee = v25
	v26.Parent = v25
	local v27 = Instance.new("BillboardGui")
	v27.Name = "FailureWaypointBillboard"
	v27.Size = v_u_5
	v27.LightInfluence = 0
	v27.SizeOffset = v_u_8
	v27.AlwaysOnTop = true
	v27.Adornee = v25
	v27.Parent = v25
	local v28 = Instance.new("Frame")
	v28.BackgroundTransparency = 1
	v28.Size = UDim2.new(0, 0, 0, 0)
	v28.Position = UDim2.new(0.5, 0, 1, 0)
	v28.Parent = v27
	local v29 = Instance.new("ImageLabel")
	v29.Image = v_u_3
	v29.BackgroundTransparency = 1
	v29.Position = UDim2.new(0, -v_u_5.X.Offset / 2, 0, -v_u_5.Y.Offset)
	v29.Size = v_u_5
	v29.Parent = v28
	return v19, v21, v25
end
local v_u_31, v_u_32, v_u_33 = v_u_30()
local function v_u_44(p34, p35) -- name: placePathWaypoint
	-- upvalues: (copy) v_u_17, (copy) v_u_12, (copy) v_u_16, (copy) v_u_18
	if v_u_17 then
		v_u_12.FilterDescendantsInstances = { v_u_16.CurrentCamera, v_u_18.Character }
		local v36 = v_u_16:Raycast(p35 + Vector3.new(0, 2.5, 0), Vector3.new(-0, -10, -0), v_u_12)
		if v36 then
			p34.CFrame = CFrame.lookAlong(v36.Position, v36.Normal)
			local v37 = v_u_16.CurrentCamera
			local v38 = v37:FindFirstChild("ClickToMoveDisplay")
			if not v38 then
				v38 = Instance.new("Model")
				v38.Name = "ClickToMoveDisplay"
				v38.Parent = v37
			end
			p34.Parent = v38
			return
		end
	else
		local v39, v40, v41 = v_u_16:FindPartOnRayWithIgnoreList(Ray.new(p35 + Vector3.new(0, 2.5, 0), Vector3.new(0, -10, 0)), { v_u_16.CurrentCamera, v_u_18.Character })
		if v39 then
			p34.CFrame = CFrame.new(v40, v40 + v41)
			local v42 = v_u_16.CurrentCamera
			local v43 = v42:FindFirstChild("ClickToMoveDisplay")
			if not v43 then
				v43 = Instance.new("Model")
				v43.Name = "ClickToMoveDisplay"
				v43.Parent = v42
			end
			p34.Parent = v43
		end
	end
end
local v_u_45 = {}
v_u_45.__index = v_u_45
function v_u_45.Destroy(p46) -- name: Destroy
	p46.DisplayModel:Destroy()
end
function v_u_45.NewDisplayModel(_, p47) -- name: NewDisplayModel
	-- upvalues: (ref) v_u_31, (copy) v_u_44
	local v48 = v_u_31:Clone()
	v_u_44(v48, p47)
	return v48
end
function v_u_45.new(p49, p50) -- name: new
	-- upvalues: (copy) v_u_45
	local v51 = v_u_45
	local v52 = setmetatable({}, v51)
	v52.DisplayModel = v52:NewDisplayModel(p49)
	v52.ClosestWayPoint = p50
	return v52
end
local v_u_53 = {}
v_u_53.__index = v_u_53
function v_u_53.Destroy(p54) -- name: Destroy
	p54.Destroyed = true
	p54.Tween:Cancel()
	p54.DisplayModel:Destroy()
end
function v_u_53.NewDisplayModel(_, p55) -- name: NewDisplayModel
	-- upvalues: (ref) v_u_32, (copy) v_u_44
	local v56 = v_u_32:Clone()
	v_u_44(v56, p55)
	return v56
end
function v_u_53.CreateTween(p57) -- name: CreateTween
	-- upvalues: (copy) v_u_14, (copy) v_u_7
	local v58 = TweenInfo.new(0.5, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, -1, true)
	local v59 = {
		["SizeOffset"] = v_u_7
	}
	local v60 = v_u_14:Create(p57.DisplayModel.EndWaypointBillboard, v58, v59)
	v60:Play()
	return v60
end
function v_u_53.TweenInFrom(p61, p62) -- name: TweenInFrom
	-- upvalues: (copy) v_u_14
	local v63 = p62 - p61.DisplayModel.Position
	local v64 = p61.DisplayModel.EndWaypointBillboard
	local v65 = v63.Y
	v64.StudsOffset = Vector3.new(0, v65, 0)
	local v66 = TweenInfo.new(1, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	local v67 = v_u_14:Create(p61.DisplayModel.EndWaypointBillboard, v66, {
		["StudsOffset"] = Vector3.new(0, 0, 0)
	})
	v67:Play()
	return v67
end
function v_u_53.new(p68, p69, p70) -- name: new
	-- upvalues: (copy) v_u_53
	local v71 = v_u_53
	local v_u_72 = setmetatable({}, v71)
	v_u_72.DisplayModel = v_u_72:NewDisplayModel(p68)
	v_u_72.Destroyed = false
	if p70 and (p70 - p68).Magnitude > 5 then
		v_u_72.Tween = v_u_72:TweenInFrom(p70)
		coroutine.wrap(function()
			-- upvalues: (copy) v_u_72
			v_u_72.Tween.Completed:Wait()
			if not v_u_72.Destroyed then
				v_u_72.Tween = v_u_72:CreateTween()
			end
		end)()
	else
		v_u_72.Tween = v_u_72:CreateTween()
	end
	v_u_72.ClosestWayPoint = p69
	return v_u_72
end
local v_u_73 = {}
v_u_73.__index = v_u_73
function v_u_73.Hide(p74) -- name: Hide
	p74.DisplayModel.Parent = nil
end
function v_u_73.Destroy(p75) -- name: Destroy
	p75.DisplayModel:Destroy()
end
function v_u_73.NewDisplayModel(_, p76) -- name: NewDisplayModel
	-- upvalues: (ref) v_u_33, (copy) v_u_44, (copy) v_u_17, (copy) v_u_12, (copy) v_u_16, (copy) v_u_18
	local v77 = v_u_33:Clone()
	v_u_44(v77, p76)
	if v_u_17 then
		v_u_12.FilterDescendantsInstances = { v_u_16.CurrentCamera, v_u_18.Character }
		local v78 = v_u_16:Raycast(p76 + Vector3.new(0, 2.5, 0), Vector3.new(-0, -10, -0), v_u_12)
		if v78 then
			v77.CFrame = CFrame.lookAlong(v78.Position, v78.Normal)
			local v79 = v_u_16.CurrentCamera
			local v80 = v79:FindFirstChild("ClickToMoveDisplay")
			if not v80 then
				v80 = Instance.new("Model")
				v80.Name = "ClickToMoveDisplay"
				v80.Parent = v79
			end
			v77.Parent = v80
			return v77
		end
	else
		local v81, v82, v83 = v_u_16:FindPartOnRayWithIgnoreList(Ray.new(p76 + Vector3.new(0, 2.5, 0), Vector3.new(0, -10, 0)), { v_u_16.CurrentCamera, v_u_18.Character })
		if v81 then
			v77.CFrame = CFrame.new(v82, v82 + v83)
			local v84 = v_u_16.CurrentCamera
			local v85 = v84:FindFirstChild("ClickToMoveDisplay")
			if not v85 then
				v85 = Instance.new("Model")
				v85.Name = "ClickToMoveDisplay"
				v85.Parent = v84
			end
			v77.Parent = v85
		end
	end
	return v77
end
function v_u_73.RunFailureTween(p86) -- name: RunFailureTween
	-- upvalues: (copy) v_u_14, (copy) v_u_9, (copy) v_u_10, (copy) v_u_8
	wait(0.125)
	local v87 = TweenInfo.new(0.0625, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	local v88 = {
		["SizeOffset"] = v_u_9
	}
	local v89 = v_u_14:Create(p86.DisplayModel.FailureWaypointBillboard, v87, v88)
	v89:Play()
	v_u_14:Create(p86.DisplayModel.FailureWaypointBillboard.Frame, v87, {
		["Rotation"] = 10
	}):Play()
	v89.Completed:wait()
	local v90 = TweenInfo.new(0.125, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 3, true)
	local v91 = {
		["SizeOffset"] = v_u_10
	}
	local v92 = v_u_14:Create(p86.DisplayModel.FailureWaypointBillboard, v90, v91)
	v92:Play()
	local v93 = TweenInfo.new(0.125, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 3, true)
	v_u_14:Create(p86.DisplayModel.FailureWaypointBillboard.Frame.ImageLabel, v93, {
		["ImageColor3"] = Color3.new(0.75, 0.75, 0.75)
	}):Play()
	v_u_14:Create(p86.DisplayModel.FailureWaypointBillboard.Frame, v93, {
		["Rotation"] = -10
	}):Play()
	v92.Completed:wait()
	local v94 = TweenInfo.new(0.0625, Enum.EasingStyle.Sine, Enum.EasingDirection.Out)
	local v95 = {
		["SizeOffset"] = v_u_8
	}
	local v96 = v_u_14:Create(p86.DisplayModel.FailureWaypointBillboard, v94, v95)
	v96:Play()
	v_u_14:Create(p86.DisplayModel.FailureWaypointBillboard.Frame, v94, {
		["Rotation"] = 0
	}):Play()
	v96.Completed:wait()
	wait(0.125)
end
function v_u_73.new(p97) -- name: new
	-- upvalues: (copy) v_u_73
	local v98 = v_u_73
	local v99 = setmetatable({}, v98)
	v99.DisplayModel = v99:NewDisplayModel(p97)
	return v99
end
local v_u_100 = Instance.new("Animation")
v_u_100.AnimationId = "rbxassetid://2874840706"
local v_u_101 = nil
local function v_u_113(p102, p103) -- name: createTrailDots
	-- upvalues: (copy) v_u_45, (copy) v_u_53
	local v104 = {}
	local v105 = 1
	for v106 = 1, #p102 - 1 do
		local v107 = (p102[v106].Position - p102[#p102].Position).Magnitude < 3
		local v108
		if v106 % 2 == 0 then
			v108 = not v107
		else
			v108 = false
		end
		if not v108 then
			continue
		end
		v104[v105] = v_u_45.new(p102[v106].Position, v106)
		v105 = v105 + 1
	end
	local v109 = v_u_53.new(p102[#p102].Position, #p102, p103)
	table.insert(v104, v109)
	local v110 = {}
	local v111 = 1
	for v112 = #v104, 1, -1 do
		v110[v111] = v104[v112]
		v111 = v111 + 1
	end
	return v110
end
local v_u_114 = 0
function v1.CreatePathDisplay(p_u_115, p116) -- name: CreatePathDisplay
	-- upvalues: (ref) v_u_114, (copy) v_u_113, (copy) v_u_15, (copy) v_u_16, (ref) v_u_11
	v_u_114 = v_u_114 + 1
	local v_u_117 = v_u_113(p_u_115, p116)
	local function v_u_121(p118) -- name: removePathBeforePoint
		-- upvalues: (copy) v_u_117
		for v119 = #v_u_117, 1, -1 do
			local v120 = v_u_117[v119]
			if v120.ClosestWayPoint > p118 then
				break
			end
			v120:Destroy()
			v_u_117[v119] = nil
		end
	end
	local v_u_122 = "ClickToMoveResizeTrail" .. v_u_114
	local function v128() -- name: resizeTrailDots
		-- upvalues: (copy) v_u_117, (ref) v_u_15, (copy) v_u_122, (ref) v_u_16, (ref) v_u_11
		if #v_u_117 == 0 then
			v_u_15:UnbindFromRenderStep(v_u_122)
		else
			local v123 = v_u_16.CurrentCamera.CFrame.Position
			for v124 = 1, #v_u_117 do
				local v125 = v_u_117[v124].DisplayModel:FindFirstChild("TrailDotImage")
				if not v125 then
					continue
				end
				local v126 = v_u_11
				local v127 = (v_u_117[v124].DisplayModel.Position - v123).Magnitude - 10
				v125.Size = v126 * (math.clamp(v127, 0, 90) / 90 * 1.5 + 1)
			end
		end
	end
	v_u_15:BindToRenderStep(v_u_122, Enum.RenderPriority.Camera.Value - 1, v128)
	return function() -- name: removePath
		-- upvalues: (copy) v_u_121, (copy) p_u_115
		v_u_121(#p_u_115)
	end, v_u_121
end
local v_u_129 = nil
function v1.DisplayFailureWaypoint(p130) -- name: DisplayFailureWaypoint
	-- upvalues: (ref) v_u_129, (copy) v_u_73
	if v_u_129 then
		v_u_129:Hide()
	end
	local v_u_131 = v_u_73.new(p130)
	v_u_129 = v_u_131
	coroutine.wrap(function()
		-- upvalues: (ref) v_u_131
		v_u_131:RunFailureTween()
		v_u_131:Destroy()
		v_u_131 = nil
	end)()
end
function v1.CreateEndWaypoint(p132) -- name: CreateEndWaypoint
	-- upvalues: (copy) v_u_53
	return v_u_53.new(p132)
end
function v1.PlayFailureAnimation() -- name: PlayFailureAnimation
	-- upvalues: (copy) v_u_18, (ref) v_u_101, (copy) v_u_100
	local v133 = v_u_18.Character
	local v134
	if v133 then
		v134 = v133:FindFirstChildOfClass("Humanoid")
	else
		v134 = nil
	end
	if v134 then
		local v135
		if v134 == nil then
			v135 = v_u_101
		else
			v_u_101 = v134:LoadAnimation(v_u_100)
			local v136 = v_u_101
			assert(v136, "")
			v_u_101.Priority = Enum.AnimationPriority.Action
			v_u_101.Looped = false
			v135 = v_u_101
		end
		v135:Play()
	end
end
function v1.CancelFailureAnimation() -- name: CancelFailureAnimation
	-- upvalues: (ref) v_u_101
	if v_u_101 ~= nil and v_u_101.IsPlaying then
		v_u_101:Stop()
	end
end
function v1.SetWaypointTexture(p137) -- name: SetWaypointTexture
	-- upvalues: (ref) v_u_2, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (copy) v_u_30
	v_u_2 = p137
	local v138, v139, v140 = v_u_30()
	v_u_31 = v138
	v_u_32 = v139
	v_u_33 = v140
end
function v1.GetWaypointTexture() -- name: GetWaypointTexture
	-- upvalues: (ref) v_u_2
	return v_u_2
end
function v1.SetWaypointRadius(p141) -- name: SetWaypointRadius
	-- upvalues: (ref) v_u_11, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (copy) v_u_30
	v_u_11 = Vector2.new(p141, p141)
	local v142, v143, v144 = v_u_30()
	v_u_31 = v142
	v_u_32 = v143
	v_u_33 = v144
end
function v1.GetWaypointRadius() -- name: GetWaypointRadius
	-- upvalues: (ref) v_u_11
	return v_u_11.X
end
function v1.SetEndWaypointTexture(p145) -- name: SetEndWaypointTexture
	-- upvalues: (ref) v_u_3, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (copy) v_u_30
	v_u_3 = p145
	local v146, v147, v148 = v_u_30()
	v_u_31 = v146
	v_u_32 = v147
	v_u_33 = v148
end
function v1.GetEndWaypointTexture() -- name: GetEndWaypointTexture
	-- upvalues: (ref) v_u_3
	return v_u_3
end
function v1.SetWaypointsAlwaysOnTop(p149) -- name: SetWaypointsAlwaysOnTop
	-- upvalues: (ref) v_u_4, (ref) v_u_31, (ref) v_u_32, (ref) v_u_33, (copy) v_u_30
	v_u_4 = p149
	local v150, v151, v152 = v_u_30()
	v_u_31 = v150
	v_u_32 = v151
	v_u_33 = v152
end
function v1.GetWaypointsAlwaysOnTop() -- name: GetWaypointsAlwaysOnTop
	-- upvalues: (ref) v_u_4
	return v_u_4
end
return v1
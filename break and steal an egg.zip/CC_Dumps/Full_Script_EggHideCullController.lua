local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("Players")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = require(v3.Shared.EggConfig)
local v_u_6 = require(v3.Shared.EggInfoUi)
local v_u_7 = require(v3.Shared.ZonesConfig)
local v_u_8 = require(script.Parent.Parent.Modules.EggCullQuality)
local v_u_9 = require(script.Parent.Parent.Modules.EggViewFrustum)
local v10 = {}
local v_u_11 = v2.LocalPlayer
local v_u_12 = {}
local v_u_13 = {}
local function v_u_21(p14, p15) -- name: showDistanceFor
	-- upvalues: (copy) v_u_5, (copy) v_u_8, (copy) v_u_7
	local v16 = v_u_5.HideCull
	local v17 = p15.zoneOverride == nil and v_u_8.EggZone(p14)
	if v17 then
		local v18 = v_u_7.Zones[v17]
		local v19 = v16.ZoneOverrides
		p15.zoneOverride = v18 and (v19 and v19[v18.Id]) or false
	end
	local v20 = p15.zoneOverride
	if v20 then
		if v20.Adaptive == false then
			return v20.Distance
		else
			return v_u_8.EggDistance(v20.Distance, p14)
		end
	else
		return v_u_8.EggDistance(v16.Distance, p14)
	end
end
local function v_u_24(p22, p23) -- name: hideInstance
	-- upvalues: (copy) v_u_11
	if p22.saved[p23] == nil then
		if p23:IsA("BasePart") or p23:IsA("Decal") then
			p22.saved[p23] = true
			p23.LocalTransparencyModifier = 1
		elseif p23:IsA("BillboardGui") then
			p22.saved[p23] = p23.PlayerToHideFrom or false
			p23.PlayerToHideFrom = v_u_11
		end
	else
		return
	end
end
local function v_u_32(p25, p26) -- name: applyHidden
	-- upvalues: (copy) v_u_24
	p25.hidden = p26
	if p26 then
		if p25.root:IsA("BasePart") then
			v_u_24(p25, p25.root)
		end
		for _, v27 in p25.root:GetDescendants() do
			v_u_24(p25, v27)
		end
		if p25.nest then
			for _, v28 in p25.nest:GetDescendants() do
				v_u_24(p25, v28)
			end
			return
		end
	else
		for v29, v31 in p25.saved do
			if v29:IsA("BasePart") or v29:IsA("Decal") then
				v29.LocalTransparencyModifier = 0
			else
				if not v29:IsA("BillboardGui") then
					continue
				end
				if v31 == false then
					local v31 = nil
				end
				v29.PlayerToHideFrom = v31
			end
		end
		table.clear(p25.saved)
	end
end
local function v_u_40(p33) -- name: untrack
	-- upvalues: (copy) v_u_12, (copy) v_u_13, (copy) v_u_6, (copy) v_u_11
	local v34 = v_u_12[p33]
	if v34 then
		v_u_12[p33] = nil
		v_u_13[p33] = nil
		for _, v35 in v34.connections do
			v35:Disconnect()
		end
		for v36, v38 in v34.saved do
			if v36:IsA("BasePart") or v36:IsA("Decal") then
				v36.LocalTransparencyModifier = 0
			else
				if not v36:IsA("BillboardGui") then
					continue
				end
				if v38 == false then
					local v38 = nil
				end
				v36.PlayerToHideFrom = v38
			end
		end
		table.clear(v34.saved)
		if p33:IsA("BasePart") then
			local v39 = v_u_6.Find(p33)
			if v39 and v39.PlayerToHideFrom == v_u_11 then
				v39.PlayerToHideFrom = nil
			end
		end
	end
end
local function v_u_76(p_u_41) -- name: track
	-- upvalues: (copy) v_u_12, (copy) v_u_24, (copy) v_u_40
	if p_u_41:IsA("BasePart") and not v_u_12[p_u_41] then
		if p_u_41:GetAttribute("Titanic") then
			return
		elseif not (p_u_41:GetAttribute("Hatching") or p_u_41:GetAttribute("Broken")) then
			local v42 = p_u_41:FindFirstAncestorOfClass("Model")
			if not v42 or v42.PrimaryPart ~= p_u_41 then
				v42 = p_u_41
			end
			local v_u_43 = {
				["root"] = nil,
				["hidden"] = nil,
				["far"] = nil,
				["offView"] = false,
				["offscreenSince"] = nil,
				["saved"] = nil,
				["connections"] = nil,
				["root"] = v42,
				["saved"] = {},
				["connections"] = {}
			}
			v_u_12[p_u_41] = v_u_43
			local v44 = v_u_43.connections
			local v45 = v42.DescendantAdded
			local function v47(p46)
				-- upvalues: (copy) v_u_43, (ref) v_u_24
				if v_u_43.hidden then
					v_u_24(v_u_43, p46)
				end
			end
			table.insert(v44, v45:Connect(v47))
			local v48 = v_u_43.connections
			local v49 = v42.DescendantRemoving
			table.insert(v48, v49:Connect(function(p50)
				-- upvalues: (copy) v_u_43
				local v51 = v_u_43.saved[p50]
				if v51 ~= nil then
					v_u_43.saved[p50] = nil
					if p50:IsA("BasePart") or p50:IsA("Decal") then
						p50.LocalTransparencyModifier = 0
						return
					end
					if p50:IsA("BillboardGui") then
						if v51 == false then
							v51 = nil
						end
						p50.PlayerToHideFrom = v51
					end
				end
			end))
			local function v_u_58(p52) -- name: hookNest
				-- upvalues: (copy) v_u_43, (ref) v_u_24
				if p52 ~= nil and (v_u_43.nest ~= p52 and p52:IsA("Model")) then
					v_u_43.nest = p52
					local v53 = v_u_43.connections
					local v54 = p52.DescendantAdded
					local function v56(p55)
						-- upvalues: (ref) v_u_43, (ref) v_u_24
						if v_u_43.hidden then
							v_u_24(v_u_43, p55)
						end
					end
					table.insert(v53, v54:Connect(v56))
					if v_u_43.hidden then
						for _, v57 in p52:GetDescendants() do
							v_u_24(v_u_43, v57)
						end
					end
				end
			end
			local function v63(p_u_59) -- name: hookLink
				-- upvalues: (copy) v_u_58, (copy) v_u_43
				if p_u_59.Name == "Nest" and p_u_59:IsA("ObjectValue") then
					v_u_58(p_u_59.Value)
					local v60 = v_u_43.connections
					local v61 = p_u_59.Changed
					local function v62()
						-- upvalues: (ref) v_u_58, (copy) p_u_59
						v_u_58(p_u_59.Value)
					end
					table.insert(v60, v61:Connect(v62))
				end
			end
			local v64 = p_u_41:FindFirstChild("Nest")
			if v64 then
				v63(v64)
			else
				local v65 = v_u_43.connections
				local v66 = p_u_41.ChildAdded
				table.insert(v65, v66:Connect(v63))
			end
			local v67 = v_u_43.connections
			local v68 = p_u_41:GetAttributeChangedSignal("Hatching")
			local function v69()
				-- upvalues: (copy) p_u_41, (ref) v_u_40
				if p_u_41:GetAttribute("Hatching") then
					v_u_40(p_u_41)
				end
			end
			table.insert(v67, v68:Connect(v69))
			local v70 = v_u_43.connections
			local v71 = p_u_41:GetAttributeChangedSignal("Broken")
			local function v72()
				-- upvalues: (copy) p_u_41, (ref) v_u_40
				if p_u_41:GetAttribute("Broken") then
					v_u_40(p_u_41)
				end
			end
			table.insert(v70, v71:Connect(v72))
			local v73 = v_u_43.connections
			local v74 = p_u_41:GetAttributeChangedSignal("Titanic")
			local function v75()
				-- upvalues: (copy) p_u_41, (ref) v_u_40
				if p_u_41:GetAttribute("Titanic") then
					v_u_40(p_u_41)
				end
			end
			table.insert(v73, v74:Connect(v75))
		end
	else
		return
	end
end
function v10.Start() -- name: Start
	-- upvalues: (copy) v_u_1, (copy) v_u_76, (copy) v_u_40, (copy) v_u_5, (copy) v_u_4, (copy) v_u_9, (copy) v_u_13, (copy) v_u_32, (copy) v_u_12, (copy) v_u_21, (copy) v_u_8, (copy) v_u_6, (copy) v_u_11
	for _, v77 in v_u_1:GetTagged("BreakableEgg") do
		v_u_76(v77)
	end
	v_u_1:GetInstanceAddedSignal("BreakableEgg"):Connect(v_u_76)
	v_u_1:GetInstanceRemovedSignal("BreakableEgg"):Connect(v_u_40)
	local v_u_78 = v_u_5.HideCull
	local v_u_79 = v_u_5.ViewCull
	local v_u_80 = v_u_79.HideEggShells == true
	if v_u_80 then
		v_u_4:BindToRenderStep("EggHideCullView", v_u_9.RENDER_PRIORITY_AFTER, function()
			-- upvalues: (ref) v_u_13, (ref) v_u_40, (ref) v_u_9, (ref) v_u_32
			for v81, v82 in v_u_13 do
				if v81.Parent then
					if not v_u_9.IsEggVisible(v81) then
						continue
					end
					v82.offView = false
					v82.offscreenSince = nil
					v_u_13[v81] = nil
					local v83 = v82.far == true and true or v82.offView
					if v82.hidden == v83 then
						continue
					end
					v_u_32(v82, v83)
				else
					v_u_40(v81)
				end
			end
		end)
	end
	local v_u_84 = 0
	v_u_4.Heartbeat:Connect(function()
		-- upvalues: (ref) v_u_84, (copy) v_u_78, (ref) v_u_12, (ref) v_u_40, (ref) v_u_21, (ref) v_u_8, (copy) v_u_79, (copy) v_u_80, (ref) v_u_9, (ref) v_u_13, (ref) v_u_32, (ref) v_u_6, (ref) v_u_11
		local v85 = os.clock()
		if v85 < v_u_84 then
			return
		else
			v_u_84 = v85 + v_u_78.CheckInterval
			local v86 = workspace.CurrentCamera
			if v86 then
				local v87 = v86.CFrame.Position
				for v88, v89 in v_u_12 do
					if v88.Parent then
						local v90 = v_u_21(v88, v89)
						local v91 = v90 * v90
						local v92 = (v90 + v_u_78.Hysteresis) ^ 2
						local v93 = v_u_8.EggHideDelay(v_u_79.HideDelay, v88)
						local v94 = v88.Position
						local v95 = v94 - v87
						local v96 = v95:Dot(v95)
						if v89.far == nil then
							v89.far = v92 <= v96
						elseif v89.far and v96 <= v91 then
							v89.far = false
						elseif not v89.far and v92 <= v96 then
							v89.far = true
						end
						if v_u_80 and not v89.offView then
							if v89.far or v_u_9.IsVisible(v94, v88.Size) then
								v89.offscreenSince = nil
							elseif v89.offscreenSince then
								if v93 <= v85 - v89.offscreenSince then
									v89.offView = true
									v89.offscreenSince = nil
									v_u_13[v88] = v89
									local v97 = v89.far == true and true or v89.offView
									if v89.hidden ~= v97 then
										v_u_32(v89, v97)
									end
								end
							else
								v89.offscreenSince = v85
							end
						end
						local v98 = v89.far == true and true or v89.offView
						if v89.hidden ~= v98 then
							v_u_32(v89, v98)
						end
						if v89.hidden then
							continue
						end
						local v99 = v_u_6.Find(v88)
						if not v99 or (v99.PlayerToHideFrom ~= v_u_11 or v89.saved[v99] ~= nil) then
							continue
						end
						v99.PlayerToHideFrom = nil
					else
						v_u_40(v88)
					end
				end
			end
		end
	end)
end
return v10
local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(v_u_2.Shared.RagdollPhysics)
local v_u_5 = v1.LocalPlayer
local v6 = {}
local v_u_7 = 0
local v_u_8 = 0
local v_u_9 = nil
local v_u_10 = nil
local v_u_11 = nil
local function v_u_14() -- name: recover
	-- upvalues: (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (copy) v_u_5, (copy) v_u_4
	if v_u_9 then
		v_u_9:Disconnect()
		v_u_9 = nil
	end
	if v_u_10 then
		v_u_10:Disconnect()
		v_u_10 = nil
	end
	if v_u_11 then
		v_u_11()
		v_u_11 = nil
	end
	local v12 = v_u_5.Character
	local v13
	if v12 then
		v13 = v12:FindFirstChildOfClass("Humanoid")
	else
		v13 = v12
	end
	if v12 then
		v_u_4.SetCharacterVelocity(v12, Vector3.new(0, 0, 0), Vector3.new(0, 0, 0))
		v_u_4.SnapUpright(v12)
	end
	if v13 then
		v13:SetStateEnabled(Enum.HumanoidStateType.GettingUp, true)
		v13:ChangeState(Enum.HumanoidStateType.GettingUp)
	end
end
local function v_u_40(p_u_15, p16, p17) -- name: onFling
	-- upvalues: (ref) v_u_7, (copy) v_u_5, (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (copy) v_u_4, (copy) v_u_3, (copy) v_u_14
	local v18 = os.clock()
	if v18 - v_u_7 < 0.5 then
		return
	else
		v_u_7 = v18
		local v_u_19 = v_u_5.Character
		v_u_19 = v_u_19
		if v_u_19 then
			local v_u_20 = v_u_19:FindFirstChildOfClass("Humanoid")
		end
		v_u_8 = v_u_8 + 1
		local v_u_21 = v_u_8
		if v_u_9 then
			v_u_9:Disconnect()
			v_u_9 = nil
		end
		if v_u_10 then
			v_u_10:Disconnect()
			v_u_10 = nil
		end
		if v_u_11 then
			v_u_11()
			v_u_11 = nil
		end
		if v_u_19 and v_u_20 then
			local v22 = p_u_15.X
			local v23 = p_u_15.Z
			local v24 = Vector3.new(v22, 0, v23)
			local v25 = p17 or 0
			local v_u_26 = (v25 == 0 or v24.Magnitude <= 0.01) and Vector3.new(0, 0, 0) or (Vector3.new(0, 1, 0)):Cross(v24.Unit) * v25
			local v27 = v_u_20:FindFirstChildOfClass("Animator")
			if v27 then
				for _, v28 in v27:GetPlayingAnimationTracks() do
					v28:Stop(0)
				end
			end
			v_u_20:SetStateEnabled(Enum.HumanoidStateType.GettingUp, false)
			v_u_20:ChangeState(Enum.HumanoidStateType.Physics)
			v_u_10 = v_u_20.StateChanged:Connect(function(_, p29)
				-- upvalues: (copy) v_u_20
				if p29 ~= Enum.HumanoidStateType.Physics and (p29 ~= Enum.HumanoidStateType.Dead and p29 ~= Enum.HumanoidStateType.PlatformStanding) then
					v_u_20:ChangeState(Enum.HumanoidStateType.Physics)
				end
			end)
			v_u_4.SetCharacterVelocity(v_u_19, p_u_15, v_u_26)
			local v30 = v_u_19:FindFirstChild("HumanoidRootPart")
			local v_u_31 = {}
			for _, v32 in v_u_19:GetChildren() do
				if not v32:IsA("BasePart") or v32 == v30 or v32.Name ~= "Head" and v_u_20:GetBodyPartR15(v32) == Enum.BodyPartR15.Unknown then
					continue
				end
				table.insert(v_u_31, v32)
			end
			local v_u_33 = v18 + 0.25
			v_u_9 = v_u_3.Heartbeat:Connect(function()
				-- upvalues: (copy) v_u_21, (ref) v_u_8, (copy) v_u_19, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11, (copy) v_u_33, (ref) v_u_4, (copy) p_u_15, (ref) v_u_26, (copy) v_u_31
				if v_u_21 == v_u_8 and v_u_19.Parent ~= nil then
					if os.clock() < v_u_33 then
						v_u_4.SetCharacterVelocity(v_u_19, p_u_15, v_u_26)
					end
					for _, v34 in v_u_31 do
						if not v34.Parent or v34.CanCollide then
							continue
						end
						v34.CanCollide = true
					end
				else
					if v_u_9 then
						v_u_9:Disconnect()
						v_u_9 = nil
					end
					if v_u_10 then
						v_u_10:Disconnect()
						v_u_10 = nil
					end
					if v_u_11 then
						v_u_11()
						v_u_11 = nil
					end
				end
			end)
			local v35 = p16 or 5
			local v36 = v_u_19:FindFirstChild("UpperTorso") or v_u_19:FindFirstChild("Torso")
			local v37 = v_u_4.StartAntiTunnelGuard
			local v38 = v35 + 1 + 1
			local v39 = {
				["CollideParts"] = v_u_31
			}
			if not (v36 and v36:IsA("BasePart")) then
				v36 = nil
			end
			v39.ReferencePart = v36
			v_u_11 = v37(v_u_19, v38, v39)
			task.delay(v35 + 1 + 1, function()
				-- upvalues: (copy) v_u_21, (ref) v_u_8, (ref) v_u_14
				if v_u_21 == v_u_8 then
					v_u_14()
				end
			end)
		end
	end
end
function v6.Start() -- name: Start
	-- upvalues: (copy) v_u_2, (copy) v_u_40, (ref) v_u_8, (copy) v_u_14, (copy) v_u_5, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11
	local v41 = v_u_2:WaitForChild("CatchFlingRemote", 30)
	if v41 and v41:IsA("RemoteEvent") then
		v41.OnClientEvent:Connect(function(p42, p43, p44, p45)
			-- upvalues: (ref) v_u_40, (ref) v_u_8, (ref) v_u_14
			if p42 == "fling" and typeof(p43) == "Vector3" then
				local v46 = v_u_40
				if typeof(p44) ~= "number" then
					p44 = nil
				end
				if typeof(p45) ~= "number" then
					p45 = nil
				end
				v46(p43, p44, p45)
			elseif p42 == "release" then
				v_u_8 = v_u_8 + 1
				v_u_14()
			end
		end)
		v_u_5.CharacterAdded:Connect(function()
			-- upvalues: (ref) v_u_8, (ref) v_u_9, (ref) v_u_10, (ref) v_u_11
			v_u_8 = v_u_8 + 1
			if v_u_9 then
				v_u_9:Disconnect()
				v_u_9 = nil
			end
			if v_u_10 then
				v_u_10:Disconnect()
				v_u_10 = nil
			end
			if v_u_11 then
				v_u_11()
				v_u_11 = nil
			end
		end)
	else
		warn("[CatchFlingController] ReplicatedStorage.CatchFlingRemote not found")
	end
end
return v6
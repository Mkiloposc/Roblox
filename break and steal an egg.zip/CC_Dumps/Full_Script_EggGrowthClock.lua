local v_u_1 = game:GetService("Workspace")
local v_u_33 = {
	["ReadyAtAttribute"] = "ReadyAtServerTime",
	["RateAttribute"] = "GrowthRate",
	["BoostEndsAtAttribute"] = "GrowthBoostEndsAt",
	["BaseRateAttribute"] = "GrowthBaseRate",
	["PredictReadyAt"] = function(p2, p3, p4, p5, p6) -- name: PredictReadyAt
		local v7
		if p4 and (p4 > 1 and p5) then
			local v8 = p5 - p2
			v7 = math.max(v8, 0)
		else
			v7 = 0
		end
		local v9 = p4 or 1
		local v10 = (not p6 or p6 <= 1) and 1 or p6
		if v7 <= 0 then
			return p2 + p3 / v10
		elseif p3 <= v7 * v9 then
			return p2 + p3 / v9
		else
			return p2 + v7 + (p3 - v7 * v9) / v10
		end
	end,
	["RemainingAt"] = function(p11, p12, p13, p14, p15) -- name: RemainingAt
		local v16 = p12 - p11
		local v17 = math.max(v16, 0)
		local v18
		if p13 and (p13 > 1 and p14) then
			local v19 = p14 - p11
			v18 = math.max(v19, 0)
		else
			v18 = 0
		end
		local v20 = p13 or 1
		local v21 = (not p15 or p15 <= 1) and 1 or p15
		if v18 <= 0 then
			return v17 * v21
		elseif v17 <= v18 then
			return v17 * v20
		else
			return v18 * v20 + (v17 - v18) * v21
		end
	end,
	["RateOf"] = function(p22) -- name: RateOf
		-- upvalues: (copy) v_u_33, (copy) v_u_1
		local v23 = p22:GetAttribute(v_u_33.RateAttribute)
		if typeof(v23) ~= "number" then
			v23 = nil
		end
		local v24 = p22:GetAttribute(v_u_33.BoostEndsAtAttribute)
		if typeof(v24) ~= "number" then
			v24 = nil
		end
		if v23 and (v23 > 1 and (v24 and v_u_1:GetServerTimeNow() < v24)) then
			return v23
		end
		local v25 = p22:GetAttribute(v_u_33.BaseRateAttribute)
		if typeof(v25) ~= "number" then
			v25 = nil
		end
		return (not v25 or v25 <= 1) and 1 or v25
	end,
	["RemainingOf"] = function(p26) -- name: RemainingOf
		-- upvalues: (copy) v_u_33, (copy) v_u_1
		local v27 = p26:GetAttribute(v_u_33.ReadyAtAttribute)
		if typeof(v27) ~= "number" then
			v27 = nil
		end
		if not v27 then
			return 0
		end
		local v28 = v_u_33.RemainingAt
		local v29 = v_u_1:GetServerTimeNow()
		local v30 = p26:GetAttribute(v_u_33.RateAttribute)
		if typeof(v30) ~= "number" then
			v30 = nil
		end
		local v31 = p26:GetAttribute(v_u_33.BoostEndsAtAttribute)
		if typeof(v31) ~= "number" then
			v31 = nil
		end
		local v32 = p26:GetAttribute(v_u_33.BaseRateAttribute)
		if typeof(v32) ~= "number" then
			v32 = nil
		end
		return v28(v29, v27, v30, v31, v32)
	end
}
return v_u_33
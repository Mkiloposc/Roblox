local v1 = game:GetService("CorePackages")
local v2 = game:GetService("CoreGui")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("GuiService")
local v_u_5 = game:GetService("RbxAnalyticsService")
local v_u_6 = v2:WaitForChild("RobloxGui")
local v_u_7 = require(v1.Workspace.Packages.BlockingUtility)
local v_u_8 = require(v1.Workspace.Packages.RobloxTranslator)
local v9 = script.Parent
local v_u_10 = require(v9.Thunks.RequestFriendship)
local v11 = require(v1.Workspace.Packages.PlayerList)
local v_u_12 = v11.PlayerListVisibilityStore
local v_u_13 = v11.PlayerContextualMenuStore
local v14 = v11.builderIcon
local v_u_15 = v_u_13.buildMenuHeader
local v_u_16 = v3.LocalPlayer
local v_u_17 = v14("person-plus")
local v_u_18 = v14("person-trash-can")
local v_u_19 = v14("circle-slash")
local v_u_20 = v14("speech-bubble-exclamation")
local v_u_21 = v14("magnifying-glass-plus")
local function v_u_35(p22) -- name: getFriendLabelAndIcon
	-- upvalues: (copy) v_u_8, (copy) v_u_18, (copy) v_u_17
	if p22 == Enum.FriendStatus.Friend then
		local v_u_23 = "InGame.PlayerDropDown.Unfriend"
		local v24, v25 = pcall(function()
			-- upvalues: (ref) v_u_8, (copy) v_u_23
			return v_u_8:FormatByKey(v_u_23)
		end)
		return (not v24 or (not v25 or v25 == "")) and "Unfriend" or v25, v_u_18
	elseif p22 == Enum.FriendStatus.FriendRequestSent then
		local v_u_26 = "InGame.PlayerDropDown.CancelRequest"
		local v27, v28 = pcall(function()
			-- upvalues: (ref) v_u_8, (copy) v_u_26
			return v_u_8:FormatByKey(v_u_26)
		end)
		return (not v27 or (not v28 or v28 == "")) and "Cancel request" or v28, v_u_17
	elseif p22 == Enum.FriendStatus.FriendRequestReceived then
		local v_u_29 = "InGame.PlayerDropDown.Accept"
		local v30, v31 = pcall(function()
			-- upvalues: (ref) v_u_8, (copy) v_u_29
			return v_u_8:FormatByKey(v_u_29)
		end)
		return (not v30 or (not v31 or v31 == "")) and "Accept request" or v31, v_u_17
	else
		local v_u_32 = "InGame.PlayerDropDown.Action.ConnectionRequest"
		local v33, v34 = pcall(function()
			-- upvalues: (ref) v_u_8, (copy) v_u_32
			return v_u_8:FormatByKey(v_u_32)
		end)
		return (not v33 or (not v34 or v34 == "")) and "Friend request" or v34, v_u_17
	end
end
local function v_u_37(p36) -- name: openReportDialog
	-- upvalues: (copy) v_u_6
	if require(v_u_6.Modules.isNewInGameMenuEnabled)() then
		require(v_u_6.Modules.InGameMenuInit).openReportDialog(p36, "PlayerListReskin")
	else
		require(v_u_6.Modules.Settings.Pages.ReportAbuseMenuContainerPage):ReportPlayer(p36, "PlayerListReskin")
	end
end
local function v_u_69(p38) -- name: assembleMenuItems
	-- upvalues: (copy) v_u_35, (copy) v_u_8, (copy) v_u_18, (copy) v_u_21, (copy) v_u_19, (copy) v_u_20
	local v39 = {}
	if not (p38.isSelf or p38.isBlocked) then
		local v40, v41 = v_u_35(p38.friendStatus)
		local v42 = p38.friendStatus == Enum.FriendStatus.Friend
		local v43 = {
			["key"] = "friend",
			["label"] = nil,
			["icon"] = nil,
			["onActivated"] = nil,
			["telemetryAction"] = nil,
			["onceGroup"] = "friending",
			["requiresConfirm"] = nil,
			["confirmLabel"] = nil,
			["label"] = v40,
			["icon"] = v41,
			["onActivated"] = p38.actions.onFriend
		}
		local v44 = p38.friendStatus
		v43.telemetryAction = v44 == Enum.FriendStatus.Friend and "friend_remove" or (v44 == Enum.FriendStatus.FriendRequestSent and "friend_cancel" or (v44 == Enum.FriendStatus.FriendRequestReceived and "friend_accept" or "friend_send"))
		v43.requiresConfirm = v42 and true or nil
		local v45
		if v42 then
			local v_u_46 = "InGame.PlayerDropDown.ConfirmUnfriend"
			local v47, v48 = pcall(function()
				-- upvalues: (ref) v_u_8, (copy) v_u_46
				return v_u_8:FormatByKey(v_u_46)
			end)
			v45 = (not v47 or (not v48 or v48 == "")) and "Tap to confirm unfriend" or v48
		else
			v45 = nil
		end
		v43.confirmLabel = v45
		table.insert(v39, v43)
		if p38.friendStatus == Enum.FriendStatus.FriendRequestReceived then
			local v49 = {
				["key"] = "decline",
				["label"] = nil,
				["icon"] = nil,
				["onActivated"] = nil,
				["telemetryAction"] = "friend_decline",
				["onceGroup"] = "friending"
			}
			local v_u_50 = "InGame.PlayerDropDown.Decline"
			local v51, v52 = pcall(function()
				-- upvalues: (ref) v_u_8, (copy) v_u_50
				return v_u_8:FormatByKey(v_u_50)
			end)
			v49.label = (not v51 or (not v52 or v52 == "")) and "Decline" or v52
			v49.icon = v_u_18
			v49.onActivated = p38.actions.onDecline
			table.insert(v39, v49)
		end
	end
	if p38.inspectMenuEnabled then
		local v53 = {
			["key"] = "examine",
			["label"] = nil,
			["icon"] = nil,
			["onActivated"] = nil,
			["telemetryAction"] = "avatar_examine"
		}
		local v_u_54 = "InGame.PlayerDropDown.Examine"
		local v55, v56 = pcall(function()
			-- upvalues: (ref) v_u_8, (copy) v_u_54
			return v_u_8:FormatByKey(v_u_54)
		end)
		v53.label = (not v55 or (not v56 or v56 == "")) and "Examine avatar" or v56
		v53.icon = v_u_21
		v53.onActivated = p38.actions.onExamine
		table.insert(v39, v53)
	end
	if not p38.isSelf then
		local v57 = {
			["key"] = "block",
			["label"] = nil,
			["icon"] = nil,
			["onActivated"] = nil,
			["telemetryAction"] = nil
		}
		local v58
		if p38.isBlocked then
			local v_u_59 = "InGame.PlayerDropDown.UnBlock"
			local v60, v61 = pcall(function()
				-- upvalues: (ref) v_u_8, (copy) v_u_59
				return v_u_8:FormatByKey(v_u_59)
			end)
			v58 = (not v60 or (not v61 or v61 == "")) and "Unblock" or v61
		else
			local v_u_62 = "InGame.PlayerDropDown.Block"
			local v63, v64 = pcall(function()
				-- upvalues: (ref) v_u_8, (copy) v_u_62
				return v_u_8:FormatByKey(v_u_62)
			end)
			v58 = (not v63 or (not v64 or v64 == "")) and "Block" or v64
		end
		v57.label = v58
		v57.icon = v_u_19
		v57.onActivated = p38.actions.onBlock
		v57.telemetryAction = p38.isBlocked and "user_unblock" or "user_block"
		table.insert(v39, v57)
		local v65 = {
			["key"] = "report",
			["label"] = nil,
			["icon"] = nil,
			["onActivated"] = nil,
			["telemetryAction"] = "user_report"
		}
		local v_u_66 = "InGame.PlayerDropDown.Report"
		local v67, v68 = pcall(function()
			-- upvalues: (ref) v_u_8, (copy) v_u_66
			return v_u_8:FormatByKey(v_u_66)
		end)
		v65.label = (not v67 or (not v68 or v68 == "")) and "Report abuse" or v68
		v65.icon = v_u_20
		v65.onActivated = p38.actions.onReport
		table.insert(v39, v65)
	end
	return v39
end
return {
	["buildMenuData"] = function(p_u_70, p_u_71, p_u_72, p73) -- name: buildMenuData
		-- upvalues: (copy) v_u_16, (copy) v_u_7, (copy) v_u_69, (copy) v_u_4, (copy) v_u_5, (copy) v_u_10, (copy) v_u_13, (copy) v_u_12, (copy) v_u_6, (copy) v_u_37, (copy) v_u_15
		local v_u_74 = p_u_70.UserId
		local v75
		if v_u_16 == nil then
			v75 = false
		else
			v75 = p_u_70 == v_u_16
		end
		local v_u_76 = false
		local v_u_77 = Enum.FriendStatus.Unknown
		if not v75 then
			pcall(function()
				-- upvalues: (ref) v_u_76, (ref) v_u_7, (copy) v_u_74
				v_u_76 = v_u_7:IsPlayerBlockedByUserId(v_u_74)
			end)
			if not v_u_76 then
				if p73 == nil then
					pcall(function()
						-- upvalues: (ref) v_u_77, (ref) v_u_16, (copy) p_u_70
						v_u_77 = v_u_16:GetFriendStatus(p_u_70)
					end)
				else
					v_u_77 = p73
				end
			end
		end
		local v78 = v_u_69({
			["isSelf"] = v75,
			["isBlocked"] = v_u_76,
			["friendStatus"] = v_u_77,
			["inspectMenuEnabled"] = v_u_4:GetInspectMenuEnabled(),
			["actions"] = {
				["onFriend"] = function() -- name: onFriend
					-- upvalues: (ref) v_u_77, (ref) v_u_5, (ref) v_u_16, (copy) p_u_70, (ref) v_u_10
					if v_u_77 == Enum.FriendStatus.Friend or v_u_77 == Enum.FriendStatus.FriendRequestSent then
						v_u_5:TrackEvent("Game", "RevokeFriendship", "PlayerDropDown")
						v_u_16:RevokeFriendship(p_u_70)
						return
					elseif v_u_77 == Enum.FriendStatus.FriendRequestReceived then
						v_u_10(p_u_70, true)()
					else
						v_u_10(p_u_70)()
					end
				end,
				["onDecline"] = function() -- name: onDecline
					-- upvalues: (ref) v_u_5, (ref) v_u_16, (copy) p_u_70
					v_u_5:TrackEvent("Game", "DeclineFriendship", "PlayerDropDown")
					v_u_16:RevokeFriendship(p_u_70)
				end,
				["onExamine"] = function() -- name: onExamine
					-- upvalues: (copy) p_u_72, (ref) v_u_13, (ref) v_u_12, (ref) v_u_4, (copy) v_u_74, (copy) p_u_71
					if p_u_72 then
						v_u_13.setSuppressNextDismissRestore(true)
						v_u_12.setVisible(false)
					end
					v_u_4:InspectPlayerFromUserIdWithCtx(v_u_74, "leaderBoard")
					p_u_71()
				end,
				["onBlock"] = function() -- name: onBlock
					-- upvalues: (copy) p_u_72, (ref) v_u_76, (ref) v_u_13, (ref) v_u_12, (ref) v_u_7, (copy) p_u_70, (ref) v_u_6, (copy) p_u_71
					if p_u_72 and not v_u_76 then
						v_u_13.setSuppressNextDismissRestore(true)
						v_u_12.setVisible(false)
					end
					if v_u_76 then
						coroutine.wrap(function()
							-- upvalues: (ref) v_u_7, (ref) p_u_70
							v_u_7:UnblockPlayerAsync(p_u_70)
						end)()
					else
						require(v_u_6.Modules.Settings.onBlockButtonActivated)(p_u_70, nil, "PlayerListReskin", {})
					end
					p_u_71()
				end,
				["onReport"] = function() -- name: onReport
					-- upvalues: (copy) p_u_72, (ref) v_u_13, (ref) v_u_12, (ref) v_u_37, (copy) p_u_70, (copy) p_u_71
					if p_u_72 then
						v_u_13.setSuppressNextDismissRestore(true)
						v_u_12.setVisible(false)
					end
					v_u_37(p_u_70)
					p_u_71()
				end
			}
		})
		local v79 = {
			["player"] = p_u_70,
			["header"] = v_u_15(p_u_70),
			["items"] = v78
		}
		local v80 = {
			["isSelf"] = v75
		}
		local v81
		if v75 then
			v81 = nil
		else
			v81 = v_u_77.Name
		end
		v80.friendStatus = v81
		v79.telemetry = v80
		return v79
	end,
	["assembleMenuItems"] = v_u_69,
	["getFriendLabelAndIcon"] = v_u_35
}
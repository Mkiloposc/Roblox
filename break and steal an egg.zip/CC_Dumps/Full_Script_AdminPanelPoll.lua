local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v_u_1.Shared.AdminConfig)
local v_u_3 = require(v_u_1.Shared.PollConfig)
local v_u_4 = require(script.Parent.AdminPanelRigVote)
local v_u_5 = require(script.Parent.Parent.Controllers.NotificationController)
local v_u_6 = require(script.Parent.Parent.Controllers.UiFrames)
local v_u_7 = require(script.Parent.RichWordTyper)
local v_u_8 = require(script.Parent.UnitTextBox)
local v9 = {}
local v_u_10 = {
	["Global"] = Color3.fromRGB(0, 170, 255),
	["Server"] = Color3.fromRGB(0, 255, 0),
	["Client"] = Color3.fromRGB(255, 60, 60)
}
local v_u_11 = {
	"Create",
	"Start",
	"Post",
	"Submit",
	"Send",
	"CreatePoll",
	"StartPoll"
}
function v9.Bind(p_u_12, p13, p14) -- name: Bind
	-- upvalues: (copy) v_u_2, (copy) v_u_3, (copy) v_u_7, (copy) v_u_10, (copy) v_u_6, (copy) v_u_8, (copy) v_u_4, (copy) v_u_5, (copy) v_u_1, (copy) v_u_11
	for _, v15 in { "GlobalSwap", "NewPoll" } do
		local v16 = p13:FindFirstChild(v15)
		if not (v16 and v16:IsA("GuiButton")) then
			continue
		end
		v16:SetAttribute("HoverScale", v_u_2.PanelHoverScale)
		v16:SetAttribute("PressScale", v_u_2.PanelPressScale)
	end
	local v17 = p_u_12:GetAttribute("Scope")
	if type(v17) ~= "string" or not table.find(v_u_3.Scopes, v17) then
		v17 = v_u_3.DefaultScope
	end
	p_u_12:SetAttribute("Scope", v17)
	local v18 = p13:FindFirstChild("Setting")
	local v_u_19
	if v18 and v18:IsA("TextLabel") then
		v_u_19 = v_u_7.new(v18)
	else
		v_u_19 = nil
	end
	if v_u_19 then
		v_u_19:Set(v17, v_u_10[v17], true)
	end
	local v20 = p13:FindFirstChild("GlobalSwap")
	if v20 and v20:IsA("GuiButton") then
		v20.Activated:Connect(function()
			-- upvalues: (ref) v_u_3, (copy) p_u_12, (copy) v_u_19, (ref) v_u_10
			local v21 = table.find(v_u_3.Scopes, p_u_12:GetAttribute("Scope")) or 0
			local v22 = v_u_3.Scopes[v21 % #v_u_3.Scopes + 1]
			p_u_12:SetAttribute("Scope", v22)
			if v_u_19 then
				v_u_19:Set(v22, v_u_10[v22])
			end
		end)
	end
	local v23 = p14:FindFirstChild("Frames")
	local v24 = v_u_2.PollCreateFrame
	local v_u_25
	if v23 then
		v_u_25 = v23:FindFirstChild(v24)
	else
		v_u_25 = nil
	end
	if v_u_25 and v_u_25:IsA("GuiObject") then
		v_u_25.Visible = false
		local v26 = p13:FindFirstChild("NewPoll")
		if v26 and v26:IsA("GuiButton") then
			v26.Activated:Connect(function()
				-- upvalues: (ref) v_u_6, (copy) v_u_25
				v_u_6.Open(v_u_25)
			end)
		end
		local v27 = v_u_25:FindFirstChild("List")
		local v28
		if v27 then
			v28 = v27:FindFirstChild("Question")
		else
			v28 = nil
		end
		local v29
		if v28 then
			v29 = v28:FindFirstChild("Text")
		else
			v29 = nil
		end
		local v_u_30
		if v29 then
			v_u_30 = v29:FindFirstChild("TextBox")
		else
			v_u_30 = nil
		end
		if v_u_30 and v_u_30:IsA("TextBox") then
			v_u_30.ClearTextOnFocus = false
		else
			v_u_30 = nil
		end
		local v_u_31 = {}
		local v32
		if v27 then
			v32 = v27:FindFirstChild("Answer_1")
		else
			v32 = nil
		end
		local v33
		if v32 then
			v33 = v32:FindFirstChild("Text")
		else
			v33 = nil
		end
		local v34
		if v33 then
			v34 = v33:FindFirstChild("TextBox")
		else
			v34 = nil
		end
		if v34 and v34:IsA("TextBox") then
			v34.ClearTextOnFocus = false
		else
			v34 = nil
		end
		local v35
		if v27 then
			v35 = v27:FindFirstChild("Answer_2")
		else
			v35 = nil
		end
		local v36
		if v35 then
			v36 = v35:FindFirstChild("Text")
		else
			v36 = nil
		end
		local v37
		if v36 then
			v37 = v36:FindFirstChild("TextBox")
		else
			v37 = nil
		end
		if v37 and v37:IsA("TextBox") then
			v37.ClearTextOnFocus = false
		else
			v37 = nil
		end
		__set_list(v_u_31, 1, {v34, v37})
		local v38
		if v27 then
			v38 = v27:FindFirstChild("Duration")
		else
			v38 = nil
		end
		local v39
		if v38 then
			v39 = v38:FindFirstChild("Text")
		else
			v39 = nil
		end
		local v_u_40
		if v39 then
			v_u_40 = v39:FindFirstChild("TextBox")
		else
			v_u_40 = nil
		end
		if v_u_40 and v_u_40:IsA("TextBox") then
			v_u_40.ClearTextOnFocus = false
		else
			v_u_40 = nil
		end
		v_u_8.Bind(v_u_40, "s")
		v_u_4.Bind(v_u_25)
		for v_u_41, v42 in { "Answer_1", "Answer_2" } do
			local v43
			if v27 then
				v43 = v27:FindFirstChild(v42)
			else
				v43 = nil
			end
			local v44
			if v43 then
				v44 = v43:FindFirstChild("Text")
			else
				v44 = nil
			end
			local v45
			if v44 then
				v45 = v44:FindFirstChild("Delete")
			else
				v45 = nil
			end
			if not (v45 and v45:IsA("GuiButton")) then
				continue
			end
			v45.Activated:Connect(function()
				-- upvalues: (copy) v_u_31, (copy) v_u_41
				local v46 = v_u_31[v_u_41]
				if v46 then
					v46.Text = ""
				end
			end)
		end
		local function v_u_50() -- name: filled
			-- upvalues: (copy) v_u_30, (copy) v_u_31
			if v_u_30 then
				local v47 = v_u_30.Text
				if string.gsub(string.gsub(v47, "^%s+", ""), "%s+$", "") ~= "" then
					for _, v48 in v_u_31 do
						if v48 then
							local v49 = v48.Text
							if string.gsub(string.gsub(v49, "^%s+", ""), "%s+$", "") ~= "" then
								continue
							end
						end
						return false
					end
					return true
				end
			end
			return false
		end
		local v_u_51 = false
		local function v_u_62() -- name: submit
			-- upvalues: (ref) v_u_51, (copy) v_u_50, (ref) v_u_5, (copy) v_u_40, (ref) v_u_8, (ref) v_u_4, (ref) v_u_1, (ref) v_u_2, (copy) v_u_30, (copy) v_u_31, (copy) p_u_12, (ref) v_u_6, (copy) v_u_25
			if v_u_51 then
				return
			elseif v_u_50() then
				local v_u_52 = not v_u_40 or (not string.match(v_u_40.Text, "%S") or v_u_8.Number(v_u_40.Text, "s"))
				if v_u_52 then
					local v_u_53, v54 = v_u_4.Get()
					if v54 then
						v_u_5.Show(("Vote rig: %*"):format(v54), "Error")
						return
					else
						local v_u_55 = v_u_1:FindFirstChild(v_u_2.PanelRemotes.Poll)
						if v_u_55 and v_u_55:IsA("RemoteFunction") then
							v_u_51 = true
							local function v56()
								-- upvalues: (copy) v_u_55, (ref) v_u_30, (ref) v_u_31, (ref) v_u_52, (ref) p_u_12, (copy) v_u_53
								return v_u_55:InvokeServer({
									["Question"] = not v_u_30 and "" or v_u_30.Text,
									["Answers"] = { not v_u_31[1] and "" or v_u_31[1].Text, not v_u_31[2] and "" or v_u_31[2].Text },
									["Duration"] = v_u_52,
									["Scope"] = p_u_12:GetAttribute("Scope"),
									["Rig"] = v_u_53
								})
							end
							local v57, v58, v59 = pcall(v56)
							v_u_51 = false
							if v57 and v58 == true then
								v_u_5.Show(type(v59) ~= "string" and "{Poll} started!" or v59, "Success")
								if v_u_30 then
									v_u_30.Text = ""
								end
								for _, v60 in v_u_31 do
									if not v60 then
										continue
									end
									v60.Text = ""
								end
								v_u_6.Close(v_u_25)
							else
								local v61 = (not v57 or type(v59) ~= "string") and "couldn\'t start the poll" or v59
								v_u_5.Show(("Poll failed: %*"):format(v61), "Error")
							end
						else
							v_u_5.Show("Polls aren\'t ready yet", "Error")
						end
					end
				else
					v_u_5.Show("Type the duration in seconds (e.g. 15)", "Error")
					return
				end
			else
				v_u_5.Show("Fill in the question and both answers", "Error")
				return
			end
		end
		for _, v63 in v_u_11 do
			local v64 = v_u_25:FindFirstChild(v63, true)
			if not (v64 and v64:IsA("GuiButton")) then
				continue
			end
			v64:SetAttribute("HoverScale", v_u_2.PanelHoverScale)
			v64:SetAttribute("PressScale", v_u_2.PanelPressScale)
			v64.Activated:Connect(function()
				-- upvalues: (copy) v_u_62
				task.spawn(v_u_62)
			end)
			return
		end
	end
end
return v9
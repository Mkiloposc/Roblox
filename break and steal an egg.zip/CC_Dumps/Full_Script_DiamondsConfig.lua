local v1 = {
	["StartingDiamonds"] = 0,
	["Attribute"] = "Diamonds",
	["SettleDelay"] = 2.5,
	["InfiniteInTestPlace"] = false,
	["InfiniteText"] = "\226\136\158",
	["DisplayPath"] = nil,
	["AmountPath"] = nil,
	["PopPath"] = nil,
	["CountTween"] = nil,
	["PopScale"] = 1.18,
	["PopInTween"] = nil,
	["PopOutTween"] = nil,
	["GainStart"] = nil,
	["GainSize"] = nil,
	["GainRise"] = -0.6,
	["GainTween"] = nil,
	["ShowEarnGain"] = false,
	["SpendColor"] = nil,
	["EarnColor"] = nil,
	["DisplayPath"] = {
		"Frames",
		"GemShop",
		"TopBar",
		"CurrencyBar"
	},
	["AmountPath"] = { "List", "Amount" },
	["PopPath"] = { "List" },
	["CountTween"] = {
		["Duration"] = 0.5,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quart,
		["Direction"] = Enum.EasingDirection.Out
	},
	["PopInTween"] = {
		["Duration"] = 0.08,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quart,
		["Direction"] = Enum.EasingDirection.Out
	},
	["PopOutTween"] = {
		["Duration"] = 0.35,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Back,
		["Direction"] = Enum.EasingDirection.Out
	},
	["GainStart"] = UDim2.fromScale(0.5, 1.45),
	["GainSize"] = UDim2.fromScale(1, 0.75),
	["GainTween"] = {
		["Duration"] = 0.9,
		["Style"] = nil,
		["Direction"] = nil,
		["Style"] = Enum.EasingStyle.Quart,
		["Direction"] = Enum.EasingDirection.Out
	},
	["SpendColor"] = Color3.fromRGB(255, 90, 90),
	["EarnColor"] = Color3.fromRGB(110, 255, 140)
}
return v1
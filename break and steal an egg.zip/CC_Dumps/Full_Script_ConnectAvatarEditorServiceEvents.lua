local v_u_1 = game:GetService("AvatarEditorService")
local v2 = game:GetService("CorePackages")
local v3 = script.Parent
local v_u_4 = require(v3.Actions.OpenPrompt)
local v_u_5 = require(v3.PromptType)
local v_u_6 = require(v3.Thunks.OpenSetFavoritePrompt)
local v_u_7 = require(v3.Thunks.OpenSaveAvatarPrompt)
local v_u_8 = require(v3.Thunks.OpenDeleteOutfitPrompt)
local v_u_9 = require(v3.Thunks.OpenRenameOutfitPrompt)
local v_u_10 = require(v3.Thunks.OpenUpdateOutfitPrompt)
local v_u_11 = require(v2.Workspace.Packages.AvatarExperienceCommon)
return function(p_u_12) -- name: ConnectAvatarEditorServiceEvents
	-- upvalues: (copy) v_u_1, (copy) v_u_11, (copy) v_u_4, (copy) v_u_5, (copy) v_u_7, (copy) v_u_6, (copy) v_u_8, (copy) v_u_9, (copy) v_u_10
	local v13 = {}
	local v14 = v_u_1.OpenPromptSaveAvatar
	local function v18(p_u_15, p_u_16)
		-- upvalues: (ref) v_u_11, (copy) p_u_12, (ref) v_u_4, (ref) v_u_5, (ref) v_u_7
		v_u_11.Stores.getTimeoutStatusStore().fetchStatusAsync():andThen(function(p17)
			-- upvalues: (ref) p_u_12, (ref) v_u_4, (ref) v_u_5, (ref) v_u_7, (copy) p_u_15, (copy) p_u_16
			if p17.isTimedOut then
				p_u_12:dispatch(v_u_4(v_u_5.SaveAvatarTimeout, {}))
			else
				p_u_12:dispatch(v_u_7(p_u_15, p_u_16))
			end
		end)
	end
	table.insert(v13, v14:Connect(v18))
	local v19 = v_u_1.OpenAllowInventoryReadAccess
	local function v20()
		-- upvalues: (copy) p_u_12, (ref) v_u_4, (ref) v_u_5
		p_u_12:dispatch(v_u_4(v_u_5.AllowInventoryReadAccess, {}))
	end
	table.insert(v13, v19:Connect(v20))
	local v21 = v_u_1.OpenPromptCreateOufit
	local function v24(p22, p23)
		-- upvalues: (copy) p_u_12, (ref) v_u_4, (ref) v_u_5
		p_u_12:dispatch(v_u_4(v_u_5.CreateOutfit, {
			["humanoidDescription"] = p22,
			["rigType"] = p23
		}))
	end
	table.insert(v13, v21:Connect(v24))
	local v25 = v_u_1.OpenPromptSetFavorite
	local function v29(p26, p27, p28)
		-- upvalues: (copy) p_u_12, (ref) v_u_6
		p_u_12:dispatch(v_u_6(p26, p27, p28))
	end
	table.insert(v13, v25:Connect(v29))
	local v30 = v_u_1.OpenPromptDeleteOutfit
	local function v32(p31)
		-- upvalues: (copy) p_u_12, (ref) v_u_8
		p_u_12:dispatch(v_u_8(p31))
	end
	table.insert(v13, v30:Connect(v32))
	local v33 = v_u_1.OpenPromptRenameOutfit
	local function v35(p34)
		-- upvalues: (copy) p_u_12, (ref) v_u_9
		p_u_12:dispatch(v_u_9(p34))
	end
	table.insert(v13, v33:Connect(v35))
	local v36 = v_u_1.OpenPromptUpdateOutfit
	local function v40(p37, p38, p39)
		-- upvalues: (copy) p_u_12, (ref) v_u_10
		p_u_12:dispatch(v_u_10(p37, p38, p39))
	end
	table.insert(v13, v36:Connect(v40))
	return v13
end
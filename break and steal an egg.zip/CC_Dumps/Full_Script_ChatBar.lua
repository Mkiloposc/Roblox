local v_u_1 = game:GetService("UserInputService")
local v_u_2 = game:GetService("RunService")
local v3 = game:GetService("Players")
local v_u_4 = game:GetService("TextService")
local v_u_5 = v3.LocalPlayer
local v6 = {}
while not v_u_5 do
	v3.PlayerAdded:wait()
	v_u_5 = v3.LocalPlayer
end
local v_u_7 = game:GetService("Chat")
local v8 = v_u_7:WaitForChild("ClientChatModules")
local v9 = script.Parent
local v_u_10 = require(v8:WaitForChild("ChatSettings"))
local v_u_11 = require(v9:WaitForChild("CurveUtil"))
local v12 = v8:WaitForChild("CommandModules")
local v_u_13 = require(v12:WaitForChild("Whisper"))
require(v9:WaitForChild("MessageSender"))
local v_u_14 = nil
pcall(function()
	-- upvalues: (ref) v_u_14
	v_u_14 = require(game:GetService("Chat").ClientChatModules.ChatLocalization)
end)
v_u_14 = v_u_14 == nil and {
	["Get"] = function(_, _, p15) -- name: Get
		return p15
	end
} or v_u_14
local v_u_16 = {}
v_u_16.__index = v_u_16
function v_u_16.CreateGuiObjects(p17, p18) -- name: CreateGuiObjects
	-- upvalues: (copy) v_u_10
	p17.ChatBarParentFrame = p18
	local v19 = Instance.new("Frame")
	v19.Selectable = false
	v19.Size = UDim2.new(1, 0, 1, 0)
	v19.BackgroundTransparency = 0.6
	v19.BorderSizePixel = 0
	v19.BackgroundColor3 = v_u_10.ChatBarBackGroundColor
	v19.Parent = p18
	local v20 = Instance.new("Frame")
	v20.Selectable = false
	v20.Name = "BoxFrame"
	v20.BackgroundTransparency = 0.6
	v20.BorderSizePixel = 0
	v20.BackgroundColor3 = v_u_10.ChatBarBoxColor
	v20.Size = UDim2.new(1, -14, 1, -14)
	v20.Position = UDim2.new(0, 7, 0, 7)
	v20.Parent = v19
	local v21 = Instance.new("Frame")
	v21.BackgroundTransparency = 1
	v21.Size = UDim2.new(1, -10, 1, -10)
	v21.Position = UDim2.new(0, 5, 0, 5)
	v21.Parent = v20
	local v22 = Instance.new("TextBox")
	v22.Selectable = v_u_10.GamepadNavigationEnabled
	v22.Name = "ChatBar"
	v22.BackgroundTransparency = 1
	v22.Size = UDim2.new(1, 0, 1, 0)
	v22.Position = UDim2.new(0, 0, 0, 0)
	v22.TextSize = v_u_10.ChatBarTextSize
	v22.Font = v_u_10.ChatBarFont
	v22.TextColor3 = v_u_10.ChatBarTextColor
	v22.TextTransparency = 0.4
	v22.TextStrokeTransparency = 1
	v22.ClearTextOnFocus = false
	v22.TextXAlignment = Enum.TextXAlignment.Left
	v22.TextYAlignment = Enum.TextYAlignment.Top
	v22.TextWrapped = true
	v22.Text = ""
	v22.Parent = v21
	local v23 = Instance.new("TextButton")
	v23.Selectable = false
	v23.Name = "MessageMode"
	v23.BackgroundTransparency = 1
	v23.Position = UDim2.new(0, 0, 0, 0)
	v23.TextSize = v_u_10.ChatBarTextSize
	v23.Font = v_u_10.ChatBarFont
	v23.TextXAlignment = Enum.TextXAlignment.Left
	v23.TextWrapped = true
	v23.Text = ""
	v23.Size = UDim2.new(0, 0, 0, 0)
	v23.TextYAlignment = Enum.TextYAlignment.Center
	v23.TextColor3 = p17:GetDefaultChannelNameColor()
	v23.Visible = true
	v23.Parent = v21
	local v24 = Instance.new("TextLabel")
	v24.Selectable = false
	v24.TextWrapped = true
	v24.BackgroundTransparency = 1
	v24.Size = v22.Size
	v24.Position = v22.Position
	v24.TextSize = v22.TextSize
	v24.Font = v22.Font
	v24.TextColor3 = v22.TextColor3
	v24.TextTransparency = v22.TextTransparency
	v24.TextStrokeTransparency = v22.TextStrokeTransparency
	v24.TextXAlignment = v22.TextXAlignment
	v24.TextYAlignment = v22.TextYAlignment
	v24.Text = "..."
	v24.Parent = v21
	p17.GuiObject = v19
	p17.TextBox = v22
	p17.TextLabel = v24
	p17.GuiObjects.BaseFrame = v19
	p17.GuiObjects.TextBoxFrame = v20
	p17.GuiObjects.TextBox = v22
	p17.GuiObjects.TextLabel = v24
	p17.GuiObjects.MessageModeTextButton = v23
	p17:AnimGuiObjects()
	p17:SetUpTextBoxEvents(v22, v24, v23)
	if p17.UserHasChatOff then
		p17:DoLockChatBar()
	end
	p17.eGuiObjectsChanged:Fire()
end
function v_u_16.DoLockChatBar(p_u_25) -- name: DoLockChatBar
	-- upvalues: (ref) v_u_5, (ref) v_u_14
	if p_u_25.TextLabel then
		if v_u_5.UserId > 0 then
			p_u_25.TextLabel.Text = v_u_14:Get("GameChat_ChatMessageValidator_SettingsError", "To chat in game, turn on chat in your Privacy Settings.")
		else
			p_u_25.TextLabel.Text = v_u_14:Get("GameChat_SwallowGuestChat_Message", "Sign up to chat in game.")
		end
		p_u_25:CalculateSize()
	end
	if p_u_25.TextBox then
		p_u_25.TextBox.Active = false
		p_u_25.TextBox.Focused:connect(function()
			-- upvalues: (copy) p_u_25
			p_u_25.TextBox:ReleaseFocus()
		end)
	end
end
function v_u_16.SetUpTextBoxEvents(p_u_26, p_u_27, p_u_28, p_u_29) -- name: SetUpTextBoxEvents
	-- upvalues: (copy) v_u_1, (copy) v_u_10
	for v30, v31 in pairs(p_u_26.TextBoxConnections) do
		v31:disconnect()
		p_u_26.TextBoxConnections[v30] = nil
	end
	p_u_26.TextBoxConnections.UserInputBegan = v_u_1.InputBegan:connect(function(p32, _)
		-- upvalues: (copy) p_u_26, (copy) p_u_27, (ref) v_u_10
		if p32.KeyCode == Enum.KeyCode.Backspace and (p_u_26:IsFocused() and p_u_27.Text == "") then
			p_u_26:SetChannelTarget(v_u_10.GeneralChannelName)
		end
	end)
	p_u_26.TextBoxConnections.TextBoxChanged = p_u_27.Changed:connect(function(p33)
		-- upvalues: (copy) p_u_26, (copy) p_u_27, (ref) v_u_10
		if p33 == "AbsoluteSize" then
			p_u_26:CalculateSize()
			return
		elseif p33 == "Text" then
			p_u_26:CalculateSize()
			if utf8.len(utf8.nfcnormalize(p_u_27.Text)) > v_u_10.MaximumMessageLength then
				p_u_27.Text = p_u_26.PreviousText
			else
				p_u_26.PreviousText = p_u_27.Text
			end
			if p_u_26.InCustomState then
				p_u_26.CustomState:TextUpdated()
			else
				local v34 = p_u_26.CommandProcessor:ProcessInProgressChatMessage(p_u_27.Text, p_u_26.ChatWindow, p_u_26)
				if v34 then
					p_u_26.InCustomState = true
					p_u_26.CustomState = v34
					return
				end
			end
		end
	end)
	p_u_26.TextBoxConnections.MessageModeClick = p_u_29.MouseButton1Click:connect(function()
		-- upvalues: (copy) p_u_29, (copy) p_u_26, (ref) v_u_10
		if p_u_29.Text ~= "" then
			p_u_26:SetChannelTarget(v_u_10.GeneralChannelName)
		end
	end)
	p_u_26.TextBoxConnections.TextBoxFocused = p_u_27.Focused:connect(function()
		-- upvalues: (copy) p_u_26, (copy) p_u_28
		if not p_u_26.UserHasChatOff then
			p_u_26:CalculateSize()
			p_u_28.Visible = false
		end
	end)
	p_u_26.TextBoxConnections.TextBoxFocusLost = p_u_27.FocusLost:connect(function(_, p35)
		-- upvalues: (copy) p_u_26, (copy) p_u_27, (copy) p_u_28
		p_u_26:CalculateSize()
		if p35 and p35.KeyCode == Enum.KeyCode.Escape then
			p_u_27.Text = ""
		end
		if p_u_27.Text == "" then
			p_u_28.Visible = true
		else
			p_u_28.Visible = false
		end
	end)
end
function v_u_16.GetTextBox(p36) -- name: GetTextBox
	return p36.TextBox
end
function v_u_16.GetMessageModeTextButton(p37) -- name: GetMessageModeTextButton
	return p37.GuiObjects.MessageModeTextButton
end
function v_u_16.GetMessageModeTextLabel(p38) -- name: GetMessageModeTextLabel
	return p38:GetMessageModeTextButton()
end
function v_u_16.IsFocused(p39) -- name: IsFocused
	if p39.UserHasChatOff then
		return false
	else
		return p39:GetTextBox():IsFocused()
	end
end
function v_u_16.GetVisible(p40) -- name: GetVisible
	return p40.GuiObject.Visible
end
function v_u_16.CaptureFocus(p41) -- name: CaptureFocus
	if not p41.UserHasChatOff then
		p41:GetTextBox():CaptureFocus()
	end
end
function v_u_16.ReleaseFocus(p42, p43) -- name: ReleaseFocus
	p42:GetTextBox():ReleaseFocus(p43)
end
function v_u_16.ResetText(p44) -- name: ResetText
	p44:GetTextBox().Text = ""
end
function v_u_16.SetText(p45, p46) -- name: SetText
	p45:GetTextBox().Text = p46
end
function v_u_16.GetEnabled(p47) -- name: GetEnabled
	return p47.GuiObject.Visible
end
function v_u_16.SetEnabled(p48, p49) -- name: SetEnabled
	if p48.UserHasChatOff then
		p48.GuiObject.Visible = true
	else
		p48.GuiObject.Visible = p49
	end
end
function v_u_16.SetTextLabelText(p50, p51) -- name: SetTextLabelText
	if not p50.UserHasChatOff then
		p50.TextLabel.Text = p51
	end
end
function v_u_16.SetTextBoxText(p52, p53) -- name: SetTextBoxText
	p52.TextBox.Text = p53
end
function v_u_16.GetTextBoxText(p54) -- name: GetTextBoxText
	return p54.TextBox.Text
end
function v_u_16.ResetSize(p55) -- name: ResetSize
	p55.TargetYSize = 0
	p55:TweenToTargetYSize()
end
function v_u_16.CalculateSize(p56) -- name: CalculateSize
	-- upvalues: (copy) v_u_4
	if not p56.CalculatingSizeLock then
		p56.CalculatingSizeLock = true
		local v57, v58
		if p56:IsFocused() or p56.TextBox.Text ~= "" then
			v57 = p56.TextBox.TextSize
			local v59 = p56.TextBox
			v58 = v_u_4:GetTextSize(v59.Text, v59.TextSize, v59.Font, Vector2.new(v59.AbsoluteSize.X, 10000)).Y
		else
			v57 = p56.TextLabel.TextSize
			local v60 = p56.TextLabel
			v58 = v_u_4:GetTextSize(v60.Text, v60.TextSize, v60.Font, Vector2.new(v60.AbsoluteSize.X, 10000)).Y
		end
		local v61 = v58 - v57
		if p56.TargetYSize ~= v61 then
			p56.TargetYSize = v61
			p56:TweenToTargetYSize()
		end
		p56.CalculatingSizeLock = false
	end
end
function v_u_16.TweenToTargetYSize(p_u_62) -- name: TweenToTargetYSize
	local v_u_63 = UDim2.new(1, 0, 1, p_u_62.TargetYSize)
	local v64 = p_u_62.GuiObject.Size
	local v65 = p_u_62.GuiObject.AbsoluteSize.Y
	p_u_62.GuiObject.Size = v_u_63
	local v66 = p_u_62.GuiObject.AbsoluteSize.Y
	p_u_62.GuiObject.Size = v64
	local v67 = v66 - v65
	local v68 = math.abs(v67) * (1 / p_u_62.TweenPixelsPerSecond)
	local v_u_69 = math.min(1, v68)
	if not pcall(function()
		-- upvalues: (copy) p_u_62, (copy) v_u_63, (copy) v_u_69
		p_u_62.GuiObject:TweenSize(v_u_63, Enum.EasingDirection.Out, Enum.EasingStyle.Quad, v_u_69, true)
	end) then
		p_u_62.GuiObject.Size = v_u_63
	end
end
function v_u_16.SetTextSize(p70, p71) -- name: SetTextSize
	if not p70:IsInCustomState() then
		if p70.TextBox then
			p70.TextBox.TextSize = p71
		end
		if p70.TextLabel then
			p70.TextLabel.TextSize = p71
		end
	end
end
function v_u_16.GetDefaultChannelNameColor(_) -- name: GetDefaultChannelNameColor
	-- upvalues: (copy) v_u_10
	if v_u_10.DefaultChannelNameColor then
		return v_u_10.DefaultChannelNameColor
	else
		return Color3.fromRGB(35, 76, 142)
	end
end
function v_u_16.SetChannelTarget(p72, p73) -- name: SetChannelTarget
	-- upvalues: (copy) v_u_10, (ref) v_u_14
	local v74 = p72.GuiObjects.MessageModeTextButton
	local v75 = p72.TextBox
	local v76 = p72.TextLabel
	p72.TargetChannel = p73
	if not p72:IsInCustomState() then
		if p73 ~= v_u_10.GeneralChannelName then
			v74.Size = UDim2.new(0, 1000, 1, 0)
			local v77
			if v_u_14.tryLocalize then
				v77 = v_u_14:tryLocalize(p73)
			else
				v77 = p73
			end
			v74.Text = string.format("[%s] ", v77)
			local v78 = p72:GetChannelNameColor(p73)
			if v78 then
				v74.TextColor3 = v78
			else
				v74.TextColor3 = p72:GetDefaultChannelNameColor()
			end
			local v79 = v74.TextBounds.X
			v74.Size = UDim2.new(0, v79, 1, 0)
			v75.Size = UDim2.new(1, -v79, 1, 0)
			v75.Position = UDim2.new(0, v79, 0, 0)
			v76.Size = UDim2.new(1, -v79, 1, 0)
			v76.Position = UDim2.new(0, v79, 0, 0)
			return
		end
		v74.Text = ""
		v74.Size = UDim2.new(0, 0, 0, 0)
		v75.Size = UDim2.new(1, 0, 1, 0)
		v75.Position = UDim2.new(0, 0, 0, 0)
		v76.Size = UDim2.new(1, 0, 1, 0)
		v76.Position = UDim2.new(0, 0, 0, 0)
	end
end
function v_u_16.IsInCustomState(p80) -- name: IsInCustomState
	return p80.InCustomState
end
function v_u_16.ResetCustomState(p81) -- name: ResetCustomState
	-- upvalues: (ref) v_u_14
	if p81.InCustomState then
		p81.CustomState:Destroy()
		p81.CustomState = nil
		p81.InCustomState = false
		p81.ChatBarParentFrame:ClearAllChildren()
		p81:CreateGuiObjects(p81.ChatBarParentFrame)
		p81:SetTextLabelText(v_u_14:Get("GameChat_ChatMain_ChatBarText", "To chat click here or press \"/\" key"))
	end
end
function v_u_16.EnterWhisperState(p82, p83) -- name: EnterWhisperState
	-- upvalues: (copy) v_u_13, (copy) v_u_10
	p82:ResetCustomState()
	if v_u_13.CustomStateCreator then
		p82.CustomState = v_u_13.CustomStateCreator(p83, p82.ChatWindow, p82, v_u_10)
		p82.InCustomState = true
	else
		local v84
		if v_u_10.PlayerDisplayNamesEnabled then
			v84 = p83.DisplayName
		else
			v84 = p83.Name
		end
		p82:SetText("/w " .. v84)
	end
	p82:CaptureFocus()
end
function v_u_16.GetCustomMessage(p85) -- name: GetCustomMessage
	if p85.InCustomState then
		return p85.CustomState:GetMessage()
	else
		return nil
	end
end
function v_u_16.CustomStateProcessCompletedMessage(p86, _) -- name: CustomStateProcessCompletedMessage
	if p86.InCustomState then
		return p86.CustomState:ProcessCompletedMessage()
	else
		return false
	end
end
function v_u_16.FadeOutBackground(p87, p88) -- name: FadeOutBackground
	-- upvalues: (copy) v_u_11
	p87.AnimParams.Background_TargetTransparency = 1
	p87.AnimParams.Background_NormalizedExptValue = v_u_11:NormalizedDefaultExptValueInSeconds(p88)
	p87:FadeOutText(p88)
end
function v_u_16.FadeInBackground(p89, p90) -- name: FadeInBackground
	-- upvalues: (copy) v_u_11
	p89.AnimParams.Background_TargetTransparency = 0.6
	p89.AnimParams.Background_NormalizedExptValue = v_u_11:NormalizedDefaultExptValueInSeconds(p90)
	p89:FadeInText(p90)
end
function v_u_16.FadeOutText(p91, p92) -- name: FadeOutText
	-- upvalues: (copy) v_u_11
	p91.AnimParams.Text_TargetTransparency = 1
	p91.AnimParams.Text_NormalizedExptValue = v_u_11:NormalizedDefaultExptValueInSeconds(p92)
end
function v_u_16.FadeInText(p93, p94) -- name: FadeInText
	-- upvalues: (copy) v_u_11
	p93.AnimParams.Text_TargetTransparency = 0.4
	p93.AnimParams.Text_NormalizedExptValue = v_u_11:NormalizedDefaultExptValueInSeconds(p94)
end
function v_u_16.AnimGuiObjects(p95) -- name: AnimGuiObjects
	p95.GuiObject.BackgroundTransparency = p95.AnimParams.Background_CurrentTransparency
	p95.GuiObjects.TextBoxFrame.BackgroundTransparency = p95.AnimParams.Background_CurrentTransparency
	p95.GuiObjects.TextLabel.TextTransparency = p95.AnimParams.Text_CurrentTransparency
	p95.GuiObjects.TextBox.TextTransparency = p95.AnimParams.Text_CurrentTransparency
	p95.GuiObjects.MessageModeTextButton.TextTransparency = p95.AnimParams.Text_CurrentTransparency
end
function v_u_16.InitializeAnimParams(p96) -- name: InitializeAnimParams
	p96.AnimParams.Text_TargetTransparency = 0.4
	p96.AnimParams.Text_CurrentTransparency = 0.4
	p96.AnimParams.Text_NormalizedExptValue = 1
	p96.AnimParams.Background_TargetTransparency = 0.6
	p96.AnimParams.Background_CurrentTransparency = 0.6
	p96.AnimParams.Background_NormalizedExptValue = 1
end
function v_u_16.Update(p97, p98) -- name: Update
	-- upvalues: (copy) v_u_11
	p97.AnimParams.Text_CurrentTransparency = v_u_11:Expt(p97.AnimParams.Text_CurrentTransparency, p97.AnimParams.Text_TargetTransparency, p97.AnimParams.Text_NormalizedExptValue, p98)
	p97.AnimParams.Background_CurrentTransparency = v_u_11:Expt(p97.AnimParams.Background_CurrentTransparency, p97.AnimParams.Background_TargetTransparency, p97.AnimParams.Background_NormalizedExptValue, p98)
	p97:AnimGuiObjects()
end
function v_u_16.SetChannelNameColor(p99, p100, p101) -- name: SetChannelNameColor
	p99.ChannelNameColors[p100] = p101
	if p99.GuiObjects.MessageModeTextButton.Text == p100 then
		p99.GuiObjects.MessageModeTextButton.TextColor3 = p101
	end
end
function v_u_16.GetChannelNameColor(p102, p103) -- name: GetChannelNameColor
	return p102.ChannelNameColors[p103]
end
function v6.new(p104, p105) -- name: new
	-- upvalues: (copy) v_u_16, (copy) v_u_10, (copy) v_u_7, (ref) v_u_5, (copy) v_u_2
	local v106 = v_u_16
	local v_u_107 = setmetatable({}, v106)
	v_u_107.GuiObject = nil
	v_u_107.ChatBarParentFrame = nil
	v_u_107.TextBox = nil
	v_u_107.TextLabel = nil
	v_u_107.GuiObjects = {}
	v_u_107.eGuiObjectsChanged = Instance.new("BindableEvent")
	v_u_107.GuiObjectsChanged = v_u_107.eGuiObjectsChanged.Event
	v_u_107.TextBoxConnections = {}
	v_u_107.PreviousText = ""
	v_u_107.InCustomState = false
	v_u_107.CustomState = nil
	v_u_107.TargetChannel = nil
	v_u_107.CommandProcessor = p104
	v_u_107.ChatWindow = p105
	v_u_107.TweenPixelsPerSecond = 500
	v_u_107.TargetYSize = 0
	v_u_107.AnimParams = {}
	v_u_107.CalculatingSizeLock = false
	v_u_107.ChannelNameColors = {}
	v_u_107.UserHasChatOff = false
	v_u_107:InitializeAnimParams()
	v_u_10.SettingsChanged:connect(function(p108, p109)
		-- upvalues: (copy) v_u_107
		if p108 == "ChatBarTextSize" then
			v_u_107:SetTextSize(p109)
		end
	end)
	coroutine.wrap(function()
		-- upvalues: (ref) v_u_7, (ref) v_u_5, (ref) v_u_2, (copy) v_u_107
		local v110, v111 = pcall(function()
			-- upvalues: (ref) v_u_7, (ref) v_u_5
			return v_u_7:CanUserChatAsync(v_u_5.UserId)
		end)
		if v110 then
			v110 = v_u_2:IsStudio() or v111
		end
		if v110 == false then
			v_u_107.UserHasChatOff = true
			v_u_107:DoLockChatBar()
		end
	end)()
	return v_u_107
end
return v6
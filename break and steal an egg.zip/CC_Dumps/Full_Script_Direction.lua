local v1 = game:GetService("CorePackages")
return require(v1.Packages.enumerate)(script.Name, {
	["Up"] = "Up",
	["Down"] = "Down",
	["Left"] = "Left",
	["Right"] = "Right"
})
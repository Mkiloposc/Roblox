local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("RunService")
local v3 = game:GetService("ReplicatedStorage")
local v_u_4 = require(v3.Shared.MasteryConfig)
local v_u_5 = require(v3.Shared.TutorialConfig)
local v6 = require(script.Parent.DiamondShopController)
local v_u_7 = require(script.Parent.NotificationController)
local v_u_8 = require(script.Parent.UiFrames)
local v_u_9 = require(script.Parent.Parent.Modules.LocalCharacter)
local v_u_10 = require(script.Parent.Parent.Modules.MainGui)
local v_u_11 = {
	["Pickaxe Shop"] = "Pickaxes",
	["Trails Shop"] = "Trails",
	["Masteries"] = "Mastery"
}
local v_u_12 = {
	["GemShop"] = v6.GetFrame
}
v_u_11["Diamond Shop"] = "GemShop"
local v_u_13 = {
	["Masteries"] = "Hitbox"
}
local v14 = {}
local v_u_15 = {}
local v_u_16 = nil
local function v_u_21(p17) -- name: disablePrompts
	local function v19(p18) -- name: tryDisable
		if p18:IsA("ProximityPrompt") then
			p18.Enabled = false
		end
	end
	for _, v20 in p17:GetDescendants() do
		if not v20:IsA("ProximityPrompt") then
			continue
		end
		v20.Enabled = false
	end
	p17.DescendantAdded:Connect(v19)
end
local function v_u_35(p22, p_u_23) -- name: bindBooth
	-- upvalues: (copy) v_u_21, (copy) v_u_13, (copy) v_u_15, (copy) v_u_12, (ref) v_u_16
	v_u_21(p22)
	local v_u_24 = v_u_13[p22.Name] or "HitZone"
	local function v_u_31(p25) -- name: tryBind
		-- upvalues: (copy) v_u_24, (ref) v_u_15, (copy) p_u_23, (ref) v_u_12, (ref) v_u_16
		if p25.Name ~= v_u_24 or not p25:IsA("BasePart") then
			return false
		end
		local v26 = v_u_15
		local v27 = {
			["zone"] = nil,
			["frameName"] = nil,
			["frame"] = nil,
			["inside"] = false,
			["zone"] = p25,
			["frameName"] = p_u_23
		}
		local v28 = p_u_23
		local v29 = v_u_12[v28]
		local v30
		if v29 then
			v30 = v29()
		else
			v30 = v_u_16
			if v30 then
				v30 = v_u_16:FindFirstChild(v28)
			end
			if not (v30 and v30:IsA("GuiObject")) then
				v30 = nil
			end
		end
		v27.frame = v30
		table.insert(v26, v27)
		return true
	end
	for _, v32 in p22:GetDescendants() do
		if not v_u_31(v32) then
			continue
		end
		return
	end
	local v_u_33 = nil
	v_u_33 = p22.DescendantAdded:Connect(function(p34)
		-- upvalues: (copy) v_u_31, (ref) v_u_33
		if v_u_31(p34) then
			v_u_33:Disconnect()
		end
	end)
end
function v14.Start() -- name: Start
	-- upvalues: (copy) v_u_10, (ref) v_u_16, (copy) v_u_15, (copy) v_u_12, (copy) v_u_11, (copy) v_u_35, (copy) v_u_2, (copy) v_u_9, (copy) v_u_1, (copy) v_u_5, (copy) v_u_7, (copy) v_u_4, (copy) v_u_8
	v_u_10.Observe(function(p36)
		-- upvalues: (ref) v_u_16, (ref) v_u_15, (ref) v_u_12
		v_u_16 = p36:FindFirstChild("Frames")
		for _, v37 in v_u_15 do
			local v38 = v37.frameName
			local v39 = v_u_12[v38]
			local v40
			if v39 then
				v40 = v39()
			else
				v40 = v_u_16
				if v40 then
					v40 = v_u_16:FindFirstChild(v38)
				end
				if not (v40 and v40:IsA("GuiObject")) then
					v40 = nil
				end
			end
			v37.frame = v40
			v37.inside = false
			if not v40 or v_u_12[v37.frameName] then
				continue
			end
			v40.Visible = false
		end
	end)
	local v41 = workspace:WaitForChild("Booths", 30)
	if v41 then
		for v42, v43 in v_u_11 do
			local v44 = v41:FindFirstChild(v42)
			if not v44 then
				continue
			end
			v_u_35(v44, v43)
		end
		v_u_2.Heartbeat:Connect(function()
			-- upvalues: (ref) v_u_9, (ref) v_u_15, (ref) v_u_12, (ref) v_u_16, (ref) v_u_1, (ref) v_u_5, (ref) v_u_7, (ref) v_u_4, (ref) v_u_8
			local v45 = v_u_9.GetPosition()
			for _, v46 in v_u_15 do
				if v_u_12[v46.frameName] then
					local v47 = v46.frameName
					local v48 = v_u_12[v47]
					local v49
					if v48 then
						v49 = v48()
					else
						v49 = v_u_16
						if v49 then
							v49 = v_u_16:FindFirstChild(v47)
						end
						if not (v49 and v49:IsA("GuiObject")) then
							v49 = nil
						end
					end
					v46.frame = v49
				end
				local v50
				if v45 == nil then
					v50 = false
				else
					local v51 = v46.zone
					local v52 = v51.CFrame:PointToObjectSpace(v45)
					local v53 = v51.Size / 2
					local v54 = v52.X
					if math.abs(v54) <= v53.X then
						local v55 = v52.Y
						if math.abs(v55) <= v53.Y then
							local v56 = v52.Z
							v50 = math.abs(v56) <= v53.Z
						else
							v50 = false
						end
					else
						v50 = false
					end
				end
				if v50 == v46.inside or v46.frame == nil then
					continue
				end
				v46.inside = v50
				if v50 then
					if v_u_1.LocalPlayer:GetAttribute(v_u_5.StageAttribute) ~= nil then
						local v57 = v46.frameName
						local v58
						if v57 == "Pickaxes" then
							v58 = true
						elseif v57 == "Trails" then
							local v59 = v_u_1.LocalPlayer:GetAttribute(v_u_5.StageAttribute)
							v58 = v59 == "EarnTrailCash" and true or v59 == "BuyTrail"
						else
							v58 = false
						end
						if v58 then
							if v46.frameName == "Mastery" and not v_u_4.IsUnlocked(v_u_1.LocalPlayer) then
								v_u_7.Show(v_u_4.LockedMessage, "Error")
							else
								v_u_8.Open(v46.frame)
							end
						else
							v_u_7.Show("Complete Tutorial First", "Error")
						end
					elseif v46.frameName == "Mastery" and not v_u_4.IsUnlocked(v_u_1.LocalPlayer) then
						v_u_7.Show(v_u_4.LockedMessage, "Error")
					else
						v_u_8.Open(v46.frame)
					end
				else
					v_u_8.Close(v46.frame)
				end
			end
		end)
	end
end
return v14
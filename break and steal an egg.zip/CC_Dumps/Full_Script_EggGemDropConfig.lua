local v_u_1 = {
	["RemoteName"] = "EggGemDropRemote",
	["Chance"] = 0.25,
	["Amounts"] = {
		["Common"] = {
			["Min"] = 1,
			["Max"] = 2
		},
		["Uncommon"] = {
			["Min"] = 2,
			["Max"] = 4
		},
		["Rare"] = {
			["Min"] = 4,
			["Max"] = 7
		},
		["Epic"] = {
			["Min"] = 8,
			["Max"] = 12
		},
		["Legendary"] = {
			["Min"] = 15,
			["Max"] = 22
		},
		["Mythic"] = {
			["Min"] = 25,
			["Max"] = 35
		},
		["Divine"] = {
			["Min"] = 40,
			["Max"] = 55
		},
		["Cosmic"] = {
			["Min"] = 60,
			["Max"] = 80
		},
		["Secret"] = {
			["Min"] = 100,
			["Max"] = 130
		},
		["Celestial"] = {
			["Min"] = 150,
			["Max"] = 200
		},
		["Inferno"] = {
			["Min"] = 200,
			["Max"] = 260
		},
		["Void"] = {
			["Min"] = 280,
			["Max"] = 350
		},
		["Omega"] = {
			["Min"] = 380,
			["Max"] = 450
		},
		["Spectral"] = {
			["Min"] = 480,
			["Max"] = 560
		},
		["Ethereal"] = {
			["Min"] = 600,
			["Max"] = 750
		}
	},
	["Default"] = {
		["Min"] = 1,
		["Max"] = 2
	}
}
local v2 = {
	["Icon"] = "rbxassetid://99253762015679",
	["MaxPieces"] = 10,
	["PieceSize"] = 1.6,
	["MaxActive"] = 80,
	["Burst"] = nil,
	["Rest"] = nil,
	["Magnet"] = nil,
	["Jelly"] = nil,
	["Trail"] = nil,
	["SoundFolder"] = "rransCustomSFX",
	["Sound"] = "Pop1",
	["PitchStep"] = 0.05,
	["PitchMax"] = 1.7,
	["ComboReset"] = 1.2,
	["GrabSound"] = "Click Pop",
	["GrabVolume"] = 0.35,
	["Gain"] = nil,
	["MaxShowDistance"] = 250,
	["Burst"] = {
		["UpSpeed"] = nil,
		["OutSpeed"] = nil,
		["Gravity"] = 70,
		["Restitution"] = 0.42,
		["Friction"] = 0.7,
		["SettleSpeed"] = 4,
		["SpinSpeed"] = nil,
		["MaxAirTime"] = 4,
		["UpSpeed"] = NumberRange.new(18, 26),
		["OutSpeed"] = NumberRange.new(6, 13),
		["SpinSpeed"] = NumberRange.new(260, 520)
	},
	["Rest"] = {
		["Hover"] = 0.35,
		["HoverSpeed"] = 2.6,
		["Wobble"] = 12,
		["Breathe"] = 0.06,
		["Lifetime"] = 60,
		["BlinkTime"] = 6,
		["FadeTime"] = 0.35
	},
	["Magnet"] = {
		["Radius"] = 20,
		["GrabDelay"] = 0.5,
		["ReleaseRadius"] = 70,
		["HopSpeed"] = 17,
		["KickBack"] = 7,
		["Stiffness"] = 45,
		["StiffnessRamp"] = 5,
		["Damping"] = 0.38,
		["MaxSpeed"] = 140,
		["CollectRadius"] = 1.8,
		["MaxPullTime"] = 1.6,
		["TargetOffset"] = Vector3.new(0, 0.6, 0),
		["ShrinkDistance"] = 5,
		["StretchPerSpeed"] = 0.011,
		["MaxStretch"] = 0.7
	},
	["Jelly"] = {
		["Stiffness"] = 320,
		["Damping"] = 0.28,
		["ImpactSquash"] = 0.09,
		["MaxSquash"] = 7
	},
	["Trail"] = {
		["Color"] = nil,
		["Lifetime"] = 0.16,
		["Width"] = 0.55,
		["LightEmission"] = 0.8,
		["Color"] = Color3.fromRGB(130, 225, 255)
	},
	["Gain"] = {
		["Format"] = "+%s",
		["Color"] = nil,
		["StrokeColor"] = nil,
		["Offset"] = 2.5,
		["Rise"] = 2.5,
		["HoldTime"] = 0.9,
		["FadeTime"] = 0.5,
		["CountRate"] = 14,
		["Punch"] = 6,
		["PunchStiffness"] = 400,
		["PunchDamping"] = 0.3,
		["Color"] = Color3.fromRGB(120, 220, 255),
		["StrokeColor"] = Color3.fromRGB(20, 40, 70)
	}
}
v_u_1.Visual = v2
function v_u_1.AmountFor(p3, p4) -- name: AmountFor
	-- upvalues: (copy) v_u_1
	local v5 = p3 and v_u_1.Amounts[p3] or v_u_1.Default
	local v6 = v5.Min
	local v7 = math.floor(v6)
	local v8 = v5.Max
	local v9 = math.floor(v8)
	local v10 = v5.Min
	local v11 = math.floor(v10)
	return p4:NextInteger(v7, (math.max(v9, v11)))
end
return v_u_1
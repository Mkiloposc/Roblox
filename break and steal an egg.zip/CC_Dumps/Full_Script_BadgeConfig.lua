local v2 = {
	["Badges"] = {
		["Welcome"] = {
			["Id"] = 1522513800439524,
			["DisplayName"] = "Welcome",
			["AwardOnJoin"] = true
		}
	},
	["JoinDelaySeconds"] = 1,
	["RetryDelays"] = {
		2,
		5,
		10,
		20,
		30,
		60
	},
	["Notify"] = false,
	["NotifyText"] = function(p1) -- name: NotifyText
		return "Badge earned: {" .. p1.DisplayName .. "}!"
	end
}
return v2
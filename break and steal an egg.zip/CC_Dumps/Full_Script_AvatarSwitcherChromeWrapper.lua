local v1 = script:FindFirstAncestor("Chrome")
local v2 = game:GetService("CorePackages")
local v3 = game:GetService("CoreGui")
local v_u_4 = game:GetService("GuiService")
local v_u_5 = v3:WaitForChild("RobloxGui")
local v_u_6 = require(v2.Packages.React)
local v_u_7 = require(v2.Packages.ReactUtils).useEventConnection
local v_u_8 = require(v2.Packages.Foundation)
local v_u_9 = require(v1.Service)
local v_u_10 = require(v1.ChromeShared.Service.ViewportUtil)
require(v1.ChromeShared.Service.WindowSizeSignal)
local v_u_11 = require(v1.ChromeShared.Unibar.Constants)
local v_u_12 = require(v2.Workspace.Packages.AvatarSwitcher).Components.AvatarSwitcherContainer
return function(p_u_13) -- name: AvatarSwitcherChromeWrapper
	-- upvalues: (copy) v_u_6, (copy) v_u_5, (copy) v_u_4, (copy) v_u_7, (copy) v_u_10, (copy) v_u_8, (copy) v_u_12, (copy) v_u_9, (copy) v_u_11
	local v_u_14 = p_u_13.windowSize
	local v15 = v_u_6.useState
	local v16 = v_u_14:get()
	local v17, v_u_18 = v15(v16.X.Offset / v16.Y.Offset < 1.2)
	local v19, v_u_20 = v_u_6.useState(false)
	local v21 = require(v_u_5.Modules.Settings.SettingsHub)
	local v_u_31 = v_u_6.useCallback(function(p22)
		-- upvalues: (ref) v_u_4, (copy) p_u_13, (copy) v_u_14, (copy) v_u_20
		local v23 = v_u_4.TopbarInset.Max.Y
		local v24 = p22.X < p_u_13.maxWindowWidth and true or p22.Y - v23 < p_u_13.maxWindowHeight
		if v24 then
			v_u_14:requestSize(p22.X, p22.Y - v23)
		else
			local v25 = v_u_14
			local v26 = p_u_13.maxWindowWidth
			local v27 = p22.X
			local v28 = math.min(v26, v27)
			local v29 = p_u_13.maxWindowHeight
			local v30 = p22.Y - v23
			v25:requestSize(v28, (math.min(v29, v30)))
		end
		v_u_20(v24)
	end, {
		v_u_14,
		p_u_13.maxWindowWidth,
		p_u_13.maxWindowHeight,
		v19
	})
	v_u_7(v_u_4:GetPropertyChangedSignal("TopbarInset"), function()
		-- upvalues: (copy) v_u_31, (ref) v_u_10
		v_u_31(v_u_10.screenSize:get())
	end)
	v_u_6.useEffect(function()
		-- upvalues: (ref) v_u_10, (copy) v_u_31, (copy) v_u_14, (copy) v_u_18
		local v_u_32 = v_u_10.screenSize:connect(v_u_31)
		local v_u_34 = v_u_14:connect(function(p33)
			-- upvalues: (ref) v_u_18
			v_u_18(p33.X.Offset / p33.Y.Offset < 1.2)
		end)
		v_u_31(v_u_10.screenSize:get())
		return function()
			-- upvalues: (copy) v_u_32, (copy) v_u_34
			v_u_32:disconnect()
			v_u_34:disconnect()
		end
	end, { v_u_31 })
	return v_u_6.createElement(v_u_8.View, {
		["tag"] = ("size-full %*"):format(v19 and "padding-x-large padding-top-medium padding-bottom-xlarge" or "")
	}, {
		["AvatarSwitcherContainer"] = v_u_6.createElement(v_u_12, {
			["getRespawnBehaviour"] = v21.GetRespawnBehaviour,
			["respawnBehaviorChangedEvent"] = v21.RespawnBehaviourChangedEvent,
			["toggleWindow"] = function() -- name: toggleWindow
				-- upvalues: (ref) v_u_9, (ref) v_u_11
				v_u_9:toggleWindow(v_u_11.AVATAR_SWITCHER_ID)
			end,
			["verticalLayout"] = v17
		})
	})
end
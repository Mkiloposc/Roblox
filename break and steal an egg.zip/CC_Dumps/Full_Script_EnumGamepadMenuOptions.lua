return {
	["Leave"] = "Leave",
	["Menu"] = "Menu",
	["Unibar"] = "Unibar",
	["Chat"] = "Chat",
	["Leaderboard"] = "Leaderboard",
	["Emotes"] = "Emotes",
	["Inventory"] = "Inventory",
	["Respawn"] = "Respawn"
}
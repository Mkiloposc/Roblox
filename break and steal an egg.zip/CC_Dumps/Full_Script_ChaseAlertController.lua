local v_u_1 = game:GetService("Debris")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("SoundService")
local v_u_5 = game:GetService("TweenService")
local v_u_6 = require(v_u_3.Shared.ChaseState)
local v7 = require(v_u_3.Shared.HudVisibility)
local v_u_8 = require(v_u_3.Shared.NotificationConfig)
local v_u_9 = require(script.Parent.Parent.Modules.SettingsState)
local v10 = {}
local v_u_11 = { "LeftHUD", "RightHUD" }
local v_u_12 = Vector2.new(0.5, 0.5)
local v_u_13 = v2.LocalPlayer
local v_u_14 = false
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = nil
local v_u_18 = nil
local v_u_19 = {}
local v_u_20 = v7.new()
local function v_u_27(p21) -- name: recenterAnchor
	-- upvalues: (copy) v_u_12
	local v22 = p21.AnchorPoint
	if v22 ~= v_u_12 then
		local v23 = p21.Position
		local v24 = p21.Size
		local v25 = 0.5 - v22.X
		local v26 = 0.5 - v22.Y
		p21.Position = UDim2.new(v23.X.Scale + v24.X.Scale * v25, v23.X.Offset + v24.X.Offset * v25, v23.Y.Scale + v24.Y.Scale * v26, v23.Y.Offset + v24.Y.Offset * v26)
		p21.AnchorPoint = v_u_12
	end
end
local function v_u_32(p28) -- name: startRunPulse
	-- upvalues: (ref) v_u_17, (ref) v_u_18, (copy) v_u_27, (copy) v_u_5
	if v_u_17 then
		v_u_17:Cancel()
		v_u_17 = nil
	end
	if v_u_18 then
		if v_u_18.Parent then
			v_u_18.Scale = 1
		end
		v_u_18 = nil
	end
	local v29 = p28:FindFirstChild("Run")
	if v29 and v29:IsA("GuiObject") then
		v_u_27(v29)
		local v30 = v29:FindFirstChild("RunPulseScale")
		if not (v30 and v30:IsA("UIScale")) then
			v30 = Instance.new("UIScale")
			v30.Name = "RunPulseScale"
			v30.Parent = v29
		end
		v30.Scale = 1
		v_u_18 = v30
		local v31 = v_u_5:Create(v30, TweenInfo.new(0.4, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
			["Scale"] = 1.15
		})
		v_u_17 = v31
		v31:Play()
	end
end
local function v_u_35(p33) -- name: startPulse
	-- upvalues: (ref) v_u_15, (ref) v_u_17, (ref) v_u_18, (ref) v_u_16, (copy) v_u_9, (copy) v_u_5, (copy) v_u_32
	if v_u_15 then
		v_u_15:Cancel()
		v_u_15 = nil
	end
	if v_u_17 then
		v_u_17:Cancel()
		v_u_17 = nil
	end
	if v_u_18 then
		if v_u_18.Parent then
			v_u_18.Scale = 1
		end
		v_u_18 = nil
	end
	if v_u_16 then
		if v_u_16.Parent then
			v_u_16.Visible = false
			v_u_16.ImageTransparency = 0.1
		end
		v_u_16 = nil
	end
	v_u_16 = p33
	p33.Visible = true
	if v_u_9.Get("ScreenFFX") == true then
		p33.ImageTransparency = 0.1
		local v34 = v_u_5:Create(p33, TweenInfo.new(0.6, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true), {
			["ImageTransparency"] = 0.8
		})
		v_u_15 = v34
		v34:Play()
	else
		p33.ImageTransparency = 1
	end
	v_u_32(p33)
end
local v_u_36 = nil
local function v_u_41() -- name: playAlertSound
	-- upvalues: (ref) v_u_36, (copy) v_u_4, (copy) v_u_8, (copy) v_u_1
	if not (v_u_36 and v_u_36.Parent) then
		v_u_36 = v_u_4:FindFirstChild(v_u_8.SoundFolderName)
	end
	local v37 = v_u_36
	if v37 then
		v37 = v_u_36:FindFirstChild("Classic Surprise")
	end
	if v37 and v37:IsA("Sound") then
		local v_u_38 = v37:Clone()
		v_u_38.Parent = v_u_4
		v_u_38.Ended:Once(function()
			-- upvalues: (copy) v_u_38
			v_u_38:Destroy()
		end)
		local v39 = v_u_1
		local v40 = v_u_38.TimeLength
		v39:AddItem(v_u_38, math.max(v40, 1) + 1)
		v_u_38:Play()
	end
end
local v_u_42 = (-1 / 0)
function v10.PlayAlertEarly() -- name: PlayAlertEarly
	-- upvalues: (ref) v_u_42, (copy) v_u_41
	v_u_42 = os.clock()
	v_u_41()
end
local function v_u_48(p43) -- name: applyOutline
	-- upvalues: (copy) v_u_13, (copy) v_u_6, (ref) v_u_15, (ref) v_u_17, (ref) v_u_18, (ref) v_u_16, (copy) v_u_35
	local v44 = v_u_13:FindFirstChildOfClass("PlayerGui")
	if v44 then
		v44 = v44:FindFirstChild("MainGUI")
	end
	if not (v44 and v44:IsA("ScreenGui")) then
		v44 = nil
	end
	local v45 = p43 or v_u_6.IsMonsterChased(v_u_13)
	local v46 = v_u_6.IsCarrying(v_u_13) or v_u_13:GetAttribute("CarryingJail") == true
	local v47
	if v44 then
		v47 = v44:FindFirstChild("Drop")
	else
		v47 = v44
	end
	if v47 and v47:IsA("GuiButton") then
		v47.Visible = v46
	end
	if v45 then
		if v44 then
			v44 = v44:FindFirstChild("RedOutline")
		end
		if v44 and v44:IsA("ImageLabel") then
			v_u_35(v44)
		end
	else
		if v_u_15 then
			v_u_15:Cancel()
			v_u_15 = nil
		end
		if v_u_17 then
			v_u_17:Cancel()
			v_u_17 = nil
		end
		if v_u_18 then
			if v_u_18.Parent then
				v_u_18.Scale = 1
			end
			v_u_18 = nil
		end
		if v_u_16 then
			if v_u_16.Parent then
				v_u_16.Visible = false
				v_u_16.ImageTransparency = 0.1
			end
			v_u_16 = nil
		end
	end
end
local function v_u_50() -- name: requestDrop
	-- upvalues: (copy) v_u_3
	local v49 = v_u_3:FindFirstChild("DropCarriedRemote")
	if v49 and v49:IsA("RemoteEvent") then
		v49:FireServer()
	end
end
local function v_u_53(p51) -- name: wireDropButton
	-- upvalues: (copy) v_u_19, (copy) v_u_50
	local v_u_52 = p51:FindFirstChild("Drop")
	if v_u_52 and (v_u_52:IsA("GuiButton") and not v_u_19[v_u_52]) then
		v_u_19[v_u_52] = true
		v_u_52.Activated:Connect(v_u_50)
		v_u_52.Destroying:Connect(function()
			-- upvalues: (ref) v_u_19, (copy) v_u_52
			v_u_19[v_u_52] = nil
		end)
	end
end
function v10.Start() -- name: Start
	-- upvalues: (copy) v_u_6, (copy) v_u_13, (ref) v_u_16, (copy) v_u_35, (copy) v_u_53, (copy) v_u_48, (ref) v_u_14, (ref) v_u_42, (copy) v_u_41, (copy) v_u_20, (copy) v_u_11, (copy) v_u_9
	local function v_u_59(p54) -- name: setupGui
		-- upvalues: (ref) v_u_6, (ref) v_u_13, (ref) v_u_16, (ref) v_u_35, (ref) v_u_53
		local v55 = v_u_6.IsCarrying(v_u_13) or v_u_6.IsMonsterChased(v_u_13)
		local v56 = p54:FindFirstChild("RedOutline")
		if v56 and (v56:IsA("ImageLabel") and v56 ~= v_u_16) then
			if v55 then
				v_u_35(v56)
			else
				v56.Visible = false
			end
		end
		local v57 = v_u_6.IsCarrying(v_u_13) or v_u_13:GetAttribute("CarryingJail") == true
		local v58
		if p54 then
			v58 = p54:FindFirstChild("Drop")
		else
			v58 = p54
		end
		if v58 and v58:IsA("GuiButton") then
			v58.Visible = v57
		end
		v_u_53(p54)
	end
	v_u_13:WaitForChild("PlayerGui").ChildAdded:Connect(function(p60)
		-- upvalues: (copy) v_u_59
		if p60.Name == "MainGUI" then
			task.defer(v_u_59, p60)
		end
	end)
	local v61 = v_u_13:FindFirstChildOfClass("PlayerGui")
	local v62 = v61
	if v62 then
		v62 = v61:FindFirstChild("MainGUI")
	end
	if not (v62 and v62:IsA("ScreenGui")) then
		v62 = nil
	end
	if v62 then
		v_u_59(v62)
	end
	v_u_6.ObserveCarrying(v_u_13, v_u_48)
	local v_u_63 = false
	v_u_6.Observe(v_u_13, function(p64)
		-- upvalues: (ref) v_u_63, (ref) v_u_6, (ref) v_u_13, (ref) v_u_14, (ref) v_u_42, (ref) v_u_41, (ref) v_u_20, (ref) v_u_11
		v_u_63 = p64
		local v65 = p64 or v_u_6.IsMonsterChased(v_u_13)
		if v65 and (not v_u_14 and os.clock() - v_u_42 > 2) then
			v_u_41()
		end
		v_u_14 = v65
		if v65 then
			local v66 = v_u_13:FindFirstChildOfClass("PlayerGui")
			if v66 then
				v66 = v66:FindFirstChild("MainGUI")
			end
			if not (v66 and v66:IsA("ScreenGui")) then
				v66 = nil
			end
			if v66 then
				v_u_20:HideChildren(v66, v_u_11)
				return
			end
		else
			v_u_20:RestoreAll()
		end
	end)
	local v_u_67 = v_u_63
	for _, v68 in { v_u_6.MonsterChasedAttribute } do
		v_u_13:GetAttributeChangedSignal(v68):Connect(function()
			-- upvalues: (ref) v_u_48, (ref) v_u_6, (ref) v_u_13, (ref) v_u_67, (ref) v_u_14, (ref) v_u_42, (ref) v_u_41, (ref) v_u_20, (ref) v_u_11
			v_u_48(v_u_6.IsCarrying(v_u_13))
			local v69 = v_u_67 or v_u_6.IsMonsterChased(v_u_13)
			if v69 and (not v_u_14 and os.clock() - v_u_42 > 2) then
				v_u_41()
			end
			v_u_14 = v69
			if v69 then
				local v70 = v_u_13:FindFirstChildOfClass("PlayerGui")
				if v70 then
					v70 = v70:FindFirstChild("MainGUI")
				end
				if not (v70 and v70:IsA("ScreenGui")) then
					v70 = nil
				end
				if v70 then
					v_u_20:HideChildren(v70, v_u_11)
					return
				end
			else
				v_u_20:RestoreAll()
			end
		end)
	end
	v_u_13:GetAttributeChangedSignal("CarryingJail"):Connect(function()
		-- upvalues: (ref) v_u_13, (ref) v_u_6
		local v71 = v_u_13:FindFirstChildOfClass("PlayerGui")
		if v71 then
			v71 = v71:FindFirstChild("MainGUI")
		end
		if not (v71 and v71:IsA("ScreenGui")) then
			v71 = nil
		end
		local v72 = v_u_6.IsCarrying(v_u_13) or v_u_13:GetAttribute("CarryingJail") == true
		if v71 then
			v71 = v71:FindFirstChild("Drop")
		end
		if v71 and v71:IsA("GuiButton") then
			v71.Visible = v72
		end
	end)
	v_u_9.Observe("ScreenFFX", function()
		-- upvalues: (ref) v_u_16, (ref) v_u_35
		local v73 = v_u_16
		if v73 and v73.Parent then
			v_u_35(v73)
		end
	end)
end
return v10
local v_u_1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("Workspace")
local v_u_5 = require(v_u_2.Shared.EggGemDropConfig)
local v_u_6 = require(script.Parent.Parent.Modules.DiamondShop.Diamonds)
local v_u_7 = require(script.Parent.Parent.Modules.UiSounds)
local v8 = {}
local v_u_9 = v_u_5.Visual
local v_u_10 = v_u_9.Burst
local v_u_11 = v_u_9.Rest
local v_u_12 = v_u_9.Magnet
local v_u_13 = v_u_9.Jelly
local v_u_14 = v_u_9.Trail
local v_u_15 = v_u_9.Gain
local v_u_16 = v_u_9.PieceSize / 2
local v_u_17 = v_u_1.LocalPlayer
local v_u_18 = Random.new()
local v_u_19 = nil
local v_u_20 = {}
local v_u_21 = nil
local v_u_22 = nil
local v_u_23 = 1
local v_u_24 = (-1 / 0)
local v_u_25 = (-1 / 0)
local v_u_26 = RaycastParams.new()
v_u_26.FilterType = Enum.RaycastFilterType.Exclude
v_u_26.RespectCanCollide = true
local function v_u_31() -- name: refreshRayFilter
	-- upvalues: (ref) v_u_19, (copy) v_u_4, (copy) v_u_1, (copy) v_u_26
	local v27 = {}
	local v28
	if v_u_19 and v_u_19.Parent then
		v28 = v_u_19
	else
		v28 = Instance.new("Folder")
		v28.Name = "EggGemDrops"
		v28.Parent = v_u_4
		v_u_19 = v28
	end
	__set_list(v27, 1, {v28})
	for _, v29 in v_u_1:GetPlayers() do
		if not v29.Character then
			continue
		end
		local v30 = v29.Character
		table.insert(v27, v30)
	end
	v_u_26.FilterDescendantsInstances = v27
end
local function v_u_42(p32) -- name: makeGain
	-- upvalues: (copy) v_u_15, (copy) v_u_9, (ref) v_u_19, (copy) v_u_4
	local v33 = Instance.new("BillboardGui")
	v33.Name = "GemGain"
	v33.Adornee = p32
	v33.Size = UDim2.fromScale(4, 1.3)
	local v34 = v_u_15.Offset
	v33.StudsOffset = Vector3.new(0, v34, 0)
	v33.AlwaysOnTop = true
	v33.LightInfluence = 0
	v33.ResetOnSpawn = false
	local v35 = Instance.new("Frame")
	v35.BackgroundTransparency = 1
	v35.Size = UDim2.fromScale(1, 1)
	v35.Parent = v33
	local v36 = Instance.new("UIScale")
	v36.Scale = 0
	v36.Parent = v35
	local v37 = Instance.new("UIListLayout")
	v37.FillDirection = Enum.FillDirection.Horizontal
	v37.HorizontalAlignment = Enum.HorizontalAlignment.Center
	v37.VerticalAlignment = Enum.VerticalAlignment.Center
	v37.Padding = UDim.new(0.02, 0)
	v37.SortOrder = Enum.SortOrder.LayoutOrder
	v37.Parent = v35
	local v38 = Instance.new("ImageLabel")
	v38.BackgroundTransparency = 1
	v38.Size = UDim2.fromScale(0.3, 1)
	v38.SizeConstraint = Enum.SizeConstraint.RelativeYY
	v38.Image = v_u_9.Icon
	v38.ScaleType = Enum.ScaleType.Fit
	v38.LayoutOrder = 1
	v38.Parent = v35
	local v39 = Instance.new("TextLabel")
	v39.BackgroundTransparency = 1
	v39.AutomaticSize = Enum.AutomaticSize.X
	v39.Size = UDim2.fromScale(0, 1)
	v39.Font = Enum.Font.FredokaOne
	v39.TextScaled = true
	v39.Text = ""
	v39.TextColor3 = v_u_15.Color
	v39.LayoutOrder = 2
	v39.Parent = v35
	local v40 = Instance.new("UIStroke")
	v40.Thickness = 2
	v40.Color = v_u_15.StrokeColor
	v40.Parent = v39
	local v41
	if v_u_19 and v_u_19.Parent then
		v41 = v_u_19
	else
		v41 = Instance.new("Folder")
		v41.Name = "EggGemDrops"
		v41.Parent = v_u_4
		v_u_19 = v41
	end
	v33.Parent = v41
	return {
		["Gui"] = nil,
		["Head"] = nil,
		["Label"] = nil,
		["Stroke"] = nil,
		["Icon"] = nil,
		["UIScale"] = nil,
		["Total"] = 0,
		["Shown"] = 0,
		["Punch"] = -1,
		["PunchVelocity"] = 0,
		["Hold"] = nil,
		["Fade"] = 0,
		["Time"] = 0,
		["Gui"] = v33,
		["Head"] = p32,
		["Label"] = v39,
		["Stroke"] = v40,
		["Icon"] = v38,
		["UIScale"] = v36,
		["Hold"] = v_u_15.HoldTime
	}
end
local function v_u_46(p43) -- name: addGain
	-- upvalues: (copy) v_u_17, (ref) v_u_21, (copy) v_u_42, (copy) v_u_15
	local v44 = v_u_17.Character
	if v44 then
		v44 = v44:FindFirstChild("Head") or v44:FindFirstChild("HumanoidRootPart")
	end
	if v44 and v44:IsA("BasePart") then
		if v_u_21 and (v_u_21.Head ~= v44 or not v_u_21.Gui.Parent) and v_u_21 then
			v_u_21.Gui:Destroy()
			v_u_21 = nil
		end
		local v45 = v_u_21 or v_u_42(v44)
		v_u_21 = v45
		v45.Total = v45.Total + p43
		v45.Hold = v_u_15.HoldTime
		v45.Fade = 0
		v45.PunchVelocity = v45.PunchVelocity + v_u_15.Punch
	end
end
local function v_u_72(p47) -- name: stepGain
	-- upvalues: (ref) v_u_21, (copy) v_u_15, (copy) v_u_6
	local v48 = v_u_21
	if v48 then
		if v48.Head.Parent and v48.Gui.Parent then
			v48.Time = v48.Time + p47
			local v49 = v48.Shown
			local v50 = v48.Total - v48.Shown
			local v51 = -v_u_15.CountRate * p47
			v48.Shown = v49 + v50 * (1 - math.exp(v51))
			if v48.Total - v48.Shown < 0.5 then
				v48.Shown = v48.Total
			end
			local v52 = v48.Label
			local v53 = string.format
			local v54 = v_u_15.Format
			local v55 = v_u_6.Format
			local v56 = v48.Shown + 0.5
			v52.Text = v53(v54, v55((math.floor(v56))))
			local v57 = v48.Punch
			local v58 = v48.PunchVelocity
			local v59 = v_u_15.PunchStiffness
			local v60 = v_u_15.PunchDamping * 2 * math.sqrt(v59)
			local v61 = v58 + ((0 - v57) * v59 - v58 * v60) * p47
			v48.Punch = v57 + v61 * p47
			v48.PunchVelocity = v61
			local v62 = v48.UIScale
			local v63 = 1 + v48.Punch * 0.12
			v62.Scale = math.max(v63, 0)
			if v48.Hold > 0 then
				v48.Hold = v48.Hold - p47
			else
				local v64 = v48.Fade + p47 / v_u_15.FadeTime
				v48.Fade = math.min(v64, 1)
			end
			local v65 = v48.Fade
			local v66 = v_u_15.Rise * (1 - (1 - v65) ^ 3)
			local v67 = v48.Time * 3
			local v68 = math.sin(v67) * 0.08
			local v69 = v48.Gui
			local v70 = v_u_15.Offset + v66 + v68
			v69.StudsOffset = Vector3.new(0, v70, 0)
			local v71 = v65 * v65
			v48.Label.TextTransparency = v71
			v48.Stroke.Transparency = v71
			v48.Icon.ImageTransparency = v71
			if v65 >= 1 and v_u_21 then
				v_u_21.Gui:Destroy()
				v_u_21 = nil
			end
		elseif v_u_21 then
			v_u_21.Gui:Destroy()
			v_u_21 = nil
		end
	else
		return
	end
end
local function v_u_86(p73, p74, p75) -- name: makeGem
	-- upvalues: (copy) v_u_9, (copy) v_u_14, (ref) v_u_19, (copy) v_u_4, (copy) v_u_18, (copy) v_u_10
	local v76 = Instance.new("Part")
	v76.Name = "Gem"
	v76.Anchored = true
	v76.CanCollide = false
	v76.CanQuery = false
	v76.CanTouch = false
	v76.CastShadow = false
	v76.Transparency = 1
	v76.Size = Vector3.new(0.2, 0.2, 0.2)
	v76.CFrame = CFrame.new(p73)
	local v77 = v_u_9.PieceSize * v_u_14.Width / 2
	local v78 = Instance.new("Attachment")
	v78.Position = Vector3.new(0, v77, 0)
	v78.Parent = v76
	local v79 = Instance.new("Attachment")
	local v80 = -v77
	v79.Position = Vector3.new(0, v80, 0)
	v79.Parent = v76
	local v81 = Instance.new("Trail")
	v81.Attachment0 = v78
	v81.Attachment1 = v79
	v81.FaceCamera = true
	v81.Lifetime = v_u_14.Lifetime
	v81.LightEmission = v_u_14.LightEmission
	v81.LightInfluence = 0
	v81.Color = ColorSequence.new(v_u_14.Color)
	v81.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.35), NumberSequenceKeypoint.new(1, 1) })
	v81.WidthScale = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1), NumberSequenceKeypoint.new(1, 0) })
	v81.Enabled = false
	v81.Parent = v76
	local v82 = Instance.new("BillboardGui")
	v82.Size = UDim2.fromScale(v_u_9.PieceSize * 1.9, v_u_9.PieceSize * 1.9)
	v82.LightInfluence = 0
	v82.ClipsDescendants = false
	v82.ResetOnSpawn = false
	v82.Parent = v76
	local v83 = Instance.new("ImageLabel")
	v83.BackgroundTransparency = 1
	v83.AnchorPoint = Vector2.new(0.5, 0.5)
	v83.Position = UDim2.fromScale(0.5, 0.5)
	v83.Size = UDim2.fromScale(0, 0)
	v83.Image = v_u_9.Icon
	v83.ScaleType = Enum.ScaleType.Fit
	v83.Parent = v82
	local v84
	if v_u_19 and v_u_19.Parent then
		v84 = v_u_19
	else
		v84 = Instance.new("Folder")
		v84.Name = "EggGemDrops"
		v84.Parent = v_u_4
		v_u_19 = v84
	end
	v76.Parent = v84
	local v85 = v_u_18:NextNumber(0, 360)
	return {
		["Part"] = nil,
		["Icon"] = nil,
		["Trail"] = nil,
		["State"] = "Air",
		["StateTime"] = 0,
		["Age"] = 0,
		["Position"] = nil,
		["Velocity"] = nil,
		["RestPosition"] = nil,
		["PopFrom"] = nil,
		["Drawn"] = nil,
		["Spin"] = nil,
		["SpinSpeed"] = nil,
		["FlightAngle"] = nil,
		["Align"] = 0,
		["Phase"] = nil,
		["HoverBlend"] = 0,
		["Scale"] = nil,
		["ScaleVelocity"] = nil,
		["Share"] = nil,
		["Part"] = v76,
		["Icon"] = v83,
		["Trail"] = v81,
		["Position"] = p73,
		["Velocity"] = p74,
		["RestPosition"] = p73,
		["PopFrom"] = p73,
		["Drawn"] = p73,
		["Spin"] = v85,
		["SpinSpeed"] = v_u_18:NextNumber(v_u_10.SpinSpeed.Min, v_u_10.SpinSpeed.Max) * (v_u_18:NextNumber() < 0.5 and -1 or 1),
		["FlightAngle"] = v85,
		["Phase"] = v_u_18:NextNumber(0, 6.283185307179586),
		["Scale"] = Vector2.new(0.15, 0.15),
		["ScaleVelocity"] = Vector2.zero,
		["Share"] = p75
	}
end
local function v_u_97(p87, p88) -- name: grab
	-- upvalues: (copy) v_u_12, (ref) v_u_25, (copy) v_u_7, (copy) v_u_9, (copy) v_u_18
	p87.Position = p87.Drawn
	local v89 = p87.Position - p88.Position
	local v90 = v89.X
	local v91 = v89.Z
	local v92 = Vector3.new(v90, 0, v91)
	local v93 = v92.Magnitude <= 0.001 and Vector3.new(0, 0, 0) or v92.Unit
	local v94 = v_u_12.HopSpeed
	p87.Velocity = Vector3.new(0, v94, 0) + v93 * v_u_12.KickBack
	p87.ScaleVelocity = p87.ScaleVelocity + Vector2.new(-3, 4)
	p87.State = "Pull"
	p87.StateTime = 0
	p87.Trail.Enabled = true
	local v95 = os.clock()
	if v95 - v_u_25 >= 0.07 then
		v_u_25 = v95
		local v96 = v_u_7.PlayAt(p87.Position, v_u_9.GrabSound, v_u_9.SoundFolder, v_u_18:NextNumber(1.1, 1.35))
		if v96 then
			v96.Volume = v96.Volume * v_u_9.GrabVolume
		end
	end
end
local function v_u_102(p98) -- name: collect
	-- upvalues: (copy) v_u_6, (ref) v_u_24, (copy) v_u_9, (ref) v_u_23, (copy) v_u_7, (copy) v_u_46
	p98.PopFrom = p98.Position
	p98.State = "Pop"
	p98.StateTime = 0
	p98.Trail.Enabled = false
	v_u_6.Add(p98.Share)
	local v99 = os.clock()
	if v99 - v_u_24 > v_u_9.ComboReset then
		v_u_23 = 1
	end
	v_u_24 = v99
	v_u_7.Play(v_u_9.Sound, v_u_9.SoundFolder, v_u_23)
	local v100 = v_u_23 + v_u_9.PitchStep
	local v101 = v_u_9.PitchMax
	v_u_23 = math.min(v100, v101)
	v_u_46(p98.Share)
end
local function v_u_120(p103, p104) -- name: stepAir
	-- upvalues: (copy) v_u_10, (copy) v_u_4, (copy) v_u_16, (copy) v_u_26, (copy) v_u_13
	local v105 = p103.Velocity
	local v106 = v_u_10.Gravity * p104
	p103.Velocity = v105 - Vector3.new(0, v106, 0)
	local v107 = p103.Velocity * p104
	local v108 = v107.Magnitude
	if v108 < 0.00001 then
		return
	else
		local v109 = v_u_4:Raycast(p103.Position, v107 * ((v108 + v_u_16) / v108), v_u_26)
		if v109 then
			local v110 = v109.Normal
			local v111 = -p103.Velocity:Dot(v110)
			if v111 <= 0 then
				p103.Position = p103.Position + v107
				return
			else
				local v112 = v109.Position + v110 * v_u_16
				if v110.Y > 0.6 and v111 < v_u_10.SettleSpeed then
					local v113 = v111 * v_u_13.ImpactSquash
					local v114 = v_u_13.MaxSquash
					local v115 = math.min(v113, v114)
					p103.ScaleVelocity = p103.ScaleVelocity + Vector2.new(v115, -v115)
					p103.Position = v112
					p103.RestPosition = v112
					p103.Velocity = Vector3.new(0, 0, 0)
					p103.HoverBlend = 0
					p103.State = "Rest"
					p103.StateTime = 0
					p103.Trail.Enabled = false
				else
					local v116 = v110 * -v111
					p103.Velocity = (p103.Velocity - v116) * v_u_10.Friction - v116 * v_u_10.Restitution
					p103.Position = v112
					p103.SpinSpeed = p103.SpinSpeed * 0.6
					local v117 = v111 * v_u_13.ImpactSquash
					local v118 = v_u_13.MaxSquash
					local v119 = math.min(v117, v118)
					p103.ScaleVelocity = p103.ScaleVelocity + Vector2.new(v119, -v119)
				end
			end
		else
			p103.Position = p103.Position + v107
			return
		end
	end
end
local function v_u_131(p121, p122, p123) -- name: stepPull
	-- upvalues: (copy) v_u_12
	local v124 = p122.Position + v_u_12.TargetOffset
	local v125 = p122.AssemblyLinearVelocity
	local v126 = 1 + v_u_12.StiffnessRamp * p121.StateTime
	local v127 = v_u_12.Stiffness * v126 * v126
	local v128 = 2 * v_u_12.Damping * math.sqrt(v127)
	local v129 = p121.Velocity - v125
	local v130 = v129 + ((v124 - p121.Position) * v127 - v129 * v128) * p123
	if v130.Magnitude > v_u_12.MaxSpeed then
		v130 = v130.Unit * v_u_12.MaxSpeed
	end
	p121.Velocity = v130 + v125
	p121.Position = p121.Position + p121.Velocity * p123
	return (v124 - p121.Position).Magnitude <= v_u_12.CollectRadius
end
local function v_u_140(p132, p133) -- name: flightAngle
	if not p132 or p133.Velocity.Magnitude < 1 then
		return nil
	end
	local v134 = p132:WorldToViewportPoint(p133.Position)
	local v135 = p132:WorldToViewportPoint(p133.Position + p133.Velocity * 0.03)
	local v136 = v135.X - v134.X
	local v137 = v135.Y - v134.Y
	if v136 * v136 + v137 * v137 < 0.0001 then
		return nil
	end
	local v138 = -v136
	local v139 = math.atan2(v138, v137)
	return math.deg(v139)
end
local function v_u_214(p141, p142, p143, p144) -- name: stepGem
	-- upvalues: (copy) v_u_12, (copy) v_u_97, (copy) v_u_120, (copy) v_u_10, (copy) v_u_11, (copy) v_u_131, (copy) v_u_102, (copy) v_u_13, (copy) v_u_140
	if not p141.Part.Parent then
		return false
	end
	p141.Age = p141.Age + p144
	p141.StateTime = p141.StateTime + p144
	if p142 and (p141.State == "Rest" or p141.State == "Air") and (p141.Age >= v_u_12.GrabDelay and (p142.Position - p141.Position).Magnitude <= v_u_12.Radius) then
		v_u_97(p141, p142)
	end
	local v145 = Vector2.one
	local v146 = 0
	local v147 = 0
	local v148 = p141.Position
	if p141.State == "Air" then
		local v149 = p144 / 0.004166666666666667
		local v150 = math.ceil(v149)
		local v151 = math.max(1, v150)
		local v152 = p144 / v151
		for _ = 1, v151 do
			v_u_120(p141, v152)
			if p141.State == "Air" then
				continue
			end
		end
		if p141.State == "Air" and p141.StateTime > v_u_10.MaxAirTime then
			local v153 = p141.Position
			p141.Position = v153
			p141.RestPosition = v153
			p141.Velocity = Vector3.new(0, 0, 0)
			p141.HoverBlend = 0
			p141.State = "Rest"
			p141.StateTime = 0
			p141.Trail.Enabled = false
		end
		p141.Spin = p141.Spin + p141.SpinSpeed * p144
		v148 = p141.Position
	elseif p141.State == "Rest" then
		local v154 = p141.HoverBlend
		local v155 = 1 - p141.HoverBlend
		local v156 = p144 * -3
		p141.HoverBlend = v154 + v155 * (1 - math.exp(v156))
		local v157 = p141.Age * v_u_11.HoverSpeed + p141.Phase
		local v158 = math.sin(v157)
		local v159 = v_u_11.Hover * p141.HoverBlend * (v158 + 1)
		p141.Position = p141.RestPosition
		v148 = p141.RestPosition + Vector3.new(0, v159, 0)
		local v160 = p141.Age * 1.7 + p141.Phase
		local v161 = math.sin(v160) * v_u_11.Wobble
		local v162 = p141.Spin
		local v163 = p144 * -5
		local v164 = 1 - math.exp(v163)
		p141.Spin = v162 + ((v161 - v162 + 180) % 360 - 180) * v164
		local v165 = p141.Age * v_u_11.HoverSpeed * 1.3 + p141.Phase
		local v166 = 1 + math.sin(v165) * v_u_11.Breathe
		v145 = Vector2.new(v166, v166)
		local v167 = v_u_11.Lifetime - p141.Age
		if v167 <= 0 then
			p141.State = "Fade"
			p141.StateTime = 0
			p141.Trail.Enabled = false
		elseif v167 < v_u_11.BlinkTime then
			local v168 = 4 + (1 - v167 / v_u_11.BlinkTime) * 10
			local v169 = p141.Age * v168 * 3.141592653589793
			if math.sin(v169) > 0 then
				v147 = 0
			else
				v147 = 0.6
			end
		end
	elseif p141.State == "Pull" then
		if p142 and (p142.Position - p141.Position).Magnitude <= v_u_12.ReleaseRadius then
			local v170 = p144 / 0.004166666666666667
			local v171 = math.ceil(v170)
			local v172 = math.max(1, v171)
			local v173 = p144 / v172
			local v174 = false
			for _ = 1, v172 do
				if not v_u_131(p141, p142, v173) then
					continue
				end
				v174 = true
			end
			if v174 or p141.StateTime >= v_u_12.MaxPullTime then
				v_u_102(p141)
			else
				local v175 = (p141.Velocity - p142.AssemblyLinearVelocity).Magnitude * v_u_12.StretchPerSpeed
				local v176 = v_u_12.MaxStretch
				local v177 = math.min(v175, v176) + 1
				local v178 = (p142.Position + v_u_12.TargetOffset - p141.Position).Magnitude / v_u_12.ShrinkDistance
				local v179 = math.clamp(v178, 0.45, 1)
				v145 = Vector2.new(v179 / math.sqrt(v177), v179 * v177)
				p141.Spin = p141.Spin + p141.SpinSpeed * 0.5 * p144
				v146 = 1
			end
		else
			p141.State = "Air"
			p141.StateTime = 0
			p141.Trail.Enabled = false
		end
		v148 = p141.Position
	end
	if p141.State == "Pop" then
		local v180 = p141.StateTime / 0.14
		local v181 = math.clamp(v180, 0, 1)
		local v182
		if p142 then
			v182 = p142.Position + v_u_12.TargetOffset
		else
			v182 = p141.PopFrom
		end
		p141.Position = p141.PopFrom:Lerp(v182, v181)
		v148 = p141.Position
		local v183 = 1 - v181
		local v184 = v181 * 3.141592653589793
		local v185 = v183 * (math.sin(v184) * 0.4 + 1)
		p141.Scale = Vector2.new(v185, v185)
		p141.ScaleVelocity = Vector2.zero
		v147 = v181 * v181
		if v181 >= 1 then
			p141.Part:Destroy()
			return false
		end
		v146 = 0
	elseif p141.State == "Fade" then
		local v186 = p141.StateTime / v_u_11.FadeTime
		v147 = math.clamp(v186, 0, 1)
		local v187 = p141.RestPosition
		local v188 = v_u_11.Hover * 2 * v147
		v148 = v187 + Vector3.new(0, v188, 0)
		v145 = Vector2.new(1 - v147, 1 - v147)
		if v147 >= 1 then
			p141.Part:Destroy()
			return false
		end
	end
	if p141.State ~= "Pop" then
		local v189 = p144 / 0.004166666666666667
		local v190 = math.ceil(v189)
		local v191 = math.max(1, v190)
		local v192 = p144 / v191
		for _ = 1, v191 do
			local v193 = p141.Scale
			local v194 = p141.ScaleVelocity
			local v195 = v_u_13.Stiffness
			local v196 = v_u_13.Damping * 2 * math.sqrt(v195)
			local v197 = v194 + ((v145 - v193) * v195 - v194 * v196) * v192
			p141.Scale = v193 + v197 * v192
			p141.ScaleVelocity = v197
		end
	end
	local v198 = v_u_140(p143, p141)
	if v198 then
		local v199 = p141.FlightAngle
		local v200 = p144 * -18
		local v201 = 1 - math.exp(v200)
		p141.FlightAngle = v199 + ((v198 - v199 + 180) % 360 - 180) * v201
	end
	local v202 = p141.Align
	local v203 = v146 - p141.Align
	local v204 = p144 * -10
	p141.Align = v202 + v203 * (1 - math.exp(v204))
	p141.Spin = p141.Spin % 360
	local v205 = Vector2.new
	local v206 = p141.Scale.X
	local v207 = math.max(v206, 0)
	local v208 = p141.Scale.Y
	local v209 = v205(v207, (math.max(v208, 0)))
	p141.Icon.Size = UDim2.fromScale(v209.X * 0.5263157894736842, v209.Y * 0.5263157894736842)
	local v210 = p141.Icon
	local v211 = p141.Spin
	local v212 = p141.FlightAngle
	local v213 = p141.Align
	v210.Rotation = v211 + ((v212 - v211 + 180) % 360 - 180) * v213
	p141.Icon.ImageTransparency = v147
	p141.Drawn = v148
	p141.Part.CFrame = CFrame.new(v148)
	return true
end
local function v_u_220(p215) -- name: step
	-- upvalues: (copy) v_u_17, (copy) v_u_4, (copy) v_u_20, (copy) v_u_214, (copy) v_u_72, (ref) v_u_21, (ref) v_u_22
	local v216 = math.min(p215, 0.1)
	local v217 = v_u_17.Character
	if v217 then
		v217 = v217:FindFirstChild("HumanoidRootPart")
	end
	if not (v217 and v217:IsA("BasePart")) then
		v217 = nil
	end
	local v218 = v_u_4.CurrentCamera
	for v219 = #v_u_20, 1, -1 do
		if v_u_214(v_u_20[v219], v217, v218, v216) then
			continue
		end
		table.remove(v_u_20, v219)
	end
	v_u_72(v216)
	if #v_u_20 == 0 and (not v_u_21 and v_u_22) then
		v_u_22:Disconnect()
		v_u_22 = nil
	end
end
local function v_u_223() -- name: enforceCap
	-- upvalues: (copy) v_u_20, (copy) v_u_9
	local v221 = #v_u_20 - v_u_9.MaxActive
	if v221 <= 0 then
		return
	end
	for _, v222 in v_u_20 do
		if v221 <= 0 then
			break
		end
		if v222.State ~= "Rest" then
			continue
		end
		v222.State = "Fade"
		v222.StateTime = 0
		v222.Trail.Enabled = false
		v221 = v221 - 1
	end
end
local function v_u_242(p224, p225) -- name: playDrop
	-- upvalues: (copy) v_u_17, (copy) v_u_9, (copy) v_u_6, (copy) v_u_31, (copy) v_u_18, (copy) v_u_10, (copy) v_u_20, (copy) v_u_86, (copy) v_u_223, (ref) v_u_22, (copy) v_u_3, (copy) v_u_220
	local v226 = v_u_17.Character
	if v226 then
		v226 = v226:FindFirstChild("HumanoidRootPart")
	end
	if not (v226 and v226:IsA("BasePart")) then
		v226 = nil
	end
	if v226 and (v226.Position - p224).Magnitude <= v_u_9.MaxShowDistance then
		v_u_31()
		local v227 = v_u_9.MaxPieces
		local v228 = math.clamp(p225, 1, v227)
		local v229 = p225 / v228
		local v230 = math.floor(v229)
		local v231 = v_u_18:NextNumber(0, 6.283185307179586)
		for v232 = 1, v228 do
			local v233 = v231 + (v232 / v228 + v_u_18:NextNumber(-0.18, 0.18) / v228) * 3.141592653589793 * 2
			local v234 = v_u_18:NextNumber(v_u_10.OutSpeed.Min, v_u_10.OutSpeed.Max)
			local v235 = v_u_18:NextNumber(v_u_10.UpSpeed.Min, v_u_10.UpSpeed.Max)
			local v236 = math.cos(v233) * v234
			local v237 = math.sin(v233) * v234
			local v238 = Vector3.new(v236, v235, v237)
			local v239
			if v232 == v228 then
				v239 = p225 - v230 * (v228 - 1)
			else
				v239 = v230
			end
			local v240 = v_u_20
			local v241 = v_u_86(p224, v238, v239)
			table.insert(v240, v241)
		end
		v_u_223()
		if not v_u_22 then
			v_u_22 = v_u_3.Heartbeat:Connect(v_u_220)
		end
	else
		v_u_6.Add(p225)
	end
end
function v8.Start() -- name: Start
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_242
	local v243 = v_u_2:WaitForChild(v_u_5.RemoteName, 60)
	if v243 and v243:IsA("RemoteEvent") then
		v243.OnClientEvent:Connect(function(p244, p245)
			-- upvalues: (ref) v_u_242
			if typeof(p244) == "Vector3" and (type(p245) == "number" and p245 >= 1) then
				v_u_242(p244, (math.floor(p245)))
			end
		end)
	else
		warn((("[EggGemDropController] ReplicatedStorage.%* not found \226\128\148 egg gem drops disabled"):format(v_u_5.RemoteName)))
	end
end
return v8
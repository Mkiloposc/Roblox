local v1 = game:GetService("CoreGui")
local v2 = game:GetService("CorePackages")
local v_u_3 = game:GetService("Players")
local v_u_4 = game:GetService("RunService")
local v5 = v1:WaitForChild("RobloxGui")
local v_u_6 = game:GetService("StarterGui")
local v_u_7 = game:GetService("VRService")
local v_u_8 = require(script.Parent.Parent.Logger)(script.Name)
local v_u_9 = require(v2.Packages.Roact)
local v10 = require(v2.Packages.RoactRodux)
local v11 = require(v2.Packages.t)
local v_u_12 = require(v2.Packages.Otter)
local v_u_13 = require(script.Parent.BubbleChatList)
local v_u_14 = require(script.Parent.ChatBubbleDistant)
local v_u_15 = require(script.Parent.VoiceBubble)
local v_u_16 = require(v5.Modules.VoiceChat.Components.VoiceIndicator)
local v17 = require(script.Parent.Parent.Types)
local v_u_18 = require(script.Parent.Parent.Constants)
local v_u_19 = require(script.Parent.Parent.Helpers.getSettingsForMessage)
local v_u_20 = require(v5.Modules.SelfView.selfViewVisibilityUpdatedSignal)
local v_u_21 = require(v2.Workspace.Packages.Chrome).Enabled
local v_u_22 = require(v5.Modules.VoiceChat.Constants)
local v_u_23 = require(v5.Modules.VoiceChat.VoiceChatServiceManager).default
local v_u_24 = require(v5.Modules.Flags.GetFFlagMicConnectingToast)
local v_u_25 = require(v5.Modules.Flags.GetFFlagBubbleChatInexistantAdorneeFix)
local v_u_26 = require(v5.Modules.SelfView.publicApi)
local v_u_27 = game:DefineFastInt("BubbleVoiceTimeoutMillis", 1000)
local v_u_28 = game:DefineFastFlag("DebugAllowControlButtonsNoVoiceChat", false)
local v_u_29 = require(v2.Workspace.Packages.IxpServiceWrapper).IXPServiceWrapper
local v_u_30 = game:DefineFastFlag("EasierUnmuting3", false)
local v_u_31 = game:DefineFastFlag("EasierUnmutingBasedOnCamera", false)
local v_u_32 = game:DefineFastFlag("EasierUnmutingHideIfMuted", false)
local v_u_33 = game:DefineFastInt("EasierUnmutingDisplayDistance", 20)
local v_u_34 = game:DefineFastString("EasierUnmutingIXPLayerName", "Voice.UserAgency")
local v_u_35 = game:DefineFastString("EasierUnmutingIXPLayerValue", "VoiceUserAgencyEnabled")
local v36 = v_u_9.PureComponent:extend("BubbleChatBillboard")
local v_u_37 = {
	["dampingRatio"] = 1,
	["frequency"] = 4
}
v36.validateProps = v11.strictInterface({
	["userId"] = v11.string,
	["onFadeOut"] = v11.optional(v11.callback),
	["voiceEnabled"] = v11.optional(v11.boolean),
	["bubbleChatEnabled"] = v11.optional(v11.boolean),
	["chatSettings"] = v17.IChatSettings,
	["messageIds"] = v11.optional(v11.array(v11.string)),
	["lastMessage"] = v11.optional(v17.IMessage),
	["voiceState"] = v11.optional(v11.string)
})
function getEasierUnmutingDistance(p38) -- name: getEasierUnmutingDistance
	-- upvalues: (copy) v_u_3, (copy) v_u_31
	if p38 then
		local v39 = v_u_3.LocalPlayer and v_u_3.LocalPlayer.Character
		if v39 then
			v39 = v_u_3.LocalPlayer.Character:FindFirstChild("HumanoidRootPart")
		end
		local v40 = v39 and v39.CFrame
		if v40 then
			v40 = v39.CFrame.Position
		end
		local v41 = workspace.CurrentCamera
		if v41 then
			v41 = workspace.CurrentCamera.CFrame.Position
		end
		if v_u_31 or not v40 then
			if v41 then
				return (p38 - v41).Magnitude
			else
				return nil
			end
		else
			return (p38 - v40).Magnitude
		end
	else
		return nil
	end
end
function v36.init(p_u_42) -- name: init
	-- upvalues: (copy) v_u_26, (copy) v_u_6, (copy) v_u_30, (copy) v_u_32, (copy) v_u_9, (copy) v_u_12, (copy) v_u_3, (copy) v_u_18, (copy) v_u_23, (copy) v_u_24, (copy) v_u_22, (copy) v_u_16, (copy) v_u_20, (copy) v_u_29, (copy) v_u_34, (copy) v_u_35
	local v43 = v_u_26.getSelfViewIsOpenAndVisible()
	local v44 = v_u_6:GetCoreGuiEnabled(Enum.CoreGuiType.SelfView)
	local v45 = {
		["adornee"] = nil,
		["isInsideRenderDistance"] = false,
		["isInsideMaximizeDistance"] = false,
		["savedChatSettings"] = nil,
		["voiceTimedOut"] = false,
		["voiceStateCounter"] = 0,
		["lastVoiceState"] = nil,
		["selfViewOpen"] = nil,
		["selfViewEnabled"] = nil,
		["isInsideEasierUnmutingDistance"] = nil,
		["isMuted"] = nil,
		["isInEasierUnmutingTreatment"] = nil,
		["haveLoggedUserExposure"] = nil,
		["savedChatSettings"] = p_u_42.props.chatSettings,
		["selfViewOpen"] = v43,
		["selfViewEnabled"] = v44
	}
	local v46
	if v_u_30 then
		v46 = false
	else
		v46 = nil
	end
	v45.isInsideEasierUnmutingDistance = v46
	local v47
	if v_u_30 and v_u_32 then
		v47 = false
	else
		v47 = nil
	end
	v45.isMuted = v47
	local v48
	if v_u_30 then
		v48 = false
	else
		v48 = nil
	end
	v45.isInEasierUnmutingTreatment = v48
	local v49
	if v_u_30 then
		v49 = false
	else
		v49 = nil
	end
	v45.haveLoggedUserExposure = v49
	p_u_42:setState(v45)
	p_u_42.isMounted = false
	local v50, v51 = v_u_9.createBinding((Vector3.new()))
	p_u_42.offset = v50
	p_u_42.updateOffset = v51
	p_u_42.offsetMotor = v_u_12.createSingleMotor(0)
	p_u_42.offsetMotor:onStep(function(p52)
		-- upvalues: (copy) p_u_42
		p_u_42.updateOffset((Vector3.new(0, p52, 0)))
	end)
	p_u_42.offsetGoal = 0
	function p_u_42.onSelfViewVisibilityUpdated()
		-- upvalues: (copy) p_u_42, (ref) v_u_26
		p_u_42:setState({
			["selfViewOpen"] = v_u_26.getSelfViewIsOpenAndVisible()
		})
	end
	function p_u_42.onLastBubbleFadeOut()
		-- upvalues: (copy) p_u_42
		if p_u_42.props.onFadeOut and not p_u_42.isFadingOut then
			p_u_42.isFadingOut = true
			p_u_42.props.onFadeOut(p_u_42.props.userId)
		end
		if p_u_42.state.hasMessage and p_u_42.isMounted then
			p_u_42:setState({
				["hasMessage"] = false
			})
		end
	end
	if p_u_42.props.voiceEnabled then
		local v53 = p_u_42.props.userId
		local v54 = v_u_3.LocalPlayer.UserId
		local v_u_55
		if v53 == tostring(v54) then
			v_u_55 = function()
				-- upvalues: (copy) p_u_42, (ref) v_u_18, (ref) v_u_23, (ref) v_u_24
				if p_u_42.props.voiceState == v_u_18.VOICE_STATE.ERROR then
					v_u_23:RejoinPreviousChannel()
					return
				elseif v_u_24() and p_u_42.props.voiceState == v_u_18.VOICE_STATE.CONNECTING then
					v_u_23:ShowVoiceChatLoadingMessage()
				else
					v_u_23:ToggleMic("LegacyBubbleChat")
				end
			end
		else
			v_u_55 = function()
				-- upvalues: (ref) v_u_23, (copy) p_u_42, (ref) v_u_22
				local v56 = v_u_23
				local v57 = p_u_42.props.userId
				local v58 = tonumber(v57)
				local v59
				if p_u_42:isShowingDueToEasierUnmuting() then
					v59 = v_u_22.VOICE_CONTEXT_TYPE.EASIER_UNMUTING
				else
					v59 = v_u_22.VOICE_CONTEXT_TYPE.BUBBLE_CHAT
				end
				v56:ToggleMutePlayer(v58, v59)
			end
		end
		local v_u_60 = p_u_42.props.userId
		local v61 = v_u_3.LocalPlayer.UserId
		local v_u_62 = v_u_60 == tostring(v61) and "MicDark" or "SpeakerDark"
		function p_u_42.renderInsert()
			-- upvalues: (ref) v_u_9, (ref) v_u_16, (ref) v_u_55, (copy) v_u_60, (copy) v_u_62
			local v63 = {
				["onClicked"] = v_u_55,
				["userId"] = v_u_60,
				["iconStyle"] = v_u_62
			}
			return v_u_9.createElement(v_u_16, v63)
		end
		p_u_42.insertSize = Vector2.new(28, 28)
	end
	function p_u_42.onCoreGuiChanged()
		-- upvalues: (ref) v_u_6, (copy) p_u_42
		local v64 = v_u_6:GetCoreGuiEnabled(Enum.CoreGuiType.SelfView)
		if p_u_42.state.selfViewOpen ~= v64 then
			p_u_42:setState({
				["selfViewOpen"] = v64
			})
		end
	end
	p_u_42.selfViewVisibilityUpdatedSignal = v_u_20:connect(function()
		-- upvalues: (copy) p_u_42, (ref) v_u_26
		p_u_42:setState({
			["selfViewOpen"] = v_u_26.getSelfViewIsOpenAndVisible()
		})
	end)
	if v_u_30 then
		local v65, v66 = pcall(function()
			-- upvalues: (ref) v_u_29, (ref) v_u_34
			return v_u_29:GetLayerData(v_u_34)
		end)
		if v65 and (v66 and v66[v_u_35]) then
			p_u_42:setState({
				["isInEasierUnmutingTreatment"] = true
			})
		end
	end
	if v_u_30 and (p_u_42.state.isInEasierUnmutingTreatment and v_u_32) then
		p_u_42.participantsUpdateConnection = v_u_23.participantsUpdate.Event:Connect(function(p67)
			-- upvalues: (copy) p_u_42
			local v68 = p67[p_u_42.props.userId]
			if v68 then
				if v68.isMuted ~= p_u_42.state.isMuted then
					p_u_42:setState({
						["isMuted"] = v68.isMuted
					})
				end
			end
		end)
	end
end
function v36.isShowingDueToEasierUnmuting(p69) -- name: isShowingDueToEasierUnmuting
	-- upvalues: (copy) v_u_30, (copy) v_u_18, (copy) v_u_32
	local v70 = v_u_30 and (p69.state.isInEasierUnmutingTreatment and (p69.props.voiceState == v_u_18.VOICE_STATE.LOCAL_MUTED and p69.state.isInsideEasierUnmutingDistance))
	if v70 then
		local v71 = v_u_32
		if v71 then
			v71 = p69.state.isMuted
		end
		v70 = not v71
	end
	return v70
end
function v36.checkCounterForTimeout(p_u_72, p73) -- name: checkCounterForTimeout
	-- upvalues: (copy) v_u_3, (copy) v_u_18, (copy) v_u_27
	local v74 = p_u_72.props.userId
	local v75 = v_u_3.LocalPlayer.UserId
	if v74 ~= tostring(v75) and (p_u_72.state.lastVoiceState ~= v_u_18.VOICE_STATE.TALKING and p_u_72.state.voiceStateCounter ~= p73) then
		local v_u_76 = p_u_72.state.voiceStateCounter
		delay(v_u_27 / 1000, function()
			-- upvalues: (copy) p_u_72, (copy) v_u_76
			if p_u_72.state.voiceStateCounter == v_u_76 and p_u_72.isMounted then
				p_u_72:setState({
					["voiceTimedOut"] = true
				})
			end
		end)
	end
end
function v36.checkCounterForTimeoutWithEasierUnmuting(p_u_77, p78) -- name: checkCounterForTimeoutWithEasierUnmuting
	-- upvalues: (copy) v_u_30, (copy) v_u_3, (copy) v_u_18, (copy) v_u_27
	local v79
	if p78 then
		v79 = p78.voiceStateCounter
	else
		v79 = nil
	end
	if not (v_u_30 and p_u_77.state.isInEasierUnmutingTreatment) then
		return p_u_77:checkCounterForTimeout(v79)
	end
	local v80 = p_u_77.props.userId
	local v81 = v_u_3.LocalPlayer.UserId
	local v82 = v80 ~= tostring(v81)
	local v83 = p_u_77.state.voiceStateCounter ~= v79
	local v84
	if p_u_77.state.lastVoiceState == v_u_18.VOICE_STATE.TALKING then
		v84 = false
	else
		v84 = p_u_77.state.lastVoiceState ~= v_u_18.VOICE_STATE.LOCAL_MUTED
	end
	if v82 and (v83 and v84) then
		local v_u_85 = p_u_77.state.voiceStateCounter
		delay(v_u_27 / 1000, function()
			-- upvalues: (copy) p_u_77, (copy) v_u_85
			if p_u_77.state.voiceStateCounter == v_u_85 and p_u_77.isMounted then
				p_u_77:setState({
					["voiceTimedOut"] = true
				})
			end
		end)
	end
end
function v36.didMount(p_u_86) -- name: didMount
	-- upvalues: (copy) v_u_12, (copy) v_u_3, (copy) v_u_4, (copy) v_u_30, (copy) v_u_33, (copy) v_u_18, (copy) v_u_37
	p_u_86.isMounted = true
	local v87 = p_u_86.props.lastMessage
	if v87 then
		v87 = p_u_86.props.lastMessage.adornee
	end
	p_u_86:setState({
		["adornee"] = v87
	})
	local v88 = p_u_86:getVerticalOffset(v87)
	p_u_86.offsetGoal = v88
	p_u_86.offsetMotor:setGoal(v_u_12.instant(v88))
	local v_u_89 = nil
	if v87 then
		v_u_89 = v_u_3:GetPlayerFromCharacter(v87)
	else
		local v90 = p_u_86.props.userId
		if tonumber(v90) then
			v_u_89 = v_u_3:GetPlayerByUserId(p_u_86.props.userId)
		end
	end
	if v_u_89 then
		if v_u_89.Character then
			coroutine.wrap(function()
				-- upvalues: (copy) p_u_86, (ref) v_u_89
				p_u_86:onCharacterAdded(v_u_89, v_u_89.Character)
			end)()
		end
		p_u_86.characterConn = v_u_89.CharacterAdded:Connect(function(p91)
			-- upvalues: (copy) p_u_86, (ref) v_u_89
			p_u_86:onCharacterAdded(v_u_89, p91)
		end)
	end
	p_u_86.heartbeatConn = v_u_4.Heartbeat:Connect(function()
		-- upvalues: (copy) p_u_86, (ref) v_u_30, (ref) v_u_33, (ref) v_u_18, (ref) v_u_12, (ref) v_u_37
		local v92 = p_u_86:getAdorneeInstance(p_u_86.state.adornee)
		if workspace.CurrentCamera and v92 then
			local v93 = v92:IsA("Attachment") and v92.WorldPosition or v92.Position
			local v94 = (workspace.CurrentCamera.CFrame.Position - v93).Magnitude
			local v95 = v94 < p_u_86.state.savedChatSettings.MaxDistance
			local v96 = v94 < p_u_86.state.savedChatSettings.MinimizeDistance
			local v97 = false
			if v_u_30 and p_u_86.state.isInEasierUnmutingTreatment then
				local v98 = getEasierUnmutingDistance(v93)
				if v98 ~= nil then
					v97 = v98 < v_u_33
				end
			end
			if v96 ~= p_u_86.state.isInsideMaximizeDistance or (v95 ~= p_u_86.state.isInsideRenderDistance or v_u_30 and (p_u_86.state.isInEasierUnmutingTreatment and v97 ~= p_u_86.state.isInsideEasierUnmutingDistance)) then
				p_u_86:setState({
					["isInsideRenderDistance"] = v95,
					["isInsideMaximizeDistance"] = v96,
					["isInsideEasierUnmutingDistance"] = v97
				})
			end
		end
		local v99 = p_u_86:getVerticalOffset(p_u_86.state.adornee)
		local v100 = v99 - p_u_86.offsetGoal
		if math.abs(v100) > v_u_18.BILLBOARD_OFFSET_EPSILON then
			p_u_86.offsetGoal = v99
			p_u_86.offsetMotor:setGoal(v_u_12.spring(v99, v_u_37))
		end
	end)
	if v_u_30 and p_u_86.state.isInEasierUnmutingTreatment then
		p_u_86:checkCounterForTimeoutWithEasierUnmuting(nil)
	else
		p_u_86:checkCounterForTimeout(nil)
	end
end
function v36.willUnmount(p101) -- name: willUnmount
	-- upvalues: (copy) v_u_8, (copy) v_u_30, (copy) v_u_32
	v_u_8:trace("Unmounting billboards for {}", p101.state.shortId)
	p101.isMounted = false
	if p101.characterConn then
		p101.characterConn:Disconnect()
		p101.characterConn = nil
	end
	if p101.heartbeatConn then
		p101.heartbeatConn:Disconnect()
		p101.heartbeatConn = nil
	end
	if p101.humanoidDiedConn then
		p101.humanoidDiedConn:Disconnect()
		p101.humanoidDiedConn = nil
	end
	p101.offsetMotor:destroy()
	if p101.selfViewVisibilityUpdatedSignal then
		p101.selfViewVisibilityUpdatedSignal:disconnect()
		p101.selfViewVisibilityUpdatedSignal = nil
	end
	if v_u_30 and (p101.state.isInEasierUnmutingTreatment and (v_u_32 and p101.participantsUpdateConnection)) then
		p101.participantsUpdateConnection:Disconnect()
		p101.participantsUpdateConnection = nil
	end
end
local function v_u_107(...) -- name: waitForFirst
	local v_u_102 = Instance.new("BindableEvent")
	local v_u_103 = { ... }
	local function v105(...) -- name: fire
		-- upvalues: (copy) v_u_103, (copy) v_u_102
		for v104 = 1, #v_u_103 do
			v_u_103[v104]:Disconnect()
		end
		return v_u_102:Fire(...)
	end
	for v106 = 1, #v_u_103 do
		v_u_103[v106] = v_u_103[v106]:Connect(v105)
	end
	return v_u_102.Event:Wait()
end
local function v_u_112(p108, p109, p110) -- name: findFirstChildByNameAndClass
	for _, v111 in ipairs(p108:GetChildren()) do
		if v111.Name ~= p109 or not v111:IsA(p110) then
			continue
		end
		return v111
	end
end
function v36.onCharacterAdded(p_u_113, p114, p_u_115) -- name: onCharacterAdded
	-- upvalues: (copy) v_u_107, (copy) v_u_8, (copy) v_u_25, (copy) v_u_112
	if not p_u_115.Parent then
		v_u_107(p_u_115.AncestryChanged, p114.CharacterAdded)
	end
	if p114.Character == p_u_115 and p_u_115.Parent then
		local v116 = p_u_115:FindFirstChildOfClass("Humanoid")
		while p_u_115:IsDescendantOf(game) and not v116 do
			v_u_107(p_u_115.ChildAdded, p_u_115.AncestryChanged, p114.CharacterAdded)
			v116 = p_u_115:FindFirstChildOfClass("Humanoid")
		end
		if p114.Character == p_u_115 and p_u_115:IsDescendantOf(game) then
			local v117
			if v_u_25() then
				v117 = p_u_115.PrimaryPart
			else
				v117 = p_u_115:FindFirstChild("HumanoidRootPart")
			end
			while p_u_115:IsDescendantOf(game) and not v117 do
				v_u_107(p_u_115.ChildAdded, p_u_115.AncestryChanged, p114.CharacterAdded)
				if v_u_25() then
					v117 = p_u_115.PrimaryPart
				else
					v117 = p_u_115:FindFirstChild("HumanoidRootPart")
				end
			end
			if v117 and (p_u_115:IsDescendantOf(game) and (p114.Character == p_u_115 and p_u_113.isMounted)) then
				local v118 = v_u_112(p_u_115, "Head", "BasePart")
				p_u_113:setState({
					["adornee"] = v116.Health == 0 and v118 and v118 or p_u_115
				})
				if p_u_113.humanoidDiedConn then
					p_u_113.humanoidDiedConn:Disconnect()
					p_u_113.humanoidDiedConn = nil
				end
				p_u_113.humanoidDiedConn = v116.Died:Connect(function()
					-- upvalues: (copy) p_u_113, (ref) v_u_112, (copy) p_u_115
					p_u_113:setState({
						["adornee"] = v_u_112(p_u_115, "Head", "BasePart") or p_u_115
					})
				end)
			end
		else
			v_u_8:debug("Mismatched or unparented character in onCharacterAdded for {}", p_u_113.state.shortId)
		end
	else
		v_u_8:debug("Mismatched or unparented character in onCharacterAdded for {}", p_u_113.state.shortId)
		return
	end
end
function v36.getVerticalOffset(p119, p120) -- name: getVerticalOffset
	if not (p120 and p120:IsA("Model")) then
		return not (p120 and p120:IsA("BasePart")) and 0 or p120.Size.Y / 2
	end
	local v121, v122 = p120:GetBoundingBox()
	local v123 = p119:getAdorneeInstance(p120)
	if not v123 then
		return v122.Y / 2
	end
	if not v123:IsA("BasePart") then
		return 0
	end
	local v124 = v121:PointToObjectSpace(v123.Position)
	return v122.Y / 2 - v124.Y
end
function v36.getAdorneeInstance(p125, p126) -- name: getAdorneeInstance
	-- upvalues: (copy) v_u_25
	if p126 then
		if p126:IsA("Model") then
			local v127 = p126:FindFirstChild(p125.state.savedChatSettings.AdorneeName, true)
			if v_u_25() then
				v127 = v127 or p126.PrimaryPart
			end
			if not v127 or (v127:IsA("BasePart") or v127:IsA("Attachment")) then
				return v127
			end
		elseif p126:IsA("BasePart") or p126:IsA("Attachment") then
			return p126
		end
	end
end
function v36.getRenderVoiceAndCameraBubble(p128) -- name: getRenderVoiceAndCameraBubble
	-- upvalues: (copy) v_u_28, (copy) v_u_3, (copy) v_u_7, (copy) v_u_21
	if p128.props.voiceEnabled or v_u_28 then
		local v129 = p128.props.userId
		local v130 = v_u_3.LocalPlayer.UserId
		if v129 == tostring(v130) then
			if v_u_7.VREnabled or v_u_21() then
				return false
			else
				return not p128.state.selfViewOpen
			end
		else
			local v131 = p128.props.voiceEnabled
			if v131 then
				v131 = not p128.state.voiceTimedOut
			end
			return v131
		end
	else
		return false
	end
end
function v36.shouldRenderCarat(p132) -- name: shouldRenderCarat
	local v133 = p132.props.chatSettings.TailVisible
	if v133 then
		v133 = not p132:getRenderVoiceAndCameraBubble()
	end
	return v133
end
function v36.render(p134) -- name: render
	-- upvalues: (copy) v_u_3, (copy) v_u_8, (copy) v_u_30, (copy) v_u_18, (copy) v_u_32, (copy) v_u_7, (copy) v_u_21, (copy) v_u_9, (copy) v_u_15, (copy) v_u_13, (copy) v_u_14
	local v135 = p134:getAdorneeInstance(p134.state.adornee)
	local v136 = p134.props.userId
	local v137 = v_u_3.LocalPlayer.UserId
	local v138 = v136 == tostring(v137)
	local v139 = p134.state.savedChatSettings
	if v135 then
		if p134.state.isInsideRenderDistance then
			if not v_u_30 or (not p134.state.isInEasierUnmutingTreatment or (p134.props.voiceState ~= v_u_18.VOICE_STATE.LOCAL_MUTED or p134.state.isInsideEasierUnmutingDistance and not (v_u_32 and p134.state.isMuted))) then
				local v140 = {}
				local v141 = p134.props.voiceEnabled
				if v141 then
					v141 = not p134.state.voiceTimedOut
				end
				if v_u_7.VREnabled or v_u_21() then
					if v138 then
						v141 = false
					end
				end
				if v141 and (not p134.props.bubbleChatEnabled or (not p134.props.messageIds or #p134.props.messageIds == 0)) then
					v140.VoiceBubble = v_u_9.createElement(v_u_15, {
						["chatSettings"] = v139,
						["renderInsert"] = p134.renderInsert,
						["insertSize"] = p134.insertSize,
						["isDistant"] = not p134.state.isInsideMaximizeDistance
					})
				end
				if p134.state.hasMessage then
					if p134.state.isInsideMaximizeDistance then
						local v142 = v_u_9.createElement
						local v143 = v_u_13
						local v144 = {
							["userId"] = p134.props.userId,
							["isVisible"] = p134.state.isInsideMaximizeDistance,
							["onLastBubbleFadeOut"] = p134.onLastBubbleFadeOut,
							["chatSettings"] = v139
						}
						local v145
						if v141 then
							v145 = p134.renderInsert
						else
							v145 = nil
						end
						v144.renderFirstInsert = v145
						v144.insertSize = p134.insertSize
						v144.showCarat = p134:shouldRenderCarat()
						v140.BubbleChatList = v142(v143, v144)
					else
						local v146 = v_u_9.createElement
						local v147 = v_u_14
						local v148 = {
							["fadingOut"] = not p134.props.messageIds or #p134.props.messageIds == 0,
							["onFadeOut"] = p134.onLastBubbleFadeOut,
							["chatSettings"] = v139
						}
						local v149
						if v141 then
							v149 = p134.renderInsert
						else
							v149 = v141
						end
						v148.renderInsert = v149
						v148.insertSize = p134.insertSize
						v140.DistantBubble = v146(v147, v148)
					end
				end
				local v150 = v138 and (v139.LocalPlayerStudsOffset or Vector3.new(0, 1, 0.1)) or Vector3.new(0, 1, 0.1)
				local v151 = v_u_9.createElement
				local v152 = {
					["Adornee"] = nil,
					["Active"] = nil,
					["Size"] = nil,
					["SizeOffset"] = nil,
					["StudsOffset"] = nil,
					["StudsOffsetWorldSpace"] = nil,
					["ResetOnSpawn"] = false,
					["Adornee"] = v135,
					["Active"] = v141,
					["Size"] = UDim2.fromOffset(500, 200),
					["SizeOffset"] = Vector2.new(0, 0.5)
				}
				local v153 = v139.VerticalStudsOffset
				v152.StudsOffset = v150 + Vector3.new(0, v153, 0)
				v152.StudsOffsetWorldSpace = p134.offset
				return v151("BillboardGui", v152, v140)
			end
			v_u_8:trace("Unmute toggle not applicable for {}", p134.state.shortId)
		else
			v_u_8:trace("Not in range for {}", p134.state.shortId)
		end
	else
		v_u_8:trace("No adornee for {}", p134.state.shortId)
		return
	end
end
function v36.didUpdate(p154, _, p155) -- name: didUpdate
	-- upvalues: (copy) v_u_30, (copy) v_u_3, (copy) v_u_18, (copy) v_u_29, (copy) v_u_34
	if (not p154.props.messageIds or #p154.props.messageIds == 0) and not p154.state.isInsideRenderDistance then
		p154.onLastBubbleFadeOut()
	end
	if p154.props.messageIds and #p154.props.messageIds > 0 then
		p154.isFadingOut = false
	end
	if v_u_30 and p154.state.isInEasierUnmutingTreatment then
		p154:checkCounterForTimeoutWithEasierUnmuting(p155)
	else
		p154:checkCounterForTimeout(p155.voiceStateCounter)
	end
	local v156 = p154.props.userId
	local v157 = v_u_3.LocalPlayer.UserId
	if v_u_30 and (v156 == tostring(v157) and (not p154.state.haveLoggedUserExposure and (p154.props.voiceState == v_u_18.VOICE_STATE.INACTIVE or (p154.props.voiceState == v_u_18.VOICE_STATE.TALKING or p154.props.voiceState == v_u_18.VOICE_STATE.MUTED)))) then
		v_u_29:LogUserLayerExposure(v_u_34)
		p154:setState({
			["haveLoggedUserExposure"] = true
		})
	end
end
function v36.getDerivedStateFromProps(p158, p159) -- name: getDerivedStateFromProps
	local v160 = p158.userId
	local v161 = tostring(v160)
	local v162 = "..." .. string.sub(v161, -4)
	local v163 = not p159.hasMessage and p158.messageIds
	if v163 then
		v163 = #p158.messageIds > 0
	end
	local v164, v165, v166
	if p159.lastVoiceState == p158.voiceState then
		v164 = nil
		v165 = nil
		v166 = nil
	else
		v164 = (p159.voiceStateCounter or 0) + 1
		v166 = p158.voiceState
		v165 = false
	end
	local v167 = {
		["hasMessage"] = v163 or nil
	}
	local v168 = p158.lastMessage
	if v168 then
		v168 = p158.chatSettings
	end
	v167.savedChatSettings = v168
	v167.shortId = v162
	v167.voiceStateCounter = v164
	v167.voiceTimedOut = v165
	v167.lastVoiceState = v166
	return v167
end
return v10.connect(function(p169, p170) -- name: mapStateToProps
	-- upvalues: (copy) v_u_19
	local v171 = p169.userMessages[p170.userId]
	local v172
	if v171 then
		if #v171 >= 1 then
			v172 = v171[#v171]
		else
			v172 = false
		end
	else
		v172 = v171
	end
	if v172 then
		v172 = p169.messages[v172]
	end
	local v173 = p169.voiceState[p170.userId]
	return {
		["chatSettings"] = v_u_19(p169.chatSettings, v172),
		["messageIds"] = v171,
		["lastMessage"] = v172,
		["voiceState"] = v173
	}
end)(v36)
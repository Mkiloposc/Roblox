local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = {
	["Carry"] = "rbxassetid://101172392454133",
	["TreadmillRunFallback"] = "rbxassetid://913376220"
}
v_u_2.Character = {
	{
		["Key"] = "Carry",
		["Id"] = nil,
		["Looped"] = true,
		["Priority"] = nil,
		["Id"] = v_u_2.Carry,
		["Priority"] = Enum.AnimationPriority.Action
	},
	{
		["Key"] = "TreadmillRunFallback",
		["Id"] = nil,
		["Looped"] = true,
		["Priority"] = nil,
		["Id"] = v_u_2.TreadmillRunFallback,
		["Priority"] = Enum.AnimationPriority.Action
	}
}
local v_u_3 = { "Assets", "Animations" }
local v_u_4 = {}
function v_u_2.Get(p5, p6) -- name: Get
	-- upvalues: (copy) v_u_4
	local v7 = v_u_4[p5]
	if v7 then
		if p6 then
			v7.Name = p6
		end
		return v7
	end
	local v8 = Instance.new("Animation")
	v8.Name = p6 or "Animation"
	v8.AnimationId = p5
	v_u_4[p5] = v8
	return v8
end
function v_u_2.AuthoredFolder() -- name: AuthoredFolder
	-- upvalues: (copy) v_u_1, (copy) v_u_3
	local v9 = v_u_1
	for _, v10 in v_u_3 do
		v9 = v9:WaitForChild(v10, 20)
		if v9 then
			continue
		end
		return nil
	end
	return v9
end
function v_u_2.PreloadList() -- name: PreloadList
	-- upvalues: (copy) v_u_2
	local v11 = {}
	for _, v12 in v_u_2.Character do
		local v13 = v_u_2.Get
		local v14 = v12.Id
		local v15 = v12.Key
		table.insert(v11, v13(v14, v15))
	end
	local v16 = v_u_2.AuthoredFolder()
	if v16 then
		for _, v17 in v16:GetChildren() do
			if not v17:IsA("Animation") or v17.AnimationId == "" then
				continue
			end
			table.insert(v11, v17)
		end
	end
	return v11
end
return v_u_2
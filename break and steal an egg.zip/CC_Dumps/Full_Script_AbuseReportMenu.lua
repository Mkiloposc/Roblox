return {
	["LegacyAbuseReportMenu"] = require(script.Components.LegacyAbuseReportMenu),
	["AbuseReportMenuV2"] = require(script.V2.AbuseReportMenu),
	["ReportAbuseAnalytics"] = require(script.Analytics.ReportAbuseAnalytics),
	["jest.config"] = script["jest.config"]
}
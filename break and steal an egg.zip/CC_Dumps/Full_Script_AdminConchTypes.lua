local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v1.Shared.GuardMorphConfig)
local v_u_3 = require(v1.Shared.RideConfig)
local v_u_4 = require(v1.Shared.FollowPetConfig)
local v_u_5 = require(v1.Shared.PotionConfig)
local v_u_6 = require(v1.Shared.WeatherConfig)
local v_u_7 = {}
local v_u_8 = {
	["k"] = 1000,
	["m"] = 1000000,
	["b"] = 1000000000,
	["t"] = 1000000000000,
	["q"] = 1000000000000000,
	["qa"] = 1000000000000000,
	["qi"] = 1e18,
	["sx"] = 1e21,
	["sp"] = 1e24,
	["oc"] = 1e27,
	["no"] = 1e30,
	["dc"] = 1e33
}
function v_u_7.ParseNumber(p9) -- name: ParseNumber
	-- upvalues: (copy) v_u_8
	if typeof(p9) == "number" then
		if p9 == nil or (p9 ~= p9 or math.abs(p9) == (1 / 0)) then
			return nil
		else
			return p9
		end
	elseif p9 == nil then
		return nil
	else
		local v10 = string.lower((string.gsub(tostring(p9), ",", "")))
		local v11 = tonumber(v10)
		if v11 then
			if v11 == nil or (v11 ~= v11 or math.abs(v11) == (1 / 0)) then
				return nil
			else
				return v11
			end
		else
			local v12, v13 = string.match(v10, "^(-?%d*%.?%d+)(%a+)$")
			local v14 = v12 and (v13 and (v_u_8[v13] and tonumber(v12)))
			if v14 then
				local v15 = v14 * v_u_8[v13]
				if v15 == nil or (v15 ~= v15 or math.abs(v15) == (1 / 0)) then
					return nil
				else
					return v15
				end
			else
				return nil
			end
		end
	end
end
v_u_7.PERMANENT = -1
local v_u_16 = {
	["perm"] = true,
	["permanent"] = true,
	["forever"] = true,
	["inf"] = true,
	["never"] = true,
	["p"] = true,
	["-1"] = true
}
local v_u_17 = {
	["s"] = 1,
	["sec"] = 1,
	["secs"] = 1,
	["second"] = 1,
	["seconds"] = 1,
	["m"] = 60,
	["min"] = 60,
	["mins"] = 60,
	["minute"] = 60,
	["minutes"] = 60,
	["h"] = 3600,
	["hr"] = 3600,
	["hrs"] = 3600,
	["hour"] = 3600,
	["hours"] = 3600,
	["d"] = 86400,
	["day"] = 86400,
	["days"] = 86400,
	["w"] = 604800,
	["wk"] = 604800,
	["week"] = 604800,
	["weeks"] = 604800,
	["mo"] = 2592000,
	["month"] = 2592000,
	["months"] = 2592000,
	["y"] = 31536000,
	["yr"] = 31536000,
	["year"] = 31536000,
	["years"] = 31536000
}
function v_u_7.ParseDuration(p18) -- name: ParseDuration
	-- upvalues: (copy) v_u_7, (copy) v_u_16, (copy) v_u_17
	if p18 == nil then
		return nil
	elseif typeof(p18) == "number" then
		if p18 < 0 then
			return v_u_7.PERMANENT
		else
			local v19 = p18 * 86400
			local v20 = math.floor(v19)
			if v20 >= 1 then
				return v20
			else
				return nil
			end
		end
	else
		local v21 = string.lower((string.gsub(tostring(p18), "%s", "")))
		if v_u_16[v21] then
			return v_u_7.PERMANENT
		end
		local v22 = tonumber(v21)
		if v22 then
			return v_u_7.ParseDuration(v22)
		end
		local v_u_23 = 0
		if string.gsub(v21, "(%d*%.?%d+)(%a+)", function(p24, p25)
			-- upvalues: (ref) v_u_17, (ref) v_u_23
			local v26 = v_u_17[p25]
			local v27 = tonumber(p24)
			if not (v26 and v27) then
				return nil
			end
			v_u_23 = v_u_23 + v27 * v26
			return ""
		end) ~= "" or v_u_23 < 1 then
			return nil
		end
		local v28 = v_u_23
		return math.floor(v28)
	end
end
function v_u_7.FormatDuration(p29) -- name: FormatDuration
	if p29 < 0 then
		return "permanent"
	end
	local v30 = math.floor(p29)
	local v31 = {}
	for _, v32 in {
		{ "y", 31536000 },
		{ "d", 86400 },
		{ "h", 3600 },
		{ "m", 60 },
		{ "s", 1 }
	} do
		local v33 = v30 // v32[2]
		if v33 <= 0 then
			continue
		end
		local v34 = ("%*%*"):format(v33, v32[1])
		table.insert(v31, v34)
		v30 = v30 - v33 * v32[2]
		if #v31 ~= 2 then
			continue
		end
	end
	return #v31 <= 0 and "0s" or table.concat(v31, " ")
end
v_u_7.ALL_POTIONS = "all"
function v_u_7.ParsePotion(p35) -- name: ParsePotion
	-- upvalues: (copy) v_u_7, (copy) v_u_5
	if p35 == nil then
		return nil
	else
		local v36 = tostring(p35)
		if string.lower(v36) == v_u_7.ALL_POTIONS then
			return v_u_7.ALL_POTIONS
		else
			local v37 = v_u_5.Find(v36)
			if v37 then
				return v37.Id
			else
				return nil
			end
		end
	end
end
function v_u_7.PotionNames() -- name: PotionNames
	-- upvalues: (copy) v_u_5, (copy) v_u_7
	local v38 = {}
	for _, v39 in v_u_5.Potions do
		local v40 = string.lower
		local v41 = v39.Id
		table.insert(v38, v40(v41))
	end
	local v42 = v_u_7.ALL_POTIONS
	table.insert(v38, v42)
	return table.concat(v38, " / ")
end
local function v_u_50(p43) -- name: guardSuggestions
	-- upvalues: (copy) v_u_2
	local v44 = string.lower(type(p43) ~= "string" and "" or p43)
	local v45 = string.gsub(v44, "[\"\']", "")
	local v46 = {}
	for _, v47 in v_u_2.Guards do
		local v48 = string.lower((("%* %* %*"):format(v47.Key, v47.DisplayName, v47.ZoneId)))
		if v45 ~= "" and not string.find(v48, v45, 1, true) then
			continue
		end
		local v49 = {
			["text"] = v47.Key,
			["display"] = ("%*  (%*, %*)"):format(v47.Key, v47.DisplayName, v47.ZoneId)
		}
		table.insert(v46, v49)
	end
	return v46
end
local function v_u_59(p51) -- name: rideableSuggestions
	-- upvalues: (copy) v_u_3
	local v52 = string.lower(type(p51) ~= "string" and "" or p51)
	local v53 = string.gsub(v52, "[\"\']", "")
	local v54 = {}
	for _, v55 in v_u_3.Animals do
		if v53 ~= "" and not string.find(string.lower(v55.Name), v53, 1, true) then
			continue
		end
		local v56 = {
			["text"] = string.lower(v55.Name)
		}
		local v57 = v55.Name
		local v58 = v55.SpeedBonus * 100 + 0.5
		v56.display = ("%*  (+%*%% WalkSpeed)"):format(v57, (math.floor(v58)))
		table.insert(v54, v56)
	end
	return v54
end
local function v_u_66(p60) -- name: followPetSuggestions
	-- upvalues: (copy) v_u_4
	local v61 = string.lower(type(p60) ~= "string" and "" or p60)
	local v62 = string.gsub(v61, "[\"\']", "")
	local v63 = {}
	for _, v64 in v_u_4.Pets do
		if v62 ~= "" and not string.find(string.lower(v64.Name), v62, 1, true) then
			continue
		end
		local v65 = {
			["text"] = string.lower(v64.Name),
			["display"] = ("%*  (%*%% damage)"):format(v64.Name, v64.DamagePercent)
		}
		table.insert(v63, v65)
	end
	return v63
end
local function v_u_75(p67) -- name: potionSuggestions
	-- upvalues: (copy) v_u_5, (copy) v_u_7
	local v68 = string.lower(type(p67) ~= "string" and "" or p67)
	local v69 = string.gsub(v68, "[\"\']", "")
	local v70 = {}
	for _, v71 in v_u_5.Potions do
		local v72 = string.lower((("%* %*"):format(v71.Id, v71.DisplayName)))
		if v69 ~= "" and not string.find(v72, v69, 1, true) then
			continue
		end
		local v73 = {
			["text"] = string.lower(v71.Id),
			["display"] = ("%*  (%*)"):format(string.lower(v71.Id), v71.DisplayName)
		}
		table.insert(v70, v73)
	end
	if v69 == "" or string.find(v_u_7.ALL_POTIONS, v69, 1, true) then
		local v74 = {
			["text"] = nil,
			["display"] = "all  (every potion)",
			["text"] = v_u_7.ALL_POTIONS
		}
		table.insert(v70, v74)
	end
	return v70
end
local v_u_76 = {
	["yes"] = true,
	["y"] = true,
	["true"] = true,
	["on"] = true,
	["1"] = true
}
local v_u_77 = {
	["no"] = true,
	["n"] = true,
	["false"] = true,
	["off"] = true,
	["0"] = true
}
function v_u_7.ParseYesNo(p78) -- name: ParseYesNo
	-- upvalues: (copy) v_u_76, (copy) v_u_77
	if typeof(p78) == "boolean" then
		return p78
	elseif p78 == nil then
		return nil
	else
		local v79 = string.lower((tostring(p78)))
		if v_u_76[v79] then
			return true
		elseif v_u_77[v79] then
			return false
		else
			return nil
		end
	end
end
local function v_u_85(p80) -- name: yesNoSuggestions
	local v81 = string.lower(type(p80) ~= "string" and "" or p80)
	local v82 = {}
	for _, v83 in { "yes", "no" } do
		if v81 ~= "" then
			local v84 = #v81
			if string.sub(v83, 1, v84) ~= v81 then
				continue
			end
		end
		table.insert(v82, {
			["text"] = v83,
			["display"] = v83
		})
	end
	return v82
end
function v_u_7.ParseWeather(p86) -- name: ParseWeather
	-- upvalues: (copy) v_u_6
	if p86 == nil then
		return nil
	else
		local v87 = string.lower((tostring(p86)))
		if v87 ~= "" then
			local v88 = #v87
			if string.sub("random", 1, v88) == v87 then
				return "random"
			end
		end
		local v89 = v_u_6.Find(v87)
		if v89 then
			return v89.Id
		else
			return nil
		end
	end
end
function v_u_7.WeatherNames() -- name: WeatherNames
	-- upvalues: (copy) v_u_6
	local v90 = {}
	for _, v91 in v_u_6.Weathers do
		local v92 = string.lower
		local v93 = v91.Id
		table.insert(v90, v92(v93))
	end
	table.insert(v90, "random")
	return table.concat(v90, ", ")
end
local function v_u_102(p94) -- name: weatherSuggestions
	-- upvalues: (copy) v_u_6
	local v95 = string.lower(type(p94) ~= "string" and "" or p94)
	local v96 = string.gsub(v95, "[\"\']", "")
	local v97 = {}
	for _, v98 in v_u_6.Weathers do
		local v99 = string.lower((("%* %* %*"):format(v98.Id, v98.DisplayName, v98.Mutation)))
		if v96 ~= "" and not string.find(v99, v96, 1, true) then
			continue
		end
		local v100 = {
			["text"] = string.lower(v98.Id),
			["display"] = ("%*  (%* - %* mutation)"):format(string.lower(v98.Id), v98.DisplayName, v98.Mutation)
		}
		table.insert(v97, v100)
	end
	if v96 == "" then
		table.insert(v97, {
			["text"] = "random",
			["display"] = "random  (any weather)"
		})
		return v97
	end
	local v101 = #v96
	if string.sub("random", 1, v101) ~= v96 then
		return v97
	end
	table.insert(v97, {
		["text"] = "random",
		["display"] = "random  (any weather)"
	})
	return v97
end
function v_u_7.ParsePotionDuration(p103) -- name: ParsePotionDuration
	-- upvalues: (copy) v_u_7
	if p103 == nil then
		return nil
	else
		local v104
		if typeof(p103) == "number" then
			v104 = p103
		else
			local v105 = tostring(p103)
			v104 = tonumber(v105)
		end
		if v104 then
			local v106 = v104 * 60
			local v107 = math.floor(v106)
			if v107 >= 1 and (v107 == v107 and v107 ~= (1 / 0)) then
				return v107
			else
				return nil
			end
		else
			local v108 = v_u_7.ParseDuration(p103)
			if v108 == nil or v108 == v_u_7.PERMANENT then
				return nil
			else
				return v108
			end
		end
	end
end
local function v_u_116(p109) -- name: eventLengthSuggestions
	local v110 = string.lower(type(p109) ~= "string" and "" or p109)
	local v111 = {}
	for _, v112 in {
		{ "1", "1 minute" },
		{ "5", "5 minutes (usual)" },
		{ "10", "10 minutes" },
		{ "15", "15 minutes (longest)" },
		{ "30s", "30 seconds" }
	} do
		if v110 ~= "" then
			local v113 = v112[1]
			local v114 = #v110
			if string.sub(v113, 1, v114) ~= v110 then
				continue
			end
		end
		local v115 = {
			["text"] = v112[1],
			["display"] = ("%*  (%*)"):format(v112[1], v112[2])
		}
		table.insert(v111, v115)
	end
	return v111
end
function v_u_7.FormatDurationWords(p117) -- name: FormatDurationWords
	local v118 = math.floor(p117)
	local v119 = {}
	for _, v120 in {
		{ "day", 86400 },
		{ "hour", 3600 },
		{ "minute", 60 },
		{ "second", 1 }
	} do
		local v121 = v118 // v120[2]
		if v121 <= 0 then
			continue
		end
		local v122 = ("%* %*%*"):format(v121, v120[1], v121 == 1 and "" or "s")
		table.insert(v119, v122)
		v118 = v118 - v121 * v120[2]
		if #v119 ~= 2 then
			continue
		end
	end
	return #v119 <= 0 and "0 seconds" or table.concat(v119, " and ")
end
function v_u_7.Register(p123) -- name: Register
	-- upvalues: (copy) v_u_7, (copy) v_u_75, (copy) v_u_2, (copy) v_u_50, (copy) v_u_3, (copy) v_u_59, (copy) v_u_4, (copy) v_u_66, (copy) v_u_102, (copy) v_u_85, (copy) v_u_116
	local v126 = {
		["convert"] = function(p124) -- name: convert
			-- upvalues: (ref) v_u_7
			local v125 = v_u_7.ParseNumber(p124)
			if v125 == nil then
				error(("%* is not a number \226\128\148 try 500, 400t, 2.5qa or 1e9"):format(p124), 0)
			end
			return v125
		end,
		["analysis"] = {
			["kind"] = "argument",
			["optional"] = false,
			["vararg"] = false,
			["name"] = "amount",
			["type"] = "number"
		}
	}
	local v127 = p123.register_type("amount", v126)
	local v130 = {
		["convert"] = function(p128) -- name: convert
			-- upvalues: (ref) v_u_7
			local v129 = v_u_7.ParseDuration(p128)
			if v129 == nil then
				error(("%* is not a ban length \226\128\148 try perm, 30m, 12h, 7d or 1d12h"):format(p128), 0)
			end
			return v129
		end,
		["analysis"] = {
			["kind"] = "argument",
			["optional"] = false,
			["vararg"] = false,
			["name"] = "banduration",
			["type"] = "string"
		}
	}
	local v131 = p123.register_type("banduration", v130)
	local v133 = p123.register_type("bantarget", {
		["convert"] = function(p132) -- name: convert
			if p132 == nil or tostring(p132) == "" then
				error("give a username or a UserId", 0)
			end
			return tostring(p132)
		end,
		["analysis"] = {
			["kind"] = "argument",
			["optional"] = false,
			["vararg"] = false,
			["name"] = "bantarget",
			["type"] = "string"
		}
	})
	local v136 = {
		["convert"] = function(p134) -- name: convert
			-- upvalues: (ref) v_u_7
			local v135 = v_u_7.ParsePotion(p134)
			if v135 == nil then
				error(("%* is not a potion \226\128\148 try %*"):format(p134, (v_u_7.PotionNames())), 0)
			end
			return v135
		end,
		["analysis"] = {
			["kind"] = "argument",
			["optional"] = false,
			["vararg"] = false,
			["name"] = "potion",
			["type"] = "string",
			["suggestions"] = nil,
			["suggestions"] = v_u_75
		}
	}
	local v137 = p123.register_type("potion", v136)
	local v140 = {
		["convert"] = function(p138) -- name: convert
			-- upvalues: (ref) v_u_7
			local v139 = v_u_7.ParsePotionDuration(p138)
			if v139 == nil then
				error(("%* is not a potion length \226\128\148 try 10 (minutes), 30s, 10m, 1h or 1h30m"):format(p138), 0)
			end
			return v139
		end,
		["analysis"] = {
			["kind"] = "argument",
			["optional"] = false,
			["vararg"] = false,
			["name"] = "potionduration",
			["type"] = "string"
		}
	}
	local v141 = p123.register_type("potionduration", v140)
	local v144 = {
		["convert"] = function(p142) -- name: convert
			-- upvalues: (ref) v_u_2
			local v143 = v_u_2.Resolve((tostring(p142)))
			if v143 == nil then
				error(("%* is not a guard \226\128\148 try %*"):format(p142, (table.concat(v_u_2.Keys(), ", "))), 0)
			end
			return v143.Key
		end,
		["analysis"] = {
			["kind"] = "argument",
			["optional"] = false,
			["vararg"] = false,
			["name"] = "guard",
			["type"] = "string",
			["suggestions"] = nil,
			["suggestions"] = v_u_50
		}
	}
	local v145 = p123.register_type("guard", v144)
	local v148 = {
		["convert"] = function(p146) -- name: convert
			-- upvalues: (ref) v_u_3
			local v147 = v_u_3.Find((tostring(p146)))
			if v147 == nil then
				error(("%* is not a rideable \226\128\148 try %*"):format(p146, (table.concat(v_u_3.Names(), ", "))), 0)
			end
			return v147.Name
		end,
		["analysis"] = {
			["kind"] = "argument",
			["optional"] = false,
			["vararg"] = false,
			["name"] = "rideable",
			["type"] = "string",
			["suggestions"] = nil,
			["suggestions"] = v_u_59
		}
	}
	local v149 = p123.register_type("rideable", v148)
	local v152 = {
		["convert"] = function(p150) -- name: convert
			-- upvalues: (ref) v_u_4
			local v151 = v_u_4.Find((tostring(p150)))
			if v151 == nil then
				error(("%* is not a follow pet \226\128\148 try %*"):format(p150, (table.concat(v_u_4.Names(), ", "))), 0)
			end
			return v151.Name
		end,
		["analysis"] = {
			["kind"] = "argument",
			["optional"] = false,
			["vararg"] = false,
			["name"] = "followpet",
			["type"] = "string",
			["suggestions"] = nil,
			["suggestions"] = v_u_66
		}
	}
	local v153 = p123.register_type("followpet", v152)
	local v156 = {
		["convert"] = function(p154) -- name: convert
			-- upvalues: (ref) v_u_7
			local v155 = v_u_7.ParseWeather(p154)
			if v155 == nil then
				error(("%* isn\'t a weather \226\128\148 try %*"):format(p154, (v_u_7.WeatherNames())), 0)
			end
			return v155
		end,
		["analysis"] = {
			["kind"] = "argument",
			["optional"] = false,
			["vararg"] = false,
			["name"] = "weather",
			["type"] = "string",
			["suggestions"] = nil,
			["suggestions"] = v_u_102
		}
	}
	local v157 = p123.register_type("weather", v156)
	local v160 = {
		["convert"] = function(p158) -- name: convert
			-- upvalues: (ref) v_u_7
			local v159 = v_u_7.ParseYesNo(p158)
			if v159 == nil then
				error(("%* isn\'t yes or no"):format(p158), 0)
			end
			return v159
		end,
		["analysis"] = {
			["kind"] = "argument",
			["optional"] = false,
			["vararg"] = false,
			["name"] = "yesno",
			["type"] = "string",
			["suggestions"] = nil,
			["suggestions"] = v_u_85
		}
	}
	local v161 = p123.register_type("yesno", v160)
	local v164 = {
		["convert"] = function(p162) -- name: convert
			-- upvalues: (ref) v_u_7
			local v163 = v_u_7.ParsePotionDuration(p162)
			if v163 == nil then
				error(("%* isn\'t a length \226\128\148 try 10 (minutes), 30s, 5m or 1m30s"):format(p162), 0)
			end
			return v163
		end,
		["analysis"] = {
			["kind"] = "argument",
			["optional"] = false,
			["vararg"] = false,
			["name"] = "eventlength",
			["type"] = "string",
			["suggestions"] = nil,
			["suggestions"] = v_u_116
		}
	}
	return {
		["eventlength"] = p123.register_type("eventlength", v164),
		["weather"] = v157,
		["yesno"] = v161,
		["amount"] = v127,
		["banduration"] = v131,
		["bantarget"] = v133,
		["guard"] = v145,
		["rideable"] = v149,
		["followpet"] = v153,
		["potion"] = v137,
		["potionduration"] = v141
	}
end
return v_u_7
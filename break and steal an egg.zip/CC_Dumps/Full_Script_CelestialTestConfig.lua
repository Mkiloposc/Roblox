local v_u_1 = {
	["Animals"] = {
		"CelestialAxolotl",
		"CelestialFrog",
		"CelestialLamb",
		"CelestialSpiritFox",
		"CelestialGorilla"
	},
	["MaxGiveEach"] = 25,
	["KgMultMin"] = 0.5,
	["KgMultMax"] = 8
}
local v_u_2 = Random.new()
function v_u_1.RollKgMult() -- name: RollKgMult
	-- upvalues: (copy) v_u_1, (copy) v_u_2
	local v3 = v_u_1.KgMultMin
	local v4 = math.log(v3)
	local v5 = v_u_1.KgMultMax
	local v6 = v_u_2:NextNumber(v4, (math.log(v5)))
	return math.exp(v6)
end
function v_u_1.IsCelestial(p7) -- name: IsCelestial
	-- upvalues: (copy) v_u_1
	return table.find(v_u_1.Animals, p7) ~= nil
end
return v_u_1
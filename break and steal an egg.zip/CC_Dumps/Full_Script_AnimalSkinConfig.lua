local v1 = {
	["SourceFolders"] = nil,
	["Base"] = nil,
	["Skins"] = nil,
	["AngelPets"] = nil,
	["Angel"] = nil,
	["GlowMaterialVariants"] = nil,
	["GlowMaterials"] = nil,
	["GlowMinBrightness"] = 0.2,
	["MinShade"] = 0.45,
	["GeneratedAttribute"] = "GeneratedSkin",
	["AuthoredAttribute"] = "AuthoredSkin",
	["SourceFolders"] = { "AnimalHELL" },
	["Base"] = {
		["Body"] = Color3.fromRGB(36, 36, 36),
		["Glow"] = Color3.fromRGB(255, 43, 1)
	}
}
local v2 = {
	["Gold"] = {
		["Body"] = Color3.fromRGB(36, 36, 36),
		["Glow"] = Color3.fromRGB(255, 190, 20)
	},
	["Diamond"] = {
		["Body"] = Color3.fromRGB(36, 36, 36),
		["Glow"] = Color3.fromRGB(0, 170, 255)
	}
}
v1.Skins = v2
v1.AngelPets = {
	["Folder"] = "AnimalANGEL",
	["From"] = nil,
	["From"] = {
		["AngelCroc"] = "HellCroc",
		["AngelAnky"] = "HellAnky",
		["AngelTrike"] = "HellTrike",
		["AngelMegalodon"] = "HellMegalodon",
		["AngelTRex"] = "HellTRex",
		["AngelDragon"] = "HellDragon",
		["AngelHydra"] = "HellHydra"
	}
}
local v3 = {
	["Gold"] = {
		["Body"] = Color3.fromRGB(255, 205, 50),
		["Glow"] = Color3.fromRGB(255, 90, 7)
	},
	["Diamond"] = {
		["Body"] = Color3.fromRGB(205, 232, 255),
		["Glow"] = Color3.fromRGB(120, 200, 255)
	}
}
v1.Angel = v3
v1.GlowMaterialVariants = { "StudsNeon" }
v1.GlowMaterials = { Enum.Material.Neon }
return v1
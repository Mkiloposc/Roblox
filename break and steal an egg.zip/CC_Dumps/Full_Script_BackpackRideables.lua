local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v_u_2.Shared.BackpackUiConfig)
local v_u_4 = require(v_u_2.Shared.RideConfig)
local v_u_5 = require(v_u_2.Shared.RideEggConfig)
local v_u_6 = require(script.Parent.BackpackHover)
local v_u_7 = require(script.Parent.BackpackSlotVisuals)
local v_u_8 = require(v_u_2.Shared.RarityGradientFX)
local v9 = {}
local v_u_10 = v1.LocalPlayer
local v_u_11 = v_u_5.Held.Attribute
local v_u_12 = nil
local v_u_13 = {}
local v_u_14 = {}
local v_u_15 = 0
local v_u_16 = false
local v_u_17 = {}
local v_u_18 = nil
local v_u_19 = false
local function v_u_23(p20) -- name: matchesSearch
	-- upvalues: (ref) v_u_17, (copy) v_u_5
	if #v_u_17 == 0 then
		return true
	end
	local v21 = string.lower(p20.Name .. " " .. v_u_5.RarityOf(p20.Name))
	for _, v22 in v_u_17 do
		if string.find(v21, v22, 1, true) then
			continue
		end
		return false
	end
	return true
end
local function v_u_26(p24) -- name: paint
	-- upvalues: (copy) v_u_3, (copy) v_u_7, (copy) v_u_5, (copy) v_u_8
	local v25
	if p24.Count > 1 then
		v25 = string.format(v_u_3.RideableCountFormat, p24.Name, p24.Count)
	else
		v25 = p24.Name
	end
	v_u_7.RenderEntry(p24.Parts, v25, v_u_5.ImageOf(p24.Name), v_u_5.RarityOf(p24.Name))
	if p24.Speed then
		p24.Speed.Text = string.format(v_u_5.InventorySpeedFormat, v_u_5.SpeedPercentOf(p24.Name))
		v_u_8.ApplyToLabel(p24.Speed, v_u_5.RarityOf(p24.Name))
	end
end
local function v_u_35(p27, p28) -- name: makeSpeedLabel
	local v29 = p28.Name
	local v30
	if v29 then
		v30 = v29:Clone()
		for _, v31 in v30:GetChildren() do
			if v31:IsA("UIStroke") then
				continue
			end
			v31:Destroy()
		end
	else
		v30 = Instance.new("TextLabel")
		v30.BackgroundTransparency = 1
		v30.TextScaled = true
		v30.Font = Enum.Font.GothamBold
		v30.TextColor3 = Color3.new(1, 1, 1)
	end
	v30.Name = "Speed"
	v30.AnchorPoint = Vector2.new(0.5, 0.5)
	v30.Position = UDim2.new(0.5, 0, 0.5, 0)
	v30.Size = UDim2.fromScale(0.9, 0.27)
	v30.LayoutOrder = 0
	v30.Visible = true
	v30.Text = ""
	local v32 = p27.ZIndex
	for _, v33 in p27:GetDescendants() do
		if not v33:IsA("GuiObject") then
			continue
		end
		local v34 = v33.ZIndex
		v32 = math.max(v32, v34)
	end
	v30.ZIndex = v32 + 1
	v30.Parent = p27
	return v30
end
local function v_u_44() -- name: refreshVisibility
	-- upvalues: (ref) v_u_18, (copy) v_u_10, (copy) v_u_4, (copy) v_u_11, (copy) v_u_14, (copy) v_u_13, (ref) v_u_16, (copy) v_u_23, (copy) v_u_7
	local v36
	if v_u_18 == nil then
		local v37 = v_u_10
		local v38
		if v_u_10:GetAttribute(v_u_4.MountedAttribute) == true then
			v38 = v_u_4.SelectedAttribute
		else
			v38 = v_u_11
		end
		v36 = v37:GetAttribute(v38)
		if type(v36) ~= "string" then
			v36 = nil
		end
	elseif v_u_18 then
		v36 = v_u_18
	else
		v36 = nil
	end
	for v39, v40 in v_u_14 do
		local v41 = v_u_13[v40]
		if not v41 then
			continue
		end
		v41.Parts.Root.LayoutOrder = v39
		local v42 = v41.Parts.Root
		local v43 = v_u_16
		if v43 then
			v43 = v_u_23(v41)
		end
		v42.Visible = v43
		v_u_7.SetEquipped(v41.Parts, v40 == v36)
	end
end
local function v_u_57(p_u_45) -- name: onCardClicked
	-- upvalues: (ref) v_u_12, (ref) v_u_19, (copy) v_u_2, (copy) v_u_5, (ref) v_u_18, (copy) v_u_10, (copy) v_u_4, (copy) v_u_11, (copy) v_u_44
	local v46 = v_u_12
	if v46 and (v46.CanClick() and not v_u_19) then
		local v_u_47 = v_u_2:FindFirstChild(v_u_5.RemoteName)
		if not (v_u_47 and v_u_47:IsA("RemoteFunction")) then
			v_u_47 = nil
		end
		if v_u_47 then
			local v48
			if v_u_18 == nil then
				local v49 = v_u_10
				local v50
				if v_u_10:GetAttribute(v_u_4.MountedAttribute) == true then
					v50 = v_u_4.SelectedAttribute
				else
					v50 = v_u_11
				end
				v48 = v49:GetAttribute(v50)
				if type(v48) ~= "string" then
					v48 = nil
				end
			elseif v_u_18 then
				v48 = v_u_18
			else
				v48 = nil
			end
			local v51
			if v48 == p_u_45.Name and v_u_10:GetAttribute(v_u_4.MountedAttribute) ~= true then
				v51 = false
			else
				v51 = p_u_45.Name
			end
			v_u_18 = v51
			v_u_19 = true
			v_u_44()
			task.spawn(function()
				-- upvalues: (copy) v_u_47, (copy) p_u_45, (ref) v_u_19, (ref) v_u_18, (ref) v_u_44
				local v52 = v_u_47.InvokeServer
				local v53 = v_u_47
				local v54 = p_u_45.Name
				local v55, v56 = pcall(v52, v53, "Hold", v54)
				v_u_19 = false
				v_u_18 = nil
				if not (v55 and v56) then
					warn((("[BackpackRideables] couldn\'t hold %*: %*"):format(p_u_45.Name, v55 and "refused" or v56)))
				end
				v_u_44()
			end)
		end
	else
		return
	end
end
local function v_u_66(p58) -- name: makeCard
	-- upvalues: (ref) v_u_12, (copy) v_u_7, (copy) v_u_3, (copy) v_u_6, (copy) v_u_35, (copy) v_u_57
	local v59 = v_u_12
	local v60 = v59.Template:Clone()
	v60.Name = "Mount_" .. p58
	v60.Visible = false
	local v61 = v60:FindFirstChild("Container")
	local v62
	if v61 then
		v62 = v61:IsA("GuiButton")
	else
		v62 = v61
	end
	assert(v62, "[BackpackRideables] Inventory Template.Container must be a button")
	local v63 = v_u_7.Collect(v60, v61)
	v_u_7.AdoptStrokes(v63, v59.StrokeTemplate, v59.SlotStroke)
	v_u_7.SetSellSelected(v63, false)
	v_u_7.AttachImageFX(v63)
	local v64 = v61:FindFirstChild("InfoList")
	if v64 and v64:IsA("GuiObject") then
		v64.Visible = v_u_3.InventoryShowInfo
	end
	v_u_6.Attach(v61)
	local v_u_65 = {
		["Name"] = nil,
		["Count"] = 0,
		["Parts"] = nil,
		["Speed"] = nil,
		["Name"] = p58,
		["Parts"] = v63,
		["Speed"] = v_u_35(v61, v63)
	}
	v61.Activated:Connect(function()
		-- upvalues: (ref) v_u_57, (copy) v_u_65
		v_u_57(v_u_65)
	end)
	v60.Parent = v59.Scrolling
	return v_u_65
end
local function v_u_75() -- name: rebuild
	-- upvalues: (ref) v_u_12, (copy) v_u_5, (copy) v_u_10, (copy) v_u_14, (ref) v_u_15, (copy) v_u_4, (copy) v_u_13, (copy) v_u_66, (copy) v_u_26, (copy) v_u_44
	if v_u_12 then
		local v67 = v_u_5.ParseCounts(v_u_10:GetAttribute(v_u_5.CountsAttribute))
		local v68 = {}
		table.clear(v_u_14)
		v_u_15 = 0
		for _, v69 in v67 do
			if not v_u_4.Find(v69.Name) or v68[v69.Name] then
				continue
			end
			v68[v69.Name] = true
			local v70 = v_u_14
			local v71 = v69.Name
			table.insert(v70, v71)
			v_u_15 = v_u_15 + v69.Count
			local v72 = v_u_13[v69.Name] or v_u_66(v69.Name)
			v_u_13[v69.Name] = v72
			if v72.Count == v69.Count then
				continue
			end
			v72.Count = v69.Count
			v_u_26(v72)
		end
		for v73, v74 in v_u_13 do
			if v68[v73] then
				continue
			end
			v74.Parts.Root:Destroy()
			v_u_13[v73] = nil
		end
		v_u_44()
		v_u_12.OnChanged()
	end
end
function v9.Init(p76) -- name: Init
	-- upvalues: (ref) v_u_12, (copy) v_u_10, (copy) v_u_5, (copy) v_u_75, (copy) v_u_4, (copy) v_u_44, (copy) v_u_11, (ref) v_u_19, (ref) v_u_18
	v_u_12 = p76
	v_u_10:GetAttributeChangedSignal(v_u_5.CountsAttribute):Connect(v_u_75)
	v_u_10:GetAttributeChangedSignal(v_u_4.MountedAttribute):Connect(v_u_44)
	v_u_10:GetAttributeChangedSignal(v_u_4.SelectedAttribute):Connect(v_u_44)
	v_u_10:GetAttributeChangedSignal(v_u_11):Connect(function()
		-- upvalues: (ref) v_u_19, (ref) v_u_18, (ref) v_u_44
		if not v_u_19 then
			v_u_18 = nil
		end
		v_u_44()
	end)
	v_u_75()
end
function v9.SetShown(p77, p78) -- name: SetShown
	-- upvalues: (ref) v_u_16, (ref) v_u_17, (copy) v_u_44
	v_u_16 = p77
	v_u_17 = p78
	v_u_44()
end
function v9.Count() -- name: Count
	-- upvalues: (ref) v_u_15
	return v_u_15
end
return v9
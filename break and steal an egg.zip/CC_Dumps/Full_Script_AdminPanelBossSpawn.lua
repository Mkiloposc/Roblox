local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = require(v_u_1.Shared.AdminConfig)
local v_u_3 = require(v_u_1.Shared.RranBossConfig)
local v_u_4 = require(script.Parent.Parent.Controllers.NotificationController)
local v_u_5 = require(script.Parent.UnitTextBox)
return {
	["Bind"] = function(p_u_6, p7) -- name: Bind
		-- upvalues: (copy) v_u_2, (copy) v_u_5, (copy) v_u_4, (copy) v_u_1, (copy) v_u_3
		local v_u_8 = p7:FindFirstChild("SpawnTime")
		if v_u_8 then
			v_u_8 = v_u_8:FindFirstChildWhichIsA("TextBox")
		end
		local v9 = p7:FindFirstChild("Spawn")
		if v_u_8 and (v_u_8:IsA("TextBox") and (v9 and v9:IsA("GuiButton"))) then
			v9:SetAttribute("HoverScale", v_u_2.PanelHoverScale)
			v9:SetAttribute("PressScale", v_u_2.PanelPressScale)
			v_u_5.Bind(v_u_8, "s")
			local v_u_10 = false
			local function v_u_19() -- name: spawn
				-- upvalues: (ref) v_u_10, (ref) v_u_5, (copy) v_u_8, (ref) v_u_4, (ref) v_u_1, (ref) v_u_2, (copy) p_u_6, (ref) v_u_3
				if v_u_10 then
					return
				else
					local v_u_11 = v_u_5.Number(v_u_8.Text, "s")
					if v_u_11 and v_u_11 > 0 then
						local v_u_12 = v_u_1:FindFirstChild(v_u_2.PanelRemotes.BossSpawn)
						if v_u_12 and v_u_12:IsA("RemoteFunction") then
							local v_u_13 = p_u_6:GetAttribute("Scope")
							if type(v_u_13) ~= "string" or not v_u_3.Scopes[v_u_13] then
								v_u_13 = v_u_3.DefaultScope
							end
							v_u_10 = true
							local function v14()
								-- upvalues: (copy) v_u_12, (copy) v_u_11, (ref) v_u_13
								return v_u_12:InvokeServer(v_u_11, v_u_13)
							end
							local v15, v16, v17 = pcall(v14)
							v_u_10 = false
							if v15 and (v16 == true and (v_u_13 == "Global" and type(v17) == "string")) then
								v_u_4.Show(v17, "Success")
							elseif not v15 or v16 ~= true then
								local v18 = (not v15 or type(v17) ~= "string") and "couldn\'t spawn" or v17
								v_u_4.Show(("Boss Spawn failed: %*"):format(v18), "Error")
							end
						else
							v_u_4.Show("Boss spawning isn\'t ready yet", "Error")
						end
					else
						v_u_4.Show("Type how long the bosses stay, in seconds (e.g. 300)", "Error")
						return
					end
				end
			end
			v9.Activated:Connect(function()
				-- upvalues: (copy) v_u_19
				task.spawn(v_u_19)
			end)
		else
			warn("[AdminPanelBossSpawn] card needs Container.SpawnTime.TextBox + Container.Spawn")
		end
	end
}
local v_u_1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("Workspace")
local v_u_3 = require(v_u_1.Shared.AdminAbuseConfig)
local v_u_4 = require(v_u_1.Shared.AdminConfig)
local v_u_5 = require(script.Parent.Parent.Controllers.NotificationController)
local v6 = {}
local v_u_7 = v_u_3.Color
local function v_u_38(p8, p_u_9, p_u_10) -- name: bindTimer
	-- upvalues: (copy) v_u_2, (copy) v_u_7
	local v_u_11 = p8:FindFirstChild("Timer")
	if v_u_11 and v_u_11:IsA("TextLabel") then
		local function v_u_34() -- name: refresh
			-- upvalues: (ref) v_u_2, (copy) p_u_9, (copy) p_u_10, (ref) v_u_7, (copy) v_u_11
			local v12 = v_u_2:GetAttribute(p_u_9)
			local v13
			if p_u_10 then
				v13 = v_u_2:GetAttribute(p_u_10)
			else
				v13 = nil
			end
			local v14
			if type(v12) == "number" then
				local v15 = "Running: <font color=\"%*\">%*</font>"
				local v16 = v_u_7
				local v17 = v_u_2:GetServerTimeNow() - v12
				local v18 = math.floor(v17)
				local v19 = math.max(v18, 0)
				local v20 = v19 // 3600
				local v21 = v19 % 3600 // 60
				local v22 = v19 % 60
				local v23
				if v20 > 0 then
					v23 = string.format("%d:%02d:%02d", v20, v21, v22)
				else
					v23 = string.format("%d:%02d", v21, v22)
				end
				v14 = v15:format(v16, v23)
			elseif type(v13) == "number" then
				local v24 = "Starts in: <font color=\"%*\">%*</font>"
				local v25 = v_u_7
				local v26 = v13 - v_u_2:GetServerTimeNow()
				local v27 = math.ceil(v26)
				local v28 = math.floor(v27)
				local v29 = math.max(v28, 0)
				local v30 = v29 // 3600
				local v31 = v29 % 3600 // 60
				local v32 = v29 % 60
				local v33
				if v30 > 0 then
					v33 = string.format("%d:%02d:%02d", v30, v31, v32)
				else
					v33 = string.format("%d:%02d", v31, v32)
				end
				v14 = v24:format(v25, v33)
			else
				v14 = "Not running"
			end
			if v_u_11.Text ~= v14 then
				v_u_11.Text = v14
			end
		end
		v_u_34()
		local v_u_35 = { v_u_2:GetAttributeChangedSignal(p_u_9):Connect(v_u_34) }
		if p_u_10 then
			local v36 = v_u_2:GetAttributeChangedSignal(p_u_10)
			table.insert(v_u_35, v36:Connect(v_u_34))
		end
		task.spawn(function()
			-- upvalues: (copy) v_u_11, (copy) v_u_34, (copy) v_u_35
			while v_u_11:IsDescendantOf(game) do
				v_u_34()
				task.wait(0.25)
			end
			for _, v37 in v_u_35 do
				v37:Disconnect()
			end
		end)
	else
		warn((("[AdminPanelEvents] %* has no Timer label"):format((p8:GetFullName()))))
	end
end
local function v_u_56(p39, p_u_40) -- name: bind
	-- upvalues: (copy) v_u_4, (copy) v_u_38, (copy) v_u_1, (copy) v_u_5
	local v41 = p39:FindFirstChild("Start")
	local v42 = p39:FindFirstChild("End")
	if v41 and (v41:IsA("GuiButton") and (v42 and v42:IsA("GuiButton"))) then
		for _, v43 in { v41, v42 } do
			v43:SetAttribute("HoverScale", v_u_4.PanelHoverScale)
			v43:SetAttribute("PressScale", v_u_4.PanelPressScale)
		end
		v_u_38(p39, p_u_40.Attribute, p_u_40.ScheduledAttribute)
		local v_u_44 = false
		local function v_u_55(p_u_45) -- name: send
			-- upvalues: (ref) v_u_44, (ref) v_u_1, (copy) p_u_40, (ref) v_u_5
			if v_u_44 then
				return
			else
				local v_u_46 = v_u_1:FindFirstChild(p_u_40.Remote)
				if v_u_46 and v_u_46:IsA("RemoteFunction") then
					local v_u_47
					if p_u_40.Args then
						local v48
						v_u_47, v48 = p_u_40.Args(p_u_45)
						if not v_u_47 then
							v_u_5.Show(v48 or ("%* failed"):format(p_u_40.Label), "Error")
							return
						end
					else
						v_u_47 = {}
					end
					v_u_44 = true
					local function v50()
						-- upvalues: (copy) v_u_46, (copy) p_u_45, (ref) v_u_47
						local v49 = v_u_47
						return v_u_46:InvokeServer(p_u_45, table.unpack(v49))
					end
					local v51, v52, v53 = pcall(v50)
					v_u_44 = false
					if v51 and v52 == true then
						if type(v53) == "string" then
							v_u_5.Show(v53, "Success")
						end
					else
						local v54 = (not v51 or type(v53) ~= "string") and "something went wrong" or v53
						v_u_5.Show(("%* failed: %*"):format(p_u_40.Label, v54), "Error")
					end
				else
					v_u_5.Show(("%* isn\'t ready yet"):format(p_u_40.Label), "Error")
				end
			end
		end
		v41.Activated:Connect(function()
			-- upvalues: (copy) v_u_55
			task.spawn(v_u_55, "Start")
		end)
		v42.Activated:Connect(function()
			-- upvalues: (copy) v_u_55
			task.spawn(v_u_55, "End")
		end)
	else
		warn((("[AdminPanelEvents] %* card needs Container.Start + Container.End"):format(p_u_40.Label)))
	end
end
function v6.BindAdminAbuse(_, p57) -- name: BindAdminAbuse
	-- upvalues: (copy) v_u_56, (copy) v_u_4, (copy) v_u_3
	v_u_56(p57, {
		["Label"] = "Admin Abuse",
		["Remote"] = nil,
		["Attribute"] = nil,
		["Remote"] = v_u_4.PanelRemotes.AdminAbuse,
		["Attribute"] = v_u_3.StartedAtAttribute
	})
end
return v6
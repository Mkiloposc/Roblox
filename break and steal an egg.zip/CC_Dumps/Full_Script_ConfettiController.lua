local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(v2.Shared.ConfettiConfig)
local v5 = {}
local v_u_6 = v1.LocalPlayer
local v_u_7 = Random.new()
local v_u_8 = nil
local v_u_9 = {}
local v_u_10 = {}
local v_u_11 = nil
local function v_u_15() -- name: getHolder
	-- upvalues: (ref) v_u_8, (copy) v_u_6, (copy) v_u_4
	if v_u_8 and v_u_8.Parent then
		return v_u_8
	end
	local v12 = v_u_6:WaitForChild("PlayerGui"):FindFirstChild(v_u_4.GuiName)
	if not v12 then
		return nil
	end
	local v13 = v12:FindFirstChild(v_u_4.LayerName)
	if v13 and v13:IsA("Frame") then
		v_u_8 = v13
		return v13
	end
	local v14 = Instance.new("Frame")
	v14.Name = v_u_4.LayerName
	v14.Size = UDim2.fromScale(1, 1)
	v14.BackgroundTransparency = 1
	v14.BorderSizePixel = 0
	v14.Active = false
	v14.ZIndex = v_u_4.ZIndex
	v14.Parent = v12
	v_u_8 = v14
	return v14
end
local function v_u_41(p16, p17) -- name: spawnPiece
	-- upvalues: (copy) v_u_9, (copy) v_u_4, (copy) v_u_7
	if #v_u_9 < v_u_4.MaxPieces then
		local v18 = p17.X
		local v19 = p17.Y
		local v20 = v_u_4.PieceWidth
		local v21 = v_u_7:NextNumber(v20.Min, v20.Max) * v19
		local v22 = v_u_4.PieceLength
		local v23 = v_u_7:NextNumber(v22.Min, v22.Max) * v19
		local v24 = math.max(v21, v23) * 0.5
		local v25 = v19 + v23
		local v26 = v_u_4.PeakAboveTop
		local v27 = -v_u_7:NextNumber(v26.Min, v26.Max) * v19 - v23
		local v28 = 2 * (v_u_4.Gravity * v19) * (v25 - v27)
		local v29 = math.sqrt(v28)
		local v30 = v_u_7:NextNumber(0, 360)
		local v31 = Instance.new("Frame")
		v31.Name = "Confetti"
		v31.AnchorPoint = Vector2.new(0.5, 0.5)
		v31.BorderSizePixel = 0
		v31.Active = false
		v31.BackgroundColor3 = v_u_4.Colors[v_u_7:NextInteger(1, #v_u_4.Colors)]
		v31.Size = UDim2.fromOffset(v21, v23)
		v31.Rotation = v30
		local v32 = {
			["frame"] = v31
		}
		local v33 = v_u_7
		local v34 = v18 - v24
		v32.x = v33:NextNumber(v24, (math.max(v34, v24)))
		v32.y = v25
		v32.vx = v_u_7:NextNumber(-v_u_4.SideSpeed, v_u_4.SideSpeed) * v19
		v32.vy = -v29
		v32.halfWidth = v24
		v32.halfLength = v23 * 0.5
		local v35 = v_u_4.FallSpeed
		v32.fallSpeed = v_u_7:NextNumber(v35.Min, v35.Max) * v19
		local v36 = v_u_4.SwayDistance
		v32.swayDistance = v_u_7:NextNumber(v36.Min, v36.Max) * v19
		local v37 = v_u_4.SwaySpeed
		v32.swaySpeed = v_u_7:NextNumber(v37.Min, v37.Max)
		v32.swayPhase = v_u_7:NextNumber(0, 6.283185307179586)
		v32.baseRotation = v30
		local v38 = v_u_4.WobbleDegrees
		v32.wobble = v_u_7:NextNumber(v38.Min, v38.Max)
		local v39 = v_u_4.WobbleSpeed
		v32.wobbleSpeed = v_u_7:NextNumber(v39.Min, v39.Max)
		v32.wobblePhase = v_u_7:NextNumber(0, 6.283185307179586)
		v31.Position = UDim2.fromOffset(v32.x, v32.y)
		v31.Parent = p16
		local v40 = v_u_9
		table.insert(v40, v32)
	end
end
local function v_u_65(p42) -- name: step
	-- upvalues: (ref) v_u_8, (copy) v_u_9, (copy) v_u_10, (copy) v_u_41, (copy) v_u_4, (ref) v_u_11
	local v43 = v_u_8
	if v43 and v43.Parent then
		local v44 = v43.AbsoluteSize
		for v45 = #v_u_10, 1, -1 do
			local v46 = v_u_10[v45]
			v46.timer = v46.timer + p42
			while v46.remaining > 0 and v46.timer >= v46.interval do
				v46.timer = v46.timer - v46.interval
				v46.remaining = v46.remaining - 1
				v_u_41(v43, v44)
			end
			if v46.remaining > 0 then
				break
			end
			table.remove(v_u_10, v45)
		end
		local v47 = v_u_4.Gravity * v44.Y
		local v48 = -v_u_4.SideDrag * p42
		local v49 = math.exp(v48)
		for v50 = #v_u_9, 1, -1 do
			local v51 = v_u_9[v50]
			local v52 = v51.frame
			local v53 = v51.vy + v47 * p42
			local v54 = v51.fallSpeed
			v51.vy = math.min(v53, v54)
			v51.vx = v51.vx * v49
			local v55 = v51.vy > 0
			local v56 = v51.x + v51.vx * p42
			if v55 then
				v51.swayPhase = v51.swayPhase + v51.swaySpeed * p42
				local v57 = v51.swayPhase
				v56 = v56 + math.sin(v57) * v51.swayDistance * p42
			end
			local v58 = v51.halfWidth
			local v59 = v44.X - v51.halfWidth
			local v60 = v51.halfWidth
			local v61 = math.max(v59, v60)
			v51.x = math.clamp(v56, v58, v61)
			v51.y = v51.y + v51.vy * p42
			if v55 and v51.y - v51.halfWidth > v44.Y or not v52.Parent then
				v52:Destroy()
				v_u_9[v50] = v_u_9[#v_u_9]
				v_u_9[#v_u_9] = nil
			else
				v52.Position = UDim2.fromOffset(v51.x, v51.y)
				if not v55 then
					continue
				end
				v51.wobblePhase = v51.wobblePhase + v51.wobbleSpeed * p42
				local v62 = v51.baseRotation
				local v63 = v51.wobblePhase
				v52.Rotation = v62 + math.sin(v63) * v51.wobble
			end
		end
	else
		for _, v64 in v_u_9 do
			v64.frame:Destroy()
		end
		table.clear(v_u_9)
		table.clear(v_u_10)
	end
	if #v_u_9 == 0 and (#v_u_10 == 0 and v_u_11) then
		v_u_11:Disconnect()
		v_u_11 = nil
	end
end
function v5.Burst() -- name: Burst
	-- upvalues: (copy) v_u_15, (copy) v_u_4, (copy) v_u_10, (ref) v_u_11, (copy) v_u_3, (copy) v_u_65
	if v_u_15() then
		local v66 = v_u_4.PieceCount
		local v67 = math.max(v66, 1)
		local v68 = v_u_4.SpawnDuration / v67
		local v69 = v_u_10
		table.insert(v69, {
			["remaining"] = v67,
			["interval"] = v68,
			["timer"] = v68
		})
		if not v_u_11 then
			v_u_11 = v_u_3.RenderStepped:Connect(v_u_65)
		end
	end
end
function v5.Start() -- name: Start
	-- upvalues: (copy) v_u_6, (copy) v_u_4, (copy) v_u_15
	v_u_6:WaitForChild("PlayerGui"):WaitForChild(v_u_4.GuiName, 30)
	v_u_15()
end
return v5
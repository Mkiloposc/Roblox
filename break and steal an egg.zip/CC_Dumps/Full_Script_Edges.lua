local v1 = game:GetService("CorePackages")
local v_u_2 = UserSettings():GetService("UserGameSettings")
local v_u_3 = settings():FindFirstChild("Game Options")
local v_u_4 = game:GetService("UserInputService")
local v_u_5 = nil
pcall(function()
	-- upvalues: (ref) v_u_5
	v_u_5 = game:GetService("PlatformService")
end)
local v6 = game:GetService("CoreGui").RobloxGui.Modules
local v_u_7 = require(v1.Packages.React)
local v_u_8 = require(v6.Shell.Utility)
local v_u_9 = require(v6.Shell.Components.ContextActionEvent)
local v_u_10 = require(v1.Workspace.Packages.RoactUtils).ExternalEventConnection
local v_u_11 = require(v6.Shell.Components.RenderStep)
local v_u_12 = game:GetEngineFeature("MigrateOverscanToGameBasicSettings")
local v_u_13 = Vector2.new(0.85, 0.85)
local v_u_14 = Vector2.new(0.9, 0.9)
local v_u_15 = Vector2.new(1920, 1080)
local v_u_16 = Vector2.new(0, 0)
local function v_u_18(p17) -- name: EdgeImage
	-- upvalues: (copy) v_u_7
	return v_u_7.createElement("ImageLabel", {
		["Size"] = nil,
		["Position"] = nil,
		["AnchorPoint"] = nil,
		["BackgroundTransparency"] = 1,
		["Rotation"] = nil,
		["Image"] = "rbxasset://textures/ui/Shell/ScreenAdjustment/ScreenAdjustmentArrow.png",
		["Size"] = UDim2.new(0, 95, 0, 95),
		["Position"] = p17.Position,
		["AnchorPoint"] = p17.AnchorPoint,
		["Rotation"] = p17.Rotation
	})
end
local v19 = v_u_7.Component:extend("Edges")
function v19.init(p_u_20) -- name: init
	-- upvalues: (copy) v_u_8, (copy) v_u_13, (copy) v_u_15, (copy) v_u_16, (copy) v_u_12, (copy) v_u_2, (copy) v_u_3, (copy) v_u_14, (copy) v_u_4
	function p_u_20.onAdjustThumbstick(_, _, p21)
		-- upvalues: (copy) p_u_20, (ref) v_u_8
		p_u_20._stickPosition = v_u_8.GamepadLinearToCurve(Vector2.new(p21.Position.X, -p21.Position.Y), 0.2)
	end
	function p_u_20.onAccept()
		-- upvalues: (ref) v_u_12, (ref) v_u_2, (copy) p_u_20, (ref) v_u_3
		local _, _ = pcall(function()
			-- upvalues: (ref) v_u_12, (ref) v_u_2, (ref) p_u_20, (ref) v_u_3
			if v_u_12 then
				local v22 = v_u_2
				local v23 = Vector2.new
				local v24 = p_u_20._edgePercent.X
				local v25 = math.min(1, v24)
				local v26 = p_u_20._edgePercent.Y
				v22.Overscan = v23(v25, (math.min(1, v26)))
			else
				local v27 = v_u_3
				local v28 = p_u_20._edgePercent.X
				v27.OverscanPX = math.min(1, v28)
				local v29 = v_u_3
				local v30 = p_u_20._edgePercent.Y
				v29.OverscanPY = math.min(1, v30)
			end
		end)
		if p_u_20.props.onSetEdges then
			p_u_20.props.onSetEdges()
		end
	end
	function p_u_20.onRenderStep()
		-- upvalues: (copy) p_u_20, (ref) v_u_16, (ref) v_u_8, (ref) v_u_13, (ref) v_u_15
		local v31 = tick()
		if p_u_20._lastUpdate then
			if p_u_20._stickPosition == v_u_16 then
				p_u_20._acceleration = 1
			else
				local v32 = v31 - p_u_20._lastUpdate
				local v33 = p_u_20
				local v34 = p_u_20._stickPosition * p_u_20._acceleration * v32 * 0.05 + p_u_20._edgePercent
				v33._edgePercent = v_u_8.ClampVector2(v_u_13, Vector2.new(1, 1), v34)
				local v35 = p_u_20
				local v36 = p_u_20._acceleration + v32 * 1
				v35._acceleration = math.min(v36, 3)
				local v37 = p_u_20
				local v38 = {}
				local v39 = p_u_20._edgePercent * v_u_15
				local v40 = Vector2.new(v_u_8.Round(v39.X / 2), v_u_8.Round(v39.Y / 2)) * 2
				v38.currentSize = v_u_8.ClampVector2(v_u_16, v_u_15, v40)
				v37:setState(v38)
			end
		end
		p_u_20._lastUpdate = v31
	end
	function p_u_20.onSuspended()
		-- upvalues: (ref) v_u_12, (ref) v_u_2, (copy) p_u_20, (ref) v_u_3
		pcall(function()
			-- upvalues: (ref) v_u_12, (ref) v_u_2, (ref) p_u_20, (ref) v_u_3
			if v_u_12 then
				v_u_2.Overscan = Vector2.new(p_u_20._lastSavedOverscan.X, p_u_20._lastSavedOverscan.Y)
			else
				v_u_3.OverscanPX = p_u_20._lastSavedOverscan.X
				v_u_3.OverscanPY = p_u_20._lastSavedOverscan.Y
			end
		end)
	end
	local v41 = v_u_14
	local v_u_42 = v_u_8.ClampVector2(v_u_13, Vector2.new(1, 1), v41)
	local v43 = v_u_42 * v_u_15
	local v44 = Vector2.new(v_u_8.Round(v43.X / 2), v_u_8.Round(v43.Y / 2)) * 2
	local v_u_45 = v_u_8.ClampVector2(v_u_16, v_u_15, v44)
	if v_u_4:GetPlatform() == Enum.Platform.XBoxOne then
		pcall(function()
			-- upvalues: (ref) v_u_12, (ref) v_u_2, (ref) v_u_42, (ref) v_u_8, (ref) v_u_13, (ref) v_u_45, (ref) v_u_15, (ref) v_u_16, (copy) p_u_20, (ref) v_u_3
			if v_u_12 then
				if v_u_2.Overscan.x > 0 and v_u_2.Overscan.y > 0 then
					v_u_42 = Vector2.new(v_u_2.Overscan.x, v_u_2.Overscan.y)
					local v46 = v_u_42
					v_u_42 = v_u_8.ClampVector2(v_u_13, Vector2.new(1, 1), v46)
					local v47 = v_u_42 * v_u_15
					local v48 = Vector2.new(v_u_8.Round(v47.X / 2), v_u_8.Round(v47.Y / 2)) * 2
					v_u_45 = v_u_8.ClampVector2(v_u_16, v_u_15, v48)
					p_u_20._lastSavedOverscan = Vector2.new(v_u_2.Overscan.x, v_u_2.Overscan.y)
					v_u_2.Overscan = Vector2.new(1, 1)
					return
				end
			elseif v_u_3.OverscanPX > 0 and v_u_3.OverscanPY > 0 then
				v_u_42 = Vector2.new(v_u_3.OverscanPX, v_u_3.OverscanPY)
				local v49 = v_u_42
				v_u_42 = v_u_8.ClampVector2(v_u_13, Vector2.new(1, 1), v49)
				local v50 = v_u_42 * v_u_15
				local v51 = Vector2.new(v_u_8.Round(v50.X / 2), v_u_8.Round(v50.Y / 2)) * 2
				v_u_45 = v_u_8.ClampVector2(v_u_16, v_u_15, v51)
				p_u_20._lastSavedOverscan = Vector2.new(v_u_3.OverscanPX, v_u_3.OverscanPY)
				v_u_3.OverscanPX = 1
				v_u_3.OverscanPY = 1
			end
		end)
	end
	p_u_20._stickPosition = v_u_16
	p_u_20._edgePercent = v_u_42
	p_u_20._lastUpdate = nil
	p_u_20._acceleration = 1
	p_u_20._seenAPressed = false
	p_u_20.state = {
		["currentSize"] = v_u_45
	}
end
function v19.render(p52) -- name: render
	-- upvalues: (copy) v_u_7, (copy) v_u_18, (copy) v_u_11, (copy) v_u_9, (ref) v_u_5, (copy) v_u_10
	local v53 = v_u_7.createElement
	local v54 = "Frame"
	local v55 = {
		["Size"] = nil,
		["Position"] = nil,
		["AnchorPoint"] = nil,
		["BackgroundTransparency"] = 1,
		["Size"] = UDim2.new(0, p52.state.currentSize.X, 0, p52.state.currentSize.Y),
		["Position"] = UDim2.new(0.5, 0, 0.5, 0),
		["AnchorPoint"] = Vector2.new(0.5, 0.5)
	}
	local v56 = {
		["SelectionImage"] = v_u_7.createElement("ImageLabel", {
			["Size"] = nil,
			["Position"] = nil,
			["BackgroundTransparency"] = 1,
			["ScaleType"] = nil,
			["SliceCenter"] = nil,
			["Image"] = "rbxasset://textures/ui/Shell/ScreenAdjustment/ScreenRangeOverlay.png",
			["Size"] = UDim2.new(1, 2, 1, 2),
			["Position"] = UDim2.new(0, -1, 0, -1),
			["ScaleType"] = Enum.ScaleType.Slice,
			["SliceCenter"] = Rect.new(21, 21, 41, 41)
		}),
		["TopLeft"] = v_u_7.createElement(v_u_18, {
			["Rotation"] = 0,
			["Position"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = UDim2.new(0, 0, 0, 0),
			["AnchorPoint"] = Vector2.new(0, 0)
		}),
		["TopRight"] = v_u_7.createElement(v_u_18, {
			["Rotation"] = 90,
			["Position"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = UDim2.new(1, 0, 0, 0),
			["AnchorPoint"] = Vector2.new(1, 0)
		}),
		["BottomRight"] = v_u_7.createElement(v_u_18, {
			["Rotation"] = 180,
			["Position"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = UDim2.new(1, 0, 1, 0),
			["AnchorPoint"] = Vector2.new(1, 1)
		}),
		["BottomLeft"] = v_u_7.createElement(v_u_18, {
			["Rotation"] = 270,
			["Position"] = nil,
			["AnchorPoint"] = nil,
			["Position"] = UDim2.new(0, 0, 1, 0),
			["AnchorPoint"] = Vector2.new(0, 1)
		}),
		["Render"] = v_u_7.createElement(v_u_11, {
			["name"] = "UpdateAdjustmentScreen",
			["priority"] = nil,
			["callback"] = nil,
			["priority"] = Enum.RenderPriority.Input.Value,
			["callback"] = p52.onRenderStep
		}),
		["AdjustConnectorThumbstick"] = v_u_7.createElement(v_u_9, {
			["name"] = "ThumbstickAdjustmentScreen",
			["callback"] = nil,
			["binds"] = nil,
			["callback"] = p52.onAdjustThumbstick,
			["binds"] = { Enum.KeyCode.Thumbstick2 }
		})
	}
	local v57 = v_u_5
	if v57 then
		v57 = v_u_7.createElement(v_u_10, {
			["event"] = v_u_5.Suspended,
			["callback"] = p52.onSuspended
		})
	end
	v56.SuspendedCn = v57
	return v53(v54, v55, v56)
end
return v19
local v_u_1 = game:GetService("AnimationClipProvider")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Shared.KeyframeRegistrar)
local v_u_4 = {
	["StrippedAttribute"] = "NoLegs"
}
local v_u_5 = {
	["LeftUpperLeg"] = true,
	["RightUpperLeg"] = true,
	["Left Leg"] = true,
	["Right Leg"] = true
}
function v_u_4.StripSequence(p6) -- name: StripSequence
	-- upvalues: (copy) v_u_5
	local v7 = 0
	for _, v8 in p6:GetDescendants() do
		if not ((v8:IsA("Pose") or v8:IsA("Folder")) and (v_u_5[v8.Name] and v8.Parent)) then
			continue
		end
		for _, v9 in v8:GetDescendants() do
			if not (v9:IsA("Pose") or v9:IsA("Folder")) then
				continue
			end
			v7 = v7 + 1
		end
		v7 = v7 + 1
		v8:Destroy()
	end
	return v7
end
v_u_4.UpperBodyAttribute = "UpperBodyOnly"
local v_u_10 = {
	["HumanoidRootPart"] = true,
	["Head"] = true,
	["LowerTorso"] = true,
	["Torso"] = true
}
function v_u_4.MaskUpperBodySequence(p11) -- name: MaskUpperBodySequence
	-- upvalues: (copy) v_u_4, (copy) v_u_10
	local v12 = v_u_4.StripSequence(p11)
	for _, v13 in p11:GetDescendants() do
		if not v_u_10[v13.Name] then
			continue
		end
		if v13:IsA("Pose") then
			v13.Weight = 0
		else
			if not v13:IsA("Folder") then
				continue
			end
			for _, v14 in v13:GetChildren() do
				if v14:IsA("Folder") then
					continue
				end
				v14:Destroy()
			end
		end
	end
	return v12
end
local v_u_15 = {}
local v_u_16 = {}
local v_u_17 = {}
local v_u_18 = {}
local function v_u_33(p19, p20, p21, p22, p23, p_u_24) -- name: buildMasked
	-- upvalues: (copy) v_u_3, (copy) v_u_1
	local v_u_25 = p19.AnimationId
	if v_u_25 == "" then
		return p19
	end
	local v26 = p22[v_u_25]
	if v26 then
		return v26
	end
	if p23[v_u_25] then
		return p19
	end
	if v_u_3.IsBlocked() then
		p23[v_u_25] = true
		return p19
	end
	local function v28()
		-- upvalues: (ref) v_u_1, (copy) v_u_25, (copy) p_u_24
		local v27 = v_u_1:GetAnimationClipAsync(v_u_25)
		p_u_24(v27)
		return v27
	end
	local v29, v30 = pcall(v28)
	if not v29 then
		p23[v_u_25] = true
		warn((("AnimationLegMask: could not fetch/mask %* (%*), playing it as-is: %*"):format(p19.Name, v_u_25, v30)))
		return p19
	end
	local v31 = v_u_3.Register(v30)
	if v31 == nil then
		p23[v_u_25] = true
		if not v_u_3.IsBlocked() then
			warn((("AnimationLegMask: could not register masked %* (%*), playing it as-is"):format(p19.Name, v_u_25)))
		end
		return p19
	end
	local v32 = Instance.new("Animation")
	v32.Name = p20 or p19.Name .. p21
	v32.AnimationId = v31
	p22[v_u_25] = v32
	return v32
end
function v_u_4.Get(p34, p35) -- name: Get
	-- upvalues: (copy) v_u_4, (copy) v_u_33, (copy) v_u_15, (copy) v_u_16
	if p34:GetAttribute(v_u_4.StrippedAttribute) == true then
		return p34
	else
		return v_u_33(p34, p35, "_NoLegs", v_u_15, v_u_16, v_u_4.StripSequence)
	end
end
function v_u_4.GetUpperBody(p36, p37) -- name: GetUpperBody
	-- upvalues: (copy) v_u_4, (copy) v_u_33, (copy) v_u_17, (copy) v_u_18
	if p36:GetAttribute(v_u_4.UpperBodyAttribute) == true then
		return p36
	else
		return v_u_33(p36, p37, "_UpperBody", v_u_17, v_u_18, v_u_4.MaskUpperBodySequence)
	end
end
return v_u_4
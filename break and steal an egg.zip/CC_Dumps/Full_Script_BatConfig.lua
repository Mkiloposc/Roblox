local v_u_9 = {
	["ToolName"] = "Bat",
	["TemplatesFolderName"] = "Tools",
	["SwingAnimationName"] = "Bat Swing",
	["TutorialEndDelay"] = 20,
	["ClientCooldown"] = 0.6,
	["ServerCooldown"] = 0.7,
	["HellClientCooldown"] = 0.5,
	["HellServerCooldown"] = 0.45,
	["HellCooldownJitter"] = 0.25,
	["SwingSpeed"] = 1.75,
	["SwingTrimEnd"] = 2,
	["Targeting"] = nil,
	["Highlight"] = nil,
	["PostRagdollImmunity"] = 1,
	["Knockback"] = nil,
	["HitRemoteName"] = "BatHitRequest",
	["DefaultTier"] = 1,
	["TierAttribute"] = "BatTier",
	["NameAttribute"] = "BatName",
	["Tiers"] = nil,
	["Targeting"] = {
		["HitTolerance"] = 2,
		["MaximumTargetViewAge"] = 0.35,
		["TargetViewSamplePadding"] = 0.05,
		["RangeMultiplierAttribute"] = "BatHitboxMultiplier",
		["MinRangeMultiplier"] = 0.1,
		["MaxRangeMultiplier"] = 20
	},
	["Highlight"] = {
		["FillColor"] = nil,
		["OutlineColor"] = nil,
		["FillTransparency"] = 0.5,
		["OutlineTransparency"] = 0.15,
		["FadeTime"] = 0.18,
		["FillColor"] = Color3.fromRGB(255, 0, 0),
		["OutlineColor"] = Color3.fromRGB(107, 0, 0)
	},
	["Knockback"] = {
		["Variance"] = 0.15,
		["MinDistance"] = 5,
		["LaunchAngle"] = 28,
		["TimeScale"] = 1.35,
		["MinGravityScale"] = 1,
		["TumbleSpin"] = 9,
		["SettleTime"] = 0.5,
		["MinDuration"] = 1
	},
	["Tiers"] = {
		{
			["Name"] = "Bat",
			["Template"] = "Bat",
			["Range"] = 15,
			["Knockback"] = 17.5,
			["Zone"] = 1
		},
		{
			["Name"] = "Cactus Bat",
			["Template"] = "CactusBat",
			["Range"] = 18,
			["Knockback"] = 24,
			["Zone"] = 2
		},
		{
			["Name"] = "Frost Bat",
			["Template"] = "FrostBat",
			["Range"] = 19.5,
			["Knockback"] = 27,
			["Zone"] = 3
		},
		{
			["Name"] = "Candy Bat",
			["Template"] = "CandyBat",
			["Range"] = 21,
			["Knockback"] = 30,
			["Zone"] = 4
		},
		{
			["Name"] = "Tree Bat",
			["Template"] = "TreeBat",
			["Range"] = 22.5,
			["Knockback"] = 33,
			["Zone"] = 5
		},
		{
			["Name"] = "Lake Bat",
			["Template"] = "LakeBat",
			["Range"] = 24,
			["Knockback"] = 36,
			["Zone"] = 6
		},
		{
			["Name"] = "Lava Bat",
			["Template"] = "LavaBat",
			["Range"] = 25.5,
			["Knockback"] = 39,
			["Zone"] = 7
		},
		{
			["Name"] = "Blossom Bat",
			["Template"] = "BlossomBat",
			["Range"] = 27,
			["Knockback"] = 42,
			["Zone"] = 8
		},
		{
			["Name"] = "Galaxy Bat",
			["Template"] = "GalaxyBat",
			["Range"] = 28.5,
			["Knockback"] = 45,
			["Zone"] = 9
		},
		{
			["Name"] = "Electric Hammer",
			["Template"] = "Electric Hammer",
			["Range"] = 30,
			["Knockback"] = 48,
			["Zone"] = 10,
			["KeepOutOfChatBubble"] = true,
			["ImageRotation"] = 40
		},
		{
			["Name"] = "Halloween Scythe",
			["Template"] = "Halloween Scythe",
			["Range"] = 31.5,
			["Knockback"] = 51,
			["Zone"] = "Halloween",
			["KeepOutOfChatBubble"] = true
		},
		{
			["Name"] = "Halloween Shovel",
			["Template"] = "Halloween Shovel",
			["Range"] = 33,
			["Knockback"] = 54,
			["Zone"] = 11,
			["KeepOutOfChatBubble"] = true,
			["ImageRotation"] = 40
		},
		{
			["Name"] = "Royal Sword",
			["Template"] = "Royal Sword",
			["Range"] = 34.5,
			["Knockback"] = 57,
			["Zone"] = 12,
			["KeepOutOfChatBubble"] = true,
			["ImageRotation"] = 40
		}
	},
	["Unlock"] = {
		["RemoteName"] = "BatUnlockRemote",
		["ClaimText"] = "Claim",
		["EquippedText"] = "Equipped",
		["EquipText"] = "Equip",
		["EquippedColor"] = nil,
		["EquippedColor"] = Color3.fromRGB(60, 255, 60)
	},
	["ClampTier"] = function(p1) -- name: ClampTier
		-- upvalues: (copy) v_u_9
		if typeof(p1) ~= "number" or p1 ~= p1 then
			return v_u_9.DefaultTier
		end
		local v2 = math.floor(p1)
		local v3 = #v_u_9.Tiers
		return math.clamp(v2, 1, v3)
	end,
	["GetTier"] = function(p4) -- name: GetTier
		-- upvalues: (copy) v_u_9
		return v_u_9.Tiers[v_u_9.ClampTier(p4)]
	end,
	["GetToolTier"] = function(p5) -- name: GetToolTier
		-- upvalues: (copy) v_u_9
		local v6 = v_u_9.GetTier
		if p5 then
			p5 = p5:GetAttribute(v_u_9.TierAttribute)
		end
		return v6(p5)
	end,
	["ImageRotationFor"] = function(p7) -- name: ImageRotationFor
		-- upvalues: (copy) v_u_9
		local v8 = v_u_9.GetTier(p7).ImageRotation
		return typeof(v8) ~= "number" and 0 or v8
	end
}
return v_u_9
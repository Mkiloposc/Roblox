local v_u_1 = game:GetService("TweenService")
local v_u_2 = require(script.Parent.AnimalChatConfig)
local v_u_3 = require(script.Parent.AnimalOverhead)
local v_u_4 = require(script.Parent.BillboardAssets)
local v_u_5 = require(script.Parent.ChatBubbleSize)
local v_u_6 = {}
local v_u_7 = false
function v_u_6.Template() -- name: Template
	-- upvalues: (copy) v_u_2, (copy) v_u_4, (ref) v_u_7
	for _, v8 in v_u_2.TemplateNames do
		local v9 = v_u_4.Find(v8)
		if not v9 then
			continue
		end
		return v9
	end
	if not v_u_7 then
		v_u_7 = true
		warn((("[AnimalBubble] ReplicatedStorage.Assets.BillboardGui.%* (BillboardGui) not found \226\128\148 no speech bubbles"):format(v_u_2.TemplateNames[1])))
	end
	return nil
end
function v_u_6.HeadPosition(p10) -- name: HeadPosition
	for _, v11 in p10:GetDescendants() do
		if not v11.Name:lower():find("head", 1, true) then
			continue
		end
		if v11:IsA("Bone") then
			return v11.TransformedWorldCFrame.Position
		end
		if not v11:IsA("BasePart") then
			continue
		end
		local v12 = v11.Position
		local v13 = v11.Size.Y / 2
		return v12 + Vector3.new(0, v13, 0)
	end
	local v14, v15 = p10:GetBoundingBox()
	local v16 = v14.Position
	local v17 = v15.Y / 2
	return v16 + Vector3.new(0, v17, 0)
end
local function v_u_29(p18, p19) -- name: placeOverHead
	-- upvalues: (copy) v_u_6, (copy) v_u_2
	local v20 = v_u_6.HeadPosition(p18)
	local v21, v22 = p18:GetBoundingBox()
	local v23 = v21.Position.Y + v22.Y / 2
	local v24 = v20.Y + v_u_2.HeightAboveHead
	local v25 = v23 + v_u_2.HeightAboveTop
	local v26 = math.max(v24, v25)
	local v27 = v20.X
	local v28 = v20.Z
	p19.WorldPosition = Vector3.new(v27, v26, v28)
	p19:SetAttribute(v_u_2.HeadAnchoredAttribute, true)
end
local function v_u_36(p30, p31, p32) -- name: isStackedOnOverhead
	-- upvalues: (copy) v_u_3, (copy) v_u_2
	local v33 = p31:FindFirstChild(v_u_3.AttachmentName)
	local v34
	if v33 and v33:IsA("Attachment") then
		v34 = v33.WorldPosition
	else
		v34 = p30:GetBoundingBox().Position
	end
	local v35 = p32.WorldPosition - v34
	return Vector2.new(v35.X, v35.Z).Magnitude <= v_u_2.StackedTolerance
end
function v_u_6.Attachment(p37) -- name: Attachment
	-- upvalues: (copy) v_u_2, (copy) v_u_36, (copy) v_u_29
	local v38 = p37.PrimaryPart or p37:FindFirstChildWhichIsA("BasePart", true)
	if not v38 then
		return nil
	end
	local v39 = v38:FindFirstChild(v_u_2.AttachmentName)
	if v39 and v39:IsA("Attachment") then
		if v39:GetAttribute(v_u_2.HeadAnchoredAttribute) ~= true and v_u_36(p37, v38, v39) then
			v_u_29(p37, v39)
		end
		return v39
	end
	local v40 = Instance.new("Attachment")
	v40.Name = v_u_2.AttachmentName
	v40.Parent = v38
	v_u_29(p37, v40)
	return v40
end
local function v_u_51(p41) -- name: overheadRowsTop
	-- upvalues: (copy) v_u_3
	local v42 = p41.PrimaryPart or p41:FindFirstChildWhichIsA("BasePart", true)
	if v42 then
		v42 = v42:FindFirstChild(v_u_3.AttachmentName)
	end
	local v43
	if v42 then
		v43 = v42:FindFirstChildWhichIsA("BillboardGui")
	else
		v43 = v42
	end
	if not (v42 and (v42:IsA("Attachment") and (v43 and v43.Enabled))) then
		return nil
	end
	local v44 = v43.Size.Y.Scale
	local v45 = v43:FindFirstChildWhichIsA("UIListLayout")
	local v46 = not v45 and 0 or v45.Padding.Scale
	local v47 = 0
	local v48 = 0
	for _, v49 in v43:GetChildren() do
		if not (v49:IsA("GuiObject") and v49.Visible) then
			continue
		end
		v47 = v47 + v49.Size.Y.Scale
		v48 = v48 + 1
	end
	if v48 == 0 then
		return nil
	end
	local v50 = v47 + v46 * (v48 - 1)
	return v42.WorldPosition.Y + v50 * v44
end
local function v_u_62(p52, p53, p54, p55) -- name: clearOverhead
	-- upvalues: (copy) v_u_51, (copy) v_u_2
	local v56 = v_u_51(p52)
	if v56 then
		local v57 = p54:FindFirstChild(v_u_2.BubbleRootName, true)
		local v58 = not (v57 and v57:IsA("GuiObject")) and 1 or v57.Size.Y.Scale
		local v59 = p55.Y.Scale * v58 / 2
		local v60 = v56 + v_u_2.OverheadClearance + v59 - p53.WorldPosition.Y
		local v61 = math.max(v60, 0)
		p54.StudsOffsetWorldSpace = Vector3.new(0, v61, 0)
	else
		p54.StudsOffsetWorldSpace = Vector3.new(0, 0, 0)
	end
end
function v_u_6.Show(p_u_63, p64, p65) -- name: Show
	-- upvalues: (copy) v_u_6, (copy) v_u_2, (copy) v_u_5, (copy) v_u_62, (copy) v_u_1
	if not p_u_63.Parent then
		return nil
	end
	local v_u_66 = v_u_6.Attachment(p_u_63)
	local v67 = v_u_6.Template()
	if not (v_u_66 and v67) then
		return nil
	end
	local v68 = v_u_2.Bubble
	local v69 = p65 or {}
	local v70 = v69.AppearDelay or v68.AppearDelay
	local v_u_71 = v69.PopTime or v68.PopTime
	local v72 = v69.DisplayTime or v68.DisplayTime
	local v_u_73 = v69.FadeTime or v68.FadeTime
	local v74 = v_u_66:FindFirstChildWhichIsA("BillboardGui")
	if v74 then
		v74:Destroy()
	end
	local v_u_75 = v67:Clone()
	local v76 = v_u_5.Apply(v_u_75, p64)
	local v77 = p_u_63:GetAttribute("SizeMult") or 1
	local v78 = v69.MinScale or v68.MinScale
	local v79 = v69.MaxScale or v68.MaxScale
	local v80 = math.clamp(v77, v78, v79)
	local v_u_81 = UDim2.new(v_u_75.Size.X.Scale * v80 * v76.WidthMult, v_u_75.Size.X.Offset * v80 * v76.WidthMult, v_u_75.Size.Y.Scale * v80, v_u_75.Size.Y.Offset * v80)
	v_u_75.Size = UDim2.new(0, 0, 0, 0)
	v_u_75.Enabled = true
	v_u_75.Parent = v_u_66
	local v_u_82 = v_u_66:GetAttribute(v_u_2.HeadAnchoredAttribute) == true
	task.delay(v70, function()
		-- upvalues: (copy) v_u_75, (copy) v_u_82, (ref) v_u_62, (copy) p_u_63, (copy) v_u_66, (copy) v_u_81, (ref) v_u_1, (copy) v_u_71
		if v_u_75.Parent then
			if v_u_82 then
				v_u_62(p_u_63, v_u_66, v_u_75, v_u_81)
			end
			local v83 = {
				["Size"] = v_u_81
			}
			v_u_1:Create(v_u_75, TweenInfo.new(v_u_71, Enum.EasingStyle.Back, Enum.EasingDirection.Out), v83):Play()
		end
	end)
	task.delay(v70 + v_u_71 + v72, function()
		-- upvalues: (copy) v_u_75, (copy) v_u_73, (ref) v_u_1
		if v_u_75.Parent then
			local v84 = TweenInfo.new(v_u_73, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
			for _, v85 in v_u_75:GetDescendants() do
				if v85:IsA("TextLabel") then
					v_u_1:Create(v85, v84, {
						["TextTransparency"] = 1,
						["BackgroundTransparency"] = 1,
						["TextStrokeTransparency"] = 1
					}):Play()
				elseif v85:IsA("ImageLabel") then
					v_u_1:Create(v85, v84, {
						["ImageTransparency"] = 1,
						["BackgroundTransparency"] = 1
					}):Play()
				else
					if not v85:IsA("Frame") then
						continue
					end
					v_u_1:Create(v85, v84, {
						["BackgroundTransparency"] = 1
					}):Play()
				end
			end
			task.delay(v_u_73, function()
				-- upvalues: (ref) v_u_75
				if v_u_75.Parent then
					v_u_75:Destroy()
				end
			end)
		end
	end)
	return v_u_75
end
return v_u_6
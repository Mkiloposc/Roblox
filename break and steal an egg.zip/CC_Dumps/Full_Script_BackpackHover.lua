local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("TweenService")
local v_u_3 = require(v1.Shared.BackpackUiConfig)
local v_u_4 = require(script.Parent.UiSounds)
local v_u_5 = {
	["ScaleName"] = "BackpackHoverScale"
}
local v_u_6 = TweenInfo.new(v_u_3.HoverTweenTime, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local v_u_7 = setmetatable({}, {
	["__mode"] = "k"
})
function v_u_5.Attach(p_u_8) -- name: Attach
	-- upvalues: (copy) v_u_5, (copy) v_u_7, (copy) v_u_3, (copy) v_u_2, (copy) v_u_6, (copy) v_u_4
	p_u_8.AutoButtonColor = false
	local v_u_9 = p_u_8:FindFirstChild(v_u_5.ScaleName)
	if not (v_u_9 and v_u_9:IsA("UIScale")) then
		v_u_9 = Instance.new("UIScale")
		v_u_9.Name = v_u_5.ScaleName
		v_u_9.Parent = p_u_8
	end
	local v_u_10 = v_u_7[p_u_8]
	if not v_u_10 then
		v_u_10 = {
			["shrink"] = 1,
			["apply"] = nil
		}
		v_u_7[p_u_8] = v_u_10
	end
	v_u_9.Scale = v_u_10.shrink
	local v_u_11 = false
	local v_u_12 = false
	local v_u_13 = false
	local function v_u_16(p14) -- name: apply
		-- upvalues: (ref) v_u_13, (ref) v_u_3, (ref) v_u_11, (ref) v_u_12, (ref) v_u_2, (copy) v_u_9, (ref) v_u_6, (copy) v_u_10
		local v15
		if v_u_13 then
			v15 = v_u_3.PressScale
		else
			v15 = not (v_u_11 or v_u_12) and 1 or v_u_3.HoverScale
		end
		v_u_2:Create(v_u_9, p14 or v_u_6, {
			["Scale"] = v15 * v_u_10.shrink
		}):Play()
	end
	v_u_10.apply = v_u_16
	p_u_8.MouseEnter:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_4, (copy) v_u_16
		if not v_u_11 then
			v_u_4.Hover()
		end
		v_u_11 = true
		v_u_16()
	end)
	p_u_8.MouseLeave:Connect(function()
		-- upvalues: (ref) v_u_11, (ref) v_u_13, (copy) v_u_16
		v_u_11 = false
		v_u_13 = false
		v_u_16()
	end)
	p_u_8.MouseButton1Down:Connect(function()
		-- upvalues: (ref) v_u_13, (copy) v_u_16
		v_u_13 = true
		v_u_16()
	end)
	p_u_8.MouseButton1Up:Connect(function()
		-- upvalues: (ref) v_u_13, (copy) v_u_16
		v_u_13 = false
		v_u_16()
	end)
	p_u_8.SelectionGained:Connect(function()
		-- upvalues: (ref) v_u_12, (ref) v_u_4, (copy) v_u_16
		if not v_u_12 then
			v_u_4.Hover()
		end
		v_u_12 = true
		v_u_16()
	end)
	p_u_8.SelectionLost:Connect(function()
		-- upvalues: (ref) v_u_12, (ref) v_u_13, (copy) v_u_16
		v_u_12 = false
		v_u_13 = false
		v_u_16()
	end)
	p_u_8.Activated:Connect(v_u_4.Click)
	p_u_8:GetPropertyChangedSignal("Visible"):Connect(function()
		-- upvalues: (copy) p_u_8, (ref) v_u_11, (ref) v_u_12, (ref) v_u_13, (copy) v_u_9, (copy) v_u_10
		if not p_u_8.Visible then
			v_u_11 = false
			v_u_12 = false
			v_u_13 = false
			v_u_9.Scale = v_u_10.shrink
		end
	end)
end
function v_u_5.SetShrink(p17, p18, p19) -- name: SetShrink
	-- upvalues: (copy) v_u_7
	local v20 = v_u_7[p17]
	if not v20 then
		v20 = {
			["shrink"] = 1,
			["apply"] = nil
		}
		v_u_7[p17] = v20
	end
	if v20.shrink ~= p18 then
		v20.shrink = p18
		if v20.apply then
			v20.apply(p19)
		end
	end
end
function v_u_5.Reset(p21) -- name: Reset
	-- upvalues: (copy) v_u_5
	local v22 = p21:FindFirstChild(v_u_5.ScaleName)
	if v22 and v22:IsA("UIScale") then
		v22.Scale = 1
	end
end
return v_u_5
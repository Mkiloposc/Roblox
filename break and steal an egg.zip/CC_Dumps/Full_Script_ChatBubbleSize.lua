local v_u_1 = game:GetService("RunService")
local v_u_2 = game:GetService("TextService")
local v_u_3 = require(script.Parent.AnimalChatConfig)
local v_u_46 = {
	["TextAspect"] = function(p_u_4, p_u_5) -- name: TextAspect
		-- upvalues: (copy) v_u_1, (copy) v_u_2
		if p_u_4 == "" then
			return 0
		end
		if not v_u_1:IsClient() then
			local v_u_6 = 0
			local function v11()
				-- upvalues: (copy) p_u_4, (ref) v_u_6
				for _, v7 in utf8.codes(p_u_4) do
					local v8 = v_u_6
					local v9
					if v7 == 32 then
						v9 = 0.28
					elseif v7 >= 8592 then
						v9 = 1.15
					elseif v7 < 128 then
						local v10 = string.char(v7)
						v9 = ("ijlItf.,:;\'`|!()[]{}"):find(v10, 1, true) and 0.3 or (("mwMW@%"):find(v10, 1, true) and 0.92 or 0.55)
					else
						v9 = 0.6
					end
					v_u_6 = v8 + v9
				end
			end
			if not pcall(v11) then
				v_u_6 = #p_u_4 * 0.55
			end
			return v_u_6 / 1.2
		end
		local function v14()
			-- upvalues: (copy) p_u_4, (copy) p_u_5, (ref) v_u_2
			local v12 = Instance.new("GetTextBoundsParams")
			v12.Text = p_u_4
			v12.Size = 100
			v12.Width = 100000
			if p_u_5 then
				v12.Font = p_u_5
			end
			local v13 = v_u_2:GetTextBoundsAsync(v12)
			v12:Destroy()
			if v13.Y <= 0 or v13.X <= 0 then
				return nil
			else
				return v13.X / v13.Y
			end
		end
		local v15, v16 = pcall(v14)
		if v15 and typeof(v16) == "number" then
			return v16
		end
		local v_u_17 = 0
		local function v22()
			-- upvalues: (copy) p_u_4, (ref) v_u_17
			for _, v18 in utf8.codes(p_u_4) do
				local v19 = v_u_17
				local v20
				if v18 == 32 then
					v20 = 0.28
				elseif v18 >= 8592 then
					v20 = 1.15
				elseif v18 < 128 then
					local v21 = string.char(v18)
					v20 = ("ijlItf.,:;\'`|!()[]{}"):find(v21, 1, true) and 0.3 or (("mwMW@%"):find(v21, 1, true) and 0.92 or 0.55)
				else
					v20 = 0.6
				end
				v_u_17 = v19 + v20
			end
		end
		if not pcall(v22) then
			v_u_17 = #p_u_4 * 0.55
		end
		return v_u_17 / 1.2
	end,
	["Apply"] = function(p23, p24) -- name: Apply
		-- upvalues: (copy) v_u_3, (copy) v_u_46
		local v25 = v_u_3.Bubble.Size
		local v26 = p23:FindFirstChild(v_u_3.BubbleRootName, true)
		local v27 = p23:FindFirstChild(v_u_3.TextLabelName, true)
		if v27 and v27:IsA("TextLabel") then
			v27.Text = p24
		end
		if not (v26 and v26:IsA("Frame")) then
			return {
				["WidthScale"] = 0,
				["WidthMult"] = 1
			}
		end
		local v28 = v26.Size
		local v29 = v28.Y.Scale
		if v29 <= 0 then
			return {
				["WidthScale"] = nil,
				["WidthMult"] = 1,
				["WidthScale"] = v28.X.Scale
			}
		end
		local v30 = p23.Size
		local v31
		if v30.X.Scale > 0 and v30.Y.Scale > 0 then
			v31 = v30.X.Scale / v30.Y.Scale
		else
			v31 = (v30.X.Offset <= 0 or v30.Y.Offset <= 0) and 1 or v30.X.Offset / v30.Y.Offset
		end
		local v32 = v28.X.Scale * v31 / v29
		local v33
		if v27 and v27:IsA("TextLabel") then
			v33 = v27.FontFace
		else
			v33 = nil
		end
		local v34 = (v_u_46.TextAspect(p24, v33) * v25.TextHeightFraction + v25.SidePadding) * v29 / v31
		local v35 = v25.MinWidthScale
		local v36 = v25.MaxWidthScale
		local v37 = math.clamp(v34, v35, v36)
		local v38 = v34 / v37
		local v39 = v25.MaxWidthMult
		local v40 = math.clamp(v38, 1, v39)
		local v41 = v26.Size
		v26.Size = UDim2.new(v37, v41.X.Offset, v41.Y.Scale, v41.Y.Offset)
		local v42 = v26:FindFirstChild(v_u_3.BubbleTailName)
		if v42 and (v42:IsA("GuiObject") and v32 > 0) then
			local v43 = v37 * v40 * v31 / v29
			local v44 = v42.Size
			local v45 = v42.Size.X.Scale * (v32 / v43)
			v42.Size = UDim2.new(v45, v44.X.Offset, v44.Y.Scale, v44.Y.Offset)
		end
		return {
			["WidthScale"] = v37,
			["WidthMult"] = v40
		}
	end
}
return v_u_46
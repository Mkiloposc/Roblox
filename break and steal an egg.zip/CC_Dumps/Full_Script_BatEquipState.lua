local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Shared.BatToolQuery)
local v_u_4 = {}
local v_u_5 = v1.LocalPlayer
v_u_4.Changed = Instance.new("BindableEvent")
local v_u_6 = false
local v_u_7 = false
local v_u_8 = {}
local function v_u_22(p9) -- name: watchCharacter
	-- upvalues: (copy) v_u_8, (copy) v_u_5, (copy) v_u_3, (ref) v_u_6, (copy) v_u_4
	for _, v10 in v_u_8 do
		v10:Disconnect()
	end
	table.clear(v_u_8)
	local function v15(p11) -- name: reread
		-- upvalues: (ref) v_u_5, (ref) v_u_3, (ref) v_u_6, (ref) v_u_4
		if p11:IsA("Tool") then
			local v12 = v_u_5.Character
			local v13
			if v12 then
				for _, v14 in v12:GetChildren() do
					if not v_u_3.IsBatWeapon(v14) then
						continue
					end
					v13 = true
				end
				v13 = false
			else
				v13 = false
			end
			if v_u_6 == v13 then
				return
			end
			v_u_6 = v13
			v_u_4.Changed:Fire(v_u_6)
		end
	end
	local v16 = v_u_8
	local v17 = p9.ChildAdded
	table.insert(v16, v17:Connect(v15))
	local v18 = v_u_8
	local v19 = p9.ChildRemoved
	table.insert(v18, v19:Connect(v15))
	local v20
	if p9 then
		for _, v21 in p9:GetChildren() do
			if not v_u_3.IsBatWeapon(v21) then
				continue
			end
			v20 = true
		end
		v20 = false
	else
		v20 = false
	end
	if v_u_6 ~= v20 then
		v_u_6 = v20
		v_u_4.Changed:Fire(v_u_6)
	end
end
local function v24() -- name: ensureStarted
	-- upvalues: (ref) v_u_7, (copy) v_u_5, (copy) v_u_22, (ref) v_u_6, (copy) v_u_4
	if v_u_7 then
		return
	else
		v_u_7 = true
		v_u_5.CharacterAdded:Connect(v_u_22)
		local v23 = v_u_5.Character
		if v23 then
			v_u_22(v23)
			return
		elseif v_u_6 ~= false then
			v_u_6 = false
			v_u_4.Changed:Fire(v_u_6)
		end
	end
end
function v_u_4.IsEquipped() -- name: IsEquipped
	-- upvalues: (ref) v_u_7, (copy) v_u_5, (copy) v_u_22, (ref) v_u_6, (copy) v_u_4
	if not v_u_7 then
		v_u_7 = true
		v_u_5.CharacterAdded:Connect(v_u_22)
		local v25 = v_u_5.Character
		if v25 then
			v_u_22(v25)
		elseif v_u_6 ~= false then
			v_u_6 = false
			v_u_4.Changed:Fire(v_u_6)
		end
	end
	return v_u_6
end
function v_u_4.Observe(p26) -- name: Observe
	-- upvalues: (ref) v_u_7, (copy) v_u_5, (copy) v_u_22, (ref) v_u_6, (copy) v_u_4
	if not v_u_7 then
		v_u_7 = true
		v_u_5.CharacterAdded:Connect(v_u_22)
		local v27 = v_u_5.Character
		if v27 then
			v_u_22(v27)
		elseif v_u_6 ~= false then
			v_u_6 = false
			v_u_4.Changed:Fire(v_u_6)
		end
	end
	local v28 = v_u_4.Changed.Event:Connect(p26)
	task.spawn(p26, v_u_6)
	return v28
end
v_u_4.Start = v24
return v_u_4
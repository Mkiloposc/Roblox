local v_u_1 = game:GetService("ContentProvider")
local v2 = game:GetService("Players")
local v_u_3 = game:GetService("ReplicatedStorage")
local v_u_4 = game:GetService("RunService")
local v_u_5 = game:GetService("SoundService")
local v_u_6 = require(v_u_3.Shared.AnimationLegMask)
local v_u_7 = require(v_u_3.Shared.BatConfig)
local v_u_8 = require(v_u_3.Shared.BatTargeting)
local v_u_9 = require(v_u_3.Shared.BatToolQuery)
local v_u_10 = require(v_u_3.Shared.SafeZoneQuery)
local v_u_11 = require(script.Parent.BatTargetHighlight)
local v_u_12 = require(script.Parent.NotificationController)
local v13 = {}
local v_u_14 = v2.LocalPlayer
local v_u_15 = nil
local v_u_16 = nil
local v_u_17 = 0
local v_u_18 = 0
local v_u_19 = 0
local v_u_20 = nil
local function v_u_22() -- name: getSwingAnimation
	-- upvalues: (ref) v_u_20, (copy) v_u_3, (copy) v_u_7
	if v_u_20 and v_u_20.Parent then
		return v_u_20
	else
		local v21 = v_u_3:WaitForChild("Assets", 30)
		if v21 then
			v21 = v21:WaitForChild("Animations", 10)
		end
		if v21 then
			v21 = v21:WaitForChild(v_u_7.SwingAnimationName, 10)
		end
		if v21 and v21:IsA("Animation") then
			v_u_20 = v21
			return v21
		else
			warn((("[BatController] Assets.Animations.%* not found"):format(v_u_7.SwingAnimationName)))
			return nil
		end
	end
end
local v_u_23 = nil
local function v_u_28() -- name: getSwingTrack
	-- upvalues: (copy) v_u_14, (ref) v_u_15, (ref) v_u_16, (copy) v_u_22, (copy) v_u_6
	local v24 = v_u_14.Character
	if not v24 then
		return nil
	end
	if v_u_15 and v_u_16 == v24 then
		return v_u_15
	end
	local v25 = v24:FindFirstChildOfClass("Humanoid")
	if not v25 then
		return nil
	end
	local v26 = v25:FindFirstChildOfClass("Animator")
	if not v26 then
		return nil
	end
	local v27 = v_u_22()
	if not v27 then
		return nil
	end
	v_u_15 = v26:LoadAnimation(v_u_6.GetUpperBody(v27, "BatSwingUpperBody"))
	v_u_15.Priority = Enum.AnimationPriority.Action4
	v_u_15.Looped = false
	v_u_16 = v24
	return v_u_15
end
local function v_u_33() -- name: currentTarget
	-- upvalues: (copy) v_u_14, (copy) v_u_10, (copy) v_u_8
	local v29 = v_u_14.Character
	local v30
	if v29 then
		v30 = v29:FindFirstChild("HumanoidRootPart")
	else
		v30 = v29
	end
	if v29 and (v30 and v30:IsA("BasePart")) then
		if v29:GetAttribute("Ragdolled") then
			return nil
		else
			local v31 = v_u_14.Character
			if v31 then
				v31 = v31:FindFirstChild("HumanoidRootPart")
			end
			local v32
			if v31 and v31:IsA("BasePart") then
				v32 = v_u_10.IsBankable(v_u_14.UserId, v31.Position)
			else
				v32 = false
			end
			if v32 then
				return nil
			else
				return v_u_8.SelectClosestTarget(v_u_14, v30.Position, v_u_8.MaxRange(v_u_14))
			end
		end
	else
		return nil
	end
end
local function v_u_40() -- name: playSwooshSound
	-- upvalues: (copy) v_u_5, (copy) v_u_14, (copy) v_u_9
	local v34 = v_u_5:FindFirstChild("SFX")
	if v34 then
		v34 = v34:FindFirstChild("Swoosh")
	end
	if v34 and v34:IsA("Sound") then
		local v35 = nil
		local v36 = v_u_14.Character
		if v36 then
			for _, v37 in v36:GetChildren() do
				if not v_u_9.IsBatWeapon(v37) then
					continue
				end
				local v38 = v37:FindFirstChild("Handle")
				if v38 then
					if v38:IsA("BasePart") then
						v35 = v38
					end
				end
			end
		end
		if v35 then
			local v39 = v35:FindFirstChild("BatSwoosh")
			if not (v39 and v39:IsA("Sound")) then
				v39 = v34:Clone()
				v39.Name = "BatSwoosh"
				v39.Parent = v35
			end
			v39:Play()
		else
			v34:Play()
		end
	else
		return
	end
end
local function v_u_51() -- name: swing
	-- upvalues: (copy) v_u_14, (copy) v_u_10, (ref) v_u_18, (copy) v_u_12, (copy) v_u_7, (ref) v_u_17, (copy) v_u_28, (ref) v_u_19, (copy) v_u_40, (ref) v_u_23, (copy) v_u_3, (copy) v_u_33
	local v41 = os.clock()
	local v42 = v_u_14.Character
	if v42 then
		v42 = v42:FindFirstChild("HumanoidRootPart")
	end
	local v43
	if v42 and v42:IsA("BasePart") then
		v43 = v_u_10.IsBankable(v_u_14.UserId, v42.Position)
	else
		v43 = false
	end
	if v43 then
		if v41 - v_u_18 >= 1 then
			v_u_18 = v41
			v_u_12.ShowPreset("BatSafeZone")
		end
		return
	elseif v_u_7.ClientCooldown <= v41 - v_u_17 then
		v_u_17 = v41
		local v_u_44 = v_u_28()
		if v_u_44 then
			if v_u_44.IsPlaying then
				v_u_44:Stop(0)
			end
			v_u_44:Play(0.1, 1, v_u_7.SwingSpeed)
			v_u_19 = v_u_19 + 1
			local v_u_45 = v_u_19
			local v46 = v_u_44.Length
			if v46 > 0 then
				local v47 = (v46 - v_u_7.SwingTrimEnd) / v_u_7.SwingSpeed
				if v47 > 0.05 then
					task.delay(v47, function()
						-- upvalues: (copy) v_u_45, (ref) v_u_19, (copy) v_u_44
						if v_u_45 == v_u_19 and v_u_44.IsPlaying then
							v_u_44:Stop(0.15)
						end
					end)
				end
			end
		end
		local v_u_48 = v_u_19
		task.delay(0.1, function()
			-- upvalues: (copy) v_u_48, (ref) v_u_19, (ref) v_u_40
			if v_u_48 == v_u_19 then
				v_u_40()
			end
		end)
		local v49
		if v_u_23 and v_u_23.Parent then
			v49 = v_u_23
		else
			local v50 = v_u_3:FindFirstChild(v_u_7.HitRemoteName)
			if not (v50 and v50:IsA("RemoteEvent")) then
				v50 = nil
			end
			v_u_23 = v50
			v49 = v_u_23
		end
		if v49 then
			v49:FireServer(v_u_33())
		end
	end
end
function v13.Swing() -- name: Swing
	-- upvalues: (copy) v_u_14, (copy) v_u_9, (copy) v_u_51
	local v52 = v_u_14.Character
	if v52 then
		for _, v53 in v52:GetChildren() do
			if not v_u_9.IsBatWeapon(v53) then
				continue
			end
			v_u_51()
			return
		end
	end
end
local v_u_54 = nil
local function v_u_57() -- name: startLockOn
	-- upvalues: (ref) v_u_54, (copy) v_u_4, (copy) v_u_33, (copy) v_u_11
	if not v_u_54 then
		v_u_54 = v_u_4.RenderStepped:Connect(function()
			-- upvalues: (ref) v_u_33, (ref) v_u_11
			local v55 = v_u_33()
			local v56 = v_u_11.SetTarget
			if v55 then
				v55 = v55.Character
			end
			v56(v55)
		end)
	end
end
local v_u_58 = {}
local function v_u_63(p_u_59) -- name: hookTool
	-- upvalues: (copy) v_u_9, (copy) v_u_58, (copy) v_u_51, (copy) v_u_57, (ref) v_u_54, (copy) v_u_11, (ref) v_u_19, (ref) v_u_15, (copy) v_u_14, (copy) v_u_4, (copy) v_u_33
	if v_u_9.IsBatWeapon(p_u_59) and not v_u_58[p_u_59] then
		v_u_58[p_u_59] = true
		p_u_59.Destroying:Once(function()
			-- upvalues: (ref) v_u_58, (copy) p_u_59
			v_u_58[p_u_59] = nil
		end)
		p_u_59.Activated:Connect(v_u_51)
		p_u_59.Equipped:Connect(v_u_57)
		p_u_59.Unequipped:Connect(function()
			-- upvalues: (ref) v_u_54, (ref) v_u_11, (ref) v_u_19, (ref) v_u_15
			if v_u_54 then
				v_u_54:Disconnect()
				v_u_54 = nil
			end
			v_u_11.Clear()
			v_u_19 = v_u_19 + 1
			if v_u_15 and v_u_15.IsPlaying then
				v_u_15:Stop(0.1)
			end
		end)
		local v60 = v_u_14.Character
		if v60 and p_u_59.Parent == v60 then
			if v_u_54 then
				return
			end
			v_u_54 = v_u_4.RenderStepped:Connect(function()
				-- upvalues: (ref) v_u_33, (ref) v_u_11
				local v61 = v_u_33()
				local v62 = v_u_11.SetTarget
				if v61 then
					v61 = v61.Character
				end
				v62(v61)
			end)
		end
	end
end
local v_u_64 = {}
local function v_u_67(p65) -- name: unhookContainer
	-- upvalues: (copy) v_u_64
	local v66 = v_u_64[p65]
	if v66 then
		v_u_64[p65] = nil
		v66:Disconnect()
	end
end
local function v_u_72(p_u_68) -- name: hookContainer
	-- upvalues: (copy) v_u_64, (copy) v_u_63
	if not v_u_64[p_u_68] then
		v_u_64[p_u_68] = p_u_68.ChildAdded:Connect(v_u_63)
		p_u_68.Destroying:Once(function()
			-- upvalues: (copy) p_u_68, (ref) v_u_64
			local v69 = p_u_68
			local v70 = v_u_64[v69]
			if v70 then
				v_u_64[v69] = nil
				v70:Disconnect()
			end
		end)
		for _, v71 in p_u_68:GetChildren() do
			v_u_63(v71)
		end
	end
end
local function v_u_79(p_u_73) -- name: onCharacter
	-- upvalues: (ref) v_u_54, (copy) v_u_11, (copy) v_u_1, (copy) v_u_22, (copy) v_u_14, (copy) v_u_28, (copy) v_u_72
	if v_u_54 then
		v_u_54:Disconnect()
		v_u_54 = nil
	end
	v_u_11.Clear()
	task.spawn(function()
		-- upvalues: (ref) v_u_1, (ref) v_u_22, (copy) p_u_73, (ref) v_u_14, (ref) v_u_28
		local v74 = v_u_1.PreloadAsync
		local v75 = v_u_1
		local v76 = { (v_u_22()) }
		pcall(v74, v75, v76)
		local v77 = p_u_73:WaitForChild("Humanoid", 10)
		if v77 then
			v77 = v77:WaitForChild("Animator", 10)
		end
		if v77 and v_u_14.Character == p_u_73 then
			v_u_28()
		end
	end)
	v_u_72(p_u_73)
	local v78 = v_u_14:WaitForChild("Backpack", 10)
	if v78 then
		v_u_72(v78)
	end
end
function v13.Start() -- name: Start
	-- upvalues: (copy) v_u_14, (copy) v_u_79, (copy) v_u_67
	if v_u_14.Character then
		task.spawn(v_u_79, v_u_14.Character)
	end
	v_u_14.CharacterAdded:Connect(v_u_79)
	v_u_14.CharacterRemoving:Connect(v_u_67)
end
return v13
local v_u_1 = game:GetService("ContentProvider")
local v_u_2 = game:GetService("Debris")
local v_u_3 = game:GetService("SoundService")
local v_u_4 = require(script.Parent.RewardFlashController)
local v5 = {}
local v_u_6 = (-1 / 0)
local v_u_7 = (-1 / 0)
local v_u_8 = nil
local function v_u_13() -- name: playSound
	-- upvalues: (ref) v_u_8, (copy) v_u_3, (copy) v_u_2
	if not (v_u_8 and v_u_8.Parent) then
		v_u_8 = v_u_3:FindFirstChild("rransCustomSFX")
	end
	local v9 = v_u_8
	if v9 then
		v9 = v_u_8:FindFirstChild("Success")
	end
	if not (v9 and v9:IsA("Sound")) then
		v9 = nil
	end
	if v9 then
		local v_u_10 = v9:Clone()
		v_u_10.Parent = v_u_3
		v_u_10.Ended:Once(function()
			-- upvalues: (copy) v_u_10
			v_u_10:Destroy()
		end)
		local v11 = v_u_2
		local v12 = v_u_10.TimeLength
		v11:AddItem(v_u_10, math.max(v12, 1) + 1)
		v_u_10:Play()
	end
end
function v5.PlaySting() -- name: PlaySting
	-- upvalues: (ref) v_u_6, (ref) v_u_7, (copy) v_u_13
	local v14 = os.clock()
	if v14 - v_u_6 < 1.5 or v14 - v_u_7 < 0.2 then
		return false
	end
	v_u_7 = v14
	v_u_13()
	return true
end
function v5.PlayBank() -- name: PlayBank
	-- upvalues: (ref) v_u_6, (copy) v_u_4, (ref) v_u_7, (copy) v_u_13
	local v15 = os.clock()
	if v15 - v_u_6 < 1.5 then
		return false
	end
	v_u_6 = v15
	v_u_4.Play()
	v_u_7 = v15
	v_u_13()
	return true
end
function v5.Stop() -- name: Stop
	-- upvalues: (ref) v_u_6, (ref) v_u_7, (copy) v_u_4
	v_u_6 = (-1 / 0)
	v_u_7 = (-1 / 0)
	v_u_4.Stop()
end
function v5.Start() -- name: Start
	-- upvalues: (ref) v_u_8, (copy) v_u_3, (copy) v_u_1
	if not (v_u_8 and v_u_8.Parent) then
		v_u_8 = v_u_3:FindFirstChild("rransCustomSFX")
	end
	local v16 = v_u_8
	if v16 then
		v16 = v_u_8:FindFirstChild("Success")
	end
	if not (v16 and v16:IsA("Sound")) then
		v16 = nil
	end
	if v16 then
		local v17 = v_u_1.PreloadAsync
		local v18 = v_u_1
		pcall(v17, v18, { v16 })
	end
end
return v5
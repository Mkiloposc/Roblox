local v1 = game:GetService("Players")
local v_u_2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = game:GetService("TweenService")
local v_u_5 = require(v_u_2.Shared.AutoSwingConfig)
local v6 = require(v_u_2.Shared.EggConfig)
local v_u_7 = require(v_u_2.Shared.EggTargeting)
local v_u_8 = require(v_u_2.Shared.RideConfig)
local v_u_9 = require(v_u_2.Shared.PickaxeConfig)
local v_u_10 = require(script.Parent.PickaxeController)
local v_u_11 = require(script.Parent.PickaxeEquipState)
local v_u_12 = v1.LocalPlayer
local v_u_13 = TweenInfo.new(v_u_5.TweenDuration, v_u_5.TweenEasingStyle, v_u_5.TweenEasingDirection)
local v14 = v6.HitRange - v_u_5.RangeMargin
local v_u_15 = math.max(0, v14)
local v16 = v6.HitRange - v_u_5.StickyRangeMargin
local v_u_17 = math.max(v_u_15, v16)
local v_u_18 = {
	["Changed"] = Instance.new("BindableEvent")
}
local v_u_19 = v_u_5.DefaultOn
local v_u_20 = 0
local v_u_21 = (-1 / 0)
local v_u_22 = nil
local v_u_23 = nil
local v_u_24 = nil
function v_u_18.IsOn() -- name: IsOn
	-- upvalues: (ref) v_u_19
	return v_u_19
end
local v_u_25 = false
local function v_u_28() -- name: stateGradients
	-- upvalues: (copy) v_u_2, (copy) v_u_5, (ref) v_u_25
	local v26 = v_u_2:FindFirstChild("Assets")
	if v26 then
		v26 = v26:FindFirstChild(v_u_5.StateGradientsFolder)
	end
	local v27
	if v26 then
		v27 = v26:FindFirstChild("Off")
	else
		v27 = v26
	end
	if v26 then
		v26 = v26:FindFirstChild("On")
	end
	if v27 and (v27:IsA("UIGradient") and (v26 and v26:IsA("UIGradient"))) then
		return v27, v26
	end
	if not v_u_25 then
		v_u_25 = true
		warn(("[AutoSwingController] ReplicatedStorage.Assets.%*"):format(v_u_5.StateGradientsFolder) .. " Off/On (UIGradients) not found \226\128\148 button keeps its authored colours")
	end
	return nil, nil
end
local function v_u_37(p29, p30) -- name: sampleSequence
	local v31 = p29.Keypoints
	if p30 <= v31[1].Time then
		return v31[1].Value
	end
	for v32 = 1, #v31 - 1 do
		local v33 = v31[v32 + 1]
		if p30 > v33.Time then
			continue
		end
		local v34 = v31[v32]
		local v35 = v33.Time - v34.Time
		local v36 = v35 <= 0 and 1 or (p30 - v34.Time) / v35
		return v34.Value:Lerp(v33.Value, v36)
	end
	return v31[#v31].Value
end
local function v_u_52(p38, p39, p40) -- name: blendStateColors
	-- upvalues: (copy) v_u_37
	if p40 <= 0 then
		return p38
	end
	if p40 >= 1 then
		return p39
	end
	local v41 = {}
	local v42 = {}
	for _, v43 in { p38, p39 } do
		for _, v44 in v43.Keypoints do
			local v45 = v44.Time * 1000 + 0.5
			local v46 = math.floor(v45)
			if v41[v46] then
				continue
			end
			v41[v46] = true
			local v47 = v44.Time
			table.insert(v42, v47)
		end
	end
	table.sort(v42)
	local v48 = table.create(#v42)
	for _, v49 in v42 do
		local v50 = v_u_37(p38, v49):Lerp(v_u_37(p39, v49), p40)
		local v51 = ColorSequenceKeypoint.new
		table.insert(v48, v51(v49, v50))
	end
	return ColorSequence.new(v48)
end
local function v_u_56() -- name: equipPickaxe
	-- upvalues: (copy) v_u_12, (copy) v_u_9
	local v53 = v_u_12.Character
	local v54
	if v53 then
		v54 = v53:FindFirstChildOfClass("Humanoid")
	else
		v54 = v53
	end
	if v54 and (v54.Health > 0 and not v53:FindFirstChildOfClass("Tool")) then
		if v_u_12:GetAttribute("Carrying") == nil and not v53:GetAttribute("Ragdolled") then
			local v55 = v_u_12:FindFirstChild("Backpack")
			if v55 then
				v55 = v55:FindFirstChild(v_u_9.ToolName)
			end
			if v55 and v55:IsA("Tool") then
				v54:EquipTool(v55)
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_58() -- name: pickTarget
	-- upvalues: (copy) v_u_12, (copy) v_u_7, (copy) v_u_8, (copy) v_u_15, (copy) v_u_10, (copy) v_u_17
	local v57 = v_u_12.Character
	if v57 then
		v57 = v57:FindFirstChild("HumanoidRootPart")
	end
	if not (v57 and v57:IsA("BasePart")) then
		v57 = nil
	end
	if v57 then
		return v_u_7.Pick(v_u_8.ReachOrigin(v57), v_u_15, v_u_10.GetLastHitEgg(), v_u_17)
	else
		return nil
	end
end
local function v_u_62() -- name: tick
	-- upvalues: (copy) v_u_10, (copy) v_u_12, (copy) v_u_7, (copy) v_u_8, (copy) v_u_15, (copy) v_u_17
	if v_u_10.IsWielding() then
		local v59 = v_u_12.Character
		if v59 then
			v59 = v59:FindFirstChildOfClass("Humanoid")
		end
		if v59 and v59.Health > 0 then
			local v60 = v_u_12.Character
			if v60 then
				v60 = v60:FindFirstChild("HumanoidRootPart")
			end
			if not (v60 and v60:IsA("BasePart")) then
				v60 = nil
			end
			local v61
			if v60 then
				v61 = v_u_7.Pick(v_u_8.ReachOrigin(v60), v_u_15, v_u_10.GetLastHitEgg(), v_u_17)
			else
				v61 = nil
			end
			if v61 then
				v_u_10.Swing(v61)
			end
		end
	else
		return
	end
end
local function v_u_70(p63) -- name: setOn
	-- upvalues: (ref) v_u_19, (ref) v_u_20, (copy) v_u_5, (copy) v_u_56, (ref) v_u_22, (copy) v_u_18
	if v_u_19 ~= p63 then
		v_u_19 = p63
		v_u_20 = not p63 and 0 or v_u_5.TickInterval
		if p63 and v_u_5.EquipPickaxeOnEnable then
			local v64 = v_u_56
			local v65, v66 = pcall(v64)
			if not v65 then
				warn((("[AutoSwingController] equip on enable failed: %*"):format(v66)))
			end
		end
		local v67 = v_u_22
		if v67 then
			local v68, v69 = pcall(v67, true)
			if not v68 then
				warn((("[AutoSwingController] button visual failed: %*"):format(v69)))
			end
		end
		v_u_18.Changed:Fire(v_u_19)
	end
end
function v_u_18.SetOn(p71) -- name: SetOn
	-- upvalues: (copy) v_u_70
	v_u_70(p71 == true)
end
local function v_u_103(p72) -- name: setupGui
	-- upvalues: (copy) v_u_5, (ref) v_u_23, (copy) v_u_28, (copy) v_u_52, (ref) v_u_19, (copy) v_u_4, (copy) v_u_13, (copy) v_u_11, (ref) v_u_24, (ref) v_u_22, (ref) v_u_21, (copy) v_u_70
	local v_u_73 = p72:WaitForChild(v_u_5.ButtonName, 10)
	if v_u_73 and (v_u_73:IsA("GuiButton") and v_u_73 ~= v_u_23) then
		if v_u_73:WaitForChild("UiGradient", 10) and (v_u_73.Parent ~= nil and v_u_73 ~= v_u_23) then
			v_u_23 = v_u_73
			local v_u_74 = {}
			for _, v75 in v_u_73:GetDescendants() do
				if not v75:IsA("UIGradient") then
					continue
				end
				table.insert(v_u_74, v75)
			end
			local v_u_76 = nil
			local v_u_77 = nil
			local function v81(p78) -- name: applyColors
				-- upvalues: (ref) v_u_76, (ref) v_u_77, (ref) v_u_52, (copy) v_u_74
				if v_u_76 and v_u_77 then
					local v79 = v_u_52(v_u_76, v_u_77, p78)
					for _, v80 in v_u_74 do
						v80.Color = v79
					end
				end
			end
			local v_u_82 = Instance.new("NumberValue")
			v_u_82.Name = "AutoSwingColorAlpha"
			v_u_82.Parent = v_u_73
			v_u_82.Changed:Connect(v81)
			local v_u_83 = nil
			local function v_u_92(p84) -- name: applyState
				-- upvalues: (ref) v_u_19, (ref) v_u_28, (ref) v_u_76, (ref) v_u_77, (ref) v_u_83, (copy) v_u_82, (ref) v_u_52, (copy) v_u_74, (ref) v_u_4, (ref) v_u_13
				local v85 = v_u_19 and 1 or 0
				local v86, v87 = v_u_28()
				local v88
				if v86 then
					v88 = v86.Color
				else
					v88 = nil
				end
				v_u_76 = v88
				local v89
				if v87 then
					v89 = v87.Color
				else
					v89 = nil
				end
				v_u_77 = v89
				if v_u_83 ~= nil then
					v_u_83:Cancel()
					v_u_83 = nil
				end
				if p84 then
					v_u_83 = v_u_4:Create(v_u_82, v_u_13, {
						["Value"] = v85
					})
					v_u_83:Play()
				else
					v_u_82.Value = v85
					if v_u_76 then
						if not v_u_77 then
							return
						end
						local v90 = v_u_52(v_u_76, v_u_77, v85)
						for _, v91 in v_u_74 do
							v91.Color = v90
						end
					end
				end
			end
			local v93 = v_u_19 and 1 or 0
			local v94, v95 = v_u_28()
			local v96
			if v94 then
				v_u_76 = v94.Color
				v96 = v_u_76
			else
				v_u_76 = nil
				v96 = v_u_76
			end
			local v97
			if v95 then
				v_u_77 = v95.Color
				v97 = v_u_77
			else
				v_u_77 = nil
				v97 = v_u_77
			end
			if v_u_83 ~= nil then
				v_u_83:Cancel()
				v_u_83 = nil
			end
			v_u_82.Value = v93
			if v96 and v97 then
				local v98 = v_u_52(v96, v97, v93)
				for _, v99 in v_u_74 do
					v99.Color = v98
				end
			end
			if v_u_5.ShowOnlyWhileEquipped then
				local function v100() -- name: refreshVisible
					-- upvalues: (ref) v_u_23, (copy) v_u_73, (ref) v_u_11
					if v_u_23 == v_u_73 then
						v_u_73.Visible = v_u_11.IsEquipped()
					end
				end
				if v_u_24 then
					v_u_24:Disconnect()
				end
				v_u_24 = v_u_11.Observe(v100)
			else
				v_u_73.Visible = true
			end
			v_u_22 = function(p101)
				-- upvalues: (ref) v_u_23, (copy) v_u_73, (copy) v_u_92
				if v_u_23 == v_u_73 and v_u_73.Parent ~= nil then
					v_u_92(p101)
				end
			end
			v_u_73.Activated:Connect(function()
				-- upvalues: (ref) v_u_23, (copy) v_u_73, (ref) v_u_21, (ref) v_u_5, (ref) v_u_70, (ref) v_u_19
				if v_u_23 == v_u_73 then
					local v102 = os.clock()
					if v102 - v_u_21 >= v_u_5.ToggleDebounce then
						v_u_21 = v102
						v_u_70(not v_u_19)
					end
				else
					return
				end
			end)
		end
	else
		return
	end
end
function v_u_18.Start() -- name: Start
	-- upvalues: (copy) v_u_10, (ref) v_u_19, (copy) v_u_58, (copy) v_u_12, (copy) v_u_103, (copy) v_u_3, (ref) v_u_20, (copy) v_u_5, (copy) v_u_62
	v_u_10.SetAutoTargeting(function()
		-- upvalues: (ref) v_u_19, (ref) v_u_58
		if v_u_19 then
			return v_u_58()
		else
			return nil
		end
	end)
	local v104 = v_u_12:WaitForChild("PlayerGui")
	v104.ChildAdded:Connect(function(p105)
		-- upvalues: (ref) v_u_103
		if p105.Name == "MainGUI" then
			task.defer(v_u_103, p105)
		end
	end)
	local v106 = v104:WaitForChild("MainGUI", 30)
	if v106 then
		v_u_103(v106)
	end
	v_u_3.Heartbeat:Connect(function(p107)
		-- upvalues: (ref) v_u_19, (ref) v_u_20, (ref) v_u_5, (ref) v_u_62
		if v_u_19 then
			v_u_20 = v_u_20 + p107
			if v_u_20 >= v_u_5.TickInterval then
				v_u_20 = 0
				local v108 = v_u_62
				local v109, v110 = pcall(v108)
				if not v109 then
					warn((("[AutoSwingController] tick failed: %*"):format(v110)))
				end
			end
		else
			return
		end
	end)
end
return v_u_18
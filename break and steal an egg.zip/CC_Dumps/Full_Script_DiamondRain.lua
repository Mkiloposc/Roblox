local v_u_1 = game:GetService("TweenService")
local v_u_2 = require(script.Parent.OnScreen)
local v3 = {}
local v_u_4 = Random.new()
local function v_u_21(p_u_5, p_u_6, p_u_7, p8) -- name: launch
	-- upvalues: (copy) v_u_2, (copy) v_u_21, (copy) v_u_4, (copy) v_u_1
	if p_u_5.Parent == nil then
		return
	elseif v_u_2.IsShown(p_u_5) then
		local v9 = v_u_4:NextNumber()
		local v10 = p_u_7.SizeMin
		local v11 = v10 + (p_u_7.SizeMax - v10) * v9
		p_u_6.Size = UDim2.fromScale(v11, v11)
		local v12 = p_u_7.FarTransparency
		p_u_6.ImageTransparency = v12 + (p_u_7.NearTransparency - v12) * v9
		local v13 = -v11
		if p8 then
			v13 = v_u_4:NextNumber(-v11, 1)
		end
		local v14 = v11 + 1
		local v15 = v_u_4:NextNumber(0.02, 0.98)
		local v16 = v_u_4:NextNumber(-p_u_7.Sway, p_u_7.Sway)
		local v17 = p_u_7.FallTimeFar
		local v18 = (v17 + (p_u_7.FallTimeNear - v17) * v9) * (v14 - v13) / (v11 * 2 + 1)
		p_u_6.Position = UDim2.fromScale(v15, v13)
		p_u_6.Rotation = v_u_4:NextNumber(-30, 30)
		local v19 = v_u_1:Create(p_u_6, TweenInfo.new(v18, Enum.EasingStyle.Linear), {
			["Position"] = UDim2.fromScale(v15 + v16, v14),
			["Rotation"] = p_u_6.Rotation + v_u_4:NextNumber(-p_u_7.Spin, p_u_7.Spin)
		})
		v19.Completed:Once(function(p20)
			-- upvalues: (ref) v_u_21, (copy) p_u_5, (copy) p_u_6, (copy) p_u_7
			if p20 == Enum.PlaybackState.Completed then
				v_u_21(p_u_5, p_u_6, p_u_7, false)
			end
		end)
		v19:Play()
	else
		task.spawn(function()
			-- upvalues: (ref) v_u_2, (copy) p_u_5, (ref) v_u_21, (copy) p_u_6, (copy) p_u_7
			v_u_2.WaitUntilShown(p_u_5)
			v_u_21(p_u_5, p_u_6, p_u_7, true)
		end)
	end
end
function v3.Attach(p22, p23) -- name: Attach
	-- upvalues: (copy) v_u_21
	local v24 = p22:FindFirstChild(p23.Name)
	if v24 and v24:IsA("CanvasGroup") then
		return v24
	end
	local v25 = Instance.new("CanvasGroup")
	v25.Name = p23.Name
	v25.AnchorPoint = Vector2.new(0.5, 0.5)
	v25.Position = UDim2.fromScale(0.5, 0.5)
	v25.Size = UDim2.fromScale(1, 1)
	v25.BackgroundTransparency = 1
	v25.ZIndex = p23.ZIndex
	v25.Active = false
	v25.Selectable = false
	local v26 = p22:FindFirstChildOfClass("UICorner")
	if v26 then
		v26:Clone().Parent = v25
	end
	v25.Parent = p22
	for _ = 1, p23.Count do
		local v27 = Instance.new("ImageLabel")
		v27.Name = "Drop"
		v27.BackgroundTransparency = 1
		v27.AnchorPoint = Vector2.new(0.5, 0.5)
		v27.SizeConstraint = Enum.SizeConstraint.RelativeYY
		v27.Image = p23.Image
		v27.ImageColor3 = p23.Color
		v27.Parent = v25
		v_u_21(v25, v27, p23, true)
	end
	return v25
end
return v3
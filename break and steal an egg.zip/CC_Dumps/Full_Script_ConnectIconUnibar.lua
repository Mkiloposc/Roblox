local v1 = game:GetService("CorePackages")
local v2 = script:FindFirstAncestor("Chrome")
local v_u_3 = require(v2.Service)
local v_u_4 = require(v1.Workspace.Packages.AppChat.InExperienceAppChatModal)
local v_u_5 = require(script.Parent.registerConnectIntegration)
local v6 = require(script.Parent.isConnectUnibarEnabled)
local v_u_7 = require(script.Parent.isConnectDropdownEnabled)
local v_u_8 = require(v1.Workspace.Packages.SharedFlags).GetFFlagIsSquadEnabled
local v_u_9 = require(v1.Workspace.Packages.UniversalAppPolicy)
local v10 = require(v1.Packages.PolicyProvider).GetPolicyImplementations.MemStorageService("app-policy")
local v_u_11 = nil
local v_u_12 = nil
local function v_u_19(p13) -- name: updateConnectIntegration
	-- upvalues: (ref) v_u_11, (copy) v_u_5, (copy) v_u_3, (ref) v_u_12, (copy) v_u_4
	if not v_u_11 then
		local v14 = v_u_5
		local v15 = "connect_unibar"
		local v16
		if p13 then
			v16 = v_u_3.AvailabilitySignal.Pinned
		else
			v16 = v_u_3.AvailabilitySignal.Unavailable
		end
		v_u_11 = v14(v15, v16)
	end
	if p13 then
		if v_u_4.default.currentSquadId ~= "" then
			v_u_11.availability:pinned()
		end
		if not v_u_12 then
			local v_u_18 = v_u_4.default.currentSquadIdSignal.Event:Connect(function(p17)
				-- upvalues: (ref) v_u_11
				if p17 == "" then
					v_u_11.availability:unavailable()
				else
					v_u_11.availability:pinned()
				end
			end)
			v_u_12 = function()
				-- upvalues: (copy) v_u_18
				v_u_18:Disconnect()
			end
		end
	else
		v_u_11.availability:unavailable()
		if v_u_12 then
			v_u_12()
			v_u_12 = nil
			return
		end
	end
end
local function v22() -- name: handlePolicyUpdate
	-- upvalues: (copy) v_u_19, (copy) v_u_8, (copy) v_u_9, (copy) v_u_7
	local v20 = v_u_19
	local v21 = v_u_8() and v_u_9.getAppFeaturePolicies().getCanAccessParty()
	if v21 then
		v21 = v_u_7()
	end
	v20(v21)
end
if v6() then
	local v23 = v_u_8() and v_u_9.getAppFeaturePolicies().getCanAccessParty()
	if v23 then
		v23 = v_u_7()
	end
	v_u_19(v23)
	v10.onPolicyChanged(v22)
end
return v_u_11
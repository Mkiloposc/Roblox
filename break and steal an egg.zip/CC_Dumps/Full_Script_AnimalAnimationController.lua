local v_u_1 = game:GetService("CollectionService")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("RunService")
local v_u_4 = require(v2.Shared.AnimalAnimator)
local v_u_5 = require(v2.Shared.EggRewards)
local v_u_6 = require(v2.Shared.WaitFor)
local v_u_7 = require(script.Parent.PlacedAnimalViewCullController)
local v_u_8 = require(script.Parent.ZonePlotCullController)
local v_u_9 = require(script.Parent.Parent.Modules.LocalModelHider)
local v10 = {}
local v_u_11 = {}
local function v_u_15(p12) -- name: getRoot
	local v13 = p12.PrimaryPart or p12:FindFirstChild("HumanoidRootPart")
	if v13 and v13:IsA("BasePart") then
		return v13
	end
	for _, v14 in p12:GetDescendants() do
		if not v14:IsA("BasePart") then
			continue
		end
		return v14
	end
	return nil
end
local function v_u_19(p16) -- name: countBones
	local v17 = 0
	for _, v18 in p16:GetDescendants() do
		if not v18:IsA("Bone") then
			continue
		end
		v17 = v17 + 1
	end
	return v17
end
local function v_u_36(p20) -- name: waitForSkeleton
	-- upvalues: (copy) v_u_5, (copy) v_u_19, (copy) v_u_6
	local v21 = p20:GetAttribute("AnimalName") or p20.Name
	local v22
	if typeof(v21) == "string" then
		v22 = v_u_5.FindAnimalTemplate(v21)
	else
		v22 = nil
	end
	local v23 = not v22 and 0 or v_u_19(v22)
	if v23 <= 0 then
		return
	end
	local v_u_24 = {}
	local v_u_25 = 0
	local v_u_26 = 0
	local function v28(p27) -- name: addBone
		-- upvalues: (copy) v_u_24, (ref) v_u_25, (ref) v_u_26
		if p27:IsA("Bone") and not v_u_24[p27] then
			v_u_24[p27] = true
			v_u_25 = v_u_25 + 1
			v_u_26 = v_u_26 + 1
		end
	end
	local v29 = p20.DescendantAdded:Connect(v28)
	local v30 = v_u_26
	local v31 = v_u_25
	for _, v32 in p20:GetDescendants() do
		if not v32:IsA("Bone") or v_u_24[v32] then
			continue
		end
		v_u_24[v32] = true
		v_u_25 = v31 + 1
		v_u_26 = v30 + 1
		v30 = v_u_26
		v31 = v_u_25
	end
	local v33 = os.clock() + 5
	local v34 = v30
	local v35 = 0
	while os.clock() < v33 and v31 < v23 do
		v_u_6.Frame()
		if v30 == v34 then
			v35 = v35 + 1
			if v35 < 4 or v31 <= 0 then
				continue
			end
			break
		end
		v34 = v30
		v35 = 0
	end
	v29:Disconnect()
end
local function v_u_39(p37) -- name: teardown
	-- upvalues: (copy) v_u_11
	local v38 = v_u_11[p37]
	if v38 ~= nil then
		v_u_11[p37] = nil
		if v38.AncestryWatch then
			v38.AncestryWatch:Disconnect()
		end
		if v38.DestroyWatch then
			v38.DestroyWatch:Disconnect()
		end
		if v38.AttrWatch then
			v38.AttrWatch:Disconnect()
		end
		if v38.Animator then
			v38.Animator:Destroy()
		end
	end
end
local function v_u_46(p_u_40) -- name: build
	-- upvalues: (copy) v_u_6, (copy) v_u_36, (copy) v_u_11, (copy) v_u_4, (copy) v_u_15
	local v_u_41 = p_u_40.Model
	if v_u_6.Until(function()
		-- upvalues: (copy) v_u_41
		local v42 = v_u_41
		return v42.PrimaryPart and true or v42:FindFirstChildWhichIsA("BasePart", true) ~= nil
	end, 10) then
		if v_u_41:FindFirstChildOfClass("AnimationController") == nil and v_u_41:FindFirstChildOfClass("Humanoid") == nil then
			v_u_6.Until(function()
				-- upvalues: (copy) v_u_41
				local v43 = v_u_41
				return v43:FindFirstChildOfClass("AnimationController") ~= nil and true or v43:FindFirstChildOfClass("Humanoid") ~= nil
			end, 1)
		end
		v_u_36(v_u_41)
		if v_u_11[v_u_41] == p_u_40 then
			local v44 = v_u_4.new(v_u_41, p_u_40.Config)
			if v_u_11[v_u_41] == p_u_40 then
				p_u_40.Animator = v44
				p_u_40.Root = p_u_40.Root or v_u_15(v_u_41)
				if p_u_40.Static then
					if p_u_40.AncestryWatch == nil then
						p_u_40.AncestryWatch = v_u_41.AncestryChanged:Connect(function()
							-- upvalues: (copy) p_u_40
							local v45 = p_u_40
							if v45.Animator ~= nil then
								if not v45.Static then
									return
								end
								if v45.Model:IsDescendantOf(workspace) then
									v45.Animator:PlayIdle()
									return
								end
								v45.Animator:Stop()
							end
						end)
					end
					if p_u_40.Animator ~= nil then
						if not p_u_40.Static then
							return
						end
						if p_u_40.Model:IsDescendantOf(workspace) then
							p_u_40.Animator:PlayIdle()
							return
						end
						p_u_40.Animator:Stop()
					end
				end
			else
				v44:Destroy()
			end
		else
			return
		end
	else
		return
	end
end
local function v_u_61(p_u_47) -- name: setup
	-- upvalues: (copy) v_u_11, (copy) v_u_39, (copy) v_u_46
	if p_u_47:IsA("Model") and not v_u_11[p_u_47] then
		local v48 = p_u_47:GetAttribute("AnimationBaseWalkSpeed")
		local v_u_49 = {
			["Model"] = nil,
			["Animator"] = nil,
			["Static"] = nil,
			["Config"] = nil,
			["AncestryWatch"] = nil,
			["DestroyWatch"] = nil,
			["AttrWatch"] = nil,
			["Root"] = nil,
			["HoldIdle"] = nil,
			["Model"] = p_u_47,
			["Static"] = p_u_47:GetAttribute("AnimStatic") == true
		}
		local v50 = {}
		if typeof(v48) ~= "number" then
			v48 = nil
		end
		v50.AnimationBaseWalkSpeed = v48
		v_u_49.Config = v50
		v_u_49.HoldIdle = p_u_47:GetAttribute("ChaseState") == "WindUp"
		v_u_11[p_u_47] = v_u_49
		v_u_49.AttrWatch = p_u_47.AttributeChanged:Connect(function(p51)
			-- upvalues: (copy) p_u_47, (copy) v_u_49
			if p51 == "AnimStatic" then
				local v52 = p_u_47:GetAttribute("AnimStatic") == true
				if v52 == v_u_49.Static then
					return
				end
				v_u_49.Static = v52
				v_u_49.Moving = nil
				if v52 then
					if v_u_49.AncestryWatch == nil then
						v_u_49.AncestryWatch = p_u_47.AncestryChanged:Connect(function()
							-- upvalues: (ref) v_u_49
							local v53 = v_u_49
							if v53.Animator ~= nil then
								if not v53.Static then
									return
								end
								if v53.Model:IsDescendantOf(workspace) then
									v53.Animator:PlayIdle()
									return
								end
								v53.Animator:Stop()
							end
						end)
					end
					local v54 = v_u_49
					if v54.Animator ~= nil then
						if v54.Static then
							if v54.Model:IsDescendantOf(workspace) then
								v54.Animator:PlayIdle()
							else
								v54.Animator:Stop()
							end
						else
							return
						end
					end
				end
			elseif p51 == "AnimationBaseWalkSpeed" then
				local v55 = p_u_47:GetAttribute("AnimationBaseWalkSpeed")
				if typeof(v55) == "number" then
					v_u_49.Config.AnimationBaseWalkSpeed = v55
					return
				end
			elseif p51 == "ChaseState" then
				local v56 = p_u_47:GetAttribute("ChaseState") == "WindUp"
				if v56 ~= v_u_49.HoldIdle then
					v_u_49.HoldIdle = v56
					v_u_49.Moving = nil
				end
			end
		end)
		v_u_49.DestroyWatch = p_u_47.Destroying:Once(function()
			-- upvalues: (ref) v_u_39, (copy) p_u_47
			v_u_39(p_u_47)
		end)
		if not v_u_49.Building then
			v_u_49.Building = true
			v_u_49.Attempts = (v_u_49.Attempts or 0) + 1
			task.spawn(function()
				-- upvalues: (ref) v_u_46, (copy) v_u_49
				local v57 = v_u_46
				local v58 = v_u_49
				local v59, v60 = pcall(v57, v58)
				v_u_49.Building = nil
				if not v59 then
					warn((("[AnimalAnimationController] build failed for %*: %*"):format(v_u_49.Model.Name, v60)))
				end
			end)
		end
	else
		return
	end
end
local function v_u_68() -- name: sweepTag
	-- upvalues: (copy) v_u_1, (copy) v_u_11, (copy) v_u_61, (copy) v_u_46
	for _, v62 in v_u_1:GetTagged("AnimatedAnimal") do
		if not (v62:IsA("Model") and v62:IsDescendantOf(game)) then
			continue
		end
		local v_u_63 = v_u_11[v62]
		if v_u_63 == nil then
			v_u_61(v62)
		else
			if v_u_63.Animator ~= nil or v_u_63.Building or (v_u_63.Attempts or 0) >= 3 and (not v62.PrimaryPart and v62:FindFirstChildWhichIsA("BasePart", true) == nil) then
				continue
			end
			if v_u_63.Building then
				continue
			end
			v_u_63.Building = true
			v_u_63.Attempts = (v_u_63.Attempts or 0) + 1
			task.spawn(function()
				-- upvalues: (ref) v_u_46, (copy) v_u_63
				local v64 = v_u_46
				local v65 = v_u_63
				local v66, v67 = pcall(v64, v65)
				v_u_63.Building = nil
				if not v66 then
					warn((("[AnimalAnimationController] build failed for %*: %*"):format(v_u_63.Model.Name, v67)))
				end
			end)
		end
	end
end
function v10.Start() -- name: Start
	-- upvalues: (copy) v_u_1, (copy) v_u_61, (copy) v_u_39, (copy) v_u_3, (copy) v_u_68, (copy) v_u_11, (copy) v_u_7, (copy) v_u_15, (copy) v_u_8, (copy) v_u_9
	for _, v69 in v_u_1:GetTagged("AnimatedAnimal") do
		v_u_61(v69)
	end
	v_u_1:GetInstanceAddedSignal("AnimatedAnimal"):Connect(v_u_61)
	v_u_1:GetInstanceRemovedSignal("AnimatedAnimal"):Connect(v_u_39)
	local v_u_70 = 0
	local v_u_71 = 0
	local v_u_72 = 0
	local v_u_73 = 0
	v_u_3.Heartbeat:Connect(function(p74)
		-- upvalues: (ref) v_u_70, (ref) v_u_71, (ref) v_u_73, (ref) v_u_72, (ref) v_u_68, (ref) v_u_11, (ref) v_u_39, (ref) v_u_7, (ref) v_u_15, (ref) v_u_1, (ref) v_u_8, (ref) v_u_9
		v_u_70 = v_u_70 + p74
		local v75 = v_u_70 >= 2
		if v75 then
			v_u_70 = 0
		end
		v_u_71 = v_u_71 + p74
		local v76 = v_u_71 >= 0.5
		if v76 then
			v_u_71 = 0
		end
		v_u_73 = v_u_73 + p74
		local v77 = v_u_73 >= 0.1
		if v77 then
			v_u_73 = 0
		end
		local v78 = workspace.CurrentCamera
		if v78 then
			v78 = v78.CFrame.Position
		end
		v_u_72 = v_u_72 + p74
		if v_u_72 >= 2 then
			v_u_72 = 0
			task.spawn(v_u_68)
		end
		local v79 = os.clock()
		for v80, v81 in v_u_11 do
			local v82, v83, v84, v85, v86, v87, v88, v89, v90, v91, v92, v93, v94, v95, v96
			if v76 or v75 then
				local v97 = v80.Parent == nil
				if not v97 and v75 then
					v97 = not v80:IsDescendantOf(game)
				end
				if v97 then
					v81.OrphanSince = v81.OrphanSince or v79
					if v79 - v81.OrphanSince < 5 then
						continue
					end
					v_u_39(v80)
				else
					if v81.OrphanSince ~= nil and v75 then
						v81.OrphanSince = nil
					end
					v82 = v81.Animator
					if v82 == nil then
						continue
					end
					if v81.Static then
						if not (v75 and v80:IsDescendantOf(workspace)) then
							continue
						end
						v82:PlayIdle()
					else
						if not v76 then
							v83 = v81.Lod or 0
							v84 = v83 < 2 and v_u_7.IsCulled(v80) and 2 or v83
							if v84 == 1 and not v77 or v84 >= 2 then
								continue
							end
						end
						v85 = v81.Root
						if not (v85 and v85.Parent) then
							v85 = v_u_15(v80)
							v81.Root = v85
							if not v85 then
								continue
							end
						end
						if v76 and v78 then
							if not v81.Guard then
								v81.Guard = v_u_1:HasTag(v80, "ZoneGuard")
							end
							v86 = (v85.Position - v78).Magnitude
							v87 = v86 < 150 and 0 or (v86 < 350 and 1 or (v86 < 1000 and 2 or 3))
							v81.Lod = v81.Guard and v87 >= 3 and 2 or v87
						end
						v88 = not v81.Guard and ((v81.Lod or 0) < 3 and v_u_8.IsActive())
						if v88 then
							v88 = v_u_9.IsHidden(v80, v_u_8.HIDE_REASON)
						end
						if v88 then
							if v81.Paused then
								continue
							end
							v81.Paused = true
							v81.Moving = nil
							v82:Stop()
						else
							if v81.Paused then
								v81.Paused = false
								v81.Moving = nil
							end
							v89 = v81.Lod or 0
							v90 = v89 < 2 and v_u_7.IsCulled(v80) and 2 or v89
							if v90 == 1 and not (v77 or v76) or v90 == 2 and not v76 then
								continue
							end
							v91 = v80:GetAttribute("ClientMoveSpeed")
							if typeof(v91) ~= "number" then
								v92 = v85.AssemblyLinearVelocity
								v93 = v92.X
								v94 = v92.Z
								v91 = Vector3.new(v93, 0, v94).Magnitude
							end
							if v91 > 2 then
								v95 = not v81.HoldIdle
							else
								v95 = false
							end
							v96 = v95 ~= v81.Moving
							v81.Moving = v95
							if v95 then
								v82:PlayRun(v91)
							else
								if not (v96 or v76) then
									continue
								end
								v82:PlayIdle()
							end
						end
					end
				end
			else
				if v81.OrphanSince ~= nil then
					continue
				end
				v82 = v81.Animator
				if v82 == nil then
					continue
				end
				if v81.Static then
					if not (v75 and v80:IsDescendantOf(workspace)) then
						continue
					end
					v82:PlayIdle()
				else
					if not v76 then
						v83 = v81.Lod or 0
						v84 = v83 < 2 and v_u_7.IsCulled(v80) and 2 or v83
						if v84 == 1 and not v77 or v84 >= 2 then
							continue
						end
					end
					v85 = v81.Root
					if not (v85 and v85.Parent) then
						v85 = v_u_15(v80)
						v81.Root = v85
						if not v85 then
							continue
						end
					end
					if v76 and v78 then
						if not v81.Guard then
							v81.Guard = v_u_1:HasTag(v80, "ZoneGuard")
						end
						v86 = (v85.Position - v78).Magnitude
						v87 = v86 < 150 and 0 or (v86 < 350 and 1 or (v86 < 1000 and 2 or 3))
						v81.Lod = v81.Guard and v87 >= 3 and 2 or v87
					end
					v88 = not v81.Guard and ((v81.Lod or 0) < 3 and v_u_8.IsActive())
					if v88 then
						v88 = v_u_9.IsHidden(v80, v_u_8.HIDE_REASON)
					end
					if v88 then
						if v81.Paused then
							continue
						end
						v81.Paused = true
						v81.Moving = nil
						v82:Stop()
					else
						if v81.Paused then
							v81.Paused = false
							v81.Moving = nil
						end
						v89 = v81.Lod or 0
						v90 = v89 < 2 and v_u_7.IsCulled(v80) and 2 or v89
						if v90 == 1 and not (v77 or v76) or v90 == 2 and not v76 then
							continue
						end
						v91 = v80:GetAttribute("ClientMoveSpeed")
						if typeof(v91) ~= "number" then
							v92 = v85.AssemblyLinearVelocity
							v93 = v92.X
							v94 = v92.Z
							v91 = Vector3.new(v93, 0, v94).Magnitude
						end
						if v91 > 2 then
							v95 = not v81.HoldIdle
						else
							v95 = false
						end
						v96 = v95 ~= v81.Moving
						v81.Moving = v95
						if v95 then
							v82:PlayRun(v91)
						else
							if not (v96 or v76) then
								continue
							end
							v82:PlayIdle()
						end
					end
				end
			end
		end
	end)
end
return v10
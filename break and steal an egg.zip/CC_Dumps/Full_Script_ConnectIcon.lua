local v1 = script:FindFirstAncestor("Chrome")
local v2 = game:GetService("CorePackages")
local v_u_3 = require(v2.Packages.Cryo)
local v_u_4 = require(v2.Packages.Foundation)
local v_u_5 = require(v2.Packages.React)
local v_u_6 = require(v1.ChromeShared.Unibar.Constants)
local v7 = require(v1.ChromeShared.Service.ChromeUtils)
local v_u_8 = require(v2.Workspace.Packages.Chrome).Hooks.useMappedSignal
local v_u_9 = require(v1.Integrations.Party.usePartyIcon)
local v_u_10 = v7.MappedSignal
local v_u_11 = v_u_4.Hooks.useTokens
local v_u_12 = require(v2.Workspace.Packages.Chrome).UnibarStyle
local v_u_13 = require(v1.ChromeShared.Unibar.SubMenuContext)
local v_u_14 = require(v2.Workspace.Packages.AppChat.InExperienceAppChatModal)
local v15 = require(v2.Workspace.Packages.AppChat.getAppChatNavbarItemConfig)
local v_u_16 = require(v1.ChromeShared.Flags).FFlagTokenizeUnibarConstantsWithStyleProvider
local v_u_17 = require(v2.Workspace.Packages.SharedFlags).FFlagEnableChatIconUnibarDropdownFixEnabled
local v_u_18 = require(v2.Workspace.Packages.SocialExperiments).ArgoPartyExperimentation
local v_u_19 = v15()
local v_u_20 = v_u_19.icon.off
local v_u_21 = v_u_19.icon.on
local v_u_22 = {
	["integrationId"] = "",
	["shouldShowCustomBadge"] = true,
	["isSquadIndicatorEnabled"] = false
}
return function(p23) -- name: ConnectIcon
	-- upvalues: (copy) v_u_3, (copy) v_u_22, (copy) v_u_11, (copy) v_u_16, (copy) v_u_12, (copy) v_u_6, (copy) v_u_5, (copy) v_u_14, (copy) v_u_10, (copy) v_u_8, (copy) v_u_9, (copy) v_u_21, (copy) v_u_20, (copy) v_u_13, (copy) v_u_17, (copy) v_u_4, (copy) v_u_18, (copy) v_u_19
	local v_u_24 = v_u_3.Dictionary.union(v_u_22, p23)
	local v_u_25 = v_u_11()
	local v26
	if v_u_16 then
		v26 = v_u_12.use().ICON_SIZE
	else
		v26 = v_u_6.ICON_SIZE
	end
	local v27, v_u_28 = v_u_5.useState(v_u_14.default.unreadCount)
	if v_u_24.shouldShowCustomBadge then
		v_u_5.useEffect(function()
			-- upvalues: (ref) v_u_14, (copy) v_u_28
			local v_u_30 = v_u_14.default.unreadCountSignal.Event:Connect(function(p29)
				-- upvalues: (ref) v_u_28
				v_u_28(p29)
			end)
			return function()
				-- upvalues: (copy) v_u_30
				v_u_30:Disconnect()
			end
		end, { v_u_28 })
	else
		v27 = 0
	end
	local v31 = nil
	local v32, v_u_33
	if v_u_24.isSquadIndicatorEnabled then
		v32, v_u_33 = v_u_5.useState(v_u_14.default.currentSquadId)
	else
		v_u_33 = nil
		v32 = nil
	end
	v_u_5.useEffect(function()
		-- upvalues: (copy) v_u_24, (ref) v_u_14, (ref) v_u_33
		if not v_u_24.isSquadIndicatorEnabled then
			return function() end
		end
		local v_u_35 = v_u_14.default.currentSquadIdSignal.Event:Connect(function(p34)
			-- upvalues: (ref) v_u_33
			v_u_33(p34)
		end)
		return function()
			-- upvalues: (copy) v_u_35
			v_u_35:Disconnect()
		end
	end, { v_u_24.isSquadIndicatorEnabled, v_u_33 })
	if v_u_24.isSquadIndicatorEnabled then
		if v32 == "" then
			if v27 > 0 then
				v31 = v_u_25.Color.System.Contrast
			end
		else
			v31 = v_u_25.Color.System.Success
		end
	end
	local v36
	if v_u_24.isSquadIndicatorEnabled then
		v36 = v31
	else
		v36 = v27 > 0
	end
	local v37 = v_u_8((v_u_10.new(v_u_14.default.visibilitySignal.Event, function(_)
		-- upvalues: (ref) v_u_14
		return v_u_14:getVisible()
	end)))
	local v38 = v_u_9
	local v39 = 24
	local v40
	if v37 then
		v40 = v_u_21
	else
		v40 = v_u_20
	end
	local v41 = v38(v26, v39, v40)
	local v42 = v_u_5.useContext(v_u_13)
	local v43
	if v_u_17 then
		local v_u_44 = v_u_25.Color.Content.Default.Transparency
		if v42 then
			v43 = v42:map(function(p45)
				-- upvalues: (copy) v_u_25, (copy) v_u_44
				return {
					["Color3"] = v_u_25.Color.Content.Default.Color3,
					["Transparency"] = v_u_44 + (1 - v_u_44) * (1 - p45)
				}
			end)
		else
			v43 = v_u_25.Color.Content.Default
		end
	else
		v43 = nil
	end
	local v46 = v_u_5.createElement
	local v47 = v_u_4.View
	local v48 = {
		["Size"] = UDim2.new(0, v26, 0, v26)
	}
	local v49 = {}
	local v50
	if v_u_18.getIsRenameEnabled() then
		local v51 = v_u_5.createElement
		local v52 = v_u_4.Icon
		local v53 = {
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["name"] = v_u_19.icon
		}
		local v54
		if v37 then
			v54 = v_u_4.Enums.IconVariant.Filled
		else
			v54 = v_u_4.Enums.IconVariant.Regular
		end
		v53.variant = v54
		if not v_u_17 then
			v43 = nil
		end
		v53.style = v43
		v50 = v51(v52, v53)
	else
		local v55 = v_u_5.createElement
		local v56 = v_u_4.Image
		local v58 = {
			["AnchorPoint"] = Vector2.new(0.5, 0.5),
			["Position"] = UDim2.fromScale(0.5, 0.5),
			["Size"] = v41.size:map(function(p57)
				return UDim2.fromOffset(p57, p57)
			end)
		}
		local v59
		if v41.image.backgroundColor then
			v59 = {
				["Color3"] = v41.image.backgroundColor
			}
			local v60
			if v42 then
				local v_u_61 = 0
				v60 = v42:map(function(p62)
					-- upvalues: (copy) v_u_61
					return v_u_61 + (1 - v_u_61) * (1 - p62)
				end)
			else
				v60 = 0
			end
			v59.Transparency = v60
		else
			v59 = v_u_25.Color.None
		end
		v58.backgroundStyle = v59
		v58.cornerRadius = UDim.new(0, v_u_25.Radius.Circle)
		v58.Image = v41.image.thumbnail
		local v63 = {
			["Color3"] = v_u_25.Color.Content.Emphasis.Color3
		}
		local v_u_64 = v_u_25.Color.Content.Emphasis.Transparency
		if v42 then
			v_u_64 = v42:map(function(p65)
				-- upvalues: (copy) v_u_64
				return v_u_64 + (1 - v_u_64) * (1 - p65)
			end)
		end
		v63.Transparency = v_u_64
		v58.imageStyle = v63
		v50 = v55(v56, v58)
	end
	v49.Icon = v50
	local v66
	if v36 then
		local v67 = v_u_5.createElement
		local v68 = v_u_4.View
		local v69 = {
			["Position"] = nil,
			["backgroundStyle"] = nil,
			["stroke"] = nil,
			["tag"] = nil,
			["ZIndex"] = 2,
			["Position"] = UDim2.new(1, -v_u_25.Stroke.Thicker, 0, v_u_25.Stroke.Thicker)
		}
		local v70
		if v_u_24.isSquadIndicatorEnabled then
			v70 = {
				["Color3"] = v31.Color3
			}
			local v_u_71 = v31.Transparency
			if v42 then
				v_u_71 = v42:map(function(p72)
					-- upvalues: (copy) v_u_71
					return v_u_71 + (1 - v_u_71) * (1 - p72)
				end)
			end
			v70.Transparency = v_u_71
		else
			v70 = {
				["Color3"] = v_u_25.Color.System.Contrast.Color3
			}
			local v_u_73 = v_u_25.Color.System.Contrast.Transparency
			if v42 then
				v_u_73 = v42:map(function(p74)
					-- upvalues: (copy) v_u_73
					return v_u_73 + (1 - v_u_73) * (1 - p74)
				end)
			end
			v70.Transparency = v_u_73
		end
		v69.backgroundStyle = v70
		local v75 = {
			["Color"] = v_u_25.Color.Surface.Surface_0.Color3
		}
		local v_u_76 = v_u_25.Color.Surface.Surface_0.Transparency
		if v42 then
			v_u_76 = v42:map(function(p77)
				-- upvalues: (copy) v_u_76
				return v_u_76 + (1 - v_u_76) * (1 - p77)
			end)
		end
		v75.Transparency = v_u_76
		v75.Thickness = v_u_25.Stroke.Thicker
		v69.stroke = v75
		v69.tag = {
			["anchor-top-right radius-circle size-200"] = true,
			["stroke-thicker"] = not v_u_17
		}
		v66 = v67(v68, v69)
	else
		v66 = nil
	end
	v49.Badge = v66
	return v46(v47, v48, v49)
end
local v1 = {}
local v_u_2 = game:GetService("Players").LocalPlayer
function v1.ConfirmWindow() -- name: ConfirmWindow
	-- upvalues: (copy) v_u_2
	local v3 = 1 + (v_u_2 and v_u_2:GetNetworkPing() or 0) * 3
	return math.min(v3, 8)
end
local v_u_4 = {}
local v_u_5 = {}
local v_u_6 = {}
local v_u_7 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_8 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_9 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_10 = 0
local function v_u_17(p11) -- name: prune
	-- upvalues: (copy) v_u_7, (copy) v_u_2
	local v12 = v_u_7[p11]
	if v12 then
		local v13 = os.clock()
		local v14 = 1 + (v_u_2 and v_u_2:GetNetworkPing() or 0) * 3
		local v15 = math.min(v14, 8)
		for v16 = #v12, 1, -1 do
			if v15 >= v13 - v12[v16].At then
				continue
			end
			table.remove(v12, v16)
		end
		if #v12 == 0 then
			v_u_7[p11] = nil
		end
	end
end
local function v_u_25(p18, p19) -- name: settle
	-- upvalues: (copy) v_u_7
	local v20 = v_u_7[p18]
	if not v20 or #v20 == 0 then
		return nil
	end
	local v21 = p19 == nil and 1 or nil
	if p19 ~= nil then
		for v22, v23 in v20 do
			if v23.Id ~= p19 then
				continue
			end
			v21 = v22
		end
	end
	if v21 == nil then
		return nil
	end
	local v24 = table.remove(v20, v21)
	if #v20 == 0 then
		v_u_7[p18] = nil
	end
	return v24
end
function v1.Announce(p26, p27) -- name: Announce
	-- upvalues: (copy) v_u_17, (ref) v_u_10, (copy) v_u_7, (copy) v_u_8, (copy) v_u_4
	v_u_17(p26)
	v_u_10 = v_u_10 + 1
	local v28 = v_u_7[p26] or {}
	local v29 = {
		["Id"] = v_u_10,
		["At"] = os.clock(),
		["Damage"] = p27
	}
	table.insert(v28, v29)
	v_u_7[p26] = v28
	local v30 = p26:GetAttribute("Health") or 0
	local v31 = v_u_8[p26]
	if v31 ~= nil then
		if v30 <= v31 then
			v_u_8[p26] = nil
		else
			v30 = v31
		end
	end
	local v32 = v_u_7[p26]
	if v32 then
		for _, v33 in v32 do
			v30 = v30 - v33.Damage
		end
	end
	local v34 = math.max(0, v30)
	for _, v35 in v_u_4 do
		task.spawn(v35, p26, v34, p27)
	end
	return v_u_10
end
function v1.OnHit(p36) -- name: OnHit
	-- upvalues: (copy) v_u_4
	local v37 = v_u_4
	table.insert(v37, p36)
end
function v1.Confirm(p38, p39, p40) -- name: Confirm
	-- upvalues: (copy) v_u_25, (copy) v_u_8, (copy) v_u_9, (copy) v_u_6
	local v41 = v_u_25(p38, p39)
	if p40 < (p38:GetAttribute("Health") or 0) then
		local v42 = v_u_8[p38]
		local v43 = v_u_8
		local v44
		if v42 then
			v44 = math.min(v42, p40)
		else
			v44 = p40
		end
		v43[p38] = v44
	end
	if not (v41 and v41.Claimed) then
		local v45 = v_u_9[p38] or {}
		local v46 = {
			["Health"] = p40,
			["At"] = os.clock()
		}
		table.insert(v45, v46)
		v_u_9[p38] = v45
	end
	for _, v47 in v_u_6 do
		task.spawn(v47, p38)
	end
end
function v1.OnConfirm(p48) -- name: OnConfirm
	-- upvalues: (copy) v_u_6
	local v49 = v_u_6
	table.insert(v49, p48)
end
function v1.Reject(p50, p51) -- name: Reject
	-- upvalues: (copy) v_u_25, (copy) v_u_5
	v_u_25(p50, p51)
	for _, v52 in v_u_5 do
		task.spawn(v52, p50)
	end
end
function v1.OnReject(p53) -- name: OnReject
	-- upvalues: (copy) v_u_5
	local v54 = v_u_5
	table.insert(v54, p53)
end
function v1.ConsumeConfirm(p55) -- name: ConsumeConfirm
	-- upvalues: (copy) v_u_9, (copy) v_u_2, (copy) v_u_17, (copy) v_u_7
	local v56 = v_u_9[p55]
	if v56 then
		local v57 = p55:GetAttribute("Health") or 0
		local v58 = os.clock()
		local v59 = 1 + (v_u_2 and v_u_2:GetNetworkPing() or 0) * 3
		local v60 = math.min(v59, 8)
		local v61 = false
		for v62 = #v56, 1, -1 do
			local v63 = v56[v62]
			if v60 < v58 - v63.At then
				table.remove(v56, v62)
			else
				if v57 > v63.Health then
					continue
				end
				table.remove(v56, v62)
				v61 = true
			end
		end
		if #v56 == 0 then
			v_u_9[p55] = nil
		end
		if v61 then
			return true
		end
	end
	v_u_17(p55)
	local v64 = v_u_7[p55]
	if v64 then
		for _, v65 in v64 do
			if v65.Claimed then
				continue
			end
			v65.Claimed = true
			return true
		end
	end
	return false
end
function v1.GetDisplayHealth(p66) -- name: GetDisplayHealth
	-- upvalues: (copy) v_u_17, (copy) v_u_8, (copy) v_u_7
	v_u_17(p66)
	local v67 = p66:GetAttribute("Health") or 0
	local v68 = v_u_8[p66]
	if v68 ~= nil then
		if v67 <= v68 then
			v_u_8[p66] = nil
		else
			v67 = v68
		end
	end
	local v69 = v_u_7[p66]
	if v69 then
		for _, v70 in v69 do
			v67 = v67 - v70.Damage
		end
	end
	return math.max(0, v67)
end
function v1.Forget(p71) -- name: Forget
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_9
	v_u_7[p71] = nil
	v_u_8[p71] = nil
	v_u_9[p71] = nil
end
return v1
local v_u_1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = game:GetService("TextChatService")
local v_u_4 = require(v2.Shared.ChatTagConfig)
local v_u_5 = require(v2.Shared.NameEmojiConfig)
local v6 = {}
local v_u_7 = true
local function v_u_9(p8) -- name: escape
	return p8:gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"):gsub("\"", "&quot;"):gsub("\'", "&apos;")
end
local function v_u_27(p10) -- name: onIncoming
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (copy) v_u_5, (copy) v_u_9, (ref) v_u_7
	local v11 = p10.TextSource
	local v12
	if v11 then
		local v13 = v_u_1:GetPlayerByUserId(v11.UserId)
		if v13 then
			local v14 = v13:GetAttribute(v_u_4.AttributeName)
			if type(v14) == "string" then
				v12 = v_u_4.Tags[v14]
			else
				v12 = nil
			end
		else
			v12 = nil
		end
	else
		v12 = nil
	end
	local v15 = p10.PrefixText
	local v16 = p10.TextSource
	if v16 then
		v16 = v_u_5.For(v16.UserId)
	end
	local v17
	if v16 then
		local v18, v19 = string.match(v15, "^(.-)(:?)$")
		v15 = ("%* %*%*"):format(v18, v16, v19)
		v17 = true
	else
		v17 = false
	end
	local v20 = p10.TextSource
	local v21 = v20 and v_u_5.GradientFor(v20.UserId) or nil
	if v12 or (v17 or v21) then
		local v22 = Instance.new("TextChatMessageProperties")
		local v23 = not v12 and "" or ("<b>%*</b> "):format((v_u_9(v12.Text)))
		local v24
		if v_u_7 then
			if v12 and v12.Gradient then
				v24 = v12.Gradient
				local _ = v12.GradientRotation or 0
			else
				local v25 = p10.TextSource
				local v26 = v25 and v_u_5.GradientFor(v25.UserId) or nil
				if v26 then
					v24 = v26.Gradient
					local _ = v26.Rotation or 0
				else
					v24 = nil
				end
			end
		else
			v24 = nil
		end
		if v24 then
			v22.PrefixText = ("<font color=\"#FFFFFF\">%*%*</font>"):format(v23, v15)
			return v22
		elseif v12 then
			v22.PrefixText = ("<font color=\"%*\">%*</font>%*"):format(v12.Color, v23, v15)
			return v22
		elseif v21 then
			v22.PrefixText = ("<font color=\"%*\">%*</font>"):format(v21.Color, v15)
			return v22
		else
			v22.PrefixText = v15
			return v22
		end
	else
		return nil
	end
end
local function v_u_43(p28) -- name: onChatWindowAdded
	-- upvalues: (copy) v_u_1, (copy) v_u_4, (ref) v_u_7, (copy) v_u_5, (copy) v_u_3
	local v29 = p28.TextSource
	local v30
	if v29 then
		local v31 = v_u_1:GetPlayerByUserId(v29.UserId)
		if v31 then
			local v32 = v31:GetAttribute(v_u_4.AttributeName)
			if type(v32) == "string" then
				v30 = v_u_4.Tags[v32]
			else
				v30 = nil
			end
		else
			v30 = nil
		end
	else
		v30 = nil
	end
	local v_u_33, v_u_34
	if v_u_7 then
		if v30 and v30.Gradient then
			v_u_33 = v30.Gradient
			v_u_34 = v30.GradientRotation or 0
		else
			local v35 = p28.TextSource
			local v36 = v35 and v_u_5.GradientFor(v35.UserId) or nil
			if v36 then
				v_u_33 = v36.Gradient
				v_u_34 = v36.Rotation or 0
			else
				v_u_33 = nil
				v_u_34 = 0
			end
		end
	else
		v_u_33 = nil
		v_u_34 = 0
	end
	if not v_u_33 then
		return nil
	end
	local v_u_37 = v_u_3:FindFirstChildOfClass("ChatWindowConfiguration")
	if not v_u_37 then
		return nil
	end
	local v_u_38 = v_u_37:DeriveNewMessageProperties()
	local v41, v42 = pcall(function()
		-- upvalues: (copy) v_u_37, (copy) v_u_33, (copy) v_u_34, (copy) v_u_38
		local v39 = v_u_37:DeriveNewMessageProperties()
		local v40 = Instance.new("UIGradient")
		v40.Color = v_u_33
		v40.Rotation = v_u_34
		v40.Parent = v39
		v_u_38.PrefixTextProperties = v39
	end)
	if not v41 then
		v_u_7 = false
		warn((("[ChatTagController] chat gradients unavailable, using plain colour: %*"):format(v42)))
	end
	return v_u_38
end
function v6.Start() -- name: Start
	-- upvalues: (copy) v_u_4, (copy) v_u_3, (copy) v_u_27, (copy) v_u_43
	if v_u_4.Enabled then
		if v_u_3.ChatVersion == Enum.ChatVersion.TextChatService then
			v_u_3.OnIncomingMessage = v_u_27
			v_u_3.OnChatWindowAdded = v_u_43
		else
			warn("[ChatTagController] legacy chat is active \226\128\148 chat tags need TextChatService")
		end
	else
		return
	end
end
return v6
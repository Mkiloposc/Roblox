local v1 = game:GetService("ReplicatedStorage")
local v_u_2 = game:GetService("RunService")
local v_u_3 = game:GetService("TweenService")
local v_u_4 = require(v1.Shared.BackpackUiConfig)
local v5 = {}
local v_u_6 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_7 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_8 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_9 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_10 = setmetatable({}, {
	["__mode"] = "k"
})
local v_u_11 = TweenInfo.new(v_u_4.LockedTintFadeTime, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
function v5.SetLockedTint(p_u_12, p13) -- name: SetLockedTint
	-- upvalues: (copy) v_u_9, (copy) v_u_6, (copy) v_u_10, (copy) v_u_3, (copy) v_u_11, (copy) v_u_4
	if v_u_9[p_u_12] == true == p13 then
		return
	else
		if p13 then
			v_u_9[p_u_12] = true
			if v_u_6[p_u_12] == nil then
				v_u_6[p_u_12] = {
					["Color"] = p_u_12.BackgroundColor3,
					["Transparency"] = p_u_12.BackgroundTransparency
				}
			end
		else
			v_u_9[p_u_12] = nil
		end
		local v14 = v_u_6[p_u_12]
		if v14 then
			local v15 = v_u_10[p_u_12]
			if v15 then
				v15:Cancel()
			end
			local v16 = v_u_3
			local v17 = v_u_11
			local v18 = {}
			local v19
			if p13 then
				v19 = v_u_4.LockedTintColor
			else
				v19 = v14.Color
			end
			v18.BackgroundColor3 = v19
			local v20
			if p13 then
				v20 = v_u_4.LockedTintTransparency
			else
				v20 = v14.Transparency
			end
			v18.BackgroundTransparency = v20
			local v21 = v16:Create(p_u_12, v17, v18)
			v_u_10[p_u_12] = v21
			if not p13 then
				v21.Completed:Once(function(p22)
					-- upvalues: (ref) v_u_9, (copy) p_u_12, (ref) v_u_6, (ref) v_u_10
					if p22 == Enum.PlaybackState.Completed and not v_u_9[p_u_12] then
						v_u_6[p_u_12] = nil
						v_u_10[p_u_12] = nil
					end
				end)
			end
			v21:Play()
		end
	end
end
function v5.Shake(p_u_23) -- name: Shake
	-- upvalues: (copy) v_u_7, (copy) v_u_8, (copy) v_u_4, (copy) v_u_2
	local v24 = v_u_7[p_u_23]
	if v24 then
		v24:Disconnect()
	else
		v_u_8[p_u_23] = p_u_23.Rotation
	end
	local v_u_25 = v_u_8[p_u_23] or 0
	local v_u_26 = v_u_4.ShakeTime
	local v_u_27 = v_u_4.ShakeAngle
	local v_u_28 = v_u_4.ShakeCycles
	local v_u_29 = 0
	local v_u_30 = nil
	v_u_30 = v_u_2.RenderStepped:Connect(function(p31)
		-- upvalues: (ref) v_u_29, (copy) v_u_26, (copy) p_u_23, (ref) v_u_30, (ref) v_u_7, (ref) v_u_8, (copy) v_u_25, (copy) v_u_27, (copy) v_u_28
		v_u_29 = v_u_29 + p31
		if v_u_26 <= v_u_29 or p_u_23.Parent == nil then
			v_u_30:Disconnect()
			if v_u_7[p_u_23] == v_u_30 then
				v_u_7[p_u_23] = nil
				v_u_8[p_u_23] = nil
			end
			p_u_23.Rotation = v_u_25
		else
			local v32 = v_u_29 / v_u_26
			local v33 = p_u_23
			local v34 = v_u_25
			local v35 = v_u_27 * (1 - v32)
			local v36 = v32 * v_u_28 * 2 * 3.141592653589793
			v33.Rotation = v34 + v35 * math.sin(v36)
		end
	end)
	v_u_7[p_u_23] = v_u_30
end
return v5
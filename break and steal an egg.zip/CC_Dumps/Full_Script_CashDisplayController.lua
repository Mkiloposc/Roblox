local v1 = game:GetService("Players")
local v2 = game:GetService("ReplicatedStorage")
local v_u_3 = require(v2.Shared.CountingNumber)
local v_u_4 = require(v2.Shared.FormatNumber)
local v_u_5 = require(script.Parent.Parent.Modules.MainGui)
local v6 = {}
local v_u_7 = v1.LocalPlayer
local v_u_8 = nil
local v_u_9 = nil
function v6.Start() -- name: Start
	-- upvalues: (copy) v_u_3, (ref) v_u_8, (copy) v_u_4, (ref) v_u_9, (copy) v_u_7, (copy) v_u_5
	local v_u_14 = v_u_3.new(function(p10)
		-- upvalues: (ref) v_u_8, (ref) v_u_4
		if v_u_8 and v_u_8.Parent then
			local v11 = v_u_4.Short
			local v12 = p10 + 0.5
			local v13 = ("$%*"):format((v11((math.floor(v12)))))
			if v_u_8.Text ~= v13 then
				v_u_8.Text = v13
			end
		end
	end)
	local v_u_19 = v_u_3.new(function(p15)
		-- upvalues: (ref) v_u_9, (ref) v_u_4
		if v_u_9 and v_u_9.Parent then
			local v16 = v_u_4.Short
			local v17 = p15 + 0.5
			local v18 = ("+$%*/s"):format((v16((math.floor(v17)))))
			if v_u_9.Text ~= v18 then
				v_u_9.Text = v18
			end
		end
	end)
	v_u_7:GetAttributeChangedSignal("Cash"):Connect(function()
		-- upvalues: (copy) v_u_14, (ref) v_u_7
		v_u_14:Set(v_u_7:GetAttribute("Cash") or 0)
	end)
	v_u_7:GetAttributeChangedSignal("CashPerSecond"):Connect(function()
		-- upvalues: (copy) v_u_19, (ref) v_u_7
		v_u_19:Set(v_u_7:GetAttribute("CashPerSecond") or 0)
	end)
	v_u_5.Observe(function(p20)
		-- upvalues: (ref) v_u_8, (ref) v_u_9, (copy) v_u_14, (ref) v_u_7, (copy) v_u_19
		local v21 = p20:FindFirstChild("Currencies")
		if v21 then
			v21 = v21:FindFirstChild("Cash")
		end
		if v21 then
			local v22 = v21:FindFirstChild("Amount")
			local v23 = v21:FindFirstChild("Gain")
			if not (v22 and v22:IsA("TextLabel")) then
				v22 = nil
			end
			v_u_8 = v22
			if not (v23 and v23:IsA("TextLabel")) then
				v23 = nil
			end
			v_u_9 = v23
			v_u_14:Snap(v_u_7:GetAttribute("Cash") or 0)
			v_u_19:Snap(v_u_7:GetAttribute("CashPerSecond") or 0)
		else
			v_u_8 = nil
			v_u_9 = nil
		end
	end)
end
return v6
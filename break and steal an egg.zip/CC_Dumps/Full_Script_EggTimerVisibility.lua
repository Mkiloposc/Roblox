local v1 = {}
local v_u_2 = game:GetService("Players").LocalPlayer
function v1.ShouldShow(p3) -- name: ShouldShow
	-- upvalues: (copy) v_u_2
	return p3:GetAttribute("OwnerUserId") == v_u_2.UserId
end
return v1